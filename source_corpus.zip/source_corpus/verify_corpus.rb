#!/usr/bin/env ruby
# frozen_string_literal: true

require "digest"
require "csv"
require "json"

path = File.join(__dir__, "corpus.jsonl")
required = %w[
  item_id title text source_url canonical_url source_revision_id retrieved_at
  license_id license_url source_terms_url attribution_text provider genre_id
  domain_id split sha256
].freeze

records = File.foreach(path, chomp: true).with_index(1).map do |line, number|
  record = JSON.parse(line)
  missing = required.select { |key| record[key].nil? || record[key].to_s.empty? }
  abort "line #{number}: missing #{missing.join(', ')}" unless missing.empty?

  digest = Digest::SHA256.hexdigest(record.fetch("text"))
  abort "line #{number}: text hash mismatch" unless digest == record.fetch("sha256")
  abort "line #{number}: redistribution not approved" unless record["redistribution_allowed"] == true
  abort "line #{number}: derivatives not approved" unless record["derivative_allowed"] == true
  abort "line #{number}: license review not passed" unless record["license_review"] == "pass"

  record
rescue JSON::ParserError => e
  abort "line #{number}: invalid JSON (#{e.message})"
end

abort "expected 1,000 records, found #{records.length}" unless records.length == 1_000

ids = records.map { |record| record.fetch("item_id") }
urls = records.map { |record| record.fetch("source_url") }
hashes = records.map { |record| record.fetch("sha256") }

abort "duplicate item_id" unless ids.uniq.length == records.length
abort "duplicate source_url" unless urls.uniq.length == records.length
abort "duplicate text hash" unless hashes.uniq.length == records.length

metadata_ids = CSV.read(
  File.join(__dir__, "metadata.csv"),
  headers: true,
  encoding: "UTF-8"
).map { |row| row.fetch("item_id") }
abort "metadata.csv does not match corpus.jsonl" unless metadata_ids == ids

summary = JSON.parse(File.read(File.join(__dir__, "summary.json")))
abort "summary record count mismatch" unless summary["records"] == records.length

corpus_digest = Digest::SHA256.file(path).hexdigest
abort "summary corpus hash mismatch" unless summary["corpus_sha256"] == corpus_digest

puts "PASS: #{records.length} records; metadata, permissions, uniqueness, text hashes, and corpus files verified."
