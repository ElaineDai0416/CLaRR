# Data licenses and attribution

The source texts in `corpus.jsonl` remain governed by their original licenses
or public-domain status. The repository's software license does not replace or
override those terms.

## License inventory

| License/status | Records | Required action |
|---|---:|---|
| US government public domain | 383 | Retain provenance; confirm any item-specific notices before downstream reuse. |
| CC BY-SA 4.0 | 250 | Give attribution, link the license, indicate changes, and preserve share-alike obligations for adaptations. |
| CC BY 4.0 | 248 | Give attribution, link the license, and indicate changes. |
| CC BY 2.5 | 116 | Give attribution and link the license. |
| CC0 1.0 | 3 | Attribution is not legally required, but provenance is retained for research transparency. |

Every record contains:

- the original source and canonical URL;
- a source revision identifier and retrieval timestamp;
- an attribution statement;
- a license identifier and license URL;
- the source provider's terms URL;
- explicit redistribution and derivative-use review fields; and
- a SHA-256 digest of the distributed text.

All 1,000 released records passed the corpus's license review and are marked
`redistribution_allowed: true` and `derivative_allowed: true`. Third-party
material identified during corpus preparation was removed, as recorded by
`third_party_material_removed: true`.

The metadata is supplied to support compliance and reproducibility; it is not
legal advice. Users remain responsible for following the item-level terms and
for checking whether source terms have changed.

