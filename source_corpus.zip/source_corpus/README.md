# CLaRR source-text corpus

This directory contains the 1,000 English source texts used in the CLaRR
experiments. Each JSONL record includes the source passage together with its
provenance, attribution, revision, license, and integrity metadata.

## Contents

- `corpus.jsonl`: 1,000 records, one JSON object per line. This is the
  machine-readable experimental corpus and includes the source text.
- `metadata.csv`: a text-free index for browsing provenance and license fields.
- `summary.json`: corpus-level counts used by the experimental data pipeline.
- `DATA_LICENSES.md`: license and attribution rules for the source texts.
- `verify_corpus.rb`: offline integrity and metadata checks.
- `CHECKSUMS.sha256`: file-level checksums for the release.

## Corpus composition

- 1,000 unique source texts and 1,000 unique source URLs;
- 221,381 words in total, with 150--509 words per record;
- five domains with 200 records each: computing/AI/engineering,
  economics/finance/social science, law/public policy, medicine/health, and
  natural science/environment;
- four genres with 250 records each: encyclopedia, institutional guidance,
  public explainer/news, and scholarly abstract;
- 200 development, 200 pilot, and 600 confirmatory records.

## JSONL fields

Important fields include `item_id`, `title`, `text`, `domain_id`, `topic_id`,
`genre_id`, `split`, `provider`, `authors`, `source_url`, `canonical_url`,
`source_revision_id`, `retrieved_at`, `doi`, `pmcid`, `license_id`,
`license_url`, `source_terms_url`, `attribution_text`,
`redistribution_allowed`, `derivative_allowed`, `third_party_material_removed`,
`word_count`, and `sha256`.

The `sha256` value is computed from the UTF-8 content of the `text` field, not
from the serialized JSON line.

## Verification

From this directory, run:

```bash
ruby verify_corpus.rb
shasum -a 256 -c CHECKSUMS.sha256
```

The verifier requires only Ruby's standard library and performs no network
requests.

## Citation and reuse

This directory is a collection of third-party texts under multiple licenses.
There is no single blanket license for the collection's contents. Before
reusing a record, follow its `license_id`, `license_url`, `source_terms_url`,
and `attribution_text`. See `DATA_LICENSES.md` for the license breakdown.

When citing the CLaRR experimental corpus, cite the repository release and the
original source identified in each record. The repository citation metadata
will be finalized with the paper release.

