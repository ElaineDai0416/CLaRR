# CLaRR V4

This repository contains one implementation version only: **CLaRR V4.2.1**.
It provides the main method and the three controlled module ablations used by
the experiment.

## Public entry points

- `CLaRR_v4.py`: full CLaRR V4 method.
- `CLaRR_ablation_v4.py`: V4 ablation runner with `no_icl`, `no_ecl`, and
  `no_schema_support` conditions.
- `scripts/run_experiment_v4.sh`: run the main method followed by all three
  ablations.

The `internal/` directory contains the required implementation modules and ECL
rubrics. It is part of the single V4 runtime and does not expose older releases.

## Installation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export LLM_API_KEY="your-key"
export LLM_BASE_URL="https://api.deepseek.com"
export LLM_MODEL="deepseek-v4-flash"
```

## Main method

```bash
python3 CLaRR_v4.py --article A01 --readers P-L-E
```

## Ablations

```bash
python3 CLaRR_ablation_v4.py --variant no_icl --article A01 --readers P-L-E
python3 CLaRR_ablation_v4.py --variant no_ecl --article A01 --readers P-L-E
python3 CLaRR_ablation_v4.py --variant no_schema_support --article A01 --readers P-L-E
```

Use `CLARR_ARTICLES_FILE`, `CLARR_READERS_FILE`, `CLARR_CLAIMS_FILE`, and
`CLARR_SIMPLIFICATIONS_FILE` to replace the synthetic example data. Outputs go
to `results/` unless `CLARR_OUTPUT_DIR` or `--output-dir` is supplied.

## Repository layout

```text
CLaRR-V4/
├── CLaRR_v4.py
├── CLaRR_ablation_v4.py
├── scripts/
├── examples/
└── internal/
```

The example article and claim contract are synthetic. The research corpus and
historical model outputs are intentionally excluded. The archived 200-article
run did not record a source commit hash, so this package is the frozen V4.2.1
reference implementation rather than a claim of byte-identical reproduction.
