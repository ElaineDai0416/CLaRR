#!/usr/bin/env python3
"""Public entry point for the CLaRR V4 main method."""

from __future__ import annotations

import os
import sys
import textwrap
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INTERNAL = ROOT / "internal"
EXAMPLES = ROOT / "examples"


def configure_paths() -> None:
    os.environ.setdefault("CLARR_ARTICLES_FILE", str(EXAMPLES / "articles.json"))
    os.environ.setdefault("CLARR_READERS_FILE", str(EXAMPLES / "readers.json"))
    os.environ.setdefault("CLARR_CLAIMS_FILE", str(EXAMPLES / "claims.json"))
    os.environ.setdefault(
        "CLARR_SIMPLIFICATIONS_FILE", str(EXAMPLES / "simplifications.json")
    )
    os.environ.setdefault("CLARR_OUTPUT_DIR", str(ROOT / "results" / "main"))
    os.environ.setdefault("CLARR_V2_CACHE_DIR", str(ROOT / ".cache" / "main"))
    os.environ.setdefault("LLM_RUN_TAG", "clarr-v4-main")


if __name__ == "__main__":
    configure_paths()
    sys.path.insert(0, str(INTERNAL))
    os.environ["LLM_THINKING"] = "disabled"

    import core
    import cost_v4

    cost_v4.apply_v4()
    source = Path(core.__file__).read_text(encoding="utf-8")
    marker = 'if __name__ == "__main__":'
    lines = source.split("\n")
    indices = [index for index, line in enumerate(lines) if line.rstrip() == marker]
    if not indices:
        raise RuntimeError("V4 core entry point not found")
    main_block = textwrap.dedent("\n".join(lines[indices[-1] + 1 :]))
    exec(compile(main_block, core.__file__, "exec"), core.__dict__)
