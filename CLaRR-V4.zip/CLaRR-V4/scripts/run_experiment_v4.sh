#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${LLM_API_KEY:?Set LLM_API_KEY before running the V4 experiment}"

python3 "$ROOT/CLaRR_v4.py" "$@"
for variant in no_icl no_ecl no_schema_support; do
  python3 "$ROOT/CLaRR_ablation_v4.py" --variant "$variant" "$@"
done
