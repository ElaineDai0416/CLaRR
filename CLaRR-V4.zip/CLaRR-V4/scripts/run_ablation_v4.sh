#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VARIANT="${1:?Usage: run_ablation_v4.sh <no_icl|no_ecl|no_schema_support> [options]}"
shift
: "${LLM_API_KEY:?Set LLM_API_KEY before running the V4 ablation}"

python3 "$ROOT/CLaRR_ablation_v4.py" --variant "$VARIANT" "$@"
