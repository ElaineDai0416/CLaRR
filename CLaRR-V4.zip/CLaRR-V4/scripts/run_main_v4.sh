#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${LLM_API_KEY:?Set LLM_API_KEY before running CLaRR V4}"

python3 "$ROOT/CLaRR_v4.py" "$@"
