"""Unified, fail-closed orchestration for the complete CLAP repair method.

The content-fidelity, ICL/IL, and schema-support modules already share a
target-scoped sentence-patch controller in :mod:`fidelity_repair`.  ECL uses a
different target namespace (failed structure dimensions and paragraphs).  This
module composes the two controllers without merging their edit permissions:

1. repair claim/ICL/schema targets with their existing disjoint ID allow-lists;
2. repair only failed ECL dimensions/paragraphs;
3. run the first controller as a read-only gate for every ECL proposal; and
4. reject any ECL proposal that regresses claim, ICL, or schema-support state.

Every run exposes its best bounded rewrite as ``final_content`` and
``analysis_content``.  Only a candidate passing both stages is additionally exposed
as ``release_content``; ``release_ready`` distinguishes publishable output from an
auditable rewrite that still has unresolved gate findings.
"""

from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import replace
from pathlib import Path
from threading import Lock
from typing import Any, Callable, Mapping

from llm_client import ContextPropagatingThreadPoolExecutor as ThreadPoolExecutor

from fidelity_repair import (
    FidelityPolicy,
    joint_repair_nonregression,
    validate_and_repair,
)
from strategy_execution import build_strategy_realization_audit
from comparative_scoring import (
    build_three_dimension_score,
    compare_three_dimension_scores,
)


INTEGRATED_REPAIR_VERSION = (
    "clarr-integrated-repair-v1.6.2-ecl-output-control"
)
ECL_REPAIR_VERSION = "ecl-structure-repair-v1.10.2-output-control"
_ECL_PASS_STATUSES = {"passed_without_repair", "passed_after_repair"}


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _validation_only_policy(policy: FidelityPolicy) -> FidelityPolicy:
    """Disable every patch budget while retaining the production thresholds."""
    return replace(
        policy,
        max_repair_rounds=0,
        max_length_repair_rounds=0,
        max_style_repair_rounds=0,
        max_redundancy_cleanup_rounds=0,
        max_schema_support_repair_rounds=0,
        max_total_repair_attempts=0,
    )


def _load_ecl_api() -> tuple[Callable[..., dict[str, Any]], type]:
    """Load the frozen sibling ECL implementation when it is not installed."""
    try:
        from ecl_repair_v4 import (  # type: ignore
            ECLRepairV34Policy,
            REPAIR_SCHEMA_VERSION,
            validate_and_repair_ecl_v34,
        )
    except ModuleNotFoundError:
        evaluator_dir = Path(__file__).resolve().parent.parent / "New_Evaluator"
        if not (evaluator_dir / "ecl_repair_v4.py").is_file():
            raise RuntimeError(
                "Frozen ECL repair module was not found next to New_CLaRR: "
                f"{evaluator_dir}"
            )
        evaluator_path = str(evaluator_dir)
        if evaluator_path not in sys.path:
            sys.path.insert(0, evaluator_path)
        from ecl_repair_v4 import (  # type: ignore
            ECLRepairV34Policy,
            REPAIR_SCHEMA_VERSION,
            validate_and_repair_ecl_v34,
        )
    if REPAIR_SCHEMA_VERSION != ECL_REPAIR_VERSION:
        raise RuntimeError(
            "ECL repair version mismatch: expected "
            f"{ECL_REPAIR_VERSION}, found {REPAIR_SCHEMA_VERSION}"
        )
    return validate_and_repair_ecl_v34, ECLRepairV34Policy


def _load_ecl_score_api() -> tuple[Callable[..., dict[str, Any]], type]:
    """Load the exact v3.4-r4 scorer for the pre-Repair strategy audit."""
    try:
        from ecl_structure_policy import ExpansionPolicy  # type: ignore
        from ecl_structure import score_candidate as score_candidate_v34  # type: ignore
    except ModuleNotFoundError:
        evaluator_dir = Path(__file__).resolve().parent.parent / "New_Evaluator"
        evaluator_path = str(evaluator_dir)
        if evaluator_path not in sys.path:
            sys.path.insert(0, evaluator_path)
        from ecl_structure_policy import ExpansionPolicy  # type: ignore
        from ecl_structure import score_candidate as score_candidate_v34  # type: ignore
    return score_candidate_v34, ExpansionPolicy


def score_ecl_candidate(
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call: Callable[..., str],
) -> dict[str, Any]:
    """Public read-only entry to the frozen v3.4-r4 scorer."""
    scorer, expansion_policy_type = _load_ecl_score_api()
    return scorer(
        source_text,
        candidate,
        preference,
        item_id,
        feature_llm_call,
        expansion_policy_type(),
    )


def _selected_evaluations(result: Mapping[str, Any]) -> tuple[dict, dict, dict | None]:
    return (
        dict(result.get("selected_validation") or {}),
        dict(result.get("selected_il_compliance") or {}),
        (
            dict(result["selected_schema_support"])
            if result.get("selected_schema_support") is not None
            else None
        ),
    )


def _gate_summary(
    validation_result: Mapping[str, Any],
    nonregression: Mapping[str, Any],
    candidate: str,
) -> dict[str, Any]:
    reasons = list(validation_result.get("release_block_reasons") or [])
    if not nonregression.get("pass", False):
        reasons.append("claim_icl_schema_nonregression")
    reasons = list(dict.fromkeys(str(value) for value in reasons))
    passed = bool(validation_result.get("release_ready")) and bool(
        nonregression.get("pass")
    )
    return {
        "overall_pass": passed,
        "policy_id": INTEGRATED_REPAIR_VERSION + "/ecl-proposal-gate",
        "candidate_sha256": _sha256(candidate),
        "release_block_reasons": reasons,
        "violations": reasons,
        "rationale": (
            "claim/ICL/schema validation and non-regression passed"
            if passed
            else "ECL proposal failed the shared claim/ICL/schema protection gate"
        ),
        "module_nonregression": dict(nonregression),
    }


def _source_ecl_target_policy(
    source_baseline_score: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Freeze ECL edit scope from the source evaluation, not candidate noise."""
    if not source_baseline_score:
        return {"enabled": False, "target_dimensions": [], "source_scores": {}}
    module = (
        (source_baseline_score.get("modules") or {}).get("ecl", {}) or {}
    )
    raw = (
        (source_baseline_score.get("raw_evaluations") or {}).get("ecl", {}) or {}
    )
    features = raw.get("features") or {}
    target_dimensions = [
        str(value) for value in module.get("failed_target_ids", []) or []
        if str(value)
    ]
    source_scores = {
        str(name): str((features.get(name) or {}).get("score", "U"))
        for name in (raw.get("derived") or {}).get("active_features", []) or []
    }
    return {
        "enabled": True,
        "policy": "repair only source-identified ECL dimensions",
        "target_dimensions": list(dict.fromkeys(target_dimensions)),
        "source_scores": source_scores,
    }


def _ecl_source_target_gate(
    policy: Mapping[str, Any],
    score: Mapping[str, Any],
    strategy_audit: Mapping[str, Any],
) -> dict[str, Any]:
    """Accept source-target improvement or deterministic strategy realization.

    A single frozen Judge score remains diagnostic.  It is not allowed to expand
    Repair scope to dimensions that passed on the source.  Score 0/U remains a
    severe fail-safe for every active feature.
    """
    derived = score.get("derived") or {}
    features = score.get("features") or {}
    if not policy.get("enabled"):
        passed = bool(derived.get("p_structure_pass") == 1)
        return {
            "policy": "legacy_all_active_features",
            "pass": passed,
            "target_dimensions": [],
            "unresolved_target_dimensions": [] if passed else list(
                derived.get("repair_targets") or []
            ),
            "severe_failures": [],
            "targets": [],
        }

    active = list(derived.get("active_features") or features.keys())
    severe = [
        str(name) for name in active
        if str((features.get(name) or {}).get("score", "U")) in {"0", "U"}
    ]
    coverage = (
        (strategy_audit.get("modules") or {}).get("ecl", {}) or {}
    ).get("logical_relation_coverage") or {}
    logical_realized = bool(
        int(coverage.get("planned_slots", 0) or 0) > 0
        and not coverage.get("missing_slots")
    )
    target_results = []
    unresolved = []
    source_scores = policy.get("source_scores") or {}
    for dimension in policy.get("target_dimensions") or []:
        before_raw = str(source_scores.get(dimension, "U"))
        after_raw = str((features.get(dimension) or {}).get("score", "U"))
        score_improved = bool(
            before_raw in {"0", "1", "2"}
            and after_raw in {"0", "1", "2"}
            and int(after_raw) > int(before_raw)
        )
        strategy_realized = bool(
            dimension == "S-LOGICAL-ORGANIZATION" and logical_realized
        )
        resolved = score_improved or strategy_realized
        if not resolved:
            unresolved.append(str(dimension))
        target_results.append({
            "dimension": str(dimension),
            "source_score": before_raw,
            "candidate_score": after_raw,
            "score_improved": score_improved,
            "strategy_realized": strategy_realized,
            "resolved": resolved,
        })
    return {
        "policy": str(policy.get("policy", "source-targeted ECL")),
        "pass": not unresolved and not severe,
        "target_dimensions": list(policy.get("target_dimensions") or []),
        "unresolved_target_dimensions": unresolved,
        "severe_failures": severe,
        "targets": target_results,
        "logical_relation_coverage": dict(coverage),
    }


def run_integrated_repair(
    *,
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
    llm_call: Callable[..., str],
    feature_llm_call: Callable[..., str],
    count_words: Callable[[str], int],
    extract_content: Callable[[str], str],
    max_words: int,
    item_id: str,
    presentation_preference: str,
    policy: FidelityPolicy | None = None,
    reader_constraints: str = "",
    il_term_contract: list[dict[str, Any]] | None = None,
    schema_support_contract: dict[str, Any] | None = None,
    strategy_execution_contract: dict[str, Any] | None = None,
    ecl_max_rounds: int = 1,
    max_total_attempts: int = 3,
    ecl_repair_call: Callable[..., dict[str, Any]] | None = None,
    ecl_policy: Any | None = None,
    audit_initial_strategy_execution: bool = False,
    source_baseline_score: dict[str, Any] | None = None,
    ecl_calibration_mode: bool = False,
) -> dict[str, Any]:
    """Run all four repair components under one fail-closed release contract.

    ``ecl_repair_call`` and ``ecl_policy`` are injectable for deterministic unit
    tests. Production callers should omit them to use the local ECL output-control
    policy. Calibration mode only rescales rejected proposals for diagnostics and
    never changes the committed candidate or acceptance decision.
    """
    effective_policy = policy or FidelityPolicy()
    preference = presentation_preference.strip().title()
    if preference not in {"Logical", "Emotional"}:
        raise ValueError(
            "presentation_preference must be 'Logical' or 'Emotional'"
        )
    if (
        not isinstance(ecl_max_rounds, int)
        or isinstance(ecl_max_rounds, bool)
        or not 0 <= ecl_max_rounds <= 1
    ):
        raise ValueError("ecl_max_rounds must be an integer between 0 and 1")
    if (
        not isinstance(max_total_attempts, int)
        or isinstance(max_total_attempts, bool)
        or max_total_attempts < 0
    ):
        raise ValueError("max_total_attempts must be a non-negative integer")
    if not isinstance(ecl_calibration_mode, bool):
        raise ValueError("ecl_calibration_mode must be a boolean")

    source_ecl_policy = _source_ecl_target_policy(source_baseline_score)
    reserved_ecl_attempts = min(
        ecl_max_rounds,
        1 if source_ecl_policy.get("target_dimensions") else 0,
        max_total_attempts,
    )
    base_attempt_limit = max(0, max_total_attempts - reserved_ecl_attempts)
    base_policy = replace(
        effective_policy,
        max_total_repair_attempts=min(
            effective_policy.max_total_repair_attempts,
            base_attempt_limit,
        ),
    )

    initial_candidate = extract_content(candidate)
    feature_cache: dict[str, str] = {}
    feature_cache_lock = Lock()

    def cached_feature_llm_call(prompt: str, **kwargs: Any) -> str:
        key = hashlib.sha256(
            (prompt + "\n" + json.dumps(kwargs, sort_keys=True, default=str)).encode("utf-8")
        ).hexdigest()
        with feature_cache_lock:
            if key in feature_cache:
                return feature_cache[key]
        value = feature_llm_call(prompt, **kwargs)
        with feature_cache_lock:
            feature_cache[key] = value
        return value

    def run_base_repair() -> dict[str, Any]:
        return validate_and_repair(
            source_text=source_text,
            candidate=initial_candidate,
            contract=contract,
            llm_call=llm_call,
            count_words=count_words,
            extract_content=extract_content,
            max_words=max_words,
            policy=base_policy,
            reader_constraints=reader_constraints,
            il_term_contract=il_term_contract,
            schema_support_contract=schema_support_contract,
            strategy_execution_contract=strategy_execution_contract,
        )

    initial_ecl_score: dict[str, Any] = {}
    if audit_initial_strategy_execution:
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="clarr-post-rewrite-audit") as pool:
            base_future = pool.submit(run_base_repair)
            ecl_future = pool.submit(
                score_ecl_candidate,
                source_text,
                initial_candidate,
                preference,
                item_id,
                cached_feature_llm_call,
            )
            base_result = base_future.result()
            initial_ecl_score = dict(ecl_future.result())
    else:
        base_result = run_base_repair()

    initial_history = (
        base_result.get("history", [])[0]
        if base_result.get("history") else {}
    )
    initial_claim_validation = {
        "assessments": list(initial_history.get("assessments", [])),
        "unsupported_claims": list(initial_history.get("unsupported_claims", [])),
    }
    initial_strategy_execution_audit = build_strategy_realization_audit(
        candidate=initial_candidate,
        claim_contract=contract,
        strategy_execution_contract=strategy_execution_contract,
        claim_validation=initial_claim_validation,
        il_evaluation=initial_history.get("il_compliance", {}),
        schema_evaluation=initial_history.get("schema_support", {}),
        ecl_score=initial_ecl_score,
    )
    initial_three_dimension_score = build_three_dimension_score(
        candidate=initial_candidate,
        il_evaluation=initial_history.get("il_compliance", {}),
        ecl_evaluation=initial_ecl_score,
        schema_evaluation=initial_history.get("schema_support", {}),
        stage="initial_unified_rewrite",
    )
    initial_improvement = (
        compare_three_dimension_scores(
            source_baseline_score, initial_three_dimension_score
        ) if source_baseline_score else None
    )
    initial_ecl_target_gate = _ecl_source_target_gate(
        source_ecl_policy,
        initial_ecl_score,
        initial_strategy_execution_audit,
    )
    initial_active_targets = dict(
        initial_history.get("active_repair_targets") or {}
    )
    parallel_target_contract = {
        "schema_version": INTEGRATED_REPAIR_VERSION,
        "evaluation_relation": "parallel_on_same_unified_candidate",
        "candidate_sha256": _sha256(initial_candidate),
        "audit_a_fidelity_icl_gcl": {
            "control_gate": dict(initial_history.get("control_gate") or {}),
            "active_repair_targets": initial_active_targets,
        },
        "audit_b_source_targeted_ecl": {
            "source_target_policy": source_ecl_policy,
            "target_gate": initial_ecl_target_gate,
        },
        "repair_coordination": {
            "shared_total_attempt_limit": max_total_attempts,
            "reserved_ecl_attempts": reserved_ecl_attempts,
            "fidelity_icl_gcl_attempt_limit": base_attempt_limit,
            "rule": (
                "diagnose both audits on the same candidate; apply only target-scoped "
                "repairs; commit through the joint Gate C non-regression check"
            ),
            "ecl_calibration_mode": ecl_calibration_mode,
        },
    }

    base_candidate = str(base_result.get("analysis_content") or initial_candidate)
    base_selected_validation, base_selected_il, base_selected_schema = (
        _selected_evaluations(base_result)
    )
    early_final_strategy_execution_audit = build_strategy_realization_audit(
        candidate=base_candidate,
        claim_contract=contract,
        strategy_execution_contract=strategy_execution_contract,
        claim_validation=base_selected_validation,
        il_evaluation=base_selected_il,
        schema_evaluation=base_selected_schema or {},
        ecl_score=(
            initial_ecl_score if base_candidate == initial_candidate else {}
        ),
    )
    early_final_strategy_execution_audit["audit_stage"] = (
        "final_candidate_before_gate_a_early_return"
    )
    base_stage = {
        "stage": "parallel_audit_a_fidelity_icl_gcl_repair",
        "status": str(base_result.get("status", "")),
        "input_sha256": _sha256(initial_candidate),
        "output_sha256": _sha256(base_candidate),
        "accepted_repairs": int(base_result.get("accepted_repair_rounds", 0)),
        "release_ready": bool(base_result.get("release_ready")),
    }
    base_attempts = int(
        base_result.get(
            "repair_attempts_used",
            base_result.get("accepted_repair_rounds", 0),
        )
    )
    remaining_attempts = max(0, max_total_attempts - base_attempts)

    if not base_result.get("release_ready"):
        reasons = list(base_result.get("release_block_reasons") or [])
        return {
            **base_result,
            "method": INTEGRATED_REPAIR_VERSION,
            "schema_version": INTEGRATED_REPAIR_VERSION,
            "final_content": base_candidate,
            "output_content": base_candidate,
            "output_disposition": "returned_not_release_ready",
            "analysis_content": base_candidate,
            "release_content": None,
            "release_ready": False,
            "release_block_reasons": reasons,
            "status": "blocked_joint_gate_c",
            "fidelity_icl_schema_result": base_result,
            "strategy_execution_contract": strategy_execution_contract or {},
            "initial_strategy_execution_audit": initial_strategy_execution_audit,
            "final_strategy_execution_audit": early_final_strategy_execution_audit,
            "source_baseline_score": source_baseline_score,
            "source_ecl_target_policy": source_ecl_policy,
            "initial_three_dimension_score": initial_three_dimension_score,
            "initial_improvement": initial_improvement,
            "parallel_target_contract": parallel_target_contract,
            "ecl_result": {
                "schema_version": ECL_REPAIR_VERSION,
                "status": "not_committed_joint_safety_gate_failed",
                "source_target_gate": initial_ecl_target_gate,
                "final_candidate": base_candidate,
                "repair_rounds_attempted": 0,
                "repair_rounds_accepted": 0,
            },
            "stage_history": [base_stage],
            "module_isolation": {
                "ecl_proposals_checked": 0,
                "ecl_proposals_rejected_for_cross_module_regression": 0,
            },
            "ecl_calibration": {
                "enabled": ecl_calibration_mode,
                "acceptance_effect": "none_read_only_diagnostic",
                "rejected_proposals_rescored": 0,
                "classification_counts": {},
                "records": [],
            },
            "attempt_budget": {
                "max_total_attempts": max_total_attempts,
                "fidelity_icl_schema_attempts": base_attempts,
                "ecl_attempts": 0,
                "total_attempts": base_attempts,
                "remaining_attempts": remaining_attempts,
                "exhausted": remaining_attempts == 0,
                "compliant": base_attempts <= max_total_attempts,
                "reserved_ecl_attempts": reserved_ecl_attempts,
                "base_attempt_limit": base_attempt_limit,
            },
        }

    base_validation, base_il, base_schema = _selected_evaluations(base_result)
    base_digest = _sha256(base_candidate)
    validation_cache: dict[str, dict[str, Any]] = {base_digest: base_result}
    gate_cache: dict[str, dict[str, Any]] = {}
    validation_policy = _validation_only_policy(base_policy)

    def existing_gate(proposed: str) -> Mapping[str, Any]:
        digest = _sha256(proposed)
        if digest in gate_cache:
            return gate_cache[digest]
        validation_result = validation_cache.get(digest)
        if validation_result is None:
            validation_result = validate_and_repair(
                source_text=source_text,
                candidate=proposed,
                contract=contract,
                llm_call=llm_call,
                count_words=count_words,
                extract_content=extract_content,
                max_words=max_words,
                policy=validation_policy,
                reader_constraints=reader_constraints,
                il_term_contract=il_term_contract,
                schema_support_contract=schema_support_contract,
                strategy_execution_contract=strategy_execution_contract,
            )
            validation_cache[digest] = validation_result
        current_validation, current_il, current_schema = _selected_evaluations(
            validation_result
        )
        nonregression = joint_repair_nonregression(
            base_validation,
            current_validation,
            base_il,
            current_il,
            base_schema,
            current_schema,
        )
        gate_cache[digest] = _gate_summary(
            validation_result, nonregression, proposed
        )
        return gate_cache[digest]

    ecl_repair_call_limit = min(ecl_max_rounds, remaining_attempts)
    ecl_repair_calls = 0

    base_ecl_score = dict(initial_ecl_score)
    if source_ecl_policy.get("enabled") and (
        not base_ecl_score or base_candidate != initial_candidate
    ):
        base_ecl_score = score_ecl_candidate(
            source_text,
            base_candidate,
            preference,
            item_id + "_post_base",
            cached_feature_llm_call,
        )
    base_strategy_execution_audit = build_strategy_realization_audit(
        candidate=base_candidate,
        claim_contract=contract,
        strategy_execution_contract=strategy_execution_contract,
        claim_validation=base_validation,
        il_evaluation=base_il,
        schema_evaluation=base_schema or {},
        ecl_score=base_ecl_score,
    )
    base_ecl_target_gate = _ecl_source_target_gate(
        source_ecl_policy,
        base_ecl_score,
        base_strategy_execution_audit,
    )
    scoped_ecl_targets = list(
        base_ecl_target_gate.get("unresolved_target_dimensions") or []
    )

    def bounded_ecl_repair_llm_call(prompt: str, **kwargs: Any) -> str:
        nonlocal ecl_repair_calls
        if ecl_repair_calls >= ecl_repair_call_limit:
            raise RuntimeError("ECL repair attempt budget exhausted")
        ecl_repair_calls += 1
        ecl_requirements = (strategy_execution_contract or {}).get("ecl", {})
        emotional_goal_rule = ""
        if str(ecl_requirements.get("cognitive_style", "")).lower() == "emotional":
            emotional_goal_rule = (
                "For an Emotional profile, repair experiential continuity only within "
                "the declared reading goal. For a learning/analytical goal, carry one "
                "source-grounded question, concern, or stake through separated explanatory "
                "regions while preserving conceptual distinctions. Do not invent a person, "
                "community, scene, human story, consequence, or solution, and do not replace "
                "analysis with emotional persuasion.\n"
            )
        alignment_suffix = "" if not ecl_requirements else (
            "\n\nREPAIR INSTRUCTION ALIGNMENT MODE — ECL ONLY\n"
            "The evaluator's failed ECL dimension IDs and target paragraphs are the "
            "complete edit scope. Execute every named ECL instruction, then internally "
            "check that each target paragraph was materially changed in the requested "
            "direction. Preserve all ICL, fidelity, and GCL/schema-support content and "
            "keep the response format required above. Do not print the self-check.\n"
            "For a Logical profile, every LR_* relation slot is also a hard postcondition: "
            "repair only the evaluator-targeted paragraphs, but ensure their boundary/topic "
            "sentences make the named source-licensed relation explicit and name the shared "
            "source entity, problem, mechanism, or claim. A generic topic shift is not enough. "
            "Use neutral scope/sequence language when causality is not source-licensed.\n"
            "Preserve source modality: never turn a question, risk, possibility, or attributed "
            "argument into an established disruption, consequence, or mechanism.\n"
            "ACTION COMPLIANCE IS A HARD GATE: repaired_candidate_markdown must differ byte-for-byte "
            "from the input candidate and must actually rewrite at least one sentence in "
            "every evaluator-targeted paragraph. Do not merely describe intended changes "
            "in the changes array. Every changes.after value must quote text that appears "
            "verbatim in repaired_candidate_markdown and differs from changes.before. Silently compare "
            "the two full candidates before returning; an unchanged candidate is rejected.\n"
            "Judge examples are nonbinding illustrations, not source evidence. Ignore any "
            "example that adds a threat, livelihood effect, causal link, mechanism, concrete "
            "example, or dependency absent from the source. Use a neutral scope, contrast, "
            "qualification, or source-sequence relation instead.\n"
            + emotional_goal_rule
            + "ECL strategy continuity contract:\n"
            + json.dumps(ecl_requirements, ensure_ascii=False, indent=2)
        )
        return llm_call(prompt + alignment_suffix, **kwargs)

    if source_ecl_policy.get("enabled") and base_ecl_target_gate.get("pass"):
        ecl_result = {
            "schema_version": ECL_REPAIR_VERSION,
            "status": "source_targets_satisfied_without_repair",
            "final_candidate": base_candidate,
            "final_candidate_sha256": _sha256(base_candidate),
            "final_ecl_score": base_ecl_score,
            "final_existing_gate": dict(existing_gate(base_candidate)),
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
            "allowed_target_dimensions": [],
            "source_target_gate_before_repair": base_ecl_target_gate,
            "history": [],
        }
    elif source_ecl_policy.get("enabled") and not scoped_ecl_targets:
        ecl_result = {
            "schema_version": ECL_REPAIR_VERSION,
            "status": "source_target_analysis_unresolved",
            "final_candidate": base_candidate,
            "final_candidate_sha256": _sha256(base_candidate),
            "final_ecl_score": base_ecl_score,
            "final_existing_gate": dict(existing_gate(base_candidate)),
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
            "allowed_target_dimensions": [],
            "source_target_gate_before_repair": base_ecl_target_gate,
            "history": [],
        }
    else:
        if ecl_repair_call is None:
            ecl_repair_call, ecl_policy_type = _load_ecl_api()
            if ecl_policy is None:
                ecl_policy = ecl_policy_type(
                    max_rounds=ecl_repair_call_limit,
                    calibration_repetitions=(2 if ecl_calibration_mode else 0),
                )
        if ecl_policy is not None and hasattr(ecl_policy, "max_rounds"):
            try:
                policy_updates = {
                    "max_rounds": min(
                        int(ecl_policy.max_rounds), ecl_repair_call_limit
                    )
                }
                if hasattr(ecl_policy, "calibration_repetitions"):
                    policy_updates["calibration_repetitions"] = (
                        2 if ecl_calibration_mode else 0
                    )
                ecl_policy = replace(ecl_policy, **policy_updates)
            except TypeError as exc:
                raise ValueError("ecl_policy must be a dataclass policy object") from exc
        ecl_kwargs = {
            "source_text": source_text,
            "candidate": base_candidate,
            "preference": preference,
            "item_id": item_id,
            "feature_llm_call": cached_feature_llm_call,
            "repair_llm_call": bounded_ecl_repair_llm_call,
            "existing_gate": existing_gate,
            "policy": ecl_policy,
            "existing_gate_policy_id": (
                INTEGRATED_REPAIR_VERSION + "/module-isolation"
            ),
            "maximum_final_words": max_words,
            "count_words": count_words,
        }
        if source_ecl_policy.get("enabled"):
            ecl_kwargs["allowed_target_dimensions"] = set(scoped_ecl_targets)
        ecl_result = ecl_repair_call(**ecl_kwargs)
        ecl_result.setdefault(
            "source_target_gate_before_repair", base_ecl_target_gate
        )
    ecl_candidate = str(ecl_result.get("final_candidate") or base_candidate)
    ecl_reported_attempts = int(ecl_result.get("repair_rounds_attempted", 0))
    # Count actual repair-model calls and fail conservatively when a custom runner
    # reports more attempted rounds than were observable through the injected caller.
    ecl_attempts = max(ecl_repair_calls, ecl_reported_attempts)
    total_attempts = base_attempts + ecl_attempts
    attempt_budget_compliant = bool(
        total_attempts <= max_total_attempts
        and ecl_attempts <= ecl_repair_call_limit
        and ecl_reported_attempts <= ecl_repair_call_limit
    )
    final_gate = dict(existing_gate(ecl_candidate))
    ecl_score = ecl_result.get("final_ecl_score") or {}
    ecl_derived = ecl_score.get("derived") or {}
    ecl_pass = bool(ecl_derived.get("p_structure_pass") == 1) and str(
        ecl_result.get("status", "")
    ) in _ECL_PASS_STATUSES
    final_validation_result = validation_cache[_sha256(ecl_candidate)]
    final_claim_validation, final_il, final_schema = _selected_evaluations(
        final_validation_result
    )
    final_strategy_execution_audit = build_strategy_realization_audit(
        candidate=ecl_candidate,
        claim_contract=contract,
        strategy_execution_contract=strategy_execution_contract,
        claim_validation=final_claim_validation,
        il_evaluation=final_il,
        schema_evaluation=final_schema or {},
        ecl_score=ecl_score,
    )
    final_ecl_target_gate = _ecl_source_target_gate(
        source_ecl_policy,
        ecl_score,
        final_strategy_execution_audit,
    )
    if source_ecl_policy.get("enabled"):
        ecl_pass = bool(final_ecl_target_gate.get("pass"))
    final_three_dimension_score = build_three_dimension_score(
        candidate=ecl_candidate,
        il_evaluation=final_il,
        ecl_evaluation=ecl_score,
        schema_evaluation=final_schema or {},
        stage="post_repair_final",
    )
    final_improvement = (
        compare_three_dimension_scores(
            source_baseline_score, final_three_dimension_score
        ) if source_baseline_score else None
    )
    logical_coverage = (
        final_strategy_execution_audit.get("modules", {})
        .get("ecl", {})
        .get("logical_relation_coverage")
    )
    logical_target_active = bool(
        not source_ecl_policy.get("enabled")
        or "S-LOGICAL-ORGANIZATION"
        in (source_ecl_policy.get("target_dimensions") or [])
    )
    logical_relation_pass = bool(
        not logical_target_active
        or not logical_coverage
        or not logical_coverage.get("missing_slots")
    )
    comparative_failed_dimensions = list(
        (final_improvement or {}).get("failed_dimensions") or []
    )
    if source_ecl_policy.get("enabled"):
        comparative_failed_dimensions = [
            value for value in comparative_failed_dimensions if value != "ecl"
        ]
    comparative_release_pass = not comparative_failed_dimensions
    release_ready = (
        ecl_pass
        and bool(final_gate.get("overall_pass"))
        and logical_relation_pass
        and comparative_release_pass
        and attempt_budget_compliant
    )

    block_reasons: list[str] = []
    if not ecl_pass:
        block_reasons.append(
            "ecl_source_target_pass"
            if source_ecl_policy.get("enabled") else "ecl_structure_pass"
        )
    if not logical_relation_pass:
        block_reasons.append("ecl_logical_relation_slots")
    if comparative_failed_dimensions:
        block_reasons.extend(
            f"no_source_baseline_improvement:{value}"
            for value in comparative_failed_dimensions
        )
    if not attempt_budget_compliant:
        block_reasons.append("max_total_attempts")
    block_reasons.extend(final_gate.get("release_block_reasons") or [])
    block_reasons = list(dict.fromkeys(str(value) for value in block_reasons))

    compatibility = {
        key: final_validation_result.get(key)
        for key in (
            "selected_validation",
            "selected_minimal_edit",
            "selected_reader_style",
            "selected_il_compliance",
            "selected_schema_support",
            "selected_control_gate",
            "selected_passing_claim_protection",
            "selected_cumulative_patch_burden",
            "explanation_protection_contract",
            "protected_passing_paragraphs",
            "passing_claim_protection_templates",
        )
    }
    rejected_cross_module = sum(
        1
        for digest, value in gate_cache.items()
        if digest != base_digest
        and not value.get("module_nonregression", {}).get("pass", False)
    )
    checked_proposals = sum(
        1 for digest in gate_cache if digest != base_digest
    )
    calibration_records = [
        dict(record["rejected_proposal_ecl_calibration"])
        for record in ecl_result.get("history", []) or []
        if isinstance(record, Mapping)
        and isinstance(record.get("rejected_proposal_ecl_calibration"), Mapping)
    ]
    calibration_classifications: dict[str, int] = {}
    for record in calibration_records:
        classification = str(record.get("classification", "unknown"))
        calibration_classifications[classification] = (
            calibration_classifications.get(classification, 0) + 1
        )
    ecl_stage = {
        "stage": "parallel_audit_b_source_targeted_ecl_repair",
        "status": str(ecl_result.get("status", "")),
        "input_sha256": _sha256(base_candidate),
        "output_sha256": _sha256(ecl_candidate),
        "accepted_repairs": int(ecl_result.get("repair_rounds_accepted", 0)),
        "release_ready": release_ready,
    }
    total_accepted = int(base_result.get("accepted_repair_rounds", 0)) + int(
        ecl_result.get("repair_rounds_accepted", 0)
    )
    return {
        **compatibility,
        "method": INTEGRATED_REPAIR_VERSION,
        "schema_version": INTEGRATED_REPAIR_VERSION,
        "final_content": ecl_candidate,
        "output_content": ecl_candidate,
        "output_disposition": (
            "returned_release_ready"
            if release_ready else "returned_not_release_ready"
        ),
        "analysis_content": ecl_candidate,
        "release_content": ecl_candidate if release_ready else None,
        "release_ready": release_ready,
        "release_block_reasons": block_reasons,
        "status": "passed_all_modules" if release_ready else "failed_final_gate",
        "repair_rounds_used": total_accepted,
        "accepted_repair_rounds": total_accepted,
        "fidelity_icl_schema_result": base_result,
        "strategy_execution_contract": strategy_execution_contract or {},
        "initial_strategy_execution_audit": initial_strategy_execution_audit,
        "parallel_target_contract": parallel_target_contract,
        "source_baseline_score": source_baseline_score,
        "source_ecl_target_policy": source_ecl_policy,
        "base_ecl_target_gate": base_ecl_target_gate,
        "initial_three_dimension_score": initial_three_dimension_score,
        "initial_improvement": initial_improvement,
        "final_three_dimension_score": final_three_dimension_score,
        "final_improvement": final_improvement,
        "final_ecl_target_gate": final_ecl_target_gate,
        "final_strategy_execution_audit": final_strategy_execution_audit,
        "final_fidelity_icl_schema_validation": final_validation_result,
        "ecl_result": ecl_result,
        "final_module_gate": final_gate,
        "stage_history": [base_stage, ecl_stage],
        "module_isolation": {
            "target_namespaces": {
                "fidelity": "claim IDs and failed claim spans",
                "icl": "IL term IDs and observed/introduced spans",
                "schema_support": "schema support IDs and failed support spans",
                "ecl": "ECL dimension IDs and target paragraph locators",
            },
            "ecl_proposals_checked": checked_proposals,
            "ecl_proposals_rejected_for_cross_module_regression": rejected_cross_module,
            "final_cross_module_nonregression_pass": bool(
                final_gate.get("module_nonregression", {}).get("pass")
            ),
        },
        "ecl_calibration": {
            "enabled": ecl_calibration_mode,
            "acceptance_effect": "none_read_only_diagnostic",
            "rejected_proposals_rescored": len(calibration_records),
            "classification_counts": calibration_classifications,
            "records": calibration_records,
        },
        "attempt_budget": {
            "max_total_attempts": max_total_attempts,
            "fidelity_icl_schema_attempts": base_attempts,
            "ecl_attempts": ecl_attempts,
            "ecl_reported_rounds_attempted": ecl_reported_attempts,
            "total_attempts": total_attempts,
            "remaining_attempts": max(0, max_total_attempts - total_attempts),
            "exhausted": total_attempts >= max_total_attempts,
            "compliant": attempt_budget_compliant,
            "reserved_ecl_attempts": reserved_ecl_attempts,
            "base_attempt_limit": base_attempt_limit,
        },
    }


__all__ = [
    "ECL_REPAIR_VERSION",
    "INTEGRATED_REPAIR_VERSION",
    "run_integrated_repair",
    "score_ecl_candidate",
]
