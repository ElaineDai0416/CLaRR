"""Concurrent resumable runner for the three controlled CLaRR ablations."""

from __future__ import annotations

import argparse
import json
import os
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from ablation_core import ABLATION_SPECS, process_article_for_reader_ablation, resolve_spec
import core as core
from fidelity_repair import FidelityPolicy


HERE = Path(__file__).resolve().parent


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
    temporary.replace(path)


def run_batch(
    *,
    variant: str,
    article_ids: list[str],
    reader_ids: list[str],
    output_dir: Path,
    workers: int = 4,
    force: bool = False,
    enable_repair: bool = True,
    fidelity_policy: FidelityPolicy | None = None,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
) -> dict[str, Any]:
    spec = resolve_spec(variant)
    policy = fidelity_policy or FidelityPolicy()
    output_dir.mkdir(parents=True, exist_ok=True)
    articles, readers, claim_registry, simplifications = core.load_data()
    summary_path = output_dir / "batch_summary.json"
    if summary_path.exists():
        with open(summary_path, encoding="utf-8") as handle:
            summary = json.load(handle)
    else:
        summary = {}

    jobs: list[tuple[str, str]] = []
    for article_id in article_ids:
        if article_id not in articles:
            print(f"[SKIP] article not found: {article_id}")
            continue
        if article_id not in claim_registry:
            print(f"[SKIP] claim contract not found: {article_id}")
            continue
        for reader_id in reader_ids:
            if reader_id not in readers:
                print(f"[SKIP] reader not found: {reader_id}")
                continue
            output_path = output_dir / f"{article_id}_{reader_id}.json"
            if output_path.exists() and not force:
                print(f"[SKIP] existing: {output_path.name}")
                continue
            jobs.append((article_id, reader_id))

    def run_one(article_id: str, reader_id: str) -> tuple[str, dict[str, Any]]:
        key = f"{article_id}_{reader_id}"
        article = articles[article_id]
        started = time.time()
        try:
            result = process_article_for_reader_ablation(
                article_id,
                article["Content"],
                readers[reader_id],
                claim_registry[article_id],
                simplifications.get(article_id, {}),
                variant=spec,
                article_title=article.get("Title", article_id),
                fidelity_policy=policy,
                enable_repair=enable_repair,
                ecl_repair_rounds=ecl_repair_rounds,
                max_total_repair_attempts=max_total_repair_attempts,
                ecl_calibration_mode=ecl_calibration_mode,
            )
            elapsed = round(time.time() - started, 1)
            timestamp = datetime.now().isoformat()
            output = {
                "article_id": article_id,
                "article_title": article.get("Title", article_id),
                "reader_id": reader_id,
                "reader_label": readers[reader_id].get("label", ""),
                "timestamp": timestamp,
                "elapsed_seconds": elapsed,
                **result,
            }
            _atomic_json(output_dir / f"{key}.json", output)
            return key, {
                "article_id": article_id,
                "reader_id": reader_id,
                "variant": spec.name,
                "removed_module": spec.removed_module,
                "status": (
                    "done_output_release_ready" if result["release_ready"]
                    else "done_output_not_release_ready"
                ),
                "release_ready": result["release_ready"],
                "release_block_reasons": result["release_block_reasons"],
                "elapsed_seconds": elapsed,
                "timestamp": timestamp,
                "output_file": f"{key}.json",
                "repair_method": result.get("repair_method"),
                "attempt_budget": result.get("repair", {}).get("attempt_budget"),
            }
        except Exception as exc:  # persist each failure without losing other jobs
            traceback.print_exc()
            return key, {
                "article_id": article_id,
                "reader_id": reader_id,
                "variant": spec.name,
                "status": "error",
                "error": str(exc),
                "timestamp": datetime.now().isoformat(),
            }

    with ThreadPoolExecutor(
        max_workers=max(1, workers), thread_name_prefix=f"clarr-{spec.name}"
    ) as pool:
        future_map = {
            pool.submit(run_one, article_id, reader_id): (article_id, reader_id)
            for article_id, reader_id in jobs
        }
        for index, future in enumerate(as_completed(future_map), 1):
            key, record = future.result()
            summary[key] = record
            _atomic_json(summary_path, summary)
            print(f"[{index}/{len(jobs)}] {key}: {record['status']}")

    print(f"Completed {len(jobs)} jobs. Results: {output_dir}")
    return summary


def build_parser(fixed_variant: str | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a strict CLaRR ICL/ECL/schema-support ablation"
    )
    if fixed_variant is None:
        parser.add_argument("--variant", choices=sorted(ABLATION_SPECS), required=True)
    parser.add_argument("--article", nargs="+", default=["A01"])
    parser.add_argument("--readers", nargs="+", default=core.ALL_READER_IDS)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--repair-rounds", type=int, default=2)
    parser.add_argument("--length-repair-rounds", type=int, default=1)
    parser.add_argument("--min-core-recall", type=float, default=1.0)
    parser.add_argument("--ecl-repair-rounds", type=int, default=1)
    parser.add_argument("--max-total-repair-attempts", type=int, default=3)
    parser.add_argument("--ecl-calibration-mode", action="store_true")
    parser.add_argument("--no-repair", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser


def main(fixed_variant: str | None = None) -> None:
    parser = build_parser(fixed_variant)
    args = parser.parse_args()
    variant = fixed_variant or args.variant
    if not 0 <= args.min_core_recall <= 1:
        parser.error("--min-core-recall must be between 0 and 1")
    if args.workers < 1:
        parser.error("--workers must be at least 1")
    if args.ecl_repair_rounds not in {0, 1}:
        parser.error("--ecl-repair-rounds must be 0 or 1")
    if min(
        args.repair_rounds,
        args.length_repair_rounds,
        args.max_total_repair_attempts,
    ) < 0:
        parser.error("repair limits must be non-negative")
    spec = resolve_spec(variant)
    output_dir = args.output_dir or HERE / "results" / spec.name
    policy = FidelityPolicy(
        min_core_recall=args.min_core_recall,
        max_repair_rounds=args.repair_rounds,
        max_length_repair_rounds=args.length_repair_rounds,
    )
    run_batch(
        variant=spec.name,
        article_ids=args.article,
        reader_ids=args.readers,
        output_dir=output_dir,
        workers=args.workers,
        force=args.force,
        enable_repair=not args.no_repair,
        fidelity_policy=policy,
        ecl_repair_rounds=args.ecl_repair_rounds,
        max_total_repair_attempts=args.max_total_repair_attempts,
        ecl_calibration_mode=args.ecl_calibration_mode,
    )


if __name__ == "__main__":
    main()
