"""Artifact-driven CLaRR v4.2.1 pipeline.

The module treats each model role as a stateless worker with a versioned JSON
contract.  Article understanding is compiled once into a content-addressed
Source IR; the strategy worker emits decisions rather than prose; the rewrite
worker consumes the frozen plan; and repair/review workers receive exact local
packets.  Existing deterministic compilers and release gates remain authoritative.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import os
import re
import threading
from pathlib import Path
from typing import Any

from fidelity_repair import _sentence_spans


PIPELINE_SCHEMA = "clarr-v4.2.1-post-rewrite-il-gcl-pipeline-v1"
SOURCE_IR_SCHEMA = "clarr-source-ir-v1"
STRATEGY_IR_SCHEMA = "clarr-strategy-ir-v2"
POST_LOCAL_SCHEMA = "clarr-post-rewrite-il-gcl-v1"
POST_IL_SCHEMA = "clarr-post-rewrite-il-v1"
POST_GCL_SCHEMA = "clarr-post-rewrite-gcl-v1"
POST_GCL_WORD_RESERVE = 32
POST_IL_GLOSS_MAX_WORDS = 10
POST_IL_TOTAL_WORD_CAP = 32
POST_IL_MICRO_MAX_TERMS = 4
# One micro call for the IL gloss fallback plus one reserved for the GCL patch
# agent: at 1, any pair whose IL lane spent the slot starved GCL entirely
# (18.7% of part_2 pairs ended in skipped_shared_micro_budget with no guidance).
POST_LOCAL_MICRO_CALL_BUDGET = 2

_GUIDANCE_TYPES_BY_GOAL = {
    "entertainment": {
        "curiosity_or_surprise", "comparison_or_contrast_prompt",
        "narrative_anticipation_or_payoff",
    },
    "learning": {
        "knowledge_gap_or_question", "advance_organizer_or_preview",
        "comparison_or_contrast_prompt", "self_explanation_prompt",
        "comprehension_checkpoint", "integration_or_connection_prompt",
    },
    "utility": {
        "goal_or_relevance_framing", "source_licensed_application",
        "practical_takeaway", "attention_cue", "recap_or_summary",
    },
}
_GUIDANCE_FUNCTIONS = {
    "orient", "activate", "focus", "organize", "elaborate", "monitor",
    "integrate", "apply", "reflect", "summarize",
}


def compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(value: Any) -> str:
    return hashlib.sha256(
        compact_json(value).encode("utf-8") if not isinstance(value, str)
        else value.encode("utf-8")
    ).hexdigest()


def _json_object(raw: str) -> dict[str, Any]:
    text = re.sub(r"^```(?:json)?\s*", "", str(raw).strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("strategy worker must return one JSON object")
    return value


def _word_count(value: Any) -> int:
    return len(re.findall(r"\b[\w'-]+\b", str(value), flags=re.UNICODE))


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(
        path.suffix + f".{os.getpid()}.{threading.get_ident()}.tmp"
    )
    tmp.write_text(compact_json(value), encoding="utf-8")
    os.replace(tmp, path)


def _compact_claim(claim: dict[str, Any]) -> dict[str, Any]:
    return {
        key: claim.get(key)
        for key in (
            "claim_id", "tier", "canonical_proposition", "immutable_slot_values",
            "source_evidence", "approved_simplifications",
        )
        if claim.get(key) not in (None, "", [], {})
    }


def build_source_ir(
    source_text: str, context: dict[str, Any], *, persist: bool = True,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build/cache an article-level, reader-independent intermediate representation."""
    claims = [
        _compact_claim(value)
        for value in context.get("claim_contract", []) or []
        if isinstance(value, dict)
    ]
    sentences = [
        {"sentence_id": f"S{index:03d}", "text": sentence}
        for index, (_, _, sentence) in enumerate(_sentence_spans(source_text), 1)
    ]
    payload = {
        "schema_version": SOURCE_IR_SCHEMA,
        "article_id": str(context.get("article_id", "")),
        "article_title": str(context.get("article_title", "")),
        "source_sha256": _sha(source_text),
        "sentences": sentences,
        "claims": claims,
    }
    key = _sha(payload)
    cache_root = Path(os.environ.get(
        "CLARR_V2_CACHE_DIR", Path(__file__).resolve().parent / "v4_cache"
    )) / "source_ir"
    path = cache_root / f"{key}.json"
    mode = os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower()
    if mode != "refresh" and path.exists():
        try:
            cached = json.loads(path.read_text(encoding="utf-8"))
            if cached.get("schema_version") == SOURCE_IR_SCHEMA:
                payload = cached
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    elif persist and mode != "off":
        _atomic_json(path, payload)
    reference = {
        "schema_version": SOURCE_IR_SCHEMA,
        "artifact_key": key,
        "source_sha256": payload["source_sha256"],
        "sentence_count": len(payload["sentences"]),
        "claim_count": len(payload["claims"]),
        "cache_path": str(path),
    }
    return payload, reference


def _strategy_contract(
    context: dict[str, Any], source_ir: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ecl = context.get("ecl_preference_alignment_contract", {}) or {}
    gcl = context.get("gcl_schema_alignment_contract", {}) or {}
    sentence_rows = (source_ir or {}).get("sentences", []) or []

    def source_id(anchor: Any) -> str:
        value = " ".join(str(anchor or "").split())
        for row in sentence_rows:
            text = " ".join(str(row.get("text", "")).split())
            if value and (value in text or text in value):
                return str(row.get("sentence_id", ""))
        return ""

    slots = []
    for item in ecl.get("logical_relation_slots", []) or []:
        row = {
            key: item.get(key)
            for key in ("relation_id", "from_unit_id", "to_unit_id", "required")
            if item.get(key) not in (None, "", [], {})
        }
        from_id = source_id(item.get("from_source_anchor"))
        to_id = source_id(item.get("to_source_anchor"))
        if from_id and to_id:
            row.update({"from_source_id": from_id, "to_source_id": to_id})
        else:
            # Defensive fallback for non-sentence anchors; never discard evidence.
            row.update({
                "from_source_anchor": item.get("from_source_anchor", ""),
                "to_source_anchor": item.get("to_source_anchor", ""),
            })
        slots.append(row)
    supports = [{
        key: item.get(key)
        for key in (
            "support_id", "term_id", "concept", "acceptable_support",
            "direct_explanation_allowed", "linked_claim_ids",
        )
        if item.get(key) not in (None, "", [], {})
    } for item in gcl.get("bridge_targets", []) or []]
    guidance = gcl.get("guidance_target", {}) or {}
    if guidance.get("support_id"):
        reading_goal = str(guidance.get("reading_goal", "learning")).lower()
        supports.append({
            "support_id": guidance.get("support_id"),
            "concept": "reader cognitive guidance",
            "acceptable_support": guidance.get("goal_aligned_support"),
            "reading_goal": reading_goal,
            "allowed_strategy_types": sorted(
                _GUIDANCE_TYPES_BY_GOAL.get(
                    reading_goal, _GUIDANCE_TYPES_BY_GOAL["learning"]
                )
            ),
            "allowed_cognitive_functions": sorted(_GUIDANCE_FUNCTIONS),
        })
    return {
        "source_sentence_ids": [
            str(item.get("sentence_id", "")) for item in sentence_rows
            if str(item.get("sentence_id", ""))
        ],
        "reader": gcl.get("reader", {}),
        "organization": {
            "active_dimension": ecl.get("active_preference_dimension", ""),
            "mode": ecl.get("organization_mode", "content_led_coherence"),
            "reading_goal": ecl.get("reading_goal", ""),
            "positive_requirements": ecl.get("positive_requirements", []),
            "forbidden_shortcuts": ecl.get("forbidden_shortcuts", []),
            "allowed_relation_types": ecl.get("allowed_relation_types", []),
        },
        "relations": slots,
        "supports": supports,
        "source_boundary": gcl.get("source_boundary", ""),
    }


def strategy_agent_prompt(source_ir: dict[str, Any], contract: dict[str, Any]) -> str:
    source_lines = "\n".join(
        f'{item["sentence_id"]}\t{item["text"]}' for item in source_ir["sentences"]
    )
    claims = compact_json(source_ir.get("claims", []))
    return """## CLARR STRATEGY AGENT V4.2 — DECISIONS ONLY
Return one JSON object and no prose. You plan; you do not rewrite the article.
Use only the Source IR. Preserve modality and attribution. Never invent a cause,
mechanism, outcome, example, application, entity, number, or reader belief.

OUTPUT SCHEMA
{"organization":{"mode":"exact requested mode","instruction":"one content-led instruction, <=32 words","source_ids":["S001"]},"relations":[{"relation_id":"LR_001","relation_type":"one allowed type","source_basis":"<=12 source-grounded words","transition":"one insertion-ready transition, <=24 words"}],"supports":[{"support_id":"GS_*","function":"direct_explanation|cognitive_cue","realization":"one insertion-ready sentence, <=24 words","placement":"first_term_mention|after_relevant_claim","source_id":"S001","strategy_type":"required for cognitive_cue","cognitive_function":"required for cognitive_cue"}]}

Rules:
- Use every requested relation_id and support_id exactly once; emit no unknown ID.
- For a relation, use an explicit causal/dependency/contrast type only when adjacent
  source anchors state it; otherwise choose a neutral allowed type.
- Ground every support in one exact source_id. For cognitive_cue, strategy_type must
  match the requested reading goal and cognitive_function must name the reader action.
- A question must retain source question/possibility modality and have a source-recoverable answer.
- A cognitive cue must orient, focus, connect, monitor, or invite prediction about a
  named source relation. A generic/decorative question or ordinary exposition is invalid.
- Prefer direct explanations to analogies. Do not output rationale or repeat a contract.

SOURCE IR — STABLE ARTICLE PREFIX
""" + source_lines + "\n\nCLAIM LEDGER — STABLE ARTICLE PREFIX\n" + claims + (
        "\n\nDYNAMIC READER/STRATEGY CONTRACT\n" + compact_json(contract)
    )


def _clean_plan_text(value: Any, *, field: str, max_words: int) -> str:
    text = " ".join(str(value or "").split())
    if not text or _word_count(text) > max_words or any(mark in text for mark in ('"', "|")):
        raise ValueError(f"invalid or overlong {field}")
    return text


def normalize_strategy_ir(raw: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    requested_relations = {
        str(item.get("relation_id", "")): item
        for item in contract.get("relations", []) if str(item.get("relation_id", ""))
    }
    requested_supports = {
        str(item.get("support_id", "")): item
        for item in contract.get("supports", []) if str(item.get("support_id", ""))
    }
    relation_rows = raw.get("relations", [])
    support_rows = raw.get("supports", [])
    if not isinstance(relation_rows, list) or not isinstance(support_rows, list):
        raise ValueError("relations and supports must be arrays")
    relation_by_id = {
        str(item.get("relation_id", "")): item
        for item in relation_rows if isinstance(item, dict)
    }
    support_by_id = {
        str(item.get("support_id", "")): item
        for item in support_rows if isinstance(item, dict)
    }
    if set(relation_by_id) != set(requested_relations):
        raise ValueError("relation IDs must exactly equal the requested relation IDs")
    if set(support_by_id) != set(requested_supports):
        raise ValueError("support IDs must exactly equal the requested support IDs")

    allowed_types = set(
        contract.get("organization", {}).get("allowed_relation_types", []) or []
    ) or {"shared_issue_different_scope", "shared_source_basis", "scope_shift"}
    relations = []
    for relation_id in requested_relations:
        item = relation_by_id[relation_id]
        relation_type = str(item.get("relation_type", ""))
        if relation_type not in allowed_types:
            raise ValueError(f"unsupported relation type for {relation_id}")
        relations.append({
            "relation_id": relation_id,
            "relation_type": relation_type,
            "source_basis": _clean_plan_text(
                item.get("source_basis"), field="source_basis", max_words=12
            ),
            "transition": _clean_plan_text(
                item.get("transition"), field="transition", max_words=24
            ),
        })

    supports = []
    allowed_source_ids = {
        str(value) for value in contract.get("source_sentence_ids", []) if str(value)
    }
    reading_goal = str(
        (contract.get("reader", {}) or {}).get("reading_goal", "learning")
    ).lower()
    allowed_guidance_types = _GUIDANCE_TYPES_BY_GOAL.get(
        reading_goal, _GUIDANCE_TYPES_BY_GOAL["learning"]
    )
    for support_id in requested_supports:
        item = support_by_id[support_id]
        function = str(item.get("function", ""))
        if function not in {"direct_explanation", "cognitive_cue"}:
            raise ValueError(f"unsupported support function for {support_id}")
        placement = str(item.get("placement", ""))
        if placement not in {"first_term_mention", "after_relevant_claim"}:
            raise ValueError(f"unsupported support placement for {support_id}")
        source_id = str(item.get("source_id", ""))
        if source_id not in allowed_source_ids:
            raise ValueError(f"support {support_id} must use one known source_id")
        normalized = {
            "support_id": support_id,
            "function": function,
            "realization": _clean_plan_text(
                item.get("realization"), field="realization", max_words=24
            ),
            "placement": placement,
            "source_id": source_id,
        }
        if function == "cognitive_cue":
            strategy_type = str(item.get("strategy_type", ""))
            cognitive_function = str(item.get("cognitive_function", ""))
            if strategy_type not in allowed_guidance_types:
                raise ValueError(
                    f"guidance strategy_type does not match {reading_goal}"
                )
            if cognitive_function not in _GUIDANCE_FUNCTIONS:
                raise ValueError("invalid guidance cognitive_function")
            normalized.update({
                "strategy_type": strategy_type,
                "cognitive_function": cognitive_function,
                "reading_goal": reading_goal,
            })
        supports.append(normalized)

    organization = raw.get("organization", {})
    if not isinstance(organization, dict):
        raise ValueError("organization must be an object")
    requested_mode = str(contract.get("organization", {}).get("mode", ""))
    if str(organization.get("mode", "")) != requested_mode:
        raise ValueError("organization.mode must equal the requested mode")
    source_ids = organization.get("source_ids", [])
    if not isinstance(source_ids, list) or any(
        not re.fullmatch(r"S\d{3}", str(value)) for value in source_ids
    ):
        raise ValueError("organization.source_ids must contain sentence IDs")
    if allowed_source_ids and not source_ids:
        raise ValueError("organization.source_ids must ground the instruction")
    if allowed_source_ids and not set(map(str, source_ids)).issubset(allowed_source_ids):
        raise ValueError("organization.source_ids contains an unknown sentence ID")
    return {
        "schema_version": STRATEGY_IR_SCHEMA,
        "organization": {
            "mode": requested_mode,
            "instruction": _clean_plan_text(
                organization.get("instruction"), field="organization instruction",
                max_words=32,
            ),
            "source_ids": [str(value) for value in source_ids[:6]],
        },
        "relations": relations,
        "supports": supports,
    }


def _render_il(context: dict[str, Any]) -> str:
    rows = ["<IL Strategy>"]
    for item in context.get("provisional_il_term_contract", []) or []:
        if item.get("hard_required", True):
            rows.append(" | ".join((
                str(item.get("term_id", "")), str(item.get("required_action", "")),
                str(item.get("source_term", "")),
            )))
    if len(rows) == 1:
        rows.append("No hard-required term action.")
    return "\n".join(rows)


def render_strategy_artifacts(
    strategy_ir: dict[str, Any], context: dict[str, Any],
) -> dict[str, str]:
    org = strategy_ir["organization"]
    ecl = [
        "<ECL Strategy>",
        f'Organization | {org["mode"]} | {org["instruction"]}',
    ]
    if strategy_ir["relations"]:
        ecl.append("<Logical Relation Execution Ledger>")
        slot_map = {
            str(item.get("relation_id", "")): item
            for item in (
                context.get("ecl_preference_alignment_contract", {}) or {}
            ).get("logical_relation_slots", []) or []
        }
        for item in strategy_ir["relations"]:
            slot = slot_map[item["relation_id"]]
            ecl.append(
                f'{item["relation_id"]} | {slot.get("from_unit_id", "")}->'
                f'{slot.get("to_unit_id", "")} | {item["relation_type"]} | '
                f'{item["source_basis"]} | Realization instruction: '
                f'"{item["transition"]}"'
            )
    gcl = ["<GCL Strategy>", "<Schema-Support Integration>"]
    for item in strategy_ir["supports"]:
        metadata = ",".join(
            value for value in (
                str(item.get("source_id", "")),
                str(item.get("strategy_type", "")),
                str(item.get("cognitive_function", "")),
            ) if value
        )
        gcl.append(
            f'{item["support_id"]} | {item["function"]} | '
            f'"{item["realization"]}" | {item["placement"]} | '
            f'source-bounded:{metadata}'
        )
    if not strategy_ir["supports"]:
        gcl.append("No target.")
    return {"IL": _render_il(context), "EL": "\n".join(ecl), "GL": "\n".join(gcl)}


def generate_pipeline_strategies(
    *, source_text: str, prompts: dict[str, str], llm_call, context=None,
) -> dict[str, Any]:
    """Run one compact strategy worker and return compiler-compatible artifacts."""
    context = context or {}
    source_ir, source_ref = build_source_ir(source_text, context)
    contract = _strategy_contract(context, source_ir)
    prompt = strategy_agent_prompt(source_ir, contract)
    requested = len(contract["relations"]) + len(contract["supports"])
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = llm_call(
                prompt + ("\nReturn corrected JSON only." if attempt else ""),
                max_tokens=max(900, 180 * requested + 320),
                temperature=0,
                response_format={"type": "json_object"},
                stage="strategy.pipeline",
            )
            strategy_ir = normalize_strategy_ir(_json_object(raw), contract)
            artifacts = render_strategy_artifacts(strategy_ir, context)
            artifacts["_pipeline_artifact"] = {
                "pipeline_schema": PIPELINE_SCHEMA,
                "source_ir": source_ref,
                "strategy_ir": strategy_ir,
                "strategy_sha256": _sha(strategy_ir),
                "fallback_used": False,
                "strategy_agent_attempts": attempt + 1,
            }
            artifacts["_strategy_bundle_metadata"] = {
                "generation_topology": "single_schema_strategy_agent_plus_local_il",
                "strategy_generation_calls": attempt + 1,
                "strategy_generation_api_outputs": ["organization", "relations", "supports"],
            }
            return artifacts
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc

    # Fail closed to the established module-owned strategy prompts.  The fallback
    # costs more but preserves the pre-v4 behavior when a compact worker violates
    # its schema; it is recorded in the result artifact.
    el = llm_call(prompts["EL"], max_tokens=3000, temperature=0, stage="strategy.ecl.fallback")
    gl = llm_call(prompts["GL"], max_tokens=3000, temperature=0, stage="strategy.gcl.fallback")
    return {
        "IL": _render_il(context), "EL": str(el), "GL": str(gl),
        "_pipeline_artifact": {
            "pipeline_schema": PIPELINE_SCHEMA,
            "source_ir": source_ref,
            "strategy_ir": None,
            "strategy_sha256": None,
            "fallback_used": True,
            "fallback_reason": str(last_error),
            "strategy_agent_attempts": 2,
        },
        "_strategy_bundle_metadata": {
            "generation_topology": "schema_agent_failed_then_established_lane_fallback",
            "strategy_generation_calls": 4,
            "strategy_generation_api_outputs": ["ecl_fallback", "gcl_fallback"],
        },
    }


def _primary_gcl_strategy(value: str) -> str:
    """Keep term bridges in phase 1 while deferring GS_Q guidance to phase 2."""
    rows = [
        line for line in str(value).splitlines()
        if "GS_Q_001" not in line
    ]
    return "\n".join(rows).strip() or "<GCL Strategy>\nNo phase-1 bridge target."


def compact_rewrite_prompt(
    text: str, IL: str, EL: str, GL: str, orig_words: int, max_words: int,
    claim_guardrail: str, il_term_contract=None, upfront_strategy_contract=None,
) -> str:
    """Phase-1 Rewrite Agent: execute ICL/ECL and term bridges, not GCL guidance."""
    terms = [{
        key: item.get(key)
        for key in (
            "term_id", "source_term", "required_action", "hard_required",
            "linked_claim_ids", "approved_familiar_forms", "protected_slot_values",
        )
        if item.get(key) not in (None, "", [], {})
    } for item in il_term_contract or []]
    primary_max_words = max(1, int(max_words) - POST_GCL_WORD_RESERVE)
    primary_gl = _primary_gcl_strategy(GL)
    return f"""## CLARR ICL/ECL PRIMARY REWRITE AGENT V4.2.1
Return exactly one adapted article and no analysis. The strategy has already been
decided: do not re-plan it. Source fidelity overrides every adaptation instruction.
Never add a factual mechanism, outcome, application, example, entity, number, causal
link, or belief about the reader.

This is the primary rewrite phase. Execute ICL, ECL, and term-bound GS_B bridges
only. Every hard retain_and_gloss term needs one immediately adjacent short gloss.
Do not add an engagement question, hook, anticipation, recap, or GS_Q guidance.
After this output, local IL/GCL gates may make only bounded missing-target patches.

SOURCE ARTICLE — STABLE PREFIX
{text}

CLAIM FIDELITY CONTRACT — STABLE ARTICLE PREFIX
{claim_guardrail}

REWRITE LIMITS
- primary_maximum_words={primary_max_words}; final_maximum_words={max_words}; source_words={orig_words}
- reserve_words_for_post_gcl={POST_GCL_WORD_RESERVE}
- preserve every claim, immutable value, attribution, scope, condition and modality
- execute each hard-required term action, each LR item, and each GS_B item exactly once
- for retain_and_gloss use `term (short nonfactual gloss)` at first occurrence
- integrate transitions/support naturally; never print an ID or a checklist
- condense optional framing before any source proposition

IL TERM CONTRACT
{compact_json(terms)}

FROZEN STRATEGY IR
{IL}
{EL}
{primary_gl}

OUTPUT FORMAT — EXACT
<Optimized Content>
[article body only]
</Optimized Content>
"""


_TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:'[A-Za-z]+)?")
_GROUNDING_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "being", "but",
    "by", "can", "could", "did", "do", "does", "for", "from", "had", "has",
    "have", "he", "her", "hers", "him", "his", "how", "i", "if", "in",
    "into", "is", "it", "its", "may", "might", "more", "most", "not", "of",
    "on", "or", "our", "she", "should", "so", "than", "that", "the", "their",
    "them", "then", "there", "these", "they", "this", "those", "to", "was",
    "we", "were", "what", "when", "where", "which", "who", "why", "will",
    "with", "would",
    # Function words absent above (mined from part_2 strategy/guidance outputs:
    # "about" alone rejected 124 real sentences, "after" 279, "only" 265).
    # Grammar only — no token here can carry article content, and digits stay
    # unlisted so fabricated numbers still fail grounding.
    "no", "only", "very", "much", "many", "some", "any", "few", "several",
    "such", "just", "even", "still", "yet", "rather", "quite", "almost",
    "nearly", "perhaps", "maybe", "cannot", "nor", "neither", "either",
    "about", "after", "before", "because", "since", "although", "though",
    "however", "thus", "therefore", "instead", "meanwhile", "whereas",
    "whether", "while", "once", "without", "within", "between", "beyond",
    "during", "through", "across", "along", "above", "below", "over",
    "under", "up", "down", "out", "off", "per", "via", "toward", "towards",
    "against", "outside", "inside", "among", "near", "behind", "beneath",
    "beside", "besides", "despite", "except", "unless", "until", "upon",
    "onto", "like", "due", "back", "non", "including", "whom", "whose",
    "itself", "yourself", "themselves", "one", "two", "three", "four",
    "five", "six", "seven", "eight", "nine", "ten", "second", "third",
}
_GUIDANCE_META_WORDS = {
    "ask", "compare", "connect", "consider", "contrast", "difference", "focus", "follow",
    "happen", "happens", "keep", "look", "notice", "pause", "predict", "question",
    "recall", "reflect", "remember", "surprise", "surprising", "track", "watch",
    # Scaffolding vocabulary: metacognitive actions and discourse-structure
    # words that reference the text or the reader's processing of it without
    # carrying any article content.  The part_2 run rejected 57% of generated
    # guidance sentences because models naturally bridge with these words
    # ("main idea", "how this connects", "the key claim"), none of which can
    # smuggle a new fact, mechanism, or causal claim — the ban list below the
    # prompt (mechanism/consequence/application/example/numbers) still applies.
    "again", "all", "another", "apply", "argument", "article", "author", "authors",
    "beginning", "both", "briefly", "carefully", "case", "closely", "claim", "claims",
    "connection", "definition", "describe", "detail", "details", "different",
    "distinguish", "end", "evidence", "example", "explain", "explanation", "fact",
    "finally", "first", "form", "goal", "group", "here", "idea", "identify", "important",
    "information", "key", "last", "line", "link", "links", "main", "map", "mean",
    "means", "meaning", "middle", "name", "next", "now", "observe", "order", "other",
    "own", "part", "passage", "pattern", "point", "purpose", "reason", "read",
    "reading", "relate", "relationship", "reread", "same", "section", "sentence",
    "sequence", "similar", "similarity", "sort", "source", "stage", "start",
    "step", "steps", "structure", "summarize", "summary", "term", "terms",
    "text", "think", "thought", "together", "trace", "whole", "writer", "you",
    "your", "yours",
    # pure connectives/scalars absent from the stopword list
    "also", "each", "every", "let", "us",
    # Second mining pass (659 strategy.gcl realizations + applied guidance,
    # part_2): metalinguistic verbs/nouns the model reaches for in guidance.
    # Mechanism/cause/consequence vocabulary deliberately stays OUT — the
    # prompt bans introducing them, and scholarly evidence carries the words
    # itself, so a reference still grounds through the evidence side.
    "add", "adds", "added", "adding", "allow", "answer", "appear", "attention",
    "build", "call", "check", "come", "comprehension", "confirm", "direct",
    "early", "earlier", "engage", "expect", "final", "find", "figure", "gap",
    "give", "given", "guess", "guidance", "help", "immediately", "indicate",
    "know", "knowledge", "learn", "list", "make", "making",
    "mention", "mind", "must", "new", "note", "notes", "noted", "need",
    "occur", "often", "outcome", "paragraph", "pass", "phrase", "phrases",
    "process", "reader", "readers", "respect", "reveal", "revise", "role",
    "see", "show", "sometimes", "specific", "strategy", "support", "take",
    "taking", "thing", "things", "time", "title", "type", "understand",
    "usually", "use", "uses", "used", "using", "way", "ways", "wonder", "word",
    "words", "work", "based",
}


def _token_stem(value: str) -> str:
    token = value.casefold().strip("'")
    for suffix in ("ingly", "edly", "ation", "ments", "ment", "ies", "ing", "ed", "es", "s"):
        if len(token) > len(suffix) + 3 and token.endswith(suffix):
            return token[:-len(suffix)]
    # Suffix stripping above yields consonant stems ("releas" from
    # "releasing") while the base form keeps its silent e ("release") —
    # without this rule the two never matched and grounded references to
    # -ing/-ed evidence verbs failed wholesale.
    if len(token) > 4 and token.endswith("e"):
        return token[:-1]
    return token


def _content_token_stems(value: str) -> set[str]:
    return {
        _token_stem(token) for token in _TOKEN_RE.findall(str(value))
        if token.casefold() not in _GROUNDING_STOPWORDS
    }


def _guidance_source_grounded(value: str, evidence: str) -> bool:
    evidence_tokens = _content_token_stems(evidence)
    allowed_meta = {_token_stem(item) for item in _GUIDANCE_META_WORDS}
    return all(
        token in evidence_tokens or token in allowed_meta
        for token in _content_token_stems(value)
    )


def _sentence_similarity(left: str, right: str) -> float:
    left_tokens = _content_token_stems(left)
    right_tokens = _content_token_stems(right)
    overlap = (
        len(left_tokens & right_tokens) / len(left_tokens | right_tokens)
        if left_tokens and right_tokens else 0.0
    )
    sequence = difflib.SequenceMatcher(
        None, " ".join(str(left).casefold().split()),
        " ".join(str(right).casefold().split()), autojunk=False,
    ).ratio()
    return 0.65 * overlap + 0.35 * sequence


def _best_candidate_anchor(candidate: str, evidence: str) -> str:
    sentences = _sentence_values(candidate)
    if not sentences:
        return ""
    return max(sentences, key=lambda value: _sentence_similarity(value, evidence))


def _near_duplicate(candidate: str, guidance: str) -> bool:
    return any(
        _sentence_similarity(sentence, guidance) >= 0.72
        for sentence in _sentence_values(candidate)
    )


def _insert_after_exact_sentence(candidate: str, anchor: str, guidance: str) -> str:
    index = candidate.find(anchor)
    if index < 0:
        raise ValueError("post-GCL anchor is not an exact candidate sentence")
    boundary = index + len(anchor)
    return candidate[:boundary] + " " + guidance + candidate[boundary:]


_INLINE_GLOSS_ACTIONS = {"retain_and_gloss", "retain_and_explain"}
_APPOSITIVE_STARTS = {"a", "an", "the", "our", "shared"}
_GLOSS_META_WORDS = {
    "activity", "approach", "benefit", "condition", "content", "data",
    "digital", "evidence", "fake", "form", "information", "material",
    "media", "method", "online", "people", "practice", "process", "public",
    "real", "resource", "resources", "role", "roles", "shared", "system",
    "systems", "tool", "tools", "way", "ways", "work", "working",
}
_GLOSS_RISK_MARKERS = re.compile(
    r"\b(?:always|never|causes?|caused|leading|leads?|increases?|decreases?|"
    r"guarantees?|proves?|will|must|according to|percent|percentage)\b|\d",
    flags=re.I,
)
_READER_PROJECTION_MARKERS = re.compile(
    r"\b(?:you know|you value|you believe|you care|your field|your role)\b",
    flags=re.I,
)


def _term_pattern(term: str) -> re.Pattern[str]:
    value = str(term or "").strip()
    return re.compile(r"(?<![\w])" + re.escape(value) + r"(?![\w])", re.I)


def _candidate_term_sentence(candidate: str, term: str) -> str:
    pattern = _term_pattern(term)
    return next(
        (sentence for sentence in _sentence_values(candidate) if pattern.search(sentence)),
        "",
    )


def _has_inline_gloss(candidate: str, term: str) -> bool:
    """Recognize a short parenthetical or an intact paired-comma appositive."""
    for match in _term_pattern(term).finditer(candidate):
        tail = candidate[match.end():]
        found = re.match(r"^[\"'”’]?\s*\(([^()]{1,120})\)", tail)
        if found and 1 <= _word_count(found.group(1)) <= 12:
            return True
        appositive = re.match(r"^,\s+([^,.;!?]{1,100})(,)", tail)
        if appositive:
            gloss = " ".join(appositive.group(1).split())
            words = _TOKEN_RE.findall(gloss)
            if (
                words and words[0].casefold() in _APPOSITIVE_STARTS
                and 2 <= _word_count(gloss) <= POST_IL_GLOSS_MAX_WORDS
            ):
                return True
    return False


def _promote_adjacent_appositive(candidate: str, term: str) -> tuple[str, str] | None:
    """Turn an existing short comma appositive into an explicit zero-word-cost gloss."""
    match = _term_pattern(term).search(candidate)
    if not match:
        return None
    tail = candidate[match.end():]
    found = re.match(r"^,\s+([^,.;!?]{1,100})([,.;!?])", tail)
    if not found or found.group(2) == ",":
        return None
    gloss = " ".join(found.group(1).split())
    words = _TOKEN_RE.findall(gloss)
    if not words or words[0].casefold() not in _APPOSITIVE_STARTS:
        return None
    if not 2 <= _word_count(gloss) <= POST_IL_GLOSS_MAX_WORDS:
        return None
    start = match.end()
    end = match.end() + found.end()
    replacement = f" ({gloss}){found.group(2)}"
    return candidate[:start] + replacement + candidate[end:], gloss


def _approved_gloss(term_row: dict[str, Any]) -> str:
    for item in term_row.get("approved_familiar_forms", []) or []:
        value = item.get("allowed_form", "") if isinstance(item, dict) else item
        gloss = " ".join(str(value or "").strip(" .;:()[]").split())
        if (
            gloss
            and gloss.casefold() != str(term_row.get("source_term", "")).casefold()
            and _word_count(gloss) <= POST_IL_GLOSS_MAX_WORDS
        ):
            return gloss
    return ""


def _strategy_gloss(
    strategy_pipeline_artifact: dict[str, Any], term_row: dict[str, Any],
) -> str:
    term_id = str(term_row.get("term_id", ""))
    source_term = str(term_row.get("source_term", ""))
    supports = (
        (strategy_pipeline_artifact.get("strategy_ir", {}) or {}).get("supports", [])
        or []
    )
    for item in supports:
        if not isinstance(item, dict) or str(item.get("function", "")) != "direct_explanation":
            continue
        if str(item.get("term_id", "")) != term_id and str(
            item.get("support_id", "")
        ) not in {f"GS_B_{term_id}", f"GS_B_IL_{term_id}"}:
            continue
        realization = " ".join(str(item.get("realization", "")).split())
        inline = re.search(
            re.escape(source_term) + r"[\"'”’]?\s*\(([^()]+)\)",
            realization,
            flags=re.I,
        )
        if inline:
            realization = inline.group(1)
        else:
            definition = re.search(
                re.escape(source_term) + r"\s+(?:means|is|refers to)\s+(.+)",
                realization,
                flags=re.I,
            )
            if definition:
                realization = definition.group(1)
        gloss = " ".join(realization.strip(" .;:()[]").split())
        if gloss and _word_count(gloss) <= POST_IL_GLOSS_MAX_WORDS:
            return gloss
    return ""


def _insert_inline_gloss(candidate: str, term: str, gloss: str) -> str:
    """Insert a parenthetical after the first exact term while preserving punctuation."""
    match = _term_pattern(term).search(candidate)
    if not match:
        raise ValueError("post-IL target term is absent from the candidate")
    end = match.end()
    tail = candidate[end:]
    # Move sentence punctuation outside a closing quote before adding the gloss:
    # "term." -> "term" (gloss).
    quoted_punctuation = re.match(r"^([,.;:!?])([\"”’])", tail)
    if quoted_punctuation:
        consumed = quoted_punctuation.end()
        suffix = quoted_punctuation.group(2) + f" ({gloss})" + quoted_punctuation.group(1)
        return candidate[:end] + suffix + candidate[end + consumed:]
    closing_quote = re.match(r"^([\"”’])", tail)
    if closing_quote:
        consumed = closing_quote.end()
        return candidate[:end] + closing_quote.group(1) + f" ({gloss})" + candidate[end + consumed:]
    return candidate[:end] + f" ({gloss})" + candidate[end:]


def _term_source_evidence(
    term_row: dict[str, Any], source_ir: dict[str, Any], claims: list[dict[str, Any]],
) -> dict[str, str]:
    term = str(term_row.get("source_term", ""))
    pattern = _term_pattern(term)
    sentence_rows = [
        item for item in source_ir.get("sentences", []) or []
        if isinstance(item, dict)
    ]
    exact = next(
        (item for item in sentence_rows if pattern.search(str(item.get("text", "")))),
        None,
    )
    if exact:
        return {
            "source_id": str(exact.get("sentence_id", "")),
            "text": str(exact.get("text", "")),
        }
    linked = {str(value) for value in term_row.get("linked_claim_ids", []) or []}
    evidence = ""
    for claim in claims:
        if str(claim.get("claim_id", "")) not in linked:
            continue
        values = claim.get("source_evidence", []) or []
        if values:
            evidence = str(values[0])
            break
    if evidence and sentence_rows:
        best = max(
            sentence_rows,
            key=lambda item: _sentence_similarity(str(item.get("text", "")), evidence),
        )
        return {
            "source_id": str(best.get("sentence_id", "")),
            "text": str(best.get("text", "")),
        }
    return {"source_id": "", "text": ""}


def _post_il_cache_path(
    source_sha256: str, term_row: dict[str, Any], evidence: dict[str, str],
) -> Path:
    payload = {
        "schema_version": POST_IL_SCHEMA,
        "source_sha256": source_sha256,
        "term_id": term_row.get("term_id", ""),
        "source_term": term_row.get("source_term", ""),
        "source_id": evidence.get("source_id", ""),
        "evidence": evidence.get("text", ""),
    }
    root = Path(os.environ.get(
        "CLARR_V2_CACHE_DIR", Path(__file__).resolve().parent / "v4_cache"
    )) / "post_il_glosses"
    return root / f"{_sha(payload)}.json"


def _load_cached_gloss(path: Path) -> str:
    if os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower() == "refresh":
        return ""
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        return ""
    if value.get("schema_version") != POST_IL_SCHEMA or not value.get("source_grounded"):
        return ""
    gloss = " ".join(str(value.get("gloss", "")).split())
    return gloss if 1 <= _word_count(gloss) <= POST_IL_GLOSS_MAX_WORDS else ""


def _store_cached_gloss(path: Path, *, term_row: dict[str, Any], gloss: str) -> None:
    mode = os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower()
    if mode == "off":
        return
    _atomic_json(path, {
        "schema_version": POST_IL_SCHEMA,
        "term_id": str(term_row.get("term_id", "")),
        "source_term": str(term_row.get("source_term", "")),
        "gloss": gloss,
        "source_grounded": True,
    })


# Raw-response disk cache for the post-rewrite micro agents.  Keyed by the
# full prompt hash, so any change to the prompt (whitelist, rules, anchors,
# evidence) or to this validator version rotates the key automatically.
# Validators still run on every replay — the cache only skips the HTTP call.
_MICRO_RESPONSE_CACHE_VERSION = "v2-gcl-guidance-validator"


def _micro_response_cache_path(prompt: str, lane: str) -> Path:
    payload = {
        "version": _MICRO_RESPONSE_CACHE_VERSION,
        "stage": f"{lane}.post_rewrite.local",
        "prompt_sha256": _sha(prompt),
    }
    root = Path(os.environ.get(
        "CLARR_V2_CACHE_DIR", Path(__file__).resolve().parent / "v4_cache"
    )) / "micro_responses"
    return root / f"{_sha(payload)}.json"


def _load_micro_response(path: Path) -> str | None:
    mode = os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower()
    if mode == "refresh":
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    if value.get("version") != _MICRO_RESPONSE_CACHE_VERSION:
        return None
    raw = str(value.get("response", ""))
    return raw if raw.strip() else None


def _store_micro_response(path: Path, raw: str) -> None:
    mode = os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower()
    if mode == "off" or not str(raw).strip():
        return
    _atomic_json(path, {
        "version": _MICRO_RESPONSE_CACHE_VERSION,
        "response": str(raw),
    })


def post_rewrite_il_prompt(*, targets: list[dict[str, str]]) -> str:
    """One compact glossary call; full source, candidate and reader profile are absent."""
    return """## CLARR POST-REWRITE IL GLOSS AGENT V4.2.1
Return one JSON object only. Produce one short parenthetical gloss for every requested
term. Do not rewrite a sentence. A gloss explains the term; it must not add a fact,
cause, outcome, recommendation, example, number, entity, or reader assumption.

OUTPUT SCHEMA
{"patches":[{"term_id":"exact requested ID","gloss":"lower-case fragment, <=10 words","gloss_type":"source_compression|nonfactual_definition"}]}

Rules:
- Return every requested term_id exactly once and no unknown ID.
- Prefer source_compression using only the supplied source evidence.
- Use nonfactual_definition only for a conventional meaning, never an article claim.
- Do not repeat the source term inside the gloss.
- No sentence-ending punctuation, brackets, rationale, or extra key.

LOCAL TARGETS
""" + compact_json(targets)


def _normalize_post_il_patches(
    raw: dict[str, Any], *, targets: list[dict[str, str]],
) -> list[dict[str, str]]:
    requested = {str(item.get("term_id", "")): item for item in targets}
    rows = raw.get("patches", [])
    if not isinstance(rows, list):
        raise ValueError("post-IL patches must be an array")
    by_id = {
        str(item.get("term_id", "")): item
        for item in rows if isinstance(item, dict)
    }
    if set(by_id) != set(requested):
        raise ValueError("post-IL term IDs must exactly equal requested IDs")
    normalized: list[dict[str, str]] = []
    for term_id, target in requested.items():
        item = by_id[term_id]
        gloss = " ".join(str(item.get("gloss", "")).strip(" .;:()[]").split())
        gloss_type = str(item.get("gloss_type", ""))
        if gloss_type not in {"source_compression", "nonfactual_definition"}:
            raise ValueError(f"invalid post-IL gloss_type for {term_id}")
        if not gloss or _word_count(gloss) > POST_IL_GLOSS_MAX_WORDS:
            raise ValueError(f"empty or overlong post-IL gloss for {term_id}")
        if re.search(r"[.!?;()[\]{}]", gloss):
            raise ValueError(f"post-IL gloss must be a plain fragment for {term_id}")
        if _READER_PROJECTION_MARKERS.search(gloss) or _GLOSS_RISK_MARKERS.search(gloss):
            raise ValueError(f"unsafe post-IL gloss for {term_id}")
        if _term_pattern(str(target.get("source_term", ""))).search(gloss):
            raise ValueError(f"post-IL gloss repeats its term for {term_id}")
        if gloss_type == "source_compression":
            licensed = _content_token_stems(
                str(target.get("source_evidence", ""))
                + " " + str(target.get("source_term", ""))
            ) | {_token_stem(value) for value in _GLOSS_META_WORDS}
            if not _content_token_stems(gloss).issubset(licensed):
                raise ValueError(f"ungrounded post-IL source compression for {term_id}")
        normalized.append({
            "term_id": term_id,
            "gloss": gloss,
            "gloss_type": gloss_type,
        })
    return normalized


def execute_post_rewrite_il(**kwargs) -> dict[str, Any]:
    """Repair only missing hard glosses using local/cached paths before one micro call."""
    candidate = str(kwargs.get("candidate", ""))
    source_text = str(kwargs.get("source_text", ""))
    max_words = int(kwargs.get("max_words", 0))
    reserve_words = max(0, int(kwargs.get("reserve_words", 0)))
    count_words = kwargs.get("count_words", _word_count)
    term_contract = kwargs.get("il_term_contract", []) or []
    strategy_artifact = kwargs.get("strategy_pipeline_artifact") or {}
    claims = kwargs.get("claim_contract", []) or []
    allow_micro = bool(kwargs.get("allow_micro_fallback", True))
    before_words = int(count_words(candidate))
    local_ceiling = max(0, max_words - reserve_words)
    addition_ceiling = min(local_ceiling, before_words + POST_IL_TOTAL_WORD_CAP)
    source_ir, source_ref = build_source_ir(source_text, {
        "article_id": kwargs.get("article_id", ""),
        "article_title": kwargs.get("article_title", ""),
        "claim_contract": claims,
    }, persist=False)
    targets = sorted([
        item for item in term_contract
        if isinstance(item, dict)
        and bool(item.get("hard_required"))
        and str(item.get("required_action", "")) in _INLINE_GLOSS_ACTIONS
    ], key=lambda item: (-_word_count(item.get("source_term", "")), str(item.get("term_id", ""))))
    artifact: dict[str, Any] = {
        "schema_version": POST_IL_SCHEMA,
        "execution_order": "after_primary_rewrite_before_post_gcl_and_integrated_audit",
        "api_calls": 0,
        "before_words": before_words,
        "max_words": max_words,
        "reserved_words_for_gcl": reserve_words,
        "local_word_ceiling": addition_ceiling,
        "target_count": len(targets),
        "targets": [],
        "source_ir": source_ref,
    }
    if not targets:
        return {"content": candidate, "artifact": {**artifact, "status": "no_target", "after_words": before_words}}

    current = candidate
    unresolved: list[dict[str, Any]] = []
    for term_row in targets:
        term_id = str(term_row.get("term_id", ""))
        term = str(term_row.get("source_term", ""))
        row_artifact = {"term_id": term_id, "source_term": term}
        if not _term_pattern(term).search(current):
            row_artifact["status"] = "missing_term_deferred_to_integrated_repair"
            artifact["targets"].append(row_artifact)
            continue
        if _has_inline_gloss(current, term):
            row_artifact["status"] = "already_realized"
            artifact["targets"].append(row_artifact)
            continue
        promoted = _promote_adjacent_appositive(current, term)
        if promoted is not None:
            proposed, gloss = promoted
            if int(count_words(proposed)) <= addition_ceiling:
                current = proposed
                row_artifact.update({"status": "normalized_existing_appositive", "mode": "zero_call", "gloss": gloss})
                artifact["targets"].append(row_artifact)
                continue
        evidence = _term_source_evidence(term_row, source_ir, claims)
        cache_path = _post_il_cache_path(source_ref["source_sha256"], term_row, evidence)
        gloss = _approved_gloss(term_row)
        mode = "approved_ledger" if gloss else ""
        if not gloss:
            gloss = _strategy_gloss(strategy_artifact, term_row)
            mode = "strategy_ir" if gloss else ""
        if not gloss:
            gloss = _load_cached_gloss(cache_path)
            mode = "source_grounded_cache" if gloss else ""
        if gloss:
            proposed = _insert_inline_gloss(current, term, gloss)
            if int(count_words(proposed)) <= addition_ceiling:
                current = proposed
                row_artifact.update({"status": "applied", "mode": mode, "gloss": gloss})
                artifact["targets"].append(row_artifact)
                continue
            row_artifact["status"] = "skipped_shared_word_budget"
            artifact["targets"].append(row_artifact)
            continue
        anchor = _candidate_term_sentence(current, term)
        if not anchor or not evidence.get("text"):
            row_artifact["status"] = "skipped_no_safe_local_evidence"
            artifact["targets"].append(row_artifact)
            continue
        row_artifact.update({
            "status": "pending_micro",
            "anchor_sentence": anchor,
            "source_id": evidence.get("source_id", ""),
            "source_evidence": evidence.get("text", ""),
            "cache_path": str(cache_path),
        })
        unresolved.append({"term_row": term_row, "artifact": row_artifact})
        artifact["targets"].append(row_artifact)

    micro_targets = unresolved[:POST_IL_MICRO_MAX_TERMS]
    for item in unresolved[POST_IL_MICRO_MAX_TERMS:]:
        item["artifact"]["status"] = "skipped_micro_term_cap"
    available = max(0, addition_ceiling - int(count_words(current)))
    if micro_targets and allow_micro and available > 0 and kwargs.get("llm_call") is not None:
        packet = [{
            "term_id": str(item["term_row"].get("term_id", "")),
            "source_term": str(item["term_row"].get("source_term", "")),
            "source_id": str(item["artifact"].get("source_id", "")),
            "source_evidence": str(item["artifact"].get("source_evidence", "")),
            "candidate_anchor": str(item["artifact"].get("anchor_sentence", "")),
        } for item in micro_targets]
        try:
            raw = kwargs["llm_call"](
                post_rewrite_il_prompt(targets=packet),
                max_tokens=min(900, 220 + 130 * len(packet)),
                temperature=0,
                response_format={"type": "json_object"},
                stage="il.post_rewrite.local",
            )
            patches = _normalize_post_il_patches(_json_object(raw), targets=packet)
            patch_map = {item["term_id"]: item for item in patches}
            artifact["api_calls"] = 1
            for item in micro_targets:
                term_row = item["term_row"]
                row_artifact = item["artifact"]
                patch = patch_map[str(term_row.get("term_id", ""))]
                proposed = _insert_inline_gloss(
                    current, str(term_row.get("source_term", "")), patch["gloss"]
                )
                if int(count_words(proposed)) > addition_ceiling:
                    row_artifact["status"] = "skipped_shared_word_budget"
                    continue
                current = proposed
                row_artifact.update({
                    "status": "applied",
                    "mode": "micro_agent",
                    "gloss": patch["gloss"],
                    "gloss_type": patch["gloss_type"],
                })
                if patch["gloss_type"] == "source_compression":
                    _store_cached_gloss(
                        Path(str(row_artifact["cache_path"])),
                        term_row=term_row,
                        gloss=patch["gloss"],
                    )
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            artifact["api_calls"] = 1
            artifact["micro_error"] = str(exc)
            for item in micro_targets:
                item["artifact"]["status"] = "skipped_agent_contract_failure"
    elif micro_targets:
        reason = (
            "skipped_shared_micro_budget" if not allow_micro
            else "skipped_shared_word_budget" if available < 1
            else "skipped_no_llm"
        )
        for item in micro_targets:
            item["artifact"]["status"] = reason

    after_words = int(count_words(current))
    unresolved_ids = [
        str(item.get("term_id", "")) for item in artifact["targets"]
        if str(item.get("status", "")) not in {
            "already_realized", "normalized_existing_appositive", "applied"
        }
    ]
    artifact.update({
        "status": "complete" if not unresolved_ids else "partial",
        "after_words": after_words,
        "words_added": after_words - before_words,
        "unresolved_term_ids": unresolved_ids,
    })
    return {"content": current, "artifact": artifact}


def _strategy_guidance(
    strategy_pipeline_artifact: dict[str, Any] | None,
) -> dict[str, Any]:
    strategy_ir = (strategy_pipeline_artifact or {}).get("strategy_ir", {}) or {}
    for item in strategy_ir.get("supports", []) or []:
        if isinstance(item, dict) and str(item.get("support_id", "")) == "GS_Q_001":
            return item
    return {}


def _source_row_map(source_ir: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        str(item.get("sentence_id", "")): item
        for item in source_ir.get("sentences", []) or []
        if isinstance(item, dict) and str(item.get("sentence_id", ""))
    }


def _goal_guidance_signal(value: str, goal: str) -> bool:
    text = str(value).casefold()
    if goal == "entertainment":
        return bool(
            "?" in value
            or re.search(
                r"\b(?:consider|imagine|notice|contrast|surpris|predict|"
                r"what happens|watch)\w*\b",
                text,
            )
        )
    if goal == "utility":
        return bool(
            "?" in value
            or re.search(r"\b(?:consider|focus|takeaway|decision|apply|priority|which)\w*\b", text)
        )
    return bool(
        "?" in value
        or re.search(r"\b(?:consider|compare|connect|explain|notice|recall|track)\w*\b", text)
    )


def _existing_guidance_span(candidate: str, goal: str) -> str:
    """Find an observable cue already present so the GCL micro call is unnecessary."""
    cue = re.compile(
        r"\b(?:consider|imagine|notice|compare|contrast|predict|reflect|remember|"
        r"ask yourself|what happens|how would|which matters)\b",
        flags=re.I,
    )
    for sentence in _sentence_values(candidate):
        if "?" in sentence or cue.search(sentence):
            if _goal_guidance_signal(sentence, goal):
                return sentence
    return ""


def _source_exact_question(
    source_ir: dict[str, Any], planned: str,
) -> dict[str, Any]:
    questions = [
        item for item in source_ir.get("sentences", []) or []
        if isinstance(item, dict)
        and str(item.get("text", "")).strip().endswith("?")
        and _word_count(item.get("text", "")) <= POST_GCL_WORD_RESERVE
    ]
    if not questions:
        return {}
    if planned:
        return max(
            questions,
            key=lambda item: _sentence_similarity(str(item.get("text", "")), planned),
        )
    return questions[0]


def post_rewrite_gcl_prompt(
    *, evidence_rows: list[dict[str, str]], candidate_anchors: list[str],
    reading_goal: str, max_words: int,
) -> str:
    """Small fallback prompt: no full source article or full candidate is included."""
    allowed_types = sorted(
        _GUIDANCE_TYPES_BY_GOAL.get(
            str(reading_goal), _GUIDANCE_TYPES_BY_GOAL["learning"]
        )
    )
    return """## CLARR POST-REWRITE GCL PATCH AGENT V4.2
Return one JSON object only. ICL and ECL are already complete. Add exactly one local,
source-grounded cognitive-guidance sentence without rewriting, summarizing, or moving
any existing sentence. Ordinary exposition and decorative questions are invalid.

OUTPUT SCHEMA
{"support_id":"GS_Q_001","operation":"insert_after_sentence","anchor_sentence":"exact candidate anchor","guidance_sentence":"one sentence","source_id":"exact evidence ID","strategy_type":"goal-compatible enum","cognitive_function":"orient|activate|focus|organize|elaborate|monitor|integrate|apply|reflect|summarize"}

Rules:
- Every content word in guidance_sentence must come from EITHER the selected source
  evidence OR this fixed scaffolding list (anything else is rejected):
  """ + ", ".join(sorted(_GUIDANCE_META_WORDS)) + """
- Preserve attribution, uncertainty, conditions, and question modality.
- Do not add a mechanism, consequence, application, example, entity, number, causal
  relation, reader belief, or claim about what the reader knows/values.
- The guidance must cause a cognitive action tied to named source content.
- Insert after one exact candidate anchor. Never alter the anchor.
- guidance_sentence must be one sentence and at most MAX_WORDS.

READING GOAL
""" + str(reading_goal) + "\n\nALLOWED STRATEGY TYPES\n" + compact_json(allowed_types) + (
        "\n\nMAX_WORDS\n" + str(max_words)
        + "\n\nSOURCE EVIDENCE\n" + compact_json(evidence_rows)
        + "\n\nCANDIDATE ANCHORS\n" + compact_json(candidate_anchors)
    )


def _normalize_post_gcl_patch(
    raw: dict[str, Any], *, evidence_rows: list[dict[str, str]],
    candidate_anchors: list[str], reading_goal: str, max_words: int,
) -> dict[str, Any]:
    if str(raw.get("support_id", "")) != "GS_Q_001":
        raise ValueError("post-GCL support_id must be GS_Q_001")
    if str(raw.get("operation", "")) != "insert_after_sentence":
        raise ValueError("post-GCL operation must be insert_after_sentence")
    anchor = str(raw.get("anchor_sentence", "")).strip()
    if anchor not in candidate_anchors:
        raise ValueError("post-GCL anchor must exactly match an allowed anchor")
    source_id = str(raw.get("source_id", ""))
    evidence_map = {
        str(item.get("source_id", "")): str(item.get("text", ""))
        for item in evidence_rows
    }
    if source_id not in evidence_map:
        raise ValueError("post-GCL source_id is not in the evidence packet")
    sentence = " ".join(str(raw.get("guidance_sentence", "")).split())
    if not sentence or _word_count(sentence) > max_words:
        raise ValueError("post-GCL guidance is empty or over budget")
    if len(_sentence_values(sentence)) != 1:
        raise ValueError("post-GCL guidance must be exactly one sentence")
    if re.search(r"\b(?:you know|you value|you believe|you care|your field|your role)\b", sentence, re.I):
        raise ValueError("post-GCL guidance projects a reader stance")
    if not _guidance_source_grounded(sentence, evidence_map[source_id]):
        raise ValueError("post-GCL guidance contains ungrounded content words")
    strategy_type = str(raw.get("strategy_type", ""))
    allowed_types = _GUIDANCE_TYPES_BY_GOAL.get(
        reading_goal, _GUIDANCE_TYPES_BY_GOAL["learning"]
    )
    if strategy_type not in allowed_types:
        raise ValueError("post-GCL strategy_type does not match the reading goal")
    cognitive_function = str(raw.get("cognitive_function", ""))
    if cognitive_function not in _GUIDANCE_FUNCTIONS:
        raise ValueError("invalid post-GCL cognitive_function")
    if not _goal_guidance_signal(sentence, reading_goal):
        raise ValueError("post-GCL sentence lacks an observable guidance action")
    return {
        "support_id": "GS_Q_001",
        "operation": "insert_after_sentence",
        "anchor_sentence": anchor,
        "guidance_sentence": sentence,
        "source_id": source_id,
        "strategy_type": strategy_type,
        "cognitive_function": cognitive_function,
    }


def execute_post_rewrite_gcl(**kwargs) -> dict[str, Any]:
    """Apply GCL guidance after ICL/ECL with a zero-call path and one-call fallback."""
    candidate = str(kwargs.get("candidate", ""))
    source_text = str(kwargs.get("source_text", ""))
    max_words = int(kwargs.get("max_words", 0))
    count_words = kwargs.get("count_words", _word_count)
    strategy_artifact = kwargs.get("strategy_pipeline_artifact") or {}
    upfront = kwargs.get("upfront_strategy_contract") or {}
    guidance_contract = (upfront.get("gcl", {}) or {}).get("guidance_target", {}) or {}
    support_id = str(guidance_contract.get("support_id", ""))
    before_words = int(count_words(candidate))
    base_artifact = {
        "schema_version": POST_GCL_SCHEMA,
        "support_id": support_id,
        "execution_order": "after_icl_ecl_primary_rewrite_before_integrated_audit",
        "api_calls": 0,
        "before_words": before_words,
        "max_words": max_words,
    }
    if support_id != "GS_Q_001":
        return {"content": candidate, "artifact": {**base_artifact, "status": "no_target"}}

    context = {
        "article_id": kwargs.get("article_id", ""),
        "article_title": kwargs.get("article_title", ""),
        "claim_contract": kwargs.get("claim_contract", []) or [],
    }
    source_ir, source_ref = build_source_ir(source_text, context, persist=False)
    source_rows = _source_row_map(source_ir)
    planned = _strategy_guidance(strategy_artifact)
    planned_sentence = str(
        planned.get("realization")
        or guidance_contract.get("planned_realization", "")
    ).strip()
    reading_goal = str(
        guidance_contract.get("reading_goal")
        or (upfront.get("gcl", {}).get("reader", {}) or {}).get("reading_goal")
        or "learning"
    ).lower()
    existing_guidance = _existing_guidance_span(candidate, reading_goal)
    if existing_guidance:
        return {"content": candidate, "artifact": {
            **base_artifact,
            "status": "already_realized",
            "mode": "candidate_guidance_precheck",
            "guidance_sentence": existing_guidance,
            "source_ir": source_ref,
            "after_words": before_words,
        }}
    remaining = max(0, max_words - before_words)
    if remaining < 1:
        return {"content": candidate, "artifact": {
            **base_artifact, "status": "skipped_no_word_budget", "source_ir": source_ref,
        }}

    exact_question = (
        _source_exact_question(source_ir, planned_sentence)
        if reading_goal in {"entertainment", "learning"} else {}
    )
    zero_call_options: list[tuple[str, str, str, str, str]] = []
    if exact_question:
        zero_call_options.append((
            "source_exact_question",
            str(exact_question.get("text", "")),
            str(exact_question.get("sentence_id", "")),
            (
                "curiosity_or_surprise" if reading_goal == "entertainment"
                else "knowledge_gap_or_question"
            ),
            "activate",
        ))
    planned_source_id = str(planned.get("source_id", ""))
    planned_evidence = str(source_rows.get(planned_source_id, {}).get("text", ""))
    if (
        planned_sentence and planned_evidence
        and _word_count(planned_sentence) <= min(24, remaining)
        and _guidance_source_grounded(planned_sentence, planned_evidence)
        and _goal_guidance_signal(planned_sentence, reading_goal)
    ):
        zero_call_options.append((
            "strategy_ir_zero_call", planned_sentence, planned_source_id,
            str(planned.get("strategy_type", "")),
            str(planned.get("cognitive_function", "")),
        ))

    for mode, sentence, source_id, strategy_type, cognitive_function in zero_call_options:
        if _word_count(sentence) > remaining:
            continue
        if _near_duplicate(candidate, sentence):
            return {"content": candidate, "artifact": {
                **base_artifact, "status": "already_realized", "mode": mode,
                "source_id": source_id, "source_ir": source_ref,
                "strategy_type": strategy_type,
                "cognitive_function": cognitive_function,
                "after_words": before_words,
            }}
        evidence = str(source_rows.get(source_id, {}).get("text", sentence))
        anchor = _best_candidate_anchor(candidate, evidence)
        if not anchor:
            continue
        proposed = _insert_after_exact_sentence(candidate, anchor, sentence)
        after_words = int(count_words(proposed))
        if after_words <= max_words:
            return {"content": proposed, "artifact": {
                **base_artifact, "status": "applied", "mode": mode,
                "source_id": source_id, "anchor_sentence": anchor,
                "guidance_sentence": sentence, "source_ir": source_ref,
                "strategy_type": strategy_type,
                "cognitive_function": cognitive_function,
                "after_words": after_words,
            }}

    # One bounded fallback call sees only selected evidence and candidate anchors.
    selected_ids: list[str] = []
    for value in (
        planned_source_id,
        str(exact_question.get("sentence_id", "")) if exact_question else "",
        *((strategy_artifact.get("strategy_ir", {}) or {}).get("organization", {}).get("source_ids", []) or []),
    ):
        value = str(value)
        if value in source_rows and value not in selected_ids:
            selected_ids.append(value)
    if not selected_ids:
        selected_ids = list(source_rows)[:2]
    selected_ids = selected_ids[:3]
    evidence_rows = [
        {"source_id": value, "text": str(source_rows[value].get("text", ""))}
        for value in selected_ids
    ]
    candidate_anchors: list[str] = []
    for item in evidence_rows:
        anchor = _best_candidate_anchor(candidate, item["text"])
        if anchor and anchor not in candidate_anchors:
            candidate_anchors.append(anchor)
    if not bool(kwargs.get("allow_micro_fallback", True)):
        return {"content": candidate, "artifact": {
            **base_artifact, "status": "skipped_shared_micro_budget",
            "source_ir": source_ref, "after_words": before_words,
        }}
    if not evidence_rows or not candidate_anchors or kwargs.get("llm_call") is None:
        return {"content": candidate, "artifact": {
            **base_artifact, "status": "skipped_no_safe_local_or_agent_path",
            "source_ir": source_ref,
        }}
    micro_max_words = min(24, remaining)
    micro_prompt = post_rewrite_gcl_prompt(
        evidence_rows=evidence_rows,
        candidate_anchors=candidate_anchors,
        reading_goal=reading_goal,
        max_words=micro_max_words,
    )
    micro_cache_path = _micro_response_cache_path(micro_prompt, "gcl")
    micro_from_cache = False
    raw = _load_micro_response(micro_cache_path)
    if raw is not None:
        micro_from_cache = True
    try:
        if raw is None:
            raw = kwargs["llm_call"](
                micro_prompt,
                max_tokens=420,
                temperature=0,
                response_format={"type": "json_object"},
                stage="gcl.post_rewrite.local",
            )
            _store_micro_response(micro_cache_path, raw)
        patch = _normalize_post_gcl_patch(
            _json_object(raw), evidence_rows=evidence_rows,
            candidate_anchors=candidate_anchors, reading_goal=reading_goal,
            max_words=micro_max_words,
        )
        if _near_duplicate(candidate, patch["guidance_sentence"]):
            return {"content": candidate, "artifact": {
                **base_artifact, "status": "already_realized", "mode": "micro_agent",
                "api_calls": 0 if micro_from_cache else 1, "source_id": patch["source_id"],
                "source_ir": source_ref, "after_words": before_words,
            }}
        proposed = _insert_after_exact_sentence(
            candidate, patch["anchor_sentence"], patch["guidance_sentence"]
        )
        after_words = int(count_words(proposed))
        if after_words > max_words:
            raise ValueError("post-GCL patch exceeds final word budget")
        return {"content": proposed, "artifact": {
            **base_artifact, "status": "applied", "mode": "micro_agent",
            "api_calls": 0 if micro_from_cache else 1, **patch, "source_ir": source_ref,
            "after_words": after_words,
        }}
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        return {"content": candidate, "artifact": {
            **base_artifact,
            "status": "skipped_agent_contract_failure",
            "mode": "micro_agent", "api_calls": 0 if micro_from_cache else 1,
            "error": str(exc), "source_ir": source_ref,
            "after_words": before_words,
        }}


def execute_post_rewrite_local_pipeline(**kwargs) -> dict[str, Any]:
    """Run IL then GCL with one shared micro-call budget and one shared word budget."""
    candidate = str(kwargs.get("candidate", ""))
    max_words = int(kwargs.get("max_words", 0))
    count_words = kwargs.get("count_words", _word_count)
    upfront = kwargs.get("upfront_strategy_contract") or {}
    guidance = (upfront.get("gcl", {}) or {}).get("guidance_target", {}) or {}
    reading_goal = str(
        guidance.get("reading_goal")
        or (upfront.get("gcl", {}).get("reader", {}) or {}).get("reading_goal")
        or "learning"
    ).lower()
    has_gcl_target = str(guidance.get("support_id", "")) == "GS_Q_001"
    existing_guidance = _existing_guidance_span(candidate, reading_goal)
    remaining = max(0, max_words - int(count_words(candidate)))
    gcl_reserve = (
        min(POST_GCL_WORD_RESERVE, remaining)
        if has_gcl_target and not existing_guidance else 0
    )

    il_result = execute_post_rewrite_il(**{
        **kwargs,
        "candidate": candidate,
        "reserve_words": gcl_reserve,
        "allow_micro_fallback": True,
    })
    il_artifact = il_result.get("artifact", {}) or {}
    il_calls = int(il_artifact.get("api_calls", 0) or 0)
    gcl_result = execute_post_rewrite_gcl(**{
        **kwargs,
        "candidate": str(il_result.get("content", candidate)),
        "allow_micro_fallback": il_calls < POST_LOCAL_MICRO_CALL_BUDGET,
    })
    gcl_artifact = gcl_result.get("artifact", {}) or {}
    gcl_calls = int(gcl_artifact.get("api_calls", 0) or 0)
    total_calls = il_calls + gcl_calls
    if total_calls > POST_LOCAL_MICRO_CALL_BUDGET:
        raise ValueError("post-rewrite local pipeline exceeded shared micro-call budget")
    content = str(gcl_result.get("content", il_result.get("content", candidate)))
    after_words = int(count_words(content))
    statuses = {
        "il": str(il_artifact.get("status", "unknown")),
        "gcl": str(gcl_artifact.get("status", "unknown")),
    }
    # A word-ceiling overrun is a style gate owned by the downstream length
    # audit, not a pair-fatal error: the condense stage upstream may already
    # end "STILL OVER" when the claim floor blocks further compression, and
    # the old hard raise here discarded the pair's whole upstream spend on ~1%
    # of short-register part_2 pairs.  Drop the local IL/GCL additions when
    # they caused the overflow; otherwise hand the over-ceiling text on
    # unchanged and let the release length gate judge it.
    budget_reverted = False
    if after_words > max_words:
        base_words = int(count_words(candidate))
        if base_words <= max_words and base_words < after_words:
            content = candidate
            after_words = base_words
            budget_reverted = True
            statuses = {"il": "reverted_word_budget", "gcl": "reverted_word_budget"}
    status = "complete"
    if (
        statuses["il"] in {"partial", "reverted_word_budget"}
        or statuses["gcl"].startswith("skipped_")
        or statuses["gcl"] == "reverted_word_budget"
    ):
        status = "partial"
    return {"content": content, "artifact": {
        "schema_version": POST_LOCAL_SCHEMA,
        "status": status,
        "execution_order": "primary_rewrite_then_local_il_then_local_gcl_then_integrated_audit",
        "api_calls": total_calls,
        "shared_micro_call_budget": POST_LOCAL_MICRO_CALL_BUDGET,
        "before_words": int(count_words(candidate)),
        "after_words": after_words,
        "max_words": max_words,
        "final_word_budget_exceeded": after_words > max_words,
        "local_additions_reverted_for_budget": budget_reverted,
        "reserved_words_for_gcl": gcl_reserve,
        "existing_gcl_detected_before_il": bool(existing_guidance),
        "il": il_artifact,
        "gcl": gcl_artifact,
    }}


def _selected_instructions(packet: dict[str, Any]) -> list[dict[str, Any]]:
    selected = {str(value) for value in packet.get("selected_instruction_ids", [])}
    return [
        item for item in packet.get("instructions", []) or []
        if isinstance(item, dict) and str(item.get("instruction_id", "")) in selected
    ]


def compact_repair_prompt(**kwargs) -> str:
    """Fixed Repair Agent packet; full article/candidate are never sent."""
    packet = kwargs.get("packet", {}) or {}
    instructions = _selected_instructions(packet)
    anchors: list[str] = []
    evidence: list[str] = []
    compact_instructions = []
    for item in instructions:
        anchors.extend(str(value) for value in item.get("allowed_anchor_sentences", []) if str(value))
        evidence.extend(str(value) for value in item.get("source_evidence_choices", []) if str(value))
        compact_instructions.append({
            key: item.get(key)
            for key in (
                "instruction_id", "module", "target_id", "instruction_scope_id",
                "required_action", "allowed_operations", "target_spans",
                "source_evidence_choices", "failure", "action_recipe",
                "acceptance_conditions", "forbidden_changes",
                "allowed_anchor_sentences", "required_protected_term_ids",
                "required_protected_support_ids", "required_preserved_claim_anchors",
                "compatible_composite_instruction_ids", "protected_target_action",
            )
            if item.get(key) not in (None, "", [], {})
        })
    anchors = list(dict.fromkeys(anchors))
    evidence = list(dict.fromkeys(evidence))
    compact_packet = {
        "mode": packet.get("mode"),
        "packet_id": packet.get("packet_id"),
        "strategy_scope_id": packet.get("strategy_scope_id"),
        "selected_instruction_ids": packet.get("selected_instruction_ids", []),
        "active_target_ids": packet.get("active_target_ids", {}),
        "instructions": compact_instructions,
    }
    return """## CLARR LOCAL REPAIR AGENT V4.2
Return one JSON object only. Apply every selected instruction exactly once. Modify
only an allowed anchor/target span with an allowed operation. IDs never grant
permission outside their module. Preserve all listed claim anchors, protected term
IDs and support IDs. Use only SOURCE EVIDENCE; nonfactual GCL cues may use empty
evidence. Do not rewrite or return unchanged article text.
For inserted/replaced text, reader_language_note is mandatory but must contain no
more than six words describing register preservation.

OUTPUT SCHEMA
{"mode":"repair_alignment","packet_id":"exact","strategy_scope_id":"exact","patches":[{"patch_id":"P01","instruction_ids":["RA-*"],"strategy_scope_id":"exact","instruction_scope_ids":["exact"],"operation":"replace_within_sentence|delete_within_sentence|insert_before_sentence|insert_after_sentence","anchor_sentence":"exact allowed anchor","target_span":"exact target or empty","replacement_text":"small local text","source_evidence":"exact choice or allowed empty","claim_ids":[],"term_ids":[],"schema_support_ids":[],"protected_term_ids":[],"protected_support_ids":[],"reader_language_note":"brief register-preservation note"}],"self_check":{"addressed_instruction_ids":["all selected IDs"],"scope_respected":true}}

REPAIR PACKET
""" + compact_json(compact_packet) + "\n\nSOURCE EVIDENCE\n" + compact_json(evidence) + (
        "\n\nCURRENT ALLOWED ANCHORS\n" + compact_json(anchors)
    ) + "\n\nTARGET READER REGISTER\n" + str(kwargs.get("reader_constraints", "")) + (
        f'\n\nLENGTH STATUS\ncurrent={kwargs.get("current_words")};maximum={kwargs.get("max_words")}'
    )


def _sentence_values(text: str) -> list[str]:
    return [value for _, _, value in _sentence_spans(text)]


def _indices_containing(sentences: list[str], values: list[str]) -> set[int]:
    indices: set[int] = set()
    for value in values:
        needle = " ".join(str(value or "").split())
        if not needle:
            continue
        for index, sentence in enumerate(sentences):
            normalized = " ".join(sentence.split())
            if needle in normalized or normalized in needle:
                indices.add(index)
    return indices


def _claim_evidence_values(claim: dict[str, Any]) -> list[str]:
    values: list[str] = []
    raw = claim.get("source_evidence")
    if isinstance(raw, str):
        values.append(raw)
    elif isinstance(raw, list):
        values.extend(str(item) for item in raw if str(item))
    elif isinstance(raw, dict):
        values.extend(str(item) for item in raw.values() if isinstance(item, str) and item)
    proposition = str(claim.get("canonical_proposition", ""))
    if proposition:
        values.append(proposition)
    return values


def build_local_review_packet(**kwargs) -> dict[str, Any]:
    """Create exact changed-sentence/source-evidence packets for post-patch judges."""
    source_text = str(kwargs["source_text"])
    previous = str(kwargs["previous_content"])
    proposed = str(kwargs["proposed_content"])
    old_sentences = _sentence_values(previous)
    new_sentences = _sentence_values(proposed)
    matcher = difflib.SequenceMatcher(a=old_sentences, b=new_sentences, autojunk=False)
    candidate_indices: set[int] = set()
    for tag, _i1, _i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        left = max(0, j1 - 1)
        right = min(len(new_sentences), max(j2, j1 + 1) + 1)
        candidate_indices.update(range(left, right))

    relevant_values: list[str] = []
    claim_ids = {str(item.get("claim_id", "")) for item in kwargs.get("claim_subset", [])}
    for item in kwargs.get("previous_validation", {}).get("assessments", []) or []:
        if str(item.get("claim_id", "")) in claim_ids:
            relevant_values.append(str(item.get("candidate_span", "")))
    term_ids = {str(value) for value in kwargs.get("term_ids", set())}
    for item in kwargs.get("previous_il_evaluation", {}).get("assessments", []) or []:
        if str(item.get("term_id", "")) in term_ids:
            relevant_values.append(str(item.get("observed_span", "")))
    for item in kwargs.get("term_contract", []) or []:
        if str(item.get("term_id", "")) in term_ids:
            relevant_values.append(str(item.get("source_term", "")))
    for patch in kwargs.get("candidate_application", {}).get("patches", []) or []:
        relevant_values.extend((
            str(patch.get("replacement_text", "")),
            str(patch.get("target_span", "")),
        ))
    candidate_indices.update(_indices_containing(new_sentences, relevant_values))

    if not candidate_indices:
        candidate_packet = proposed
        candidate_scope = "whole_candidate_fallback"
    else:
        candidate_packet = "\n".join(
            new_sentences[index] for index in sorted(candidate_indices)
        )
        if len(candidate_packet) > len(proposed) * 0.75:
            candidate_packet = proposed
            candidate_scope = "whole_candidate_threshold_fallback"
        else:
            candidate_scope = "changed_sentences_plus_neighbors"

    source_sentences = _sentence_values(source_text)
    evidence_values: list[str] = []
    for claim in kwargs.get("claim_subset", []) or []:
        evidence_values.extend(_claim_evidence_values(claim))
    for patch in kwargs.get("candidate_application", {}).get("patches", []) or []:
        evidence_values.append(str(patch.get("source_evidence", "")))
    source_indices = _indices_containing(source_sentences, evidence_values + relevant_values)
    if source_indices:
        source_packet = "\n".join(source_sentences[index] for index in sorted(source_indices))
        source_scope = "contract_evidence_sentences"
    else:
        source_packet = source_text
        source_scope = "whole_source_fallback"
    return {
        "source_text": source_packet,
        "candidate_text": candidate_packet,
        "metadata": {
            "scope": candidate_scope,
            "source_scope": source_scope,
            "candidate_chars": len(candidate_packet),
            "whole_candidate_chars": len(proposed),
            "source_chars": len(source_packet),
            "whole_source_chars": len(source_text),
        },
    }


def stage_token_cap(stage: str, prompt: str, requested: int | None) -> int | None:
    """Conservative stage-size caps; never increase a caller's requested cap."""
    stage = str(stage)
    cap: int | None = None
    if stage == "strategy.pipeline":
        cap = 2600
    elif stage == "rewrite":
        match = re.search(r"maximum_words=(\d+)", prompt)
        words = int(match.group(1)) if match else 500
        cap = max(1200, 4 * words + 250)
    elif "fidelity" in stage:
        rows = max(1, prompt.count('"claim_id"') - 1)
        # JSON verifier caps must never truncate: a cut verdict JSON kills the
        # pair after a same-cap retry, and raising the cap costs nothing when
        # the model naturally writes less (billed tokens are actual output,
        # not the requested cap).  The old 180/claim+700 floor truncated
        # part_2-scale validation JSON at 1200 tokens (~43% pair death on
        # astronomy encyclopedia articles before this fix).
        cap = max(3600, 240 * rows + 700)
    elif stage.endswith("audit.icl") or stage == "audit.icl":
        rows = max(1, prompt.count('"term_id"') - 1)
        cap = max(1000, 170 * rows + 600)
    elif stage.endswith("audit.gcl") or stage == "audit.gcl":
        rows = max(1, prompt.count('"support_id"') - 3)
        # Same no-truncation rule as fidelity: the schema-support verdict JSON
        # carries per-support evidence and ran past the old 360/row+1200 cap
        # (unterminated string at ~16.5k chars) on part_2 articles.  520/row
        # still cut row-dense institutional-guidance at the cap (17 rows →
        # 10240 tokens ≈ 10.4k chars of dense JSON): verdict rows with exact
        # evidence spans run ~600-700 tokens worst case, so size for that.
        cap = max(3600, 700 * rows + 1400)
    elif "audit.ecl" in stage:
        cap = 2800
    elif stage == "repair.local_patch":
        rows = max(1, prompt.count('"instruction_id"') - 1)
        cap = max(1200, 420 * rows + 700)
    elif stage == "il.post_rewrite.local":
        rows = max(1, prompt.count('"term_id"') - 1)
        cap = min(900, 220 + 130 * rows)
    elif stage == "gcl.post_rewrite.local":
        cap = 420
    if cap is None:
        return requested
    if requested is None:
        return cap
    return min(int(requested), cap)


def pipeline_contract() -> dict[str, Any]:
    return {
        "schema_version": PIPELINE_SCHEMA,
        "agents": {
            "source_compiler": {"execution": "local_once_per_article", "output": SOURCE_IR_SCHEMA},
            "strategy_agent": {"input": "source_ir+compact_reader_contract", "output": STRATEGY_IR_SCHEMA},
            "rewrite_agent": {"input": "source+frozen_icl_ecl_and_term_bridges", "output": "optimized_content_tags_only"},
            "post_rewrite_il": {
                "input": "missing_hard_gloss_terms+one_source_sentence+one_candidate_anchor",
                "output": POST_IL_SCHEMA,
                "execution": "deterministic_or_cache_first_then_shared_micro_budget",
            },
            "post_rewrite_gcl": {
                "input": "source_evidence+actual_candidate_anchor+guidance_contract",
                "output": POST_GCL_SCHEMA,
                "execution": "existing_guidance_or_zero_call_local_then_shared_micro_budget",
            },
            "evaluation_router": {"input": "deterministic_precheck_then_scoped_specialist", "output": "existing_fail_closed_schemas"},
            "repair_agent": {"input": "selected_instructions+anchors+source_evidence", "output": "bounded_sentence_patches"},
        },
        "post_rewrite_shared_limits": {
            "micro_api_calls_max": POST_LOCAL_MICRO_CALL_BUDGET,
            "il_gloss_words_each_max": POST_IL_GLOSS_MAX_WORDS,
            "il_added_words_total_max": POST_IL_TOTAL_WORD_CAP,
            "gcl_word_reserve": POST_GCL_WORD_RESERVE,
        },
        "conversation_history": "disabled_stateless_artifacts",
        "raw_dataset_mutation": False,
    }
