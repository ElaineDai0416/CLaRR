#!/usr/bin/env python3
"""Unified CLaRR V4 ECL structure scoring and structural utilities.

This module combines deterministic structure extraction with the frozen V4
feature scorer. The guarded repair controller remains in ``ecl_repair_v4``.
"""

from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


ROOT = Path(__file__).resolve().parent
PROMPT_PATH = ROOT / "ecl_prompts" / "base.md"
SCHEMA_VERSION = "ecl-structure-auto-v1"
CORE_COMMON = ("S-COHERENCE", "S-PROPORTIONALITY", "S-NONMECHANICAL")
FEATURE_NAMES = (
    "S-COHERENCE",
    "S-LOGICAL-ORGANIZATION",
    "S-EMOTIONAL-PROGRESSION",
    "S-PROPORTIONALITY",
    "S-NONMECHANICAL",
)
DIAGNOSTIC_NAMES = (
    "D-HEADING-HIERARCHY",
    "D-PARAGRAPH-ORGANIZATION",
    "D-LIST-APPROPRIATENESS",
)
HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S")
LIST_RE = re.compile(r"^\s{0,3}(?:[-+*]|\d+[.)])\s+\S")
QUOTE_RE = re.compile(r"^\s*>")
FENCE_RE = re.compile(r"^\s*(```|~~~)")


class ECLStructureError(ValueError):
    pass


@dataclass(frozen=True)
class ECLRepairPolicy:
    max_rounds: int = 2
    repair_diagnostics: bool = False
    require_existing_gate: bool = True
    require_no_active_regression: bool = True


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _json_object(raw: str) -> dict[str, Any]:
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", raw)
        if not match:
            raise ECLStructureError("LLM response did not contain a JSON object")
        value = json.loads(match.group())
    if not isinstance(value, dict):
        raise ECLStructureError("LLM response JSON must be an object")
    return value


def _call_json(llm_call: Callable[..., str], prompt: str, max_tokens: int) -> dict[str, Any]:
    try:
        raw = llm_call(
            prompt,
            max_tokens=max_tokens,
            temperature=0,
            response_format={"type": "json_object"},
        )
    except TypeError as exc:
        if "response_format" not in str(exc):
            raise
        raw = llm_call(prompt, max_tokens=max_tokens, temperature=0)
    return _json_object(raw)


def _is_prose_block(block: str) -> bool:
    lines = [line for line in block.splitlines() if line.strip()]
    if not lines or FENCE_RE.match(lines[0]) or QUOTE_RE.match(lines[0]):
        return False
    if all(HEADING_RE.match(line) for line in lines):
        return False
    if all(LIST_RE.match(line) for line in lines):
        return False
    return True


def candidate_structure_facts(candidate_markdown: str) -> dict[str, Any]:
    """Return deterministic applicability facts and stable paragraph IDs."""
    blocks = [block.strip() for block in re.split(r"\n\s*\n", candidate_markdown) if block.strip()]
    prose = [block for block in blocks if _is_prose_block(block)]
    return {
        "has_explicit_markdown_headings": any(
            HEADING_RE.match(line) for line in candidate_markdown.splitlines()
        ),
        "has_markdown_list_blocks": any(
            LIST_RE.match(line) for line in candidate_markdown.splitlines()
        ),
        "n_top_level_prose_paragraphs": len(prose),
        "prose_paragraphs": [
            {"paragraph_id": f"P{index:02d}", "paragraph_text": paragraph}
            for index, paragraph in enumerate(prose, start=1)
        ],
    }


def active_feature_names(preference: str) -> tuple[str, ...]:
    normalized = preference.strip().title()
    if normalized not in {"Logical", "Emotional"}:
        raise ECLStructureError(f"invalid presentation preference: {preference!r}")
    fit = "S-LOGICAL-ORGANIZATION" if normalized == "Logical" else "S-EMOTIONAL-PROGRESSION"
    return (*CORE_COMMON, fit)


def _inactive_feature_name(preference: str) -> str:
    return (
        "S-EMOTIONAL-PROGRESSION"
        if preference.strip().title() == "Logical"
        else "S-LOGICAL-ORGANIZATION"
    )


def _require_mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ECLStructureError(f"{label} must be an object")
    return dict(value)


def _validate_evidence(quotes: Any, candidate: str, label: str) -> list[str]:
    if not isinstance(quotes, list) or not all(isinstance(item, str) for item in quotes):
        raise ECLStructureError(f"{label}.candidate_evidence must be a string list")
    if len(quotes) > 2:
        raise ECLStructureError(f"{label}.candidate_evidence allows at most two excerpts")
    for quote in quotes:
        if quote and quote not in candidate:
            raise ECLStructureError(f"{label}: candidate evidence is not an exact substring")
    return quotes


def _validate_scored_dimension(
    name: str,
    value: Any,
    candidate: str,
    *,
    allow_na: bool,
) -> dict[str, Any]:
    item = _require_mapping(value, name)
    required = {
        "score", "candidate_evidence", "rationale", "failure_tags",
        "repair_instruction", "confidence",
    }
    missing = required - set(item)
    if missing:
        raise ECLStructureError(f"{name}: missing fields {sorted(missing)}")
    score = str(item["score"]).upper()
    allowed = {"0", "1", "2", "U"} | ({"NA"} if allow_na else set())
    if score not in allowed:
        raise ECLStructureError(f"{name}: invalid score {score!r}")
    item["score"] = score
    item["candidate_evidence"] = _validate_evidence(item["candidate_evidence"], candidate, name)
    if not isinstance(item["failure_tags"], list):
        raise ECLStructureError(f"{name}.failure_tags must be a list")
    item["failure_tags"] = [str(tag).strip() for tag in item["failure_tags"] if str(tag).strip()]
    item["rationale"] = str(item["rationale"]).strip()
    item["repair_instruction"] = str(item["repair_instruction"]).strip()
    item["confidence"] = str(item["confidence"]).strip().lower()
    if score == "NA":
        if item["candidate_evidence"] or item["repair_instruction"]:
            raise ECLStructureError(f"{name}: NA requires empty evidence and repair instruction")
        if item["confidence"] != "not_applicable":
            raise ECLStructureError(f"{name}: NA requires confidence=not_applicable")
    elif score == "U":
        if item["confidence"] != "low" or not item["rationale"]:
            raise ECLStructureError(f"{name}: U requires a rationale and low confidence")
    else:
        if item["confidence"] not in {"high", "medium", "low"}:
            raise ECLStructureError(f"{name}: invalid confidence")
        if not item["rationale"]:
            raise ECLStructureError(f"{name}: automatic numeric score requires a rationale")
        if score in {"0", "1"} and not item["repair_instruction"]:
            raise ECLStructureError(f"{name}: failed score requires repair_instruction")
        if score == "2" and item["repair_instruction"]:
            raise ECLStructureError(f"{name}: score 2 must not request repair")
    return item


def _na_diagnostic(reason: str) -> dict[str, Any]:
    return {
        "score": "NA",
        "candidate_evidence": [],
        "rationale": reason,
        "failure_tags": [],
        "repair_instruction": "",
        "confidence": "not_applicable",
    }


def _derive_topic(
    value: Any,
    facts: Mapping[str, Any],
    candidate: str,
) -> dict[str, Any]:
    diagnostic = _require_mapping(value, "D-TOPIC-SENTENCE-COVERAGE")
    paragraphs = diagnostic.get("paragraphs")
    if not isinstance(paragraphs, list):
        raise ECLStructureError("D-TOPIC-SENTENCE-COVERAGE.paragraphs must be a list")
    expected_ids = [item["paragraph_id"] for item in facts["prose_paragraphs"]]
    actual_ids = [str(item.get("paragraph_id", "")) for item in paragraphs if isinstance(item, Mapping)]
    if actual_ids != expected_ids:
        raise ECLStructureError("topic paragraph IDs/order differ from deterministic paragraphs")
    counts = {"clear": 0, "partial": 0, "absent": 0, "U": 0}
    normalized: list[dict[str, Any]] = []
    for raw in paragraphs:
        paragraph = _require_mapping(raw, "topic paragraph")
        eligible = bool(paragraph.get("eligible"))
        label = str(paragraph.get("label", ""))
        quote = str(paragraph.get("topic_sentence_quote", "")).strip()
        if quote and quote not in candidate:
            raise ECLStructureError(f"{paragraph.get('paragraph_id')}: topic quote is not exact")
        if eligible:
            if label not in counts:
                raise ECLStructureError(f"{paragraph.get('paragraph_id')}: invalid eligible label")
            counts[label] += 1
            if label in {"clear", "partial"} and not quote:
                raise ECLStructureError(f"{paragraph.get('paragraph_id')}: label requires quote")
            if label == "absent" and quote:
                raise ECLStructureError(f"{paragraph.get('paragraph_id')}: absent must not quote")
        elif label != "NA" or quote:
            raise ECLStructureError(f"{paragraph.get('paragraph_id')}: ineligible paragraph must be NA")
        normalized.append({
            "paragraph_id": str(paragraph.get("paragraph_id", "")),
            "paragraph_role": str(paragraph.get("paragraph_role", "body")),
            "eligible": eligible,
            "label": label,
            "topic_sentence_quote": quote,
            "rationale": str(paragraph.get("rationale", "")).strip(),
        })
    n_eligible = sum(counts.values())
    status = str(diagnostic.get("status", "")).upper()
    if not expected_ids:
        status = "NA"
    if status == "OK" and (n_eligible == 0 or counts["U"]):
        raise ECLStructureError("topic status OK requires eligible paragraphs and no U")
    if status == "NA" and n_eligible:
        raise ECLStructureError("topic status NA requires zero eligible paragraphs")
    if status == "U" and not str(diagnostic.get("abstention_reason", "")).strip():
        raise ECLStructureError("topic status U requires abstention_reason")
    if status not in {"OK", "NA", "U"}:
        raise ECLStructureError(f"invalid topic status {status!r}")
    coverage = None
    if status == "OK":
        coverage = (counts["clear"] + 0.5 * counts["partial"]) / n_eligible
    return {
        "status": status,
        "paragraphs": normalized,
        "abstention_reason": str(diagnostic.get("abstention_reason", "")).strip(),
        "n_eligible": n_eligible,
        "n_clear": counts["clear"],
        "n_partial": counts["partial"],
        "n_absent": counts["absent"],
        "n_u": counts["U"],
        "coverage": coverage,
    }


def validate_and_derive_score(
    response: Mapping[str, Any],
    candidate: str,
    preference: str,
    item_id: str,
) -> dict[str, Any]:
    """Validate a candidate-only judge response and deterministically derive P-STRUCTURE."""
    value = deepcopy(dict(response))
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ECLStructureError("schema_version mismatch")
    if str(value.get("item_id", "")) != str(item_id):
        raise ECLStructureError("item_id mismatch")
    normalized_preference = preference.strip().title()
    if str(value.get("presentation_preference", "")).title() != normalized_preference:
        raise ECLStructureError("presentation_preference mismatch")
    features = _require_mapping(value.get("features"), "features")
    if set(features) != set(FEATURE_NAMES):
        raise ECLStructureError("features must contain exactly the five frozen fields")
    active = active_feature_names(normalized_preference)
    inactive = _inactive_feature_name(normalized_preference)
    normalized_features = {
        name: _validate_scored_dimension(
            name, features[name], candidate, allow_na=(name == inactive)
        )
        for name in FEATURE_NAMES
    }
    if normalized_features[inactive]["score"] != "NA":
        raise ECLStructureError(f"{inactive}: inactive feature must be NA")
    for name in active:
        if normalized_features[name]["score"] == "NA":
            raise ECLStructureError(f"{name}: active feature cannot be NA")

    diagnostics = _require_mapping(value.get("diagnostics"), "diagnostics")
    if set(diagnostics) != {*DIAGNOSTIC_NAMES, "D-TOPIC-SENTENCE-COVERAGE"}:
        raise ECLStructureError("diagnostics must contain exactly four frozen fields")
    facts = candidate_structure_facts(candidate)
    normalized_diagnostics: dict[str, Any] = {}
    overrides: list[dict[str, str]] = []
    applicability = {
        "D-HEADING-HIERARCHY": (
            facts["has_explicit_markdown_headings"], "No explicit Markdown heading"
        ),
        "D-LIST-APPROPRIATENESS": (
            facts["has_markdown_list_blocks"], "No Markdown list block"
        ),
        "D-PARAGRAPH-ORGANIZATION": (
            facts["n_top_level_prose_paragraphs"] >= 2,
            "Fewer than two top-level prose paragraphs",
        ),
    }
    for name in DIAGNOSTIC_NAMES:
        applicable, reason = applicability[name]
        if not applicable:
            original = str(_require_mapping(diagnostics[name], name).get("score", ""))
            normalized_diagnostics[name] = _na_diagnostic(reason)
            if original != "NA":
                overrides.append({"field": name, "from": original, "to": "NA", "reason": reason})
        else:
            item = _validate_scored_dimension(name, diagnostics[name], candidate, allow_na=False)
            normalized_diagnostics[name] = item
    normalized_diagnostics["D-TOPIC-SENTENCE-COVERAGE"] = _derive_topic(
        diagnostics["D-TOPIC-SENTENCE-COVERAGE"], facts, candidate
    )

    scores = [normalized_features[name]["score"] for name in active]
    if "U" in scores:
        aggregate = "U"
        passed = None
    else:
        aggregate = str(min(int(score) for score in scores))
        passed = int(aggregate == "2")
    repair_targets = [name for name in active if normalized_features[name]["score"] in {"0", "1"}]
    return {
        "schema_version": SCHEMA_VERSION,
        "item_id": str(item_id),
        "presentation_preference": normalized_preference,
        "candidate_sha256": _sha256(candidate),
        "candidate_organizing_principle": str(value.get("candidate_organizing_principle", "")).strip(),
        "features": normalized_features,
        "diagnostics": normalized_diagnostics,
        "derived": {
            "active_features": list(active),
            "p_structure_score": aggregate,
            "p_structure_pass": passed,
            "repair_targets": repair_targets,
        },
        "applicability_overrides": overrides,
        "record_confidence": str(value.get("record_confidence", "")).strip().lower(),
    }


def scoring_prompt(candidate: str, preference: str, item_id: str) -> str:
    rubric = PROMPT_PATH.read_text(encoding="utf-8")
    payload = {
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "candidate_markdown": candidate,
        "deterministic_structure_facts": candidate_structure_facts(candidate),
    }
    return rubric + "\n\n## Item to score\n\n" + json.dumps(payload, ensure_ascii=False, indent=2)


def _legacy_score_candidate(
    candidate: str,
    preference: str,
    item_id: str,
    llm_call: Callable[..., str],
) -> dict[str, Any]:
    raw = _call_json(llm_call, scoring_prompt(candidate, preference, item_id), max_tokens=6500)
    return validate_and_derive_score(raw, candidate, preference, item_id)


def parse_and_validate_score(
    raw_text: str,
    candidate: str,
    preference: str,
    item_id: str,
) -> dict[str, Any]:
    """Parse one raw response, sanitize audit excerpts, and validate its scores.

    Candidate evidence is audit metadata, not a scoring input.  GLM sometimes
    wraps an otherwise useful excerpt in commentary, adds an ellipsis, or emits
    more than the two allowed excerpts.  Invalid excerpts are therefore dropped
    deterministically; scores, rationales, tags, and repair instructions are
    never altered by this sanitation step.
    """
    def recover_exact_excerpt(quote: str) -> str:
        if quote in candidate:
            return quote
        # Recover excerpts that are verbatim after removing inline Markdown
        # emphasis/code markers.  The returned value is always an exact slice
        # of the original candidate, so no text is invented.
        stripped: list[str] = []
        source_positions: list[int] = []
        for index, char in enumerate(candidate):
            if char in {"*", "_", "`"}:
                continue
            stripped.append(char)
            source_positions.append(index)
        plain = "".join(stripped)
        start = plain.find(quote)
        if start < 0:
            compact_chars: list[str] = []
            compact_positions: list[int] = []
            for index, char in enumerate(plain):
                if char.isspace():
                    next_index = index + 1
                    while next_index < len(plain) and plain[next_index].isspace():
                        next_index += 1
                    if next_index < len(plain) and plain[next_index] in ".,;:!?":
                        continue
                compact_chars.append(char)
                compact_positions.append(source_positions[index])
            compact_plain = "".join(compact_chars)
            compact_quote = re.sub(r"\s+([.,;:!?])", r"\1", quote)
            compact_start = compact_plain.find(compact_quote)
            if compact_start >= 0 and compact_quote:
                compact_end = compact_start + len(compact_quote) - 1
                return candidate[
                    compact_positions[compact_start]:compact_positions[compact_end] + 1
                ]
        if start < 0 or not quote:
            return ""
        end = start + len(quote) - 1
        return candidate[source_positions[start]:source_positions[end] + 1]

    response = _json_object(raw_text)
    repairs: list[dict[str, Any]] = []
    for section_name in ("features", "diagnostics"):
        section = response.get(section_name)
        if not isinstance(section, Mapping):
            continue
        for dimension, raw_item in section.items():
            if dimension == "D-TOPIC-SENTENCE-COVERAGE" or not isinstance(raw_item, Mapping):
                continue
            item = dict(raw_item)
            evidence = item.get("candidate_evidence")
            if not isinstance(evidence, list):
                continue
            before = list(evidence)
            after = []
            for quote in evidence:
                if not isinstance(quote, str):
                    continue
                recovered = recover_exact_excerpt(quote)
                if recovered:
                    after.append(recovered)
                if len(after) == 2:
                    break
            if after != before:
                item["candidate_evidence"] = after
                section[dimension] = item
                repairs.append({
                    "dimension": str(dimension),
                    "action": "drop_non_exact_or_excess_audit_excerpt",
                    "before_count": len(before),
                    "after_count": len(after),
                })
    diagnostics = response.get("diagnostics")
    topic = diagnostics.get("D-TOPIC-SENTENCE-COVERAGE") if isinstance(diagnostics, Mapping) else None
    paragraphs = topic.get("paragraphs") if isinstance(topic, Mapping) else None
    if isinstance(paragraphs, list):
        for paragraph in paragraphs:
            if not isinstance(paragraph, dict):
                continue
            quote = paragraph.get("topic_sentence_quote")
            if not isinstance(quote, str) or not quote or quote in candidate:
                continue
            recovered = recover_exact_excerpt(quote)
            if recovered:
                paragraph["topic_sentence_quote"] = recovered
                repairs.append({
                    "dimension": "D-TOPIC-SENTENCE-COVERAGE",
                    "paragraph_id": str(paragraph.get("paragraph_id", "")),
                    "action": "restore_exact_markdown_audit_excerpt",
                })
    score = validate_and_derive_score(response, candidate, preference, item_id)
    score["evidence_sanitization"] = repairs
    return score


def select_repair_targets(
    score: Mapping[str, Any], *, repair_diagnostics: bool = False
) -> list[dict[str, Any]]:
    targets: list[dict[str, Any]] = []
    for name in score["derived"]["repair_targets"]:
        targets.append({"dimension": name, **score["features"][name]})
    if repair_diagnostics:
        for name in DIAGNOSTIC_NAMES:
            item = score["diagnostics"][name]
            if item["score"] in {"0", "1"}:
                targets.append({"dimension": name, **item})
    return targets


def repair_prompt(
    candidate: str,
    preference: str,
    score: Mapping[str, Any],
    *,
    repair_diagnostics: bool = False,
) -> str:
    targets = select_repair_targets(score, repair_diagnostics=repair_diagnostics)
    return f"""You are the ECL structure repairer in a controlled rewrite pipeline.

Repair only the listed ECL structural weaknesses in the candidate Markdown.
The source article is intentionally unavailable. This is not a factual rewrite.

Hard constraints:
- Preserve every factual proposition, entity, quantity, date, condition, example,
  technical term, and reader-directed recommendation already present.
- Add no new factual content, example, analogy, causal explanation, or advice.
- Do not delete content merely to improve style. You may move intact sentences or
  paragraphs, merge/split paragraphs, remove decorative scaffolding, and minimally
  edit transition wording.
- Preserve the declared presentation preference.
- Address only the listed dimensions; do not optimize diagnostics that are absent.
- Return JSON only.

PRESENTATION PREFERENCE
{preference.strip().title()}

TARGETED ECL FAILURES
{json.dumps(targets, ensure_ascii=False, indent=2)}

CANDIDATE MARKDOWN
{candidate}

Return:
{{
  "repaired_candidate_markdown": "complete candidate",
  "changes": [{{"dimension":"exact target name","before":"exact short span or block description","after":"short description"}}],
  "preservation_check": {{"claims_added":false,"claims_deleted":false,"quantities_changed":false,"terms_changed":false}}
}}
"""


def _gate_pass(result: Mapping[str, Any]) -> bool:
    if "overall_pass" in result:
        return bool(result["overall_pass"])
    if isinstance(result.get("selected_control_gate"), Mapping):
        return bool(result["selected_control_gate"].get("overall_pass"))
    if "release_ready" in result:
        return bool(result["release_ready"])
    raise ECLStructureError("existing gate result must expose overall_pass or release_ready")


def _score_rank(score: Mapping[str, Any]) -> tuple[int, int, int]:
    names = score["derived"]["active_features"]
    values = [int(score["features"][name]["score"]) for name in names]
    return min(values), sum(value == 2 for value in values), sum(values)


def _active_regressions(before: Mapping[str, Any], after: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    for name in before["derived"]["active_features"]:
        old = before["features"][name]["score"]
        new = after["features"][name]["score"]
        if old in {"0", "1", "2"} and new in {"0", "1", "2"} and int(new) < int(old):
            result.append(name)
    return result


def validate_and_repair_ecl(
    candidate: str,
    preference: str,
    item_id: str,
    llm_call: Callable[..., str],
    existing_gate: Callable[[str], Mapping[str, Any]] | None,
    policy: ECLRepairPolicy | None = None,
    existing_gate_policy_id: str = "unchanged-existing-gate",
) -> dict[str, Any]:
    """Score, repair failed ECL features, and re-run the caller's unchanged gate."""
    policy = policy or ECLRepairPolicy()
    if policy.require_existing_gate and existing_gate is None:
        raise ECLStructureError("ECL repair requires the existing full validation gate")
    initial_gate = dict(existing_gate(candidate)) if existing_gate else {"overall_pass": True}
    initial_score = _legacy_score_candidate(candidate, preference, item_id, llm_call)
    base = {
        "schema_version": "ecl-structure-repair-v1",
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "existing_gate_policy_id": existing_gate_policy_id,
        "initial_candidate": candidate,
        "initial_candidate_sha256": _sha256(candidate),
        "initial_ecl_score": initial_score,
        "initial_existing_gate": initial_gate,
        "history": [],
    }
    if not _gate_pass(initial_gate):
        return {
            **base,
            "status": "blocked_by_existing_gate",
            "final_candidate": candidate,
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "ecl_repair_rounds_used": 0,
        }
    if initial_score["derived"]["p_structure_pass"] == 1:
        return {
            **base,
            "status": "passed_without_ecl_repair",
            "final_candidate": candidate,
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "ecl_repair_rounds_used": 0,
        }
    if initial_score["derived"]["p_structure_score"] == "U":
        return {
            **base,
            "status": "unresolved_ecl_score",
            "final_candidate": candidate,
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "ecl_repair_rounds_used": 0,
        }

    current = candidate
    current_score = initial_score
    current_gate = initial_gate
    history: list[dict[str, Any]] = []
    accepted_rounds = 0
    for round_index in range(1, policy.max_rounds + 1):
        targets = select_repair_targets(
            current_score, repair_diagnostics=policy.repair_diagnostics
        )
        if not targets:
            break
        raw = _call_json(
            llm_call,
            repair_prompt(
                current,
                preference,
                current_score,
                repair_diagnostics=policy.repair_diagnostics,
            ),
            max_tokens=5000,
        )
        proposed = str(raw.get("repaired_candidate_markdown", "")).strip()
        record: dict[str, Any] = {
            "round": round_index,
            "targets": [item["dimension"] for item in targets],
            "before_sha256": _sha256(current),
            "proposal_sha256": _sha256(proposed) if proposed else "",
            "changes": raw.get("changes", []),
            "preservation_check": raw.get("preservation_check", {}),
            "accepted": False,
        }
        if not proposed or proposed == current:
            record["rejection_reason"] = "empty_or_unchanged_proposal"
            history.append(record)
            continue
        proposed_gate = dict(existing_gate(proposed)) if existing_gate else {"overall_pass": True}
        record["existing_gate"] = proposed_gate
        if not _gate_pass(proposed_gate):
            record["rejection_reason"] = "existing_gate_failed"
            history.append(record)
            continue
        proposed_score = _legacy_score_candidate(proposed, preference, item_id, llm_call)
        regressions = _active_regressions(current_score, proposed_score)
        record["ecl_score"] = proposed_score
        record["active_regressions"] = regressions
        if policy.require_no_active_regression and regressions:
            record["rejection_reason"] = "active_ecl_feature_regressed"
            history.append(record)
            continue
        if _score_rank(proposed_score) <= _score_rank(current_score):
            record["rejection_reason"] = "ecl_score_did_not_improve"
            history.append(record)
            continue
        record["accepted"] = True
        history.append(record)
        current = proposed
        current_score = proposed_score
        current_gate = proposed_gate
        accepted_rounds += 1
        if current_score["derived"]["p_structure_pass"] == 1:
            break

    if current_score["derived"]["p_structure_pass"] == 1:
        status = "passed_after_ecl_repair"
    elif accepted_rounds:
        status = "improved_but_below_ecl_pass"
    else:
        status = "no_acceptable_ecl_repair"
    return {
        **base,
        "history": history,
        "status": status,
        "final_candidate": current,
        "final_candidate_sha256": _sha256(current),
        "final_ecl_score": current_score,
        "final_existing_gate": current_gate,
        "ecl_repair_rounds_used": accepted_rounds,
    }

# ---------------------------------------------------------------------------
# Frozen V4 scorer
# ---------------------------------------------------------------------------

PROMPT_DIR = ROOT / "ecl_prompts/v4"
COMMON_PROMPT_PATH = PROMPT_DIR / "common_calibration.md"
FEATURE_SCHEMA_VERSION = "ecl-structure-feature-v1.4.3"
OUTPUT_SCHEMA_VERSION = "ecl-structure-auto-v1.4.3"
RUBRIC_VERSION = "v3.4-r4"
SEVERE_EXPANSION_AUDIT_RATIO = 1.60
DIMENSION_TO_PROMPT = {
    "S-COHERENCE": "coherence.md",
    "S-PROPORTIONALITY-INTERNAL": "proportionality_internal.md",
    "S-NONMECHANICAL": "nonmechanical.md",
    "S-LOGICAL-ORGANIZATION": "logical_organization.md",
    "S-EMOTIONAL-PROGRESSION": "emotional_progression.md",
}


class ECLV34Error(ECLStructureError):
    pass


def dimensions_for(preference: str) -> tuple[str, ...]:
    active = active_feature_names(preference)
    return (
        "S-COHERENCE",
        "S-PROPORTIONALITY-INTERNAL",
        "S-NONMECHANICAL",
        active[-1],
    )


def feature_prompt(dimension: str, item_id: str, preference: str, candidate: str) -> str:
    if dimension not in DIMENSION_TO_PROMPT:
        raise ECLV34Error(f"unknown v3.4 dimension: {dimension}")
    common = COMMON_PROMPT_PATH.read_text(encoding="utf-8")
    rubric = (PROMPT_DIR / DIMENSION_TO_PROMPT[dimension]).read_text(encoding="utf-8")
    payload = {
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "dimension": dimension,
        "candidate_markdown": candidate,
        "deterministic_structure_facts": candidate_structure_facts(candidate),
    }
    return common + "\n\n" + rubric + "\n\n## Item\n\n" + json.dumps(
        payload, ensure_ascii=False, indent=2
    )


def parse_feature_response(
    raw: str,
    *,
    dimension: str,
    item_id: str,
    candidate: str,
) -> dict[str, Any]:
    value = _json_object(raw)
    if value.get("schema_version") != FEATURE_SCHEMA_VERSION:
        raise ECLV34Error("feature schema_version mismatch")
    if str(value.get("item_id", "")) != str(item_id):
        raise ECLV34Error("feature item_id mismatch")
    if value.get("dimension") != dimension:
        raise ECLV34Error("feature dimension mismatch")
    result_score = str(value.get("score", "")).upper()
    if result_score not in {"0", "1", "2", "U"}:
        raise ECLV34Error(f"invalid feature score: {result_score!r}")
    rationale = str(value.get("rationale", "")).strip()
    repair = str(value.get("repair_instruction", "")).strip()
    confidence = str(value.get("confidence", "")).strip().lower()
    if not rationale:
        raise ECLV34Error("feature rationale is required")
    if result_score in {"0", "1"} and not repair:
        raise ECLV34Error("failed feature requires repair_instruction")
    if result_score == "2" and repair:
        raise ECLV34Error("feature score 2 requires empty repair_instruction")
    if result_score == "U" and confidence != "low":
        raise ECLV34Error("feature U requires low confidence")
    if result_score != "U" and confidence not in {"high", "medium", "low"}:
        raise ECLV34Error("invalid feature confidence")
    evidence = value.get("candidate_evidence", [])
    if not isinstance(evidence, list):
        evidence = []
    exact = [quote for quote in evidence if isinstance(quote, str) and quote in candidate][:2]
    tags = value.get("failure_tags", [])
    if not isinstance(tags, list):
        tags = []
    return {
        "score": result_score,
        "candidate_evidence": exact,
        "rationale": rationale,
        "failure_tags": [str(tag).strip() for tag in tags if str(tag).strip()],
        "repair_instruction": repair,
        "confidence": confidence,
        "evidence_sanitized": exact != evidence,
    }


def build_score_record(
    *,
    item_id: str,
    preference: str,
    source_text: str,
    candidate: str,
    feature_results: Mapping[str, Mapping[str, Any]],
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    from ecl_structure_policy import build_score_record as build_v31_score_record

    record = build_v31_score_record(
        item_id=item_id,
        preference=preference,
        source_text=source_text,
        candidate=candidate,
        feature_results=feature_results,
        policy=policy,
    )
    record["schema_version"] = OUTPUT_SCHEMA_VERSION
    record["rubric_version"] = RUBRIC_VERSION
    expansion = record.get("expansion", {})
    ratio = expansion.get("candidate_source_ratio")
    severe_expansion = isinstance(ratio, (int, float)) and ratio > SEVERE_EXPANSION_AUDIT_RATIO
    expansion["severe_expansion_audit_ratio"] = SEVERE_EXPANSION_AUDIT_RATIO
    expansion["severe_expansion_flag"] = severe_expansion
    proportionality = record.get("features", {}).get("S-PROPORTIONALITY", {})
    proportionality["severe_expansion_flag"] = severe_expansion
    record.get("derived", {})["severe_expansion_flag"] = severe_expansion
    return record


def score_candidate(
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call: Callable[..., str],
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    """Run four independent v3.4-r4 judges and frozen deterministic aggregation."""
    results: dict[str, dict[str, Any]] = {}
    for dimension in dimensions_for(preference):
        raw = feature_llm_call(
            feature_prompt(dimension, item_id, preference, candidate),
            dimension=dimension,
            max_tokens=1400,
            temperature=0,
            response_format={"type": "json_object"},
        )
        results[dimension] = parse_feature_response(
            raw,
            dimension=dimension,
            item_id=item_id,
            candidate=candidate,
        )
    return build_score_record(
        item_id=item_id,
        preference=preference,
        source_text=source_text,
        candidate=candidate,
        feature_results=results,
        policy=policy,
    )
