"""True ICL/ECL/schema-support ablations over the frozen CLaRR pipeline.

Each condition removes one module at every causal stage: source evaluation,
strategy generation, unified-rewrite instructions, post-rewrite evaluation, and
targeted Repair. Claim fidelity remains active in every condition as the shared
research-safety baseline.
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


HERE = Path(__file__).resolve().parent
# The GitHub release keeps the frozen V4 runtime beside this module.
FINAL_CODE_DIR = HERE
if str(FINAL_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(FINAL_CODE_DIR))

import core as core  # noqa: E402
from comparative_scoring import build_three_dimension_score  # noqa: E402
from fidelity_repair import (  # noqa: E402
    FidelityPolicy,
    generation_guardrail,
    normalize_claim_contract,
    validate_candidate,
)
from il_fidelity import build_il_term_contract, validate_il_compliance  # noqa: E402
from integrated_repair import (  # noqa: E402
    INTEGRATED_REPAIR_VERSION,
    run_integrated_repair,
    score_ecl_candidate,
)
from schema_support import (  # noqa: E402
    build_schema_support_contract,
    evaluate_schema_support,
)
from strategy_execution import (  # noqa: E402
    build_ecl_preference_alignment_contract,
    build_gcl_schema_alignment_contract,
    build_icl_claim_alignment_contract,
    build_strategy_execution_contract,
    build_upfront_strategy_contract,
    compile_ecl_relation_plan,
    compile_gcl_support_plan,
    freeze_strategy_bundle,
)


ABLATION_SCHEMA_VERSION = "clarr-module-ablation-v1.0.0"
ALL_MODULES = frozenset({"icl", "ecl", "gcl"})


@dataclass(frozen=True)
class AblationSpec:
    name: str
    removed_module: str
    active_modules: frozenset[str]
    description: str

    def __post_init__(self) -> None:
        if self.removed_module not in ALL_MODULES:
            raise ValueError(f"unknown removed module: {self.removed_module}")
        if self.active_modules != ALL_MODULES - {self.removed_module}:
            raise ValueError("an ablation must remove exactly one strategy module")


ABLATION_SPECS: dict[str, AblationSpec] = {
    "no_icl": AblationSpec(
        name="no_icl",
        removed_module="icl",
        active_modules=frozenset({"ecl", "gcl"}),
        description="Remove term scoring, ICL evaluation/strategy, and IL Repair.",
    ),
    "no_ecl": AblationSpec(
        name="no_ecl",
        removed_module="ecl",
        active_modules=frozenset({"icl", "gcl"}),
        description="Remove structure/preference scoring, ECL strategy, and ECL Repair.",
    ),
    "no_schema_support": AblationSpec(
        name="no_schema_support",
        removed_module="gcl",
        active_modules=frozenset({"icl", "ecl"}),
        description="Remove schema-support/GCL contract, strategy, evaluation, and Repair.",
    ),
}
# Accept the historical experiment misspelling at the CLI boundary only.
ABLATION_ALIASES = {"no_shema_support": "no_schema_support"}


def resolve_spec(value: str | AblationSpec) -> AblationSpec:
    if isinstance(value, AblationSpec):
        return value
    name = ABLATION_ALIASES.get(str(value).strip().lower(), str(value).strip().lower())
    try:
        return ABLATION_SPECS[name]
    except KeyError as exc:
        raise ValueError(
            f"variant must be one of {sorted(ABLATION_SPECS)}"
        ) from exc


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _disabled_evaluation(module: str) -> dict[str, Any]:
    return {
        "status": "disabled_by_ablation",
        "module": module,
        "evaluated": False,
    }


def _mask_score_packet(
    value: dict[str, Any], active_modules: frozenset[str]
) -> dict[str, Any]:
    modules = dict(value.get("modules") or {})
    raw = dict(value.get("raw_evaluations") or {})
    for name in ALL_MODULES - active_modules:
        modules[name] = {
            "status": "disabled_by_ablation",
            "score": None,
            "components": {},
            "hard_pass": None,
            "failed_target_ids": [],
            "repair_signals": [],
        }
        raw[name] = _disabled_evaluation(name)
    active_scores = [float(modules[name]["score"]) for name in active_modules]
    value["modules"] = modules
    value["raw_evaluations"] = raw
    value["macro_score"] = round(sum(active_scores) / len(active_scores), 4)
    value["active_modules"] = sorted(active_modules)
    value["disabled_modules"] = sorted(ALL_MODULES - active_modules)
    return value


def evaluate_active_source_baseline(
    *,
    source_text: str,
    claim_contract: list[dict[str, Any]],
    il_term_contract: list[dict[str, Any]],
    schema_support_contract: dict[str, Any],
    preference: str,
    item_id: str,
    policy: FidelityPolicy,
    spec: AblationSpec,
    llm_call: Callable[..., str],
    feature_llm_call: Callable[..., str],
) -> dict[str, Any]:
    """Call only source evaluators that belong to the active condition."""
    claim_validation = validate_candidate(
        source_text, source_text, claim_contract, llm_call, policy
    )
    evaluations: dict[str, dict[str, Any]] = {
        name: _disabled_evaluation(name) for name in ALL_MODULES
    }
    with ThreadPoolExecutor(
        max_workers=len(spec.active_modules),
        thread_name_prefix="clarr-ablation-source",
    ) as pool:
        futures = {}
        if "icl" in spec.active_modules:
            futures["icl"] = pool.submit(
                validate_il_compliance,
                source_text,
                source_text,
                il_term_contract,
                claim_validation,
                llm_call,
            )
        if "gcl" in spec.active_modules:
            futures["gcl"] = pool.submit(
                evaluate_schema_support,
                source_text,
                source_text,
                schema_support_contract,
                claim_validation,
                llm_call,
                {},
            )
        if "ecl" in spec.active_modules:
            futures["ecl"] = pool.submit(
                score_ecl_candidate,
                source_text,
                source_text,
                preference,
                item_id + "_source_baseline",
                feature_llm_call,
            )
        for name, future in futures.items():
            evaluations[name] = future.result()
    score = build_three_dimension_score(
        candidate=source_text,
        il_evaluation=evaluations["icl"],
        ecl_evaluation=evaluations["ecl"],
        schema_evaluation=evaluations["gcl"],
        stage="source_before_strategy",
    )
    score = _mask_score_packet(score, spec.active_modules)
    score["claim_validation"] = claim_validation
    return score


def _strategy_prompt(
    module: str,
    *,
    source_text: str,
    reader_text: str,
    scored_terms_block: str,
    orig_words: int,
    max_words: int,
    icl_alignment: dict[str, Any],
    ecl_alignment: dict[str, Any],
    gcl_alignment: dict[str, Any],
    spec: AblationSpec,
) -> str:
    coordination = (
        "The other active strategy layer is generated in parallel; emit only this "
        "module's owned delta. Do not reconstruct an unlisted strategy layer."
    )
    if module == "icl":
        prompt = core.prompt_IL_strategy(
            source_text,
            scored_terms_block,
            reader_text,
            orig_words,
            max_words,
            icl_alignment,
        )
        if "gcl" not in spec.active_modules:
            prompt = prompt.replace(
                "ICL owns only source-proposition preservation, lexical complexity, and term actions.\n"
                "Do not choose paragraph structure (ECL) or explanation/analogy/guidance form (GCL).\n"
                "Later layers may place or explain an ICL term but may not change its required action.",
                "ICL owns only source-proposition preservation, lexical complexity, and term actions.\n"
                "Do not choose paragraph structure (ECL). Use only a short literal definition when a\n"
                "required term needs explanation; add no analogy, schema bridge, or engagement guidance.\n"
                "The active structure layer may place a term but may not change its required action.",
            )
            prompt = prompt.replace(
                "Core Expertise requires\nan adjacent explanation, but leave its explanatory form to GCL.",
                "Core Expertise requires an adjacent, short literal definition. Do not add "
                "analogy, schema bridge, engagement question, or cognitive guidance.",
            )
        if "ecl" not in spec.active_modules:
            prompt = prompt.replace(
                "ICL owns only source-proposition preservation, lexical complexity, and term actions.\n"
                "Do not choose paragraph structure (ECL) or explanation/analogy/guidance form (GCL).\n"
                "Later layers may place or explain an ICL term but may not change its required action.",
                "ICL owns only source-proposition preservation, lexical complexity, and term actions.\n"
                "Keep the source's organization; do not create paragraph-structure instructions. GCL\n"
                "may explain an ICL term but may not change its required action.",
            )
        return prompt + "\n\n### Ablation coordination\n" + coordination
    if module == "ecl":
        prompt = core.prompt_EL_strategy(
            source_text, reader_text, coordination, ecl_alignment
        )
        if "icl" not in spec.active_modules:
            prompt = prompt.replace(
                "ECL controls organization and presentation only. ICL controls lexical/claim-safe\n"
                "term treatment; GCL controls explanations and schema support. Do not redesign either.",
                "ECL controls organization and presentation only. The shared fidelity boundary\n"
                "preserves claims; GCL controls explanations and schema support. Do not redesign it.",
            ).replace(
                "The ICL strategy is generated independently from the same source and deterministic\n"
                "term contract. Do not repeat term actions or claim-preservation rules in this ECL\n"
                "strategy. Do not infer facts from the reader profile.",
                "No lexical or term-adaptation strategy is supplied. Preserve source terminology;\n"
                "plan organization only and do not infer facts from the reader profile.",
            )
        if "gcl" not in spec.active_modules:
            prompt = prompt.replace(
                "ECL controls organization and presentation only. ICL controls lexical/claim-safe\n"
                "term treatment; GCL controls explanations and schema support. Do not redesign either.",
                "ECL controls organization and presentation only. ICL controls lexical and\n"
                "claim-safe term treatment. Do not add explanations, analogies, engagement\n"
                "questions, or schema bridges in this organization strategy.",
            )
        return prompt
    if module == "gcl":
        prompt = core.prompt_GL_strategy(
            source_text, reader_text, coordination, gcl_alignment
        )
        if "icl" not in spec.active_modules:
            prompt = prompt.replace(
                "GCL adds only term explanations, schema bridges, and the minimum useful cognitive\n"
                "guidance. ICL has already fixed which terms/claims survive; ECL independently fixes\n"
                "organization. Do not repeat lexical actions or redesign paragraph relations.",
                "GCL adds only schema bridges and the minimum useful cognitive guidance. Shared\n"
                "fidelity constraints fix which claims survive; ECL independently fixes organization.\n"
                "No term-adaptation strategy is supplied, so do not invent lexical substitutions.",
            )
        if "ecl" not in spec.active_modules:
            prompt = prompt.replace(
                "GCL adds only term explanations, schema bridges, and the minimum useful cognitive\n"
                "guidance. ICL has already fixed which terms/claims survive; ECL independently fixes\n"
                "organization. Do not repeat lexical actions or redesign paragraph relations.",
                "GCL adds only term explanations, schema bridges, and the minimum useful cognitive\n"
                "guidance. ICL fixes term/claim treatment. Keep the source's order and paragraph\n"
                "relations; add only local support and do not create an organization strategy.",
            )
        return prompt
    raise ValueError(f"unknown strategy module: {module}")


def _strip_disabled_contracts(
    *,
    strategy_bundle: dict[str, Any],
    upfront: dict[str, Any],
    execution: dict[str, Any],
    active_modules: frozenset[str],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Remove disabled lanes after using frozen compiler invariants."""
    bundle = deepcopy(strategy_bundle)
    bundle["strategy_generation_calls"] = len(active_modules)
    bundle["generation_topology"] = "parallel_active_module_owned_deltas"
    bundle["strategies"] = {
        key: value for key, value in bundle.get("strategies", {}).items()
        if key in active_modules
    }
    bundle["strategy_sha256"] = {
        key: value for key, value in bundle.get("strategy_sha256", {}).items()
        if key in active_modules
    }
    bundle["deduplication"] = {
        "mode": "active_lanes_only",
        "active_modules": sorted(active_modules),
        "additional_llm_calls": 0,
    }
    bundle["disabled_modules"] = sorted(ALL_MODULES - active_modules)

    upfront_value = deepcopy(upfront)
    for name in ALL_MODULES - active_modules:
        upfront_value.pop(name, None)
    composition = dict(upfront_value.get("composition") or {})
    composition["layer_order"] = [
        name for name in ("icl", "ecl", "gcl") if name in active_modules
    ]
    composition["layer_ownership"] = {
        key: value for key, value in (composition.get("layer_ownership") or {}).items()
        if key in active_modules
    }
    composition["execution_rule"] = (
        "compose the two active frozen deltas, then perform one unified rewrite"
    )
    upfront_value["composition"] = composition
    upfront_value["active_modules"] = sorted(active_modules)
    upfront_value["disabled_modules"] = sorted(ALL_MODULES - active_modules)
    upfront_value["repair_role"] = (
        "repair only evaluator-confirmed omissions, incorrect executions, or local "
        "regressions in the active strategy lanes; do not add another strategy lane"
    )
    baseline = deepcopy(upfront_value.get("source_baseline_score") or {})
    baseline["modules"] = {
        key: value for key, value in (baseline.get("modules") or {}).items()
        if key in active_modules
    }
    baseline["raw_evaluations"] = {
        key: value for key, value in (baseline.get("raw_evaluations") or {}).items()
        if key in active_modules
    }
    baseline.pop("disabled_modules", None)
    upfront_value["source_baseline_score"] = baseline
    upfront_value["frozen_strategy_bundle"] = {
        key: value for key, value in bundle.items() if key != "strategies"
    }
    upfront_value.pop("contract_sha256", None)
    upfront_value["contract_sha256"] = _sha256(
        json.dumps(upfront_value, ensure_ascii=False, sort_keys=True)
    )

    execution_value = deepcopy(execution)
    for name in ALL_MODULES - active_modules:
        execution_value.pop(name, None)
    execution_value["strategy_sha256"] = {
        key: value
        for key, value in (execution_value.get("strategy_sha256") or {}).items()
        if key in active_modules
    }
    execution_value["composition"] = composition
    execution_value["source_baseline_score"] = baseline
    execution_value["active_modules"] = sorted(active_modules)
    execution_value["disabled_modules"] = sorted(ALL_MODULES - active_modules)
    execution_value["upfront_integration"]["contract_sha256"] = upfront_value[
        "contract_sha256"
    ]
    return bundle, upfront_value, execution_value


def build_active_rewrite_prompt(
    *,
    source_text: str,
    reader_text: str,
    strategies: Mapping[str, str],
    claim_guardrail: str,
    il_term_contract: list[dict[str, Any]],
    upfront_strategy_contract: dict[str, Any],
    orig_words: int,
    max_words: int,
) -> str:
    """One rewrite prompt containing exactly the two active strategy deltas."""
    labels = {"icl": "ICL", "ecl": "ECL", "gcl": "GCL/schema-support"}
    sections = "\n\n".join(
        f"### Frozen {labels[name]} strategy\n{strategies[name]}"
        for name in ("icl", "ecl", "gcl") if name in strategies
    )
    il_payload = (
        "\n\n### Active IL term contract\n"
        + json.dumps(il_term_contract, ensure_ascii=False, indent=2)
        if "icl" in strategies else ""
    )
    return f"""## CLaRR CONTROLLED ABLATION — SINGLE UNIFIED REWRITE
Rewrite the source once for the target reader. Execute every obligation in the two
frozen strategy sections below. Merge compatible instructions into the same sentence;
do not create a third strategy layer or add an additional rewrite pass.

### Shared claim-fidelity boundary (always active)
{claim_guardrail}

### Source
{source_text}

### Reader
{reader_text}

### Length
Source length: {orig_words} units. Hard maximum: {max_words} units.

{sections}
{il_payload}

### Active upfront integration contract
{json.dumps(upfront_strategy_contract, ensure_ascii=False, indent=2)}

### Output
Return only:
<Optimized Content>
[the complete rewritten article]
</Optimized Content>
Do not output plans, audits, strategy labels, or commentary.
"""


def build_active_condense_prompt(
    *,
    candidate: str,
    max_words: int,
    current_words: int,
    claim_guardrail: str,
    strategies: Mapping[str, str],
    strategy_execution_contract: dict[str, Any],
) -> str:
    active = ", ".join(name.upper() for name in strategies)
    return f"""Condense the candidate from {current_words} to at most {max_words} units.
Preserve every shared claim-fidelity obligation and every already-realized obligation
from the active strategy layers ({active}). Remove repetition and optional decoration
before shortening required explanations or relation/support sentences. Do not introduce
new facts and do not reconstruct an unlisted module.

CLAIM BOUNDARY:
{claim_guardrail}

ACTIVE EXECUTION CONTRACT:
{json.dumps(strategy_execution_contract, ensure_ascii=False, indent=2)}

CANDIDATE:
{candidate}

Return only <Optimized Content>...</Optimized Content>.
"""


_QUADRANT_DEFAULT_ACTION = {
    "Core Expertise": "retain_and_explain",
    "Peripheral Jargon": "replace_with_familiar_equivalent",
    "HF Concept": "retain_exact",
    "Redundant": "compress_or_merge",
}


def resolve_anchor_conflicts(
    il_contract: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Apply the frozen claim-slot precedence the alignment handshake expects.

    The frozen ``build_il_term_contract`` only upgrades the branches that check
    *linked* claims, so a term whose quadrant default is compression/pruning but
    that also names an immutable claim anchor (via ``immutable_slot_values``)
    keeps an unsafe ``required_action``.  The frozen
    ``build_icl_claim_alignment_contract`` then marks the conflict unresolved and
    ``build_upfront_strategy_contract`` aborts the pair — reachable only with
    dataset-style contracts that carry ``immutable_slot_values``.  This shim
    deterministically rewrites those actions to the anchor-safe actions the
    frozen checker accepts and the frozen prompts/validators already support;
    no LLM behaviour changes and the frozen modules stay untouched.
    """
    for term in il_contract:
        if not term.get("immutable_anchor_claim_ids"):
            continue
        default = _QUADRANT_DEFAULT_ACTION.get(
            str(term.get("quadrant", "")), "compress_or_merge"
        )
        if default == "compress_or_merge":
            term["required_action"] = "retain_anchor_compress_context"
        elif default == "replace_with_familiar_equivalent":
            term["required_action"] = (
                "replace_with_approved_familiar_form"
                if term.get("approved_familiar_forms")
                else "retain_and_gloss"
            )
    return il_contract


def raise_output_cap(call: Callable[..., str]) -> Callable[..., str]:
    """Lift the frozen 5000-token JSON evaluator caps to 8000.

    Dataset-scale contracts (e.g. 10 claims x 24 terms) can exceed the frozen
    evaluators' hardcoded ``max_tokens=5000`` and come back truncated, which
    invalidates the JSON and kills the pair.  DeepSeek accepts 8000; the raised
    cap only takes effect for responses that would otherwise be cut, so normal
    responses are unchanged.
    """
    def wrapped(prompt: str, *args: Any, **kwargs: Any) -> str:
        if isinstance(kwargs.get("max_tokens"), int) and kwargs["max_tokens"] < 8000:
            kwargs = {**kwargs, "max_tokens": 8000}
        return call(prompt, *args, **kwargs)
    return wrapped


def process_article_for_reader_ablation(
    article_id: str,
    article_text: str,
    reader_profile: dict[str, Any],
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None = None,
    *,
    variant: str | AblationSpec,
    article_title: str = "",
    fidelity_policy: FidelityPolicy | None = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    llm_call: Callable[..., str] | None = None,
    feature_llm_call: Callable[..., str] | None = None,
) -> dict[str, Any]:
    """Run one strict two-of-three module ablation with one unified rewrite."""
    spec = resolve_spec(variant)
    # 2026-09-02 用户解禁传输层:改用 04Ablation/llm_client.py(供应商可切换,
    # 环境变量选择 DeepSeek/DashScope-qwen),冻结层 core.py 零改动。
    # 签名/超时/空响应守卫与冻结版逐字段一致,调用方无感知。
    import llm_client as _transport  # noqa: WPS433 (延迟导入,便于测试桩替换)
    llm_call = llm_call or raise_output_cap(_transport.call_llm)
    feature_llm_call = feature_llm_call or raise_output_cap(
        _transport.call_ecl_feature_llm)
    fidelity_policy = fidelity_policy or FidelityPolicy()
    reader_text = core.format_reader(reader_profile)
    claim_contract = normalize_claim_contract(
        article_claim_record, simplification_ledger or {}
    )
    if not claim_contract:
        raise ValueError(f"No source claim contract found for {article_id}")
    claim_guardrail = generation_guardrail(claim_contract)
    orig_words = core.count_words(article_text)
    max_words = math.ceil(orig_words * (1 + core.MAX_INFLATION))

    call_manifest = {
        "term_extraction": False,
        "term_scoring": False,
        "source_evaluators": {name: name in spec.active_modules for name in ALL_MODULES},
        "strategy_generators": {name: name in spec.active_modules for name in ALL_MODULES},
        "unified_rewrite_calls": 1,
        "post_rewrite_evaluators": {
            name: enable_repair and name in spec.active_modules for name in ALL_MODULES
        },
        "repair_permissions": {
            "fidelity": enable_repair,
            **{
                name: enable_repair and name in spec.active_modules
                for name in ALL_MODULES
            },
        },
    }

    terms_raw_text = ""
    scored_terms: list[dict[str, Any]] = []
    if "icl" in spec.active_modules:
        call_manifest["term_extraction"] = True
        call_manifest["term_scoring"] = True
        terms_raw_text = llm_call(core.prompt_term_extraction(article_text))
        terms = core.normalize_extracted_terms(terms_raw_text, article_text)
        scored_terms = core.score_terms_for_reader(
            terms,
            article_text,
            reader_text,
            article_title=article_title,
            llm_call_fn=llm_call,
        )
    scored_terms_block = core.format_scored_terms(scored_terms)
    provisional_il_contract = (
        resolve_anchor_conflicts(build_il_term_contract(scored_terms, claim_contract))
        if "icl" in spec.active_modules else []
    )
    icl_alignment = (
        build_icl_claim_alignment_contract(claim_contract, provisional_il_contract)
        if "icl" in spec.active_modules else {}
    )
    schema_contract = (
        build_schema_support_contract(
            reader_profile, provisional_il_contract, claim_contract
        )
        if "gcl" in spec.active_modules else {}
    )
    ecl_alignment = (
        build_ecl_preference_alignment_contract(reader_profile, article_text)
        if "ecl" in spec.active_modules else {}
    )
    gcl_alignment = (
        build_gcl_schema_alignment_contract(schema_contract)
        if "gcl" in spec.active_modules else {}
    )
    preference = str(
        reader_profile.get("schema", {}).get("cognitive_style", "")
    ).strip().title()
    item_id = f"{article_id}_{reader_profile.get('id', 'reader')}"
    source_baseline = evaluate_active_source_baseline(
        source_text=article_text,
        claim_contract=claim_contract,
        il_term_contract=provisional_il_contract,
        schema_support_contract=schema_contract,
        preference=preference,
        item_id=item_id,
        policy=fidelity_policy,
        spec=spec,
        llm_call=llm_call,
        feature_llm_call=feature_llm_call,
    )
    if "icl" in spec.active_modules:
        icl_alignment["source_baseline_evaluation"] = core._compact_baseline_signal(
            source_baseline, "icl"
        )
    if "ecl" in spec.active_modules:
        ecl_alignment["source_baseline_evaluation"] = core._compact_baseline_signal(
            source_baseline, "ecl"
        )
    if "gcl" in spec.active_modules:
        gcl_alignment["source_baseline_evaluation"] = core._compact_baseline_signal(
            source_baseline, "gcl"
        )

    strategy_prompts = {
        name: _strategy_prompt(
            name,
            source_text=article_text,
            reader_text=reader_text,
            scored_terms_block=scored_terms_block,
            orig_words=orig_words,
            max_words=max_words,
            icl_alignment=icl_alignment,
            ecl_alignment=ecl_alignment,
            gcl_alignment=gcl_alignment,
            spec=spec,
        )
        for name in spec.active_modules
    }
    with ThreadPoolExecutor(
        max_workers=len(strategy_prompts),
        thread_name_prefix="clarr-ablation-strategy",
    ) as pool:
        futures = {
            name: pool.submit(llm_call, prompt)
            for name, prompt in strategy_prompts.items()
        }
        strategies = {name: future.result() for name, future in futures.items()}

    if "ecl" in spec.active_modules:
        ecl_alignment = compile_ecl_relation_plan(
            ecl_alignment, strategies["ecl"]
        )
    il_contract = (
        resolve_anchor_conflicts(
            build_il_term_contract(scored_terms, claim_contract, strategies["icl"])
        )
        if "icl" in spec.active_modules else []
    )
    if "icl" in spec.active_modules:
        icl_alignment = build_icl_claim_alignment_contract(
            claim_contract, il_contract
        )
        icl_alignment["source_baseline_evaluation"] = core._compact_baseline_signal(
            source_baseline, "icl"
        )
    if "gcl" in spec.active_modules:
        schema_contract = build_schema_support_contract(
            reader_profile, il_contract, claim_contract
        )
        gcl_alignment = build_gcl_schema_alignment_contract(schema_contract)
        gcl_alignment["source_baseline_evaluation"] = core._compact_baseline_signal(
            source_baseline, "gcl"
        )
        gcl_alignment = compile_gcl_support_plan(
            gcl_alignment, strategies["gcl"]
        )

    full_strategies = {
        "icl": strategies.get("icl", ""),
        "ecl": strategies.get("ecl", ""),
        "gcl": strategies.get("gcl", ""),
    }
    full_bundle = freeze_strategy_bundle(
        full_strategies["icl"], full_strategies["ecl"], full_strategies["gcl"]
    )
    full_upfront = build_upfront_strategy_contract(
        icl_claim_alignment=icl_alignment,
        ecl_preference_alignment=ecl_alignment,
        gcl_schema_alignment=gcl_alignment,
        strategy_bundle=full_bundle,
        source_baseline_score=source_baseline,
    )
    full_execution = build_strategy_execution_contract(
        reader_profile=reader_profile,
        icl_strategy=full_strategies["icl"],
        ecl_strategy=full_strategies["ecl"],
        gcl_strategy=full_strategies["gcl"],
        il_term_contract=il_contract,
        schema_support_contract=schema_contract,
        max_words=max_words,
        upfront_strategy_contract=full_upfront,
    )
    strategy_bundle, upfront_contract, execution_contract = _strip_disabled_contracts(
        strategy_bundle=full_bundle,
        upfront=full_upfront,
        execution=full_execution,
        active_modules=spec.active_modules,
    )

    raw_rewrite = llm_call(build_active_rewrite_prompt(
        source_text=article_text,
        reader_text=reader_text,
        strategies=strategies,
        claim_guardrail=claim_guardrail,
        il_term_contract=il_contract,
        upfront_strategy_contract=upfront_contract,
        orig_words=orig_words,
        max_words=max_words,
    ))
    content = core.extract_optimized_content(raw_rewrite)
    final_words = core.count_words(content)
    condensed = False
    if final_words > max_words:
        raw_rewrite = llm_call(build_active_condense_prompt(
            candidate=content,
            max_words=max_words,
            current_words=final_words,
            claim_guardrail=claim_guardrail,
            strategies=strategies,
            strategy_execution_contract=execution_contract,
        ))
        content = core.extract_optimized_content(raw_rewrite)
        final_words = core.count_words(content)
        condensed = True
        call_manifest["unified_rewrite_calls"] += 1

    pre_repair_text = content
    if enable_repair:
        repair_result = run_integrated_repair(
            source_text=article_text,
            candidate=content,
            contract=claim_contract,
            llm_call=llm_call,
            feature_llm_call=feature_llm_call,
            count_words=core.count_words,
            extract_content=core.extract_optimized_content,
            max_words=max_words,
            item_id=item_id,
            presentation_preference=preference,
            policy=fidelity_policy,
            reader_constraints=reader_text,
            il_term_contract=il_contract,
            schema_support_contract=schema_contract,
            strategy_execution_contract=execution_contract,
            ecl_max_rounds=(ecl_repair_rounds if "ecl" in spec.active_modules else 0),
            max_total_attempts=max_total_repair_attempts,
            audit_initial_strategy_execution=True,
            source_baseline_score=source_baseline,
            ecl_calibration_mode=(
                ecl_calibration_mode and "ecl" in spec.active_modules
            ),
            active_modules=spec.active_modules,
        )
        content = str(repair_result["analysis_content"])
    else:
        repair_result = {
            "method": "repair-disabled",
            "schema_version": ABLATION_SCHEMA_VERSION,
            "status": "disabled",
            "analysis_content": content,
            "release_content": content,
            "release_ready": True,
            "release_block_reasons": [],
            "repair_rounds_used": 0,
            "ecl_result": {"status": "disabled"},
        }
    final_words = core.count_words(content)
    release_content = repair_result.get("release_content")
    final_text = f"<Optimized Content>\n{content}\n</Optimized Content>"
    release_text = (
        f"<Optimized Content>\n{release_content}\n</Optimized Content>"
        if repair_result.get("release_ready") and release_content is not None
        else None
    )
    fidelity_component = repair_result.get(
        "fidelity_icl_schema_result", repair_result
    )
    repair_audit_keys = (
        "method", "schema_version", "status", "release_ready",
        "release_block_reasons", "repair_rounds_used", "accepted_repair_rounds",
        "stage_history", "module_isolation", "final_module_gate", "attempt_budget",
        "source_baseline_score", "initial_three_dimension_score",
        "initial_improvement", "final_three_dimension_score", "final_improvement",
    )
    return {
        "ablation": {
            "schema_version": ABLATION_SCHEMA_VERSION,
            "variant": spec.name,
            "removed_module": spec.removed_module,
            "active_modules": sorted(spec.active_modules),
            "shared_safety_module": "fidelity",
            "description": spec.description,
            "parent_code_dir": str(FINAL_CODE_DIR),
            "parent_integrated_repair_version": INTEGRATED_REPAIR_VERSION,
            "call_manifest": call_manifest,
        },
        "final_text": final_text,
        "release_text": release_text,
        "candidate_text": final_text,
        "output_disposition": repair_result.get(
            "output_disposition",
            "returned_release_ready" if repair_result.get("release_ready")
            else "returned_not_release_ready",
        ),
        "release_ready": bool(repair_result.get("release_ready")),
        "release_block_reasons": list(
            repair_result.get("release_block_reasons") or []
        ),
        "pre_repair_text": pre_repair_text,
        "extracted_terms": terms_raw_text,
        "scored_terms": scored_terms,
        "il_term_contract": il_contract,
        "schema_support_contract": schema_contract,
        "strategy_execution_contract": execution_contract,
        "upfront_strategy_contract": upfront_contract,
        "strategy_bundle": strategy_bundle,
        "strategies": {
            {"icl": "IL", "ecl": "EL", "gcl": "GL"}[name]: text
            for name, text in strategies.items()
        },
        "repair_method": repair_result.get("method", INTEGRATED_REPAIR_VERSION),
        "repair": {
            key: repair_result.get(key)
            for key in repair_audit_keys if key in repair_result
        },
        "initial_strategy_execution_audit": repair_result.get(
            "initial_strategy_execution_audit", {}
        ),
        "final_strategy_execution_audit": repair_result.get(
            "final_strategy_execution_audit", {}
        ),
        "three_dimension_evaluation": {
            "source_baseline": source_baseline,
            "initial_rewrite": repair_result.get("initial_three_dimension_score", {}),
            "initial_comparison": repair_result.get("initial_improvement"),
            "post_repair": repair_result.get("final_three_dimension_score", {}),
            "final_comparison": repair_result.get("final_improvement"),
        },
        "ecl": repair_result.get("ecl_result", {"status": "disabled"}),
        "fidelity": {
            "policy": asdict(fidelity_policy),
            "claim_contract": claim_contract,
            **fidelity_component,
        },
        "length": {
            "original_words": orig_words,
            "max_words": max_words,
            "max_inflation": core.MAX_INFLATION,
            "final_words": final_words,
            "within_budget": final_words <= max_words,
            "condensed": condensed,
            "pre_repair_words": core.count_words(pre_repair_text),
        },
    }


__all__ = [
    "ABLATION_SCHEMA_VERSION",
    "ABLATION_SPECS",
    "AblationSpec",
    "build_active_rewrite_prompt",
    "evaluate_active_source_baseline",
    "process_article_for_reader_ablation",
    "resolve_spec",
]
