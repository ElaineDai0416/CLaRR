#!/usr/bin/env python3
"""Guarded ECL Structure repair wired to the v3.4-r4 scorer."""

from __future__ import annotations

from typing import Any, Callable, Mapping

from ecl_repair_base import (
    ECLRepairV32Error,
    ECLRepairV32Policy,
    global_token_budget,
    proposal_action_compliance,
    protected_dimensions,
    repair_prompt,
    select_repair_targets,
    target_paragraph_locators,
    target_paragraph_coverage,
    validate_and_repair,
)
from ecl_structure_policy import ExpansionPolicy
from ecl_structure import RUBRIC_VERSION, score_candidate as score_candidate_v34


ECLRepairV34Error = ECLRepairV32Error
ECLRepairV34Policy = ECLRepairV32Policy
REPAIR_SCHEMA_VERSION = "ecl-structure-repair-v1.10.2-output-control"


def validate_and_repair_ecl_v34(
    *,
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call: Callable[..., str],
    repair_llm_call: Callable[..., str],
    existing_gate: Callable[[str], Mapping[str, Any]] | None,
    policy: ECLRepairV34Policy | None = None,
    existing_gate_policy_id: str = "unchanged-existing-gate",
    allowed_target_dimensions: set[str] | None = None,
    maximum_final_words: int | None = None,
    count_words: Callable[[str], int] | None = None,
) -> dict[str, Any]:
    """Evaluate with v3.4-r4, repair only its failures, then rescore with v3.4-r4."""
    effective_policy = policy or ECLRepairV34Policy()
    expansion_policy = ExpansionPolicy(effective_policy.max_unpenalized_ratio)

    def scorer(source: str, text: str, pref: str, identifier: str) -> Mapping[str, Any]:
        return score_candidate_v34(
            source,
            text,
            pref,
            identifier,
            feature_llm_call,
            expansion_policy,
        )

    result = validate_and_repair(
        source_text=source_text,
        candidate=candidate,
        preference=preference,
        item_id=item_id,
        score_candidate_call=scorer,
        repair_llm_call=repair_llm_call,
        existing_gate=existing_gate,
        policy=effective_policy,
        existing_gate_policy_id=existing_gate_policy_id,
        repair_rubric_version=RUBRIC_VERSION,
        allowed_target_dimensions=allowed_target_dimensions,
        maximum_final_words=maximum_final_words,
        count_words=count_words,
    )
    result["schema_version"] = REPAIR_SCHEMA_VERSION
    result["scorer_rubric_version"] = RUBRIC_VERSION
    return result


__all__ = [
    "ECLRepairV34Error",
    "ECLRepairV34Policy",
    "REPAIR_SCHEMA_VERSION",
    "global_token_budget",
    "proposal_action_compliance",
    "protected_dimensions",
    "repair_prompt",
    "select_repair_targets",
    "target_paragraph_locators",
    "target_paragraph_coverage",
    "validate_and_repair_ecl_v34",
]
