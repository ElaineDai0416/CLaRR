"""CLaRR v3 phase-2 cost controls, isolated from the v1/v2 entry points."""

from __future__ import annotations

from dataclasses import replace
import json
import os
import re
from typing import Any

import ecl_repair_v4
import ecl_structure
import fidelity_repair
import integrated_repair
import cost_foundation
from incremental_validation import evaluate_repair_proposal


V3_SCHEMA = "clarr-v3-cost-controls-v1"
_JUDGE_MODE = os.environ.get("CLARR_V3_ECL_JUDGE_MODE", "combined").strip().lower()
_STRATEGY_MODE = os.environ.get("CLARR_V3_STRATEGY_MODE", "joint").strip().lower()
_ECL_REPAIR_MODE = os.environ.get("CLARR_V3_ECL_REPAIR", "auto").strip().lower()
if _JUDGE_MODE not in {"combined", "four"}:
    raise ValueError("CLARR_V3_ECL_JUDGE_MODE must be combined or four")
if _STRATEGY_MODE not in {"joint", "parallel"}:
    raise ValueError("CLARR_V3_STRATEGY_MODE must be joint or parallel")
if _ECL_REPAIR_MODE not in {"auto", "off", "on"}:
    raise ValueError("CLARR_V3_ECL_REPAIR must be auto, off, or on")

# Frozen evidence from the completed v1 probe.  ``auto`` is deliberately
# conservative: a lane with zero accepted proposals is not allowed to keep
# spending repair+four-rescore calls until new calibration evidence enables it.
_ECL_HISTORY = {"attempted": 23, "accepted": 0, "source": "results_probe_no_icl_v162"}


def _json_object(raw: str) -> dict[str, Any]:
    text = re.sub(r"^```(?:json)?\s*", "", str(raw).strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("expected a JSON object")
    return value


def generate_joint_strategies(
    *, source_text: str, prompts: dict[str, str], llm_call, context=None,
):
    """Generate IL/ECL/GCL plans in one response with the source included once."""
    lane_sections = []
    for key in ("IL", "EL", "GL"):
        prompt = str(prompts[key])
        # The exact original lane instruction and contract stay intact; only the
        # duplicated source body is replaced by an explicit shared reference.
        prompt = prompt.replace(source_text, "[USE THE SHARED SOURCE ARTICLE ABOVE]", 1)
        lane_sections.append(f"## {key} LANE\n{prompt}")
    prompt = """Generate the three independent CLAP strategy artifacts below in one call.
The source is shared, but each lane must obey only its own contract and exact output
format. Do not let one lane override another. Return JSON only as
{"IL":"complete IL artifact","EL":"complete EL artifact","GL":"complete GL artifact"}.

## SHARED SOURCE ARTICLE
""" + source_text + "\n\n" + "\n\n".join(lane_sections)
    last_error: Exception | None = None
    for attempt in range(2):
        raw = llm_call(
            prompt + ("\nReturn corrected complete JSON only." if attempt else ""),
            max_tokens=8192,
            response_format={"type": "json_object"},
        )
        try:
            value = _json_object(raw)
            output = {key: str(value.get(key, "")).strip() for key in ("IL", "EL", "GL")}
            if not all(output.values()):
                raise ValueError("joint strategy response omitted a lane")
            return output
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc
    raise ValueError(f"joint strategy generator returned invalid JSON twice: {last_error}")


def _combined_ecl_prompt(candidate: str, preference: str, item_id: str) -> str:
    dimensions = ecl_structure.dimensions_for(preference)
    common = ecl_structure.COMMON_PROMPT_PATH.read_text(encoding="utf-8")
    rubrics = []
    for dimension in dimensions:
        path = (
            ecl_structure.PROMPT_DIR
            / ecl_structure.DIMENSION_TO_PROMPT[dimension]
        )
        rubrics.append(f"## RUBRIC: {dimension}\n{path.read_text(encoding='utf-8')}")
    payload = {
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "dimensions": list(dimensions),
        "candidate_markdown": candidate,
        "deterministic_structure_facts": (
            ecl_structure.candidate_structure_facts(candidate)
        ),
    }
    return """Run the four frozen ECL v3.4-r4 rubrics independently on one shared
candidate. Return one JSON object with key `evaluations`; its value is an array of
four ordinary feature-schema objects, in the requested dimension order. Every item
must retain schema_version, item_id, dimension, score, evidence, rationale, failure
tags, repair instruction, and confidence required by the rubric.

""" + common + "\n\n" + "\n\n".join(rubrics) + "\n\n## SHARED ITEM\n" + json.dumps(
        payload, ensure_ascii=False, indent=2
    )


def _parse_combined_evaluations(
    raw: str,
    dimensions: tuple[str, ...],
    item_id: str,
    candidate: str,
) -> dict[str, Any]:
    """Parse the combined judge response into per-dimension feature records.

    ``item_id`` is an echo of a field the prompt already pins down; a wrong or
    missing echo is a formatting slip, not a scoring error, so the expected
    value is restored instead of failing the pair (observed on ~6% of dataset
    calls and ~50% of astronomy calls before this guard).
    """
    value = _json_object(raw)
    evaluations = value.get("evaluations")
    if not isinstance(evaluations, list):
        raise ValueError("combined ECL response requires evaluations array")
    by_dimension = {}
    for item in evaluations:
        if not isinstance(item, dict):
            continue
        item = {**item, "item_id": str(item_id)}
        by_dimension[str(item.get("dimension", ""))] = item
    results = {}
    for dimension in dimensions:
        if dimension not in by_dimension:
            raise ValueError(f"combined ECL response omitted {dimension}")
        results[dimension] = ecl_structure.parse_feature_response(
            json.dumps(by_dimension[dimension], ensure_ascii=False),
            dimension=dimension,
            item_id=item_id,
            candidate=candidate,
        )
    return results


def score_ecl_combined(
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call,
    policy=None,
) -> dict[str, Any]:
    """One model call, four frozen feature records, unchanged aggregation."""
    dimensions = ecl_structure.dimensions_for(preference)
    last_error: Exception | None = None
    for attempt in range(2):
        raw = feature_llm_call(
            _combined_ecl_prompt(candidate, preference, item_id),
            dimension="S-COMBINED-V3",
            max_tokens=5600,
            temperature=0,
            response_format={"type": "json_object"},
        )
        try:
            results = _parse_combined_evaluations(raw, dimensions, item_id, candidate)
            break
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc
    else:
        raise ValueError(f"combined ECL judge failed twice: {last_error}")
    record = ecl_structure.build_score_record(
        item_id=item_id,
        preference=preference,
        source_text=source_text,
        candidate=candidate,
        feature_results=results,
        policy=policy,
    )
    record["judge_execution"] = {
        "mode": "single_call_four_rubrics",
        "model_calls": attempt + 1,
        "aggregation": "unchanged_v3.4-r4",
    }
    return record


def _patch_ecl_scorer(v1) -> None:
    if _JUDGE_MODE == "four":
        return

    def public_score(source_text, candidate, preference, item_id, feature_llm_call):
        _, expansion_policy_type = integrated_repair._load_ecl_score_api()
        return score_ecl_combined(
            source_text, candidate, preference, item_id, feature_llm_call,
            expansion_policy_type(),
        )

    integrated_repair.score_ecl_candidate = public_score
    v1.score_ecl_candidate = public_score
    ecl_repair_v4.score_candidate_v34 = score_ecl_combined


def _patch_final_double_check(v1) -> None:
    original_run = v1.run_integrated_repair

    def run_integrated_repair_v3(**kwargs):
        result = original_run(**kwargs)
        candidate = str(result.get("analysis_content") or "")
        full_policy = replace(
            kwargs.get("policy") or fidelity_repair.FidelityPolicy(),
            use_adversarial_double_check=True,
        )
        final_validation = fidelity_repair.validate_candidate(
            kwargs["source_text"], candidate, kwargs["contract"],
            kwargs["llm_call"], full_policy,
        )
        result["final_adversarial_validation"] = final_validation
        result["selected_validation"] = final_validation
        nested = result.get("fidelity_icl_schema_result")
        if isinstance(nested, dict):
            nested["selected_validation"] = final_validation
        final_record = result.get("final_fidelity_icl_schema_validation")
        if isinstance(final_record, dict):
            final_record["selected_validation"] = final_validation
        passed = bool(final_validation.get("metrics", {}).get("hard_fidelity_pass"))
        if not passed:
            reasons = list(result.get("release_block_reasons") or [])
            reasons.append("final_adversarial_fidelity")
            result["release_block_reasons"] = list(dict.fromkeys(reasons))
            result["release_ready"] = False
            result["release_content"] = None
            result["output_disposition"] = "returned_not_release_ready"
            result["status"] = "failed_final_gate"
            gate = result.setdefault("final_module_gate", {})
            gate["overall_pass"] = False
            gate_reasons = list(gate.get("release_block_reasons") or [])
            gate_reasons.append("final_adversarial_fidelity")
            gate["release_block_reasons"] = list(dict.fromkeys(gate_reasons))
        return result

    v1.run_integrated_repair = run_integrated_repair_v3


def _patch_process(v1) -> None:
    original_process = v1.process_article_for_reader
    ecl_enabled = _ECL_REPAIR_MODE == "on" or (
        _ECL_REPAIR_MODE == "auto" and _ECL_HISTORY["accepted"] > 0
    )

    def process_article_for_reader(*args, **kwargs):
        policy = kwargs.get("fidelity_policy") or fidelity_repair.FidelityPolicy()
        kwargs["fidelity_policy"] = replace(
            policy, use_adversarial_double_check=False
        )
        if not ecl_enabled:
            kwargs["ecl_repair_rounds"] = 0
        if _STRATEGY_MODE == "joint":
            kwargs.setdefault("strategy_generation_fn", generate_joint_strategies)
        result = original_process(*args, **kwargs)
        result["cost_optimization_v3"] = {
            "schema_version": V3_SCHEMA,
            "intermediate_fidelity": "single_primary",
            "final_fidelity": "primary_plus_adversarial_fail_closed",
            "repair_revalidation": "target_scoped_claim_term_bridge_plus_global_safety",
            "strategy_generation": _STRATEGY_MODE,
            "ecl_judge_execution": _JUDGE_MODE,
            "ecl_repair_mode": _ECL_REPAIR_MODE,
            "ecl_repair_effective": ecl_enabled,
            "ecl_repair_history": dict(_ECL_HISTORY),
        }
        return result

    v1.process_article_for_reader = process_article_for_reader


_APPLIED = False


def apply_v3(verbose: bool = True):
    global _APPLIED
    os.environ.setdefault("LLM_RUN_TAG", "v3")
    v1 = cost_foundation.apply_v2(verbose=False)
    if _APPLIED:
        return v1
    fidelity_repair.REPAIR_PROPOSAL_EVALUATOR = evaluate_repair_proposal
    _patch_ecl_scorer(v1)
    _patch_final_double_check(v1)
    _patch_process(v1)
    _APPLIED = True
    if verbose:
        print(
            "[v3] patched: target-scoped repair validation + final adversarial "
            f"fidelity + strategy={_STRATEGY_MODE} + ecl_judges={_JUDGE_MODE} "
            f"+ ecl_repair={_ECL_REPAIR_MODE}",
            flush=True,
        )
    return v1
