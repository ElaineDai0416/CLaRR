"""IL term-transformation contracts and compliance auditing.

The claim contract answers *what facts must remain true*.  This module adds the
orthogonal question *how may each reader-facing term be rewritten*.  A rewrite is
releasable only when its term treatment follows the IL decision and the treatment
does not change the proposition in which the term participates.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Callable


SAFE_SEMANTIC_VERDICTS = {
    "preserved_exact",
    "preserved_with_safe_explanation",
    "preserved_via_equivalent_familiar_substitution",
    "preserved_under_safe_compression",
    "minor_nonmaterial_variation",
}

SEMANTIC_VERDICTS = SAFE_SEMANTIC_VERDICTS | {
    "material_meaning_drift",
    "unsupported_extension",
    "claim_loss",
}

OBSERVED_TREATMENTS = {
    "retained_exact",
    "retained_with_explanation",
    "familiar_substitution",
    "compressed_or_merged",
    "absent",
    "other",
}

INTRODUCED_PROPOSITION_VERDICTS = {
    "supported_clarification",
    "nonfactual_gloss",
    "reader_framing",
    "unsupported_material",
    "inappropriate_inference",
    "redundant_restatement",
    "excessive_supported_detail",
}

SEMANTICALLY_UNSAFE_INTRODUCTIONS = {
    "unsupported_material",
    "inappropriate_inference",
}

REPAIR_REQUIRED_INTRODUCTIONS = SEMANTICALLY_UNSAFE_INTRODUCTIONS | {
    "redundant_restatement",
    "excessive_supported_detail",
}

# One source-grounded factual clarification is enough to explain a term.  Purely
# linguistic glosses and nonfactual reader framing do not consume this budget.
MAX_SUPPORTED_CLARIFICATIONS_PER_TERM = 1
MAX_SUPPORTED_CLARIFICATIONS_PER_ARTICLE = 4

QUADRANT_ACTIONS = {
    "Core Expertise": "retain_and_explain",
    "Peripheral Jargon": "replace_with_familiar_equivalent",
    "HF Concept": "retain_exact",
    "Redundant": "compress_or_merge",
}

REQUIRED_ACTIONS = {
    "retain_and_explain",
    "retain_and_gloss",
    "retain_exact",
    "replace_with_approved_familiar_form",
    "replace_with_familiar_equivalent",
    "retain_anchor_compress_context",
}


def _norm(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", value.lower()))


def _contains_phrase(container: str, phrase: str) -> bool:
    container_norm = _norm(container)
    phrase_norm = _norm(phrase)
    return bool(phrase_norm and re.search(rf"(?:^| )({re.escape(phrase_norm)})(?: |$)", container_norm))


_LEADING_DETERMINERS = {"a", "an", "the"}


def _token_surface_forms(token: str) -> set[str]:
    """Return conservative inflectional forms for one already-normalized token.

    This is deliberately not a semantic synonym table.  It only covers surface
    variation that should not turn an exact lexical anchor into a false negative:
    plural/possessive forms and common ``-ing``/``-ed`` inflections.
    """
    forms = {token}
    if len(token) <= 2:
        return forms
    if token.endswith("ies") and len(token) > 4:
        forms.add(token[:-3] + "y")
    if token.endswith("es") and len(token) > 4:
        forms.add(token[:-2])
        forms.add(token[:-1])
    elif token.endswith("s") and not token.endswith("ss"):
        forms.add(token[:-1])
    if token.endswith("ing") and len(token) > 5:
        stem = token[:-3]
        forms.add(stem)
        forms.add(stem + "e")
        if len(stem) > 2 and stem[-1] == stem[-2]:
            forms.add(stem[:-1])
    if token.endswith("ed") and len(token) > 4:
        stem = token[:-2]
        forms.add(stem)
        forms.add(stem + "e")
        if len(stem) > 2 and stem[-1] == stem[-2]:
            forms.add(stem[:-1])
    return forms


def _surface_tokens_equivalent(left: str, right: str) -> bool:
    return bool(_token_surface_forms(left) & _token_surface_forms(right))


def _contains_surface_anchor(
    container: str,
    phrase: str,
    *,
    ignore_leading_determiner: bool = False,
) -> bool:
    """Match a lexical anchor under limited, auditable surface normalization.

    Hyphens and punctuation are already normalized by tokenization.  No broad
    semantic substitution is accepted: token counts must match and every token
    pair must be identical or a conservative inflectional variant.
    """
    container_tokens = re.findall(r"[a-z0-9]+", str(container).lower())
    phrase_tokens = re.findall(r"[a-z0-9]+", str(phrase).lower())
    if (
        ignore_leading_determiner
        and phrase_tokens
        and phrase_tokens[0] in _LEADING_DETERMINERS
    ):
        phrase_tokens = phrase_tokens[1:]
    if not phrase_tokens:
        return False
    width = len(phrase_tokens)
    for start in range(0, len(container_tokens) - width + 1):
        window = container_tokens[start:start + width]
        if all(
            _surface_tokens_equivalent(observed, required)
            for observed, required in zip(window, phrase_tokens)
        ):
            return True
    return False


def _claim_text(claim: dict[str, Any]) -> str:
    evidence = " ".join(str(x) for x in claim.get("source_evidence", []))
    return " ".join((str(claim.get("canonical_proposition", "")), evidence))


def build_il_term_contract(
    scored_terms: list[dict[str, Any]],
    claim_contract: list[dict[str, Any]],
    il_strategy_text: str = "",
) -> list[dict[str, Any]]:
    """Create an auditable term-treatment contract from the scored IL quadrants.

    Claim-slot precedence is deterministic: an IL decision may never lexically prune
    a frozen immutable anchor unless the claim ledger already supplies an approved
    form.  This prevents a reader-adaptation instruction from silently overriding a
    fidelity obligation.
    """
    output: list[dict[str, Any]] = []
    for index, scored in enumerate(scored_terms, 1):
        term = str(scored.get("term", "")).strip()
        if not term:
            continue
        quadrant = str(scored.get("quadrant", "Redundant"))
        action = QUADRANT_ACTIONS.get(quadrant, "compress_or_merge")
        linked_claim_ids: list[str] = []
        anchor_claim_ids: list[str] = []
        protected_slot_values: list[dict[str, str]] = []
        approved_forms: list[str] = []
        for claim in claim_contract:
            claim_id = str(claim.get("claim_id", ""))
            if _contains_phrase(_claim_text(claim), term):
                linked_claim_ids.append(claim_id)
            for slot in claim.get("immutable_slot_values", []):
                if not isinstance(slot, dict) or not slot.get("value"):
                    continue
                value = str(slot["value"])
                if _contains_phrase(value, term) or _contains_phrase(term, value):
                    anchor_claim_ids.append(claim_id)
                    protected_slot_values.append({
                        "claim_id": claim_id,
                        "slot_type": str(slot.get("slot_type", "slot")),
                        "value": value,
                    })
            for item in claim.get("approved_simplifications", []):
                if not isinstance(item, dict):
                    continue
                if _norm(str(item.get("source_form", ""))) == _norm(term):
                    allowed = str(item.get("allowed_form", "")).strip()
                    if allowed:
                        approved_forms.append(allowed)

        linked_claim_ids = list(dict.fromkeys(linked_claim_ids + anchor_claim_ids))
        anchor_claim_ids = list(dict.fromkeys(anchor_claim_ids))
        approved_forms = list(dict.fromkeys(approved_forms))

        # A term that names part of a frozen proposition is not safe to replace
        # freely merely because it is not also encoded as an immutable slot.  The
        # adversarial fidelity verifier correctly treats a broader near-synonym as
        # proposition drift.  Therefore unapproved linked terms remain visible;
        # approved source-specific forms are the only lexical substitutions.
        if quadrant == "Peripheral Jargon" and linked_claim_ids:
            action = (
                "replace_with_approved_familiar_form"
                if approved_forms else "retain_and_gloss"
            )
        elif quadrant == "Redundant" and linked_claim_ids:
            action = (
                "replace_with_approved_familiar_form"
                if approved_forms else "retain_exact"
            )

        hard_required = bool(
            action in REQUIRED_ACTIONS
            and not (
                action == "replace_with_familiar_equivalent"
                and not linked_claim_ids
            )
        )
        output.append({
            "term_id": f"IL_T{index:03d}",
            "source_term": term,
            "v_tech": int(scored.get("v_tech", 1)),
            "v_cent": int(scored.get("v_cent", 1)),
            "quadrant": quadrant,
            "required_action": action,
            "hard_required": hard_required,
            "linked_claim_ids": linked_claim_ids,
            "immutable_anchor_claim_ids": anchor_claim_ids,
            "protected_slot_values": protected_slot_values,
            "approved_familiar_forms": approved_forms,
            "reader_rationale": str(scored.get("rationale", "")),
            "max_supported_factual_clarifications": (
                MAX_SUPPORTED_CLARIFICATIONS_PER_TERM
                if action in {"retain_and_explain", "retain_and_gloss"}
                else 0
            ),
            "semantic_constraint": (
                "The term treatment may change wording or add a local explanation, "
                "but may not change entity, quantity, polarity, modality, causal "
                "direction, condition, scope, comparison, population, time, or the "
                "main relation of any linked claim."
            ),
            "il_strategy_sha256": hashlib.sha256(
                il_strategy_text.encode("utf-8")
            ).hexdigest() if il_strategy_text else None,
        })
    return output


def _json_response(llm_call: Callable[..., str], prompt: str) -> dict[str, Any]:
    try:
        raw = llm_call(
            prompt,
            max_tokens=5000,
            temperature=0.0,
            response_format={"type": "json_object"},
        )
    except TypeError as exc:
        if "response_format" not in str(exc):
            raise
        raw = llm_call(prompt, max_tokens=5000, temperature=0.0)
    text = str(raw).strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("IL compliance response must be a JSON object")
    return value


def _linked_claims_preserved(
    term: dict[str, Any], claim_validation: dict[str, Any]
) -> bool:
    preserved = {
        str(item.get("claim_id"))
        for item in claim_validation.get("assessments", [])
        if item.get("verdict") in {
            "entailed_exact", "entailed_via_approved_simplification"
        }
    }
    return all(claim_id in preserved for claim_id in term.get("linked_claim_ids", []))


def _deterministic_assessment(
    term: dict[str, Any], candidate: str, claim_validation: dict[str, Any]
) -> dict[str, Any] | None:
    """Resolve exact-retention actions without another subjective model call."""
    action = term["required_action"]
    if action not in {"retain_exact", "retain_anchor_compress_context"}:
        return None
    present = _contains_surface_anchor(candidate, term["source_term"])
    claims_ok = _linked_claims_preserved(term, claim_validation)
    if present and claims_ok:
        return {
            "term_id": term["term_id"],
            "source_term": term["source_term"],
            "observed_span": term["source_term"],
            "observed_treatment": "retained_exact",
            "semantic_verdict": "preserved_exact",
            "strategy_compliant": True,
            "reason": "Exact required term is present and every linked claim is preserved.",
        }
    if not present and claims_ok:
        return {
            "term_id": term["term_id"],
            "source_term": term["source_term"],
            "observed_span": "",
            "observed_treatment": "absent",
            "semantic_verdict": "minor_nonmaterial_variation",
            "strategy_compliant": False,
            "reason": (
                "The exact IL surface form is absent, but every linked source "
                "claim remains fully preserved; this is a strategy failure, not "
                "semantic claim loss."
            ),
        }
    return {
        "term_id": term["term_id"],
        "source_term": term["source_term"],
        "observed_span": term["source_term"] if present else "",
        "observed_treatment": "retained_exact" if present else "absent",
        "semantic_verdict": "material_meaning_drift" if present else "claim_loss",
        "strategy_compliant": False,
        "reason": (
            "The exact term is present but at least one linked claim is not fully preserved."
            if present else "The IL contract requires exact retention, but the term is absent."
        ),
    }


def il_compliance_prompt(
    source_text: str,
    candidate: str,
    term_contract: list[dict[str, Any]],
    claim_validation: dict[str, Any],
) -> str:
    return f"""You audit whether a reader-adapted rewrite obeys its IL term-treatment
contract without changing source meaning. Use only the supplied source, claim results,
and term contract. Judge semantic equivalence rather than word overlap.

ALLOWED TRANSFORMATIONS
- retain_and_explain / retain_and_gloss: keep the source term and add a short local
  explanation. The explanation may clarify meaning but may not add a mechanism,
  cause, outcome, institutional role, scope, certainty, number, or example presented
  as source fact.
- replace_with_familiar_equivalent: the jargon surface form may disappear only when
  familiar wording preserves the same referent and every linked proposition. A
  broader, narrower, more certain, causal, evaluative, or merely related word is not
  equivalent.
- replace_with_approved_familiar_form: use one of approved_familiar_forms and preserve
  linked propositions.
- retain_exact: keep the term; surrounding syntax may change without changing facts.
- compress_or_merge: shorten wording, never delete or merge away a linked proposition.
- retain_anchor_compress_context: keep the exact immutable anchor while compressing
  surrounding wording.

For each requested term return exactly one assessment. `semantic_verdict` must be one
of: preserved_exact, preserved_with_safe_explanation,
preserved_via_equivalent_familiar_substitution, preserved_under_safe_compression,
minor_nonmaterial_variation, material_meaning_drift, unsupported_extension, claim_loss.
`observed_treatment` must be one of: retained_exact, retained_with_explanation,
familiar_substitution, compressed_or_merged, absent, other.

A treatment can be semantically safe but strategy-noncompliant (for example jargon
was retained although IL required a familiar substitution). Conversely, a fluent
explanation can be strategy-shaped but semantically unsafe. Keep these judgments
separate.

AUDIT EVERY FAMILIAR SUBSTITUTION AND EXPLANATION FOR INTRODUCED PROPOSITIONS
- A familiar replacement must preserve the same referent, relation, scope and degree;
  a broader/narrower near-synonym or a word with different certainty is
  `material_meaning_drift`.
- Split every explanation into factual propositions. For each proposition classify:
  `supported_clarification` when recoverable from the source; `nonfactual_gloss` for
  a purely definitional/linguistic aid; `reader_framing` for nonfactual navigation;
  `unsupported_material` for a new fact/mechanism/cause/outcome/example presented as
  true; `inappropriate_inference` for an unwarranted implication; or
  `redundant_restatement` when it merely duplicates an already expressed source claim
  without adding reader-relevant clarification.
- Unsupported material and inappropriate inference are semantic failures. An
  unlicensed redundant restatement is semantically safe but strategy-noncompliant and
  should be shortened or removed by repair.
- Explanations also have a proposition budget: at most one source-grounded factual
  clarification per explained/glossed term and at most four across the article.
  Purely linguistic glosses and nonfactual reader framing do not consume the budget.
  Any otherwise supported detail beyond that budget is `excessive_supported_detail`:
  it is not a hallucination, but it is an IL failure and must be removed by repair.

Return JSON only:
{{"assessments":[{{"term_id":"IL_T001","source_term":"...",
"observed_span":"short exact candidate span or empty","observed_treatment":"...",
"semantic_verdict":"...","strategy_compliant":true,
"introduced_propositions":[{{"candidate_span":"exact local span",
"verdict":"supported_clarification|nonfactual_gloss|reader_framing|unsupported_material|inappropriate_inference|redundant_restatement|excessive_supported_detail",
"closest_source_span":"exact source span or empty","related_claim_ids":["C01"],
"reason":"why this proposition is allowed, wrong, inappropriate, or redundant"}}],
"reason":"source-grounded explanation"}}]}}

SOURCE ARTICLE
{source_text}

CLAIM VALIDATION
{json.dumps(claim_validation, ensure_ascii=False)}

IL TERM CONTRACT
{json.dumps(term_contract, ensure_ascii=False)}

CANDIDATE REWRITE
{candidate}"""


def normalize_il_assessments(
    raw: dict[str, Any], term_contract: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    by_id = {
        str(item.get("term_id", "")): item
        for item in raw.get("assessments", [])
        if isinstance(item, dict)
    }
    output = []
    for term in term_contract:
        found = by_id.get(term["term_id"], {})
        observed = str(found.get("observed_treatment", "other"))
        semantic = str(found.get("semantic_verdict", "claim_loss"))
        if observed not in OBSERVED_TREATMENTS:
            observed = "other"
        if semantic not in SEMANTIC_VERDICTS:
            semantic = "claim_loss"
        expected_treatments = {
            "retain_and_explain": {"retained_with_explanation"},
            "retain_and_gloss": {"retained_with_explanation"},
            "retain_exact": {"retained_exact", "retained_with_explanation"},
            "replace_with_approved_familiar_form": {"familiar_substitution"},
            "replace_with_familiar_equivalent": {"familiar_substitution"},
            "compress_or_merge": {"compressed_or_merged", "retained_exact"},
            "retain_anchor_compress_context": {
                "retained_exact", "retained_with_explanation", "compressed_or_merged"
            },
        }.get(term["required_action"], set())
        observed_span = str(found.get("observed_span", ""))
        strategy_compliant = (
            bool(found.get("strategy_compliant", False))
            and observed in expected_treatments
        )
        if term["required_action"] == "replace_with_approved_familiar_form":
            strategy_compliant = strategy_compliant and any(
                _contains_surface_anchor(
                    observed_span,
                    allowed,
                    ignore_leading_determiner=True,
                )
                for allowed in term.get("approved_familiar_forms", [])
            )
        introduced = []
        for proposition in found.get("introduced_propositions", []):
            if not isinstance(proposition, dict):
                continue
            verdict = str(proposition.get("verdict", "unsupported_material"))
            if verdict not in INTRODUCED_PROPOSITION_VERDICTS:
                verdict = "unsupported_material"
            introduced.append({
                "candidate_span": str(proposition.get("candidate_span", "")),
                "verdict": verdict,
                "closest_source_span": str(proposition.get("closest_source_span", "")),
                "related_claim_ids": [str(x) for x in proposition.get("related_claim_ids", [])],
                "reason": str(proposition.get("reason", "")),
            })
        if any(
            item["verdict"] in SEMANTICALLY_UNSAFE_INTRODUCTIONS
            for item in introduced
        ):
            semantic = "unsupported_extension"
        if any(item["verdict"] == "redundant_restatement" for item in introduced):
            strategy_compliant = False
        output.append({
            "term_id": term["term_id"],
            "source_term": term["source_term"],
            "required_action": term["required_action"],
            "hard_required": bool(term.get("hard_required", True)),
            "linked_claim_ids": list(term.get("linked_claim_ids", [])),
            "observed_span": observed_span,
            "observed_treatment": observed,
            "semantic_verdict": semantic,
            "meaning_preserved": semantic in SAFE_SEMANTIC_VERDICTS,
            "strategy_compliant": strategy_compliant,
            "introduced_propositions": introduced,
            "reason": str(found.get("reason", "missing IL term assessment")),
        })
    # Enforce a deterministic factual-explanation budget after semantic labeling.
    # This applies identically to the internal controller and the external blind audit.
    article_supported = 0
    for item in output:
        per_term_limit = (
            MAX_SUPPORTED_CLARIFICATIONS_PER_TERM
            if item["required_action"] in {"retain_and_explain", "retain_and_gloss"}
            else 0
        )
        term_supported = 0
        for proposition in item["introduced_propositions"]:
            if proposition["verdict"] != "supported_clarification":
                continue
            term_supported += 1
            if term_supported > per_term_limit:
                proposition["verdict"] = "excessive_supported_detail"
                proposition["reason"] = (
                    proposition["reason"]
                    + " | Source-grounded but beyond the frozen explanation-proposition budget."
                ).strip(" |")
                continue
            if article_supported >= MAX_SUPPORTED_CLARIFICATIONS_PER_ARTICLE:
                proposition["verdict"] = "excessive_supported_detail"
                proposition["reason"] = (
                    proposition["reason"]
                    + " | Source-grounded but beyond the frozen article explanation budget."
                ).strip(" |")
                continue
            article_supported += 1
        if any(
            proposition["verdict"] == "excessive_supported_detail"
            for proposition in item["introduced_propositions"]
        ):
            item["strategy_compliant"] = False
    return output


def score_il_compliance(assessments: list[dict[str, Any]]) -> dict[str, Any]:
    required = [item for item in assessments if item["hard_required"]]
    semantic_failures = [item for item in assessments if not item["meaning_preserved"]]
    required_strategy_failures = [
        item for item in required if not item["strategy_compliant"]
    ]
    optional_strategy_failures = [
        item for item in assessments
        if not item["hard_required"] and not item["strategy_compliant"]
    ]
    introduced = [
        proposition
        for item in assessments
        for proposition in item.get("introduced_propositions", [])
    ]
    introduction_control_failures = [
        item for item in introduced
        if item.get("verdict") in {"redundant_restatement", "excessive_supported_detail"}
    ]
    return {
        "n_terms": len(assessments),
        "n_required_terms": len(required),
        "n_semantically_preserved": sum(item["meaning_preserved"] for item in assessments),
        "n_strategy_compliant": sum(item["strategy_compliant"] for item in assessments),
        "n_semantic_failures": len(semantic_failures),
        "n_required_strategy_failures": len(required_strategy_failures),
        "n_optional_strategy_failures": len(optional_strategy_failures),
        "n_unsupported_introduced_propositions": sum(
            item.get("verdict") in SEMANTICALLY_UNSAFE_INTRODUCTIONS
            for item in introduced
        ),
        "n_redundant_introduced_propositions": sum(
            item.get("verdict") == "redundant_restatement"
            for item in introduced
        ),
        "n_excessive_supported_details": sum(
            item.get("verdict") == "excessive_supported_detail"
            for item in introduced
        ),
        "n_introduced_propositions": len(introduced),
        "term_semantic_preservation_rate": (
            sum(item["meaning_preserved"] for item in assessments) / len(assessments)
            if assessments else 1.0
        ),
        "required_strategy_compliance_rate": (
            sum(item["strategy_compliant"] for item in required) / len(required)
            if required else 1.0
        ),
        "semantic_pass": not semantic_failures,
        "explanation_budget_pass": not introduction_control_failures,
        "hard_il_pass": (
            not semantic_failures
            and not required_strategy_failures
            and not introduction_control_failures
        ),
    }


def validate_il_compliance(
    source_text: str,
    candidate: str,
    term_contract: list[dict[str, Any]],
    claim_validation: dict[str, Any],
    llm_call: Callable[..., str],
) -> dict[str, Any]:
    if not term_contract:
        metrics = score_il_compliance([])
        return {"assessments": [], "metrics": metrics, "evaluated": False}

    resolved: dict[str, dict[str, Any]] = {}
    subjective = []
    for term in term_contract:
        deterministic = _deterministic_assessment(term, candidate, claim_validation)
        if deterministic is None:
            subjective.append(term)
        else:
            resolved[term["term_id"]] = deterministic

    if subjective:
        prompt = il_compliance_prompt(
            source_text, candidate, subjective, claim_validation
        )
        last_error: Exception | None = None
        for attempt in range(2):
            try:
                retry = prompt if not attempt else (
                    prompt + "\nReturn a corrected complete JSON object only."
                )
                raw = _json_response(llm_call, retry)
                normalized = normalize_il_assessments(raw, subjective)
                resolved.update({item["term_id"]: item for item in normalized})
                break
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                last_error = exc
        else:
            raise ValueError(f"IL compliance evaluator returned invalid JSON twice: {last_error}")

    assessments = []
    for term in term_contract:
        item = dict(resolved[term["term_id"]])
        item.setdefault("required_action", term["required_action"])
        item.setdefault("hard_required", bool(term.get("hard_required", True)))
        item.setdefault("linked_claim_ids", list(term.get("linked_claim_ids", [])))
        action = term["required_action"]
        if action in {"retain_and_explain", "retain_and_gloss"} and not _contains_surface_anchor(
            candidate, term["source_term"]
        ):
            item["strategy_compliant"] = False
            item["reason"] = (
                str(item.get("reason", ""))
                + " | Required source term is absent from the candidate."
            ).strip(" |")
        if not _linked_claims_preserved(term, claim_validation):
            item["semantic_verdict"] = (
                "material_meaning_drift"
                if str(item.get("observed_span", "")).strip()
                else "claim_loss"
            )
            item["reason"] = (
                str(item.get("reason", ""))
                + " | At least one linked source claim is not fully preserved."
            ).strip(" |")
        item["meaning_preserved"] = item["semantic_verdict"] in SAFE_SEMANTIC_VERDICTS
        assessments.append(item)
    return {
        "assessments": assessments,
        "metrics": score_il_compliance(assessments),
        "evaluated": True,
    }


def failed_il_spans(evaluation: dict[str, Any]) -> list[str]:
    assessment_spans = [
        str(item.get("observed_span", "")).strip()
        for item in evaluation.get("assessments", [])
        if (
            not item.get("meaning_preserved", False)
            or (item.get("hard_required", True) and not item.get("strategy_compliant", False))
        )
        and str(item.get("observed_span", "")).strip()
    ]
    proposition_spans = [
        str(proposition.get("candidate_span", "")).strip()
        for item in evaluation.get("assessments", [])
        for proposition in item.get("introduced_propositions", [])
        if proposition.get("verdict") in (
            REPAIR_REQUIRED_INTRODUCTIONS
        )
        and str(proposition.get("candidate_span", "")).strip()
    ]
    return list(dict.fromkeys(assessment_spans + proposition_spans))
