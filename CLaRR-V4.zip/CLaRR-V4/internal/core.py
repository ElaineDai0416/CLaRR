"""
batch_adapt.py
--------------
Batch article adaptation using the CLAP cognitive-load pipeline.

Usage:
    # Adapt A01 for all 18 readers (default):
    python batch_adapt.py

    # Adapt a specific article for specific readers:
    python batch_adapt.py --article A01 --readers P-L-E L-L-M U-E-X

    # Adapt multiple articles for all readers:
    python batch_adapt.py --article A01 A02 A03

Output:
    results/<ARTICLE_ID>_<READER_ID>.json   — one file per (article, reader) pair
    results/batch_summary.json              — summary index of all runs
"""

import argparse
import hashlib
import json
import math
import os
import re
import time
import traceback
from concurrent.futures import as_completed
from datetime import datetime
from dataclasses import asdict
from pathlib import Path


import llm_client
from llm_client import (
    ContextPropagatingThreadPoolExecutor as ThreadPoolExecutor,
    call_ecl_feature_llm,
    call_llm,
)

from fidelity_repair import (
    FidelityPolicy,
    generation_guardrail,
    normalize_claim_contract,
    validate_candidate,
    validate_and_repair,
)
from il_fidelity import build_il_term_contract, validate_il_compliance
from integrated_repair import (
    INTEGRATED_REPAIR_VERSION,
    run_integrated_repair,
    score_ecl_candidate,
)
from schema_support import build_schema_support_contract, evaluate_schema_support
from comparative_scoring import build_three_dimension_score
from strategy_execution import (
    build_ecl_preference_alignment_contract,
    compile_ecl_relation_plan,
    compile_gcl_support_plan,
    build_gcl_schema_alignment_contract,
    build_icl_claim_alignment_contract,
    freeze_strategy_bundle,
    build_strategy_execution_contract,
    build_upfront_strategy_contract,
)

# ── Configuration ─────────────────────────────────────────────────────────────

DATA_DIR = Path(__file__).resolve().parent
PARENT_DATA_DIR = DATA_DIR.parent

# Quadrant defaults mirrored from il_fidelity; used only by the anchor-conflict
# shim below (ported from 04Ablation/ablation_core.py).
_QUADRANT_DEFAULT_ACTION = {
    "Core Expertise": "retain_and_explain",
    "Peripheral Jargon": "replace_with_familiar_equivalent",
    "HF Concept": "retain_exact",
    "Redundant": "compress_or_merge",
}


def resolve_anchor_conflicts(il_contract: list) -> list:
    """Apply the frozen claim-slot precedence the alignment handshake expects.

    ``build_il_term_contract`` only upgrades the branches that check *linked*
    claims, so a term whose quadrant default is compression/pruning but that
    also names an immutable claim anchor (via ``immutable_slot_values``) keeps
    an unsafe ``required_action``.  ``build_icl_claim_alignment_contract``
    then marks the conflict unresolved and ``build_upfront_strategy_contract``
    aborts the pair — reachable only with dataset-style contracts that carry
    immutable anchors (67% of part_1 articles).  Deterministic post-processing
    only; no LLM behaviour changes and the frozen libs stay untouched.
    """
    for term in il_contract:
        if not term.get("immutable_anchor_claim_ids"):
            continue
        default = _QUADRANT_DEFAULT_ACTION.get(
            str(term.get("quadrant", "")), "compress_or_merge"
        )
        if default == "compress_or_merge":
            term["required_action"] = "retain_anchor_compress_context"
        elif default == "replace_with_familiar_equivalent":
            term["required_action"] = (
                "replace_with_approved_familiar_form"
                if term.get("approved_familiar_forms")
                else "retain_and_gloss"
            )
    return il_contract


def _input_path(filename: str) -> Path:
    """Prefer a local experiment copy, then fall back to the parent data folder."""
    local = DATA_DIR / filename
    return local if local.exists() else PARENT_DATA_DIR / filename


ARTICLES_FILE = Path(
    os.environ.get("CLARR_ARTICLES_FILE", _input_path("articles_1-12_copy.json"))
)
READERS_FILE = Path(
    os.environ.get("CLARR_READERS_FILE", _input_path("virtual_readers_copy.json"))
)
CLAIMS_FILE = Path(
    os.environ.get("CLARR_CLAIMS_FILE", _input_path("source_core_claims.json"))
)
SIMPLIFICATIONS_FILE = Path(
    os.environ.get(
        "CLARR_SIMPLIFICATIONS_FILE", DATA_DIR / "approved_simplifications.json"
    )
)
OUTPUT_DIR = Path(os.environ.get("CLARR_OUTPUT_DIR", DATA_DIR / "results_repair"))

# ── Reader-schema label map ───────────────────────────────────────────────────
# K_LABELS converts the raw k_reader value (0.2 / 0.5 / 0.8) into a text label.
# Kept identical to the B_RS baseline so the Prior Knowledge (K) dimension is
# *presented* the same way in both experiments — the CLAP vs. B_RS contrast then
# isolates the controlled use of rewriting strategies, not how the reader is
# described.
K_LABELS = {0.2: "novice", 0.5: "intermediate", 0.8: "expert"}

# ── Length control ─────────────────────────────────────────────────────────────
# The adapted text must not balloon relative to the source. We cap its length at
# (1 + MAX_INFLATION) × the original word count so rewriting stays a *re-expression*
# of the source rather than an expansion. Enforced both in the prompts (soft) and
# by a programmatic check + condense retry (hard).
MAX_INFLATION = 0.15   # adapted text may exceed the original by at most 15%

# Sub-budgets for the two text elements most prone to inflation. Both are enforced
# in the prompts and are the FIRST things trimmed when the whole text is condensed:
#   - Analogies used to explain Core Expertise terms tend to balloon, so each is capped
#     and is the primary simplification target during condensing.
#   - The opening hook/sentence must exist (it carries the engagement strategy) but must
#     stay short; condensing shrinks it rather than deleting it.
MAX_ANALOGY_WORDS = 25   # each per-term analogy/explanation bridge ≤ this many words
MAX_OPENING_WORDS = 30   # the opening sentence/hook ≤ this many words (never removed)

# ── Length helpers ─────────────────────────────────────────────────────────────

def count_words(text: str) -> int:
    """Length measure that works for both CJK and Latin text.

    Each CJK character counts as one unit; each run of Latin letters/digits counts
    as one word. This makes the 15% budget meaningful whether the article is in
    Chinese, English, or mixed.
    """
    if not text:
        return 0
    cjk   = re.findall(r"[一-鿿]", text)
    latin = re.findall(r"[A-Za-z0-9]+", text)
    return len(cjk) + len(latin)


def extract_optimized_content(raw: str) -> str:
    """Return the text inside <Optimized Content>…</Optimized Content>, or the
    whole response if the wrapper is absent. Used so length is measured on the
    actual article body, not on the surrounding tags."""
    m = re.search(r"<Optimized Content>([\s\S]*?)</Optimized Content>", raw, re.IGNORECASE)
    return m.group(1).strip() if m else raw.strip()


# ── Term scoring helpers ───────────────────────────────────────────────────────

def _quadrant(v_tech: int, v_cent: int) -> tuple:
    """Map (V_tech, V_cent) scores to (quadrant_name, adaptation_strategy)."""
    hi_t, hi_c = v_tech >= 4, v_cent >= 4
    if hi_t and hi_c:  return "Core Expertise",    "Elaborative Scaffolding"
    if hi_t:           return "Peripheral Jargon", "Selective Pruning"
    if hi_c:           return "HF Concept",        "Preserve"
    return                    "Redundant",          "Compress"


def compute_v_cent(term: str, article_text: str, article_title: str = "") -> int:
    """
    Programmatic centrality score — how important is this term to the TEXT's core message?
    Reader-agnostic: same text → same V_cent regardless of who reads it.

    Three components (theory: Lorch & Lorch 1995; Kintsch 1998):
      tf_score    (0-1): normalised term frequency — frequent terms carry the topic
      spread      (0-1): fraction of paragraphs containing the term — breadth of use
                         signals a cross-cutting concept vs. a one-off mention
      pos_bonus   (0-1): position-based salience
                         • title match   → 1.0  (author explicitly named it as core)
                         • first para    → 0.6  (topic introduction)
                         • last para     → 0.3  (conclusion reinforcement)
                         • elsewhere     → 0.0

    Weights: tf=0.40, spread=0.35, position=0.25
    Final score scaled linearly to 1-7.
    """
    term_lower  = term.lower()
    text_lower  = article_text.lower()
    paragraphs  = [p.strip() for p in re.split(r"\n\s*\n", article_text) if p.strip()]
    # The JSON corpus often stores an article as one physical line. Treating that
    # line as one paragraph makes every mentioned term appear in 100% of paragraphs
    # and in the "first paragraph", falsely routing almost every term to a
    # high-centrality hard-retention action. Fall back to sentence-like discourse
    # units when paragraph boundaries are absent.
    if len(paragraphs) <= 1:
        sentence_units = [
            value.strip()
            for value in re.split(r"(?<=[.!?])\s+", article_text)
            if value.strip()
        ]
        if len(sentence_units) > 1:
            paragraphs = sentence_units
    n_para      = max(len(paragraphs), 1)
    n_words     = max(len(re.findall(r"\b\w+\b", text_lower)), 1)

    # Component 1: term frequency (saturates at 1 occurrence per 100 words)
    count    = len(re.findall(r"\b" + re.escape(term_lower) + r"\b", text_lower))
    tf_score = min(count / n_words * 100, 1.0)   # 1.0 reached at ≥1% frequency

    # Component 2: paragraph spread
    para_hits = sum(1 for p in paragraphs if term_lower in p.lower())
    spread    = para_hits / n_para

    # Component 3: positional salience
    if article_title and term_lower in article_title.lower():
        pos_bonus = 1.0
    elif paragraphs and term_lower in paragraphs[0].lower():
        pos_bonus = 0.6
    elif len(paragraphs) > 1 and term_lower in paragraphs[-1].lower():
        pos_bonus = 0.3
    else:
        pos_bonus = 0.0

    raw    = 0.40 * tf_score + 0.35 * spread + 0.25 * pos_bonus
    v_cent = round(1 + raw * 6)          # map [0,1] → [1,7]
    return max(1, min(7, v_cent))


def score_terms_for_reader(
    terms_raw: list,
    article_text: str,
    reader_str: str,
    article_title: str = "",
    llm_call_fn=None,
) -> list:
    """
    Score each extracted term on two axes, then classify into quadrants.

    V_cent — TEXT-SIDE, computed programmatically (reader-agnostic):
      Uses term frequency, paragraph spread, and positional salience to measure
      how central the term is to the article's core message.
      Same text → same V_cent for all readers.

    V_tech — READER-SIDE, scored by LLM embodying the reader persona:
      How specialised / unfamiliar is this term for THIS specific reader?
      1 = everyday word they know effortlessly
      7 = highly technical jargon they would almost certainly not understand

    Quadrant map:
      Core Expertise     (hi V_tech, hi V_cent) → Elaborative Scaffolding
      Peripheral Jargon  (hi V_tech, lo V_cent) → Selective Pruning
      HF Concept         (lo V_tech, hi V_cent) → Preserve
      Redundant          (lo V_tech, lo V_cent) → Compress

    Returns list of dicts: {term, v_tech, v_cent, quadrant, strategy, rationale}.
    """
    if not terms_raw:
        return []

    # ── Step A: V_cent — programmatic, reader-agnostic ───────────────────────
    v_cent_map = {
        t: compute_v_cent(t, article_text, article_title) for t in terms_raw
    }

    # ── Step B: V_tech — LLM, fully embodying the reader persona ─────────────
    terms_str = "\n".join(f"- {t}" for t in terms_raw)
    prompt = f"""You are simulating the reader described below. Fully embody this persona.

{reader_str}

For each term, reason from THIS READER'S perspective and score:
- V_tech (1-7): how specialised / unfamiliar is this term FOR THIS SPECIFIC READER?
  1 = everyday word this reader knows effortlessly
  7 = highly technical jargon they would almost certainly not know

Note: you are scoring reader familiarity only — not text importance.

Respond with valid JSON only (no markdown fences, no extra text):
{{
  "evaluations": [
    {{
      "term": "<term>",
      "v_tech": <1-7>,
      "rationale": "<one sentence: why this reader would/would not know this term>"
    }}
  ]
}}

Terms to evaluate:
{terms_str}"""

    scorer = llm_call_fn or call_llm
    raw  = scorer(prompt, max_tokens=4096, temperature=0.2)
    jm   = re.search(r"\{[\s\S]*\}", raw)
    evals = []
    if jm:
        try:
            evals = json.loads(jm.group()).get("evaluations", [])
        except (json.JSONDecodeError, KeyError):
            pass

    # Index LLM results by term for lookup
    vtech_map = {}
    for ev in evals:
        term_key = ev.get("term", "").strip()
        vtech_map[term_key] = {
            "v_tech":    max(1, min(7, int(ev.get("v_tech", 1)))),
            "rationale": ev.get("rationale", ""),
        }

    # ── Step C: combine scores → quadrant ────────────────────────────────────
    scored = []
    for t in terms_raw:
        vc = v_cent_map.get(t, 1)
        ev = vtech_map.get(t, {})
        vt = ev.get("v_tech", 1)
        q, s = _quadrant(vt, vc)
        scored.append({
            "term":      t,
            "v_tech":    vt,
            "v_cent":    vc,
            "quadrant":  q,
            "strategy":  s,
            "rationale": ev.get("rationale", ""),
        })
    return scored


def format_scored_terms(scored_terms: list) -> str:
    """
    Render scored/classified terms grouped by quadrant for use in the IL prompt.
    Each group shows the assigned adaptation strategy so the LLM can act on it.
    """
    buckets = {
        "Core Expertise":    [],
        "Peripheral Jargon": [],
        "HF Concept":        [],
        "Redundant":         [],
    }
    for t in scored_terms:
        buckets.get(t["quadrant"], buckets["Redundant"]).append(t)

    strategy_desc = {
        "Core Expertise":    "Elaborative Scaffolding — explain in depth with analogies/examples",
        "Peripheral Jargon": "Lexical Pruning — replace jargon, never delete its proposition",
        "HF Concept":        "Preserve — reader already knows this; keep as-is",
        "Redundant":         "Lexical Compression — merge wording, never delete a required claim",
    }

    lines = []
    for q, terms in buckets.items():
        if not terms:
            continue
        lines.append(f"\n### {q}  [{strategy_desc[q]}]")
        for t in terms:
            lines.append(
                f"  - {t['term']}  (V_tech={t['v_tech']}, V_cent={t['v_cent']})"
                f"  — {t['rationale']}"
            )
    return "\n".join(lines) if lines else "(no terms scored)"


# ── Prompt builders ───────────────────────────────────────────────────────────

MAX_EXTRACTED_TERMS = 24


def _term_match_key(value: str) -> str:
    """Normalize harmless hyphen/space variation for source-presence checks."""
    value = value.casefold().replace("‐", "-").replace("‑", "-")
    value = re.sub(r"[^\w]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def normalize_extracted_terms(
    raw: str,
    source_text: str,
    max_terms: int = MAX_EXTRACTED_TERMS,
) -> list[str]:
    """Bound, deduplicate, and source-ground term-extraction output."""
    if max_terms < 1:
        raise ValueError("max_terms must be positive")
    source_key = _term_match_key(source_text)
    accepted: list[str] = []
    seen: set[str] = set()
    for value in re.split(r"[,;\n]", raw or ""):
        term = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", value).strip()
        term = term.strip(" `\"'[](){}.:\t")
        key = _term_match_key(term)
        if not key or key in seen:
            continue
        if len(term) > 120 or len(term.split()) > 8:
            continue
        if not re.search(rf"(?:^| ){re.escape(key)}(?: |$)", source_key):
            continue
        accepted.append(term)
        seen.add(key)
        if len(accepted) >= max_terms:
            break
    return accepted


def prompt_term_extraction(text: str) -> str:
    return f"""
## Role
You are a computational linguist. Please analyze the theme of the given article and the specialized terms it contains. These terms are crucial for understanding the content and may pose reading obstacles for readers without relevant prior knowledge.

## Requirements:
The extracted specialized terms must meet the following conditions:
 1. Require specific domain knowledge to understand.
 2. The terms are essential for grasping the main idea of the article; avoid extracting broad or vague vocabulary.
 3. The terms are not clearly explained in the context and may create understanding barriers for general readers.
 4. The terms should be concise and clear, avoiding lengthy or complex expressions, and removing unnecessary symbols.
 5. Merge similar or redundant terms, retaining the more representative terms.
 6. English words linked by "-" are considered a single word.
 7. Return at most {MAX_EXTRACTED_TERMS} terms, ordered from most important to least important.
 8. Every returned term must occur in the source text. Do not generate related absent terms.

Step Two:
Review and filter the specialized terms obtained in the previous step, ensuring they meet the following conditions:
- High relevance: Only extract terms closely related to the theme.
- Uniform format: Prioritize using clear terms; retain necessary proper nouns in English.
- Deduplication and merging: Merge similar or redundant terms.

Text content:
{text}

## Output:
Output only a list of at most {MAX_EXTRACTED_TERMS} specialized terms, separated by commas.
"""


def prompt_IL_strategy(
    text: str, scored_terms_block: str, reader: str,
    orig_words: int, max_words: int,
    icl_claim_alignment_contract: dict | None = None,
) -> str:
    if icl_claim_alignment_contract:
        contract = icl_claim_alignment_contract
        compact_claims = []
        for value in contract.get("claim_obligations", []):
            compact_claims.append({
                key: value.get(key)
                for key in (
                    "claim_id", "tier", "canonical_proposition",
                    "immutable_slots", "immutable_slot_values",
                )
                if value.get(key) not in (None, "", [], {})
            })
        compact_terms = []
        for value in contract.get("term_claim_bindings", []):
            compact_terms.append({
                key: value.get(key)
                for key in (
                    "term_id", "source_term", "quadrant", "required_action",
                    "linked_claim_ids", "immutable_anchor_claim_ids",
                    "protected_slot_values", "approved_familiar_forms",
                )
                if value.get(key) not in (None, "", [], {})
            })
        payload = {
            "precedence": contract.get("precedence", ""),
            "claim_obligations": compact_claims,
            "term_actions": compact_terms,
            "unresolved_conflicts": contract.get("unresolved_conflicts", []),
            "source_baseline_evaluation": contract.get(
                "source_baseline_evaluation", {}
            ),
        }
        return f"""## ICL STRATEGY — LAYER 1 / COMPACT AUTHORITATIVE PATH
ICL owns only source-proposition preservation, lexical complexity, and term actions.
Do not choose paragraph structure (ECL) or explanation/analogy/guidance form (GCL).
Later layers may place or explain an ICL term but may not change its required action.

### Source
{text}

### Reader
{reader}

### Hard budget
Source: {orig_words} words. Final rewrite: at most {max_words} words. Prefer lexical
replacement/compression over deletion; no term quadrant licenses deleting a claim.

### Deterministic ICL contract
{json.dumps(payload, ensure_ascii=False, indent=2)}

### Task
For every term action, state the exact retained/replaced/compressed surface treatment.
Keep every linked proposition and protected slot recoverable. Core Expertise requires
an adjacent explanation, but leave its explanatory form to GCL. If unresolved_conflicts
is non-empty, output only those conflicts and no strategy.

Return exactly:
<Terms for Elaborative Scaffolding>
<Terms to Prune>
<Terms to Preserve>
<Terms to Compress>
<Final Terms Included in Summary>
<Article Length and Estimated Reading Time>
<Complexity Strategy>
<Claim–ICL Alignment Audit>
"""
    prompt = f"""
## Task Description
Based on the following input, generate an optimized Internal Cognitive Load (ICL) strategy that makes the article easier to understand for a specific reader.

## Input Content
### Article Content:
{text}

### Reader Information:
{reader}

### Term Analysis — scored from THIS READER's perspective
Each term has been scored on:
  V_tech (1-7): how specialised / unfamiliar the term is FOR THIS READER
  V_cent (1-7): how central the term is to the article's CORE MESSAGE
And classified into one of four quadrants with a recommended adaptation strategy:
{scored_terms_block}

### Optimization Goals: Enhance Internal Cognition

1. <Terms for Elaborative Scaffolding> (Core Expertise quadrant):
   These are high V_tech AND high V_cent terms — difficult for this reader AND essential.
   They MUST be included in the adapted text with accessible explanation (analogy, example, metaphor).
   List them here.
   Each term may receive one short source-grounded factual clarification at most.
   Prefer a nonfactual definitional gloss or clearly signalled comparison. Do not
   introduce a new mechanism, outcome, application, example, entity, or number.
   If an analogy is proposed, identify the source subject, actual action agent,
   patient/affected entity, and beneficiary before choosing a figurative subject.
   The analogy must preserve those roles; personification is not permission to make
   an organ, institution, or abstract concept perform a person's action or preference.

2. <Terms to Prune> (Peripheral Jargon quadrant):
   These are high V_tech but low V_cent — jargon not worth explaining.
   Replace the TERM with plain language when possible. This is a lexical decision only:
   never remove a source proposition, number, condition, comparison, or causal link merely
   because one of its terms is in this quadrant.
   List them here.

3. <Terms to Preserve> (HF Concept quadrant):
   These are low V_tech but high V_cent — familiar to this reader AND essential to the core message.
   They MUST appear in the adapted text as-is; no explanation needed, but do not remove them.
   List them here.

4. <Terms to Compress> (Redundant quadrant):
   Low V_tech AND low V_cent for this reader — merge or shorten the expression, but do not
   omit any source-derived core proposition or immutable fact slot.
   List them here.

5. <Final Terms Included in Summary>:
   Based on the quadrant analysis above, list every mandatory Core Expertise and HF
   Concept term that must appear in the final adapted text. Add a Peripheral Jargon or
   Redundant term only when its transformed wording is useful for tracking the source
   proposition:
   - Core Expertise terms MUST be included with explanation (Elaborative Scaffolding).
   - HF Concept terms MUST be included as-is (Preserve).
   - Peripheral Jargon forms should be replaced with plain language; their facts remain.
   - Redundant wording may be merged; source-derived core claims remain.

6. Complexity of Text Content:
   1. <Text Length>: HARD CONSTRAINT — the adapted article must NOT exceed {max_words} words
      (the original is {orig_words} words; the rewrite may be at most {int(MAX_INFLATION * 100)}%
      longer than the original). The goal is to RE-EXPRESS the source for this reader, not to
      expand it: prefer staying at or below the original length. Adaptation is achieved by
      simplifying and restructuring, NOT by adding bulk. Provide a target word-count range whose
      upper bound is ≤ {max_words} words, and ensure the reader can still finish within ~2 minutes.
   2. <Complexity Strategy>: Adjust sentence structure and vocabulary depth to match this reader's
      background — guided by their Prior Knowledge (K) and Cognitive Style (S) from the
      Reader Schema (RS) block above. Achieve any required elaboration (e.g. Core Expertise term
      explanations) WITHIN the word budget by pruning Peripheral Jargon and Redundant content to
      make room — the net length must stay within the cap.

## Output Format Requirements:
1. <Terms for Elaborative Scaffolding>
2. <Terms to Prune>
3. <Terms to Preserve>
4. <Terms to Compress>
5. <Final Terms Included in Summary>
6. <Article Length and Estimated Reading Time>
7. <Complexity Strategy>
"""
    if not icl_claim_alignment_contract:
        return prompt
    return prompt + f"""

## AUTHORITATIVE CLAIM–ICL ALIGNMENT CONTRACT
This deterministic contract was compiled before strategy generation. It overrides
any quadrant wording that would remove or weaken a source proposition. Design the
ICL strategy around its already-resolved `required_action` values. Do not merely
repeat the contract: state exactly how each term will be transformed while every
linked claim and protected slot remains recoverable. If `unresolved_conflicts` is
non-empty, return no strategy and report the conflict; the caller also fails closed.

{json.dumps(icl_claim_alignment_contract, ensure_ascii=False, indent=2)}

Add one final section:
8. <Claim–ICL Alignment Audit>
For each term–claim binding, list the executable lexical action and the proposition/
slot content that the action must preserve. Do not select claim inclusion or deletion;
claim survival has already been fixed by the contract.
"""


def prompt_EL_strategy(
    text: str,
    reader: str,
    IL_strategy: str,
    ecl_preference_alignment_contract: dict | None = None,
) -> str:
    # Keep the no-contract branch byte-identical for legacy experiments.  The
    # production branch below deliberately replaces (rather than appends to)
    # the older device-heavy template so the model receives one ECL authority.
    if ecl_preference_alignment_contract:
        contract = ecl_preference_alignment_contract
        active = str(contract.get("active_preference_dimension", ""))
        common = {
            "content_boundary": contract.get("content_boundary", ""),
            "proportionality_rule": contract.get("proportionality_rule", ""),
            "nonmechanical_rule": contract.get("nonmechanical_rule", ""),
            "source_baseline_evaluation": contract.get(
                "source_baseline_evaluation", {}
            ),
        }
        if active == "S-LOGICAL-ORGANIZATION":
            task = """Build one recoverable relation network across the source's major units.
For every LR slot, write one short, content-specific realization instruction for the
opening/topic sentence of the TO unit. It must name the shared source basis and the
relation predicate. Preserve source modality. Use causality, dependency, contrast, or
priority only when the quoted source anchors license it. A heading, paragraph order,
bare connector, roadmap, recap, or generic topic shift does not execute a slot.
For `shared_issue_different_scope`, `shared_source_basis`, or `scope_shift`, never use
"given this", "therefore", "as a result", "leads to", "creates", "drives",
"consequence", or "in response to". State that the units are different levels or
aspects of the same named source question; do not imply that one causes the other.

Return exactly these sections:
<ECL Strategy>
<Article Relation Network>
<Unit Organization Plan>
<Logical Relation Execution Ledger>

Ledger line schema (one line per slot, unchanged ID/order):
LR_ID | FROM->TO | relation_type | source_basis | Realization instruction: \"exact sentence\""""
            preference_payload = {
                "active_dimension": active,
                "source_major_units": contract.get("source_major_units", []),
                "logical_relation_slots": contract.get("logical_relation_slots", []),
                "allowed_relation_types": contract.get("allowed_relation_types", []),
                "quality_rule": contract.get("relation_quality_rule", ""),
                "modality_rule": contract.get("relation_modality_rule", ""),
                "anti_mechanical_rule": contract.get(
                    "relation_anti_mechanical_rule", ""
                ),
            }
        else:
            task = """Build one coherent emotional progression grounded only in the source.
State the reader position, the felt stake, the middle development, and the ending
movement. Do not invent a person, scene, event, consequence, or emotional fact. Use
continuous prose or sections only when they serve that progression; do not force a
story template. Follow the declared reading-goal alignment. For a learning/analytical
goal, emotional style must support analysis: carry one source-grounded question,
concern, or stake through separated explanations while preserving explicit conceptual
distinctions. Do not turn learning into persuasion or invent a human story.

Return exactly these sections:
<ECL Strategy>
<Emotional Progression>
<Reading Goal Alignment>
<Unit Organization Plan>"""
            preference_payload = {
                "active_dimension": active,
                "reading_goal": contract.get("reading_goal", ""),
                "organization_mode": contract.get("organization_mode", ""),
                "goal_alignment": contract.get("goal_alignment", {}),
                "positive_requirements": contract.get("positive_requirements", []),
                "forbidden_shortcuts": contract.get("forbidden_shortcuts", []),
            }
        return f"""## ECL STRATEGY — LAYER 2 / COMPACT AUTHORITATIVE PATH
ECL controls organization and presentation only. ICL controls lexical/claim-safe
term treatment; GCL controls explanations and schema support. Do not redesign either.

### Source
{text}

### Reader
{reader}

### Parallel coordination
The ICL strategy is generated independently from the same source and deterministic
term contract. Do not repeat term actions or claim-preservation rules in this ECL
strategy. Do not infer facts from the reader profile.

### Common ECL constraints
{json.dumps(common, ensure_ascii=False, indent=2)}

### Active preference contract
{json.dumps(preference_payload, ensure_ascii=False, indent=2)}

### Task and output
{task}
"""
    prompt = f"""
## Task Description
Based on the following input, generate an optimized External Cognitive Load (ECL) strategy.
This strategy controls HOW the adapted text is structured and presented — not what it says.
Use the reader's cognitive_style and reading_motivation (from the Reader profile) and the
term-level decisions from the IL Strategy to make every choice concrete and reader-specific.

## Input Content
### Article Content:
{text}

### Reader:
{reader}

### IL Strategy:
{IL_strategy}

## Optimization Goal: Reduce Extraneous Cognitive Load

## 1. <Bold Key Information Strategy>
Apply bolding rules derived directly from the IL Strategy quadrant results:
(1) Bold every term listed under <Terms for Elaborative Scaffolding> (Core Expertise):
    these are unfamiliar AND essential — bolding signals "an explanation follows here".
(2) Bold every term listed under <Terms to Preserve> (HF Concept):
    these are familiar AND central — bolding supports navigation without slowing the reader.
(3) Do NOT bold any term from <Terms to Prune> or <Terms to Compress>:
    those terms are being removed or minimised; bolding them would mislead the reader.
(4) Logical-connector guidance — differentiated by cognitive_style:
    - Logical reader: insert explicit transition phrases (e.g., "therefore", "as a result",
      "in contrast") immediately before or after each bolded Core Expertise term to mark its
      logical role in the argument.
    - Emotional reader: do NOT add analytical connectors; instead use smooth narrative
      bridges ("this led to…", "what made this remarkable was…") to keep story flow intact.

## 2. <Structuring Strategy>
Organise the adapted text into paragraphs based on the reader's cognitive_style:
- Logical reader: use numbered or bulleted sections; one idea per unit; begin each paragraph
  with a topic sentence; separate Core Expertise explanations into their own labelled block.
- Emotional reader: use continuous flowing paragraphs; each paragraph carries one emotional
  or narrative beat; avoid bullet lists that fragment the reading experience.

## 3. <Structured Expression Strategy>
Select ONE article-level structure based on the reader's cognitive_style × reading_motivation:

  cognitive_style=logical, reading_motivation=utility     → Topic Sentence Method:
      lead with the key finding or practical takeaway, then support with evidence.
  cognitive_style=logical, reading_motivation=learning    → Cause-Effect Structure:
      make the reasoning chain explicit step by step.
  cognitive_style=logical, reading_motivation=entertainment → Topic Sentence Method:
      clear argument with a compelling opening fact or statistic.
  cognitive_style=emotional, reading_motivation=utility   → Problem-Solution with human impact:
      frame the finding as a concrete real-world benefit or risk to people.
  cognitive_style=emotional, reading_motivation=learning  → Problem-Solution with human story:
      anchor abstract ideas in a specific person's or community's experience.
  cognitive_style=emotional, reading_motivation=entertainment → Narrative Arc:
      open with a hook, build tension around the Core Expertise terms, resolve at the end.

State which structure you have selected and why it matches this reader.

## 4. <Content Guidance Strategy>
Provide inter-term bridging and explanation depth calibrated to the reader's Prior Knowledge
(K) level — read the K label from the Reader Schema (RS) block — and the Core Expertise terms
identified in the IL Strategy:

  K = novice:
    - Insert an explicit bridging sentence between every two Core Expertise terms.
    - Define each Core Expertise term before it is first used; do not assume any prior exposure.
    - Use analogy chains: connect each new concept to something from the reader's known domain.

  K = intermediate:
    - Use brief parenthetical clarifications for Core Expertise terms on first occurrence only.
    - Assume the reader knows all HF Concept terms; no re-explanation needed.
    - One bridging sentence per paragraph is sufficient.

  K = expert:
    - Minimal guidance; trust the reader's background for HF Concept terms entirely.
    - Only flag findings that are counter-intuitive or contradict established knowledge.
    - No bridging sentences required; logical flow alone suffices.

Also state which guidance tier applies to this reader and list the Core Expertise terms
that require bridging treatment.

## Output Requirements:
<Bold Key Information Strategy>
<Structuring Strategy>
<Structured Expression Strategy>
<Content Guidance Strategy>
"""
    if not ecl_preference_alignment_contract:
        return prompt
    return prompt + f"""

## AUTHORITATIVE ECL PREFERENCE ALIGNMENT CONTRACT
Use only the active preference branch below. This contract aligns strategy generation
with the ECL scorer: coherence, internal proportionality and nonmechanical integration
are always active; the fourth dimension is exactly Logical Organization or Emotional
Progression. Examples in the earlier template are optional patterns, not permission to
invent facts, people, stories, stakes, causal links, priorities, or applications.

For a Logical profile, the legacy suggestions to force numbered sections, bold-term
connectors, or a Cause-Effect template are NOT binding. The binding object is the
`logical_relation_slots` ledger below. For every LR_* slot, plan one content-specific
boundary/topic sentence that makes the relation between the two major source units
recoverable. Use a neutral source-sequence, scope-shift, or topic-extension relation
unless an exact source excerpt licenses contrast, dependency, priority, or causality.
Do not count paragraph order, a heading, a bare connector, or a generic "the article
now turns to X" topic shift as execution. Every relation must name the shared source
entity, problem, mechanism, or claim that makes the two units belong in one argument,
and state a relation predicate: broader/narrower scope, qualification, evidence,
consequence, or response when source-licensed. Apply this test: from the transition
sentence alone, the reader must be able to answer why the two units are adjacent.
If `relation_type=shared_issue_different_scope` or `shared_source_basis`, do not use
causal predicates such as consequence, leads to, results in, causes, drives, or creates.
If the relation is causal/dependent, include the exact source mechanism in
`source_basis` and carry that mechanism into the realization sentence.
Preserve epistemic modality exactly. If the source asks what may happen, warns of a
risk, reports an argument, or describes a possibility, the transition must not call
it an observed disruption, established consequence, proven mechanism, or inevitable
outcome. Link noncausal units as two levels/aspects of the same source concern or
question instead.

{json.dumps(ecl_preference_alignment_contract, ensure_ascii=False, indent=2)}

Add one final section:
<ECL Preference Alignment>
Name the active preference dimension, the article-level relation/progression that will
carry it, and which tempting but unsupported template shortcuts will not be used.

For Logical profiles, also add:
<Logical Relation Execution Ledger>
One line for every required slot, in slot order:
`LR_ID | FROM->TO | relation_type | source_basis | exact realization instruction`.
The realization instruction must be content-specific, short enough to integrate into
the next unit's topic sentence, and must identify the shared source basis rather than
merely announcing the next topic. Prefer `shared_issue_different_scope` or
`shared_source_basis` over generic `topic_extension`. It must not introduce a factual
causal claim. Do not omit or merge slots. Emotional profiles must not output this ledger.
"""


def prompt_GL_strategy(
    text: str,
    reader: str,
    EL_strategy: str,
    gcl_schema_alignment_contract: dict | None = None,
) -> str:
    if gcl_schema_alignment_contract:
        contract = gcl_schema_alignment_contract
        guidance = contract.get("guidance_target", {}) or {}
        analogy = contract.get("analogy_support", {}) or {}
        grounding = contract.get("reader_grounding", {}) or {}
        payload = {
            "reader": contract.get("reader", {}),
            "bridge_targets": contract.get("bridge_targets", []),
            "guidance_target": {
                key: guidance.get(key)
                for key in (
                    "support_id", "reading_goal", "goal_aligned_support",
                    "anti_padding_rule",
                )
                if guidance.get(key) not in (None, "", [], {})
            },
            "reader_grounding": {
                key: grounding.get(key)
                for key in ("support_id", "placement_rule", "stance_rule", "safe_pattern")
                if grounding.get(key) not in (None, "", [], {})
            },
            "analogy": {
                key: analogy.get(key)
                for key in (
                    "support_id", "role_rule", "continuity_rule", "complexity_rule",
                    "minimum_sufficient_support_rule", "direct_explanation_fallback",
                )
                if analogy.get(key) not in (None, "", [], {})
            },
            "source_boundary": contract.get("source_boundary", ""),
            "source_baseline_evaluation": contract.get(
                "source_baseline_evaluation", {}
            ),
        }
        return f"""## GCL STRATEGY — LAYER 3 / COMPACT AUTHORITATIVE PATH
GCL adds only term explanations, schema bridges, and the minimum useful cognitive
guidance. ICL has already fixed which terms/claims survive; ECL independently fixes
organization. Do not repeat lexical actions or redesign paragraph relations.

### Source
{text}

### Reader
{reader}

### Deterministic GCL contract
{json.dumps(payload, ensure_ascii=False, indent=2)}

### Task
Required targets are ONLY `bridge_targets[*].support_id` and
`guidance_target.support_id` when present. `reader_grounding.support_id` and
`analogy.support_id` label safety constraints; they do not require a new span.
Plan exactly one local realization per required target and no extra support device.
If `bridge_targets` is empty, add no term explanation or analogy. Prefer an accurate
direct explanation. An analogy is default-OFF and may be used only to execute a
required bridge when every mapped relation is source-supported; it must not introduce
a new scenario such as model retraining, software systems, classrooms, or workplaces.
Each explanation or analogy is at most {MAX_ANALOGY_WORDS} words. Reader-profile
details may not create a standalone analogy or claim about what the reader knows,
values, or experiences. Add no new mechanism, outcome, application, person,
institution, number, example, or causal relation.
For a guidance target, use one source-grounded contrast, comparison, or necessary
comprehension question. A question is valid only when its premise and answer are
recoverable from the source; it must not introduce a mechanism, application, or fact.
Place a necessary question immediately after a source-grounded sentence that states
the answer relation explicitly; do not leave a new distinction unresolved at the end.
Do not add decorative questions. If a later draft exceeds 1.5 times the source length,
optional questions are among the first elements to compress or remove.

Return exactly:
<Term Explanation Method>
<Analogy Role-Mapping Ledger>
<Engagement Strategy>
<Schema-Support Integration>

In <Schema-Support Integration>, use one line per support_id:
support_id | local function | exact realization | placement | source/claim boundary
"""
    prompt = f"""
## Task Description
Generate a Germane Cognitive Load (GCL) strategy that maximises productive schema-building
for the specific reader. This layer controls HOW concepts are explained and how the reader
is engaged — not the structure (already decided in EL Strategy).

## Input Content
### Article Content:
{text}

### Reader:
{reader}

### EL Strategy (structure already decided — do not re-specify):
{EL_strategy}

## Optimization Goal: Maximise Productive Schema-Building

### 1. <Term Explanation Method>
For each term listed under <Terms for Elaborative Scaffolding> (Core Expertise) in the
EL Strategy, craft an explanation that bridges new knowledge to the reader's existing schemas
(Ausubel 1968), calibrated by their Prior Knowledge (K) level — read the K label from the
Reader Schema (RS) block — and knowledge domain:

  K = novice:
    - Use a two-step analogy chain: first connect to something from everyday life,
      then bridge to the scientific concept. Avoid all secondary jargon in the explanation.
    - Example pattern: "Think of X like [everyday thing]. In this context, X means [concept]."

  K = intermediate:
    - Use a single domain-adjacent analogy drawn from the reader's known field
      (as described in their profile). One sentence of explanation per term is sufficient.

  K = expert:
    - No full analogy needed. Use a brief contrastive clarification if the term is used
      in an unusual way, otherwise use it directly.

For <Terms to Preserve> (HF Concept): use the term directly — no explanation.

ANALOGY LENGTH CONSTRAINT (applies to every analogy above, all K levels):
  - Each analogy / explanatory bridge for a Core Expertise term must be ≤ {MAX_ANALOGY_WORDS} words.
  - Keep analogies vivid but compact — one concrete comparison, not a multi-clause story.
  - Analogies are the FIRST thing to cut if the article needs to be shortened, so write them
    so they can be trimmed to the core comparison without losing the term's meaning.
  - Even the novice two-step analogy chain must fit within this cap combined.
  - An analogy is a nonfactual comparison, not a source claim. Signal it with "like"
    or "think of" and never attach a new mechanism, outcome, number, named entity,
    application, or real-world example absent from the source.

ANALOGY ROLE-MAPPING CONSTRAINT (hard requirement):
  - Before using an analogy, write its mapping in the strategy as:
    `source subject -> figurative role; actual agent; patient/beneficiary; shared relation;
    prohibited inference`.
  - Preserve semantic roles. A person may exercise while the heart benefits; do not
    write that the heart itself chooses, likes, or performs the person's workout.
  - Personification may express an established narrative role (for example,
    heart=protagonist or risk factor=villain) only when the underlying source relation
    is still explicit and no intention, preference, agency, or causal power is added.
  - Maintain one coherent story ledger across the article. Once an entity is mapped
    to protagonist, villain, helper, setting, or action, later uses must retain that
    referent and relation unless an explicit transition remaps it.
  - If no compact role-correct mapping is available, use an accurate direct
    explanation instead of an analogy.
  - Use the minimum sufficient scaffold, not zero scaffold: every Core Expertise term
    must retain one complete familiar explanation. Protect a single accurate analogy
    when it is genuinely useful for this reader. Within a paragraph, prefer one
    primary frame; do not stack independent mechanisms such as server load, memory
    leak, plumbing, garbage collection, and software patches. Explain the remaining
    source relations directly.

EXPLANATION PROPOSITION BUDGET:
  - At most one source-grounded factual clarification may be introduced for any one
    explained term, and at most four across the entire adapted article.
  - Definitional glosses and reader-navigation phrases should not assert new facts.
  - Familiar-word substitution must add zero new factual propositions.

Only if space remains after all source-derived claims are preserved, add one short sentence
recommending specialised sources. This sentence is optional and is removed before source facts.

### 2. <Engagement Strategy>
Tailor the tone and engagement hooks to the reader's reading_motivation:

  reading_motivation = entertainment:
    - Open with a surprising fact, counter-intuitive finding, or vivid human consequence.
    - Keep language relaxed and conversational. Avoid academic hedging ("it is suggested that").
    - Compress non-core methodology only when it is not part of a source-derived fidelity claim.

  reading_motivation = learning:
    - Open with the core question or problem the article addresses.
    - Make the knowledge gain explicit: "By the end of this summary you will understand X."
    - Mention an application or implication only when the source explicitly states it;
      otherwise use a nonfactual comprehension cue rather than inventing an example.

  reading_motivation = utility:
    - Lead with the practical takeaway or actionable implication in the first sentence.
    - State a practical consequence only when it is explicit in the source; do not infer one.
    - Compress background/methodology only when it is not protected by the fidelity contract.

OPENING SENTENCE LENGTH CONSTRAINT (applies to all motivations):
  - The opening hook/sentence must exist — it carries the engagement strategy — but must be
    ≤ {MAX_OPENING_WORDS} words. Make it a single tight sentence, not a multi-sentence lead-in.
  - It must NEVER be deleted, only shortened, when the article is condensed.

### 3. <Narrative Style>
Select ONE narrative style based on the reader's cognitive_style (S_style) × reading_motivation.
Read these two fields from the Reader profile above before choosing. Apply only the selected style — do not blend styles.

  cognitive_style=logical, reading_motivation=entertainment  → Style 4: Data & Facts Visualisation
      Present key numbers and findings as vivid comparisons; let the data tell the story.
  cognitive_style=logical, reading_motivation=learning       → Style 6: Logical Structure
      Explicit if-then reasoning chains; label each step; summarise at the end (Style 7 close).
  cognitive_style=logical, reading_motivation=utility        → Style 7: Repetition & Summary
      State the key finding, support it, restate it as a clear takeaway.
  cognitive_style=emotional, reading_motivation=entertainment → Style 5: Suspense & Reversal
      Build tension around an unexpected finding; deliver a narrative payoff.
  cognitive_style=emotional, reading_motivation=learning     → Style 1: Storytelling
      Centre the explanation on a person, team, or community affected by the discovery.
  cognitive_style=emotional, reading_motivation=utility      → Style 2: Emotional Narrative
      Frame practical implications through the lens of human impact and lived consequence.

State which style you selected and give one source-grounded example sentence demonstrating
that style. The example must not introduce a proposition absent from the article.

## Output Requirements:
<Term Explanation Method>
<Analogy Role-Mapping Ledger>
<Engagement Strategy>
<Narrative Style>
"""
    if not gcl_schema_alignment_contract:
        return prompt
    return prompt + f"""

## AUTHORITATIVE GCL / SCHEMA-SUPPORT INTEGRATION CONTRACT
The GCL strategy must jointly implement the named bridge targets and the cognitive-
guidance target below. A term explanation is not automatically guidance, and a generic
question is not automatically a bridge. One span may count for both only if it meets
both contracts independently. Prefer an accurate direct explanation whenever a
familiar-domain analogy would require unsupported facts or forced role mapping.

{json.dumps(gcl_schema_alignment_contract, ensure_ascii=False, indent=2)}

Add one final section:
<Schema-Support Integration>
List every `support_id`, its planned local function, its source/claim boundary, and
whether it will be realized as a direct explanation, accurate bridge, or minimal
goal-aligned cognitive cue. Do not redesign the ECL structure.
"""


def prompt_regenerate(
    text: str, IL: str, EL: str, GL: str,
    orig_words: int, max_words: int, claim_guardrail: str,
    il_term_contract: list[dict] | None = None,
    upfront_strategy_contract: dict | None = None,
) -> str:
    # As above, preserve the historical no-contract prompt exactly.  For the
    # integrated path, send one compact execution packet instead of appending a
    # second 20–30 kB copy of the full upfront contract and its Logical rules.
    if upfront_strategy_contract:
        ecl = upfront_strategy_contract.get("ecl", {}) or {}
        gcl = upfront_strategy_contract.get("gcl", {}) or {}
        compact_terms = []
        for value in il_term_contract or []:
            compact_terms.append({
                key: value.get(key)
                for key in (
                    "term_id", "source_term", "required_action", "hard_required",
                    "linked_claim_ids", "protected_slot_values",
                    "approved_familiar_forms",
                )
                if value.get(key) not in (None, "", [], {})
            })
        compact_slots = []
        for value in ecl.get("logical_relation_slots", []):
            compact_slots.append({
                key: value.get(key)
                for key in (
                    "relation_id", "from_unit_id", "to_unit_id",
                    "planned_relation_type", "planned_source_basis",
                    "planned_transition",
                )
                if value.get(key) not in (None, "", [], {})
            })
        compact_bridges = []
        for value in gcl.get("bridge_targets", []):
            compact_bridges.append({
                key: value.get(key)
                for key in (
                    "support_id", "term_id", "concept", "acceptable_support",
                    "direct_explanation_allowed", "linked_claim_ids",
                    "planned_function", "planned_realization", "planned_placement",
                )
                if value.get(key) not in (None, "", [], {})
            })
        guidance = gcl.get("guidance_target", {}) or {}
        execution_packet = {
            "composition": upfront_strategy_contract.get("composition", {}),
            "repair_role": upfront_strategy_contract.get("repair_role", ""),
            "source_baseline_scores": {
                name: {
                    "score": value.get("score"),
                    "failed_target_ids": value.get("failed_target_ids", []),
                }
                for name, value in (
                    upfront_strategy_contract.get("source_baseline_score", {})
                    .get("modules", {})
                ).items()
            },
            "ecl": {
                "active_dimension": ecl.get("active_preference_dimension", ""),
                "reading_goal": ecl.get("reading_goal", ""),
                "organization_mode": ecl.get("organization_mode", ""),
                "goal_alignment": ecl.get("goal_alignment", {}),
                "logical_relation_slots": compact_slots,
                "relation_quality_rule": ecl.get("relation_quality_rule", ""),
                "relation_modality_rule": ecl.get("relation_modality_rule", ""),
            },
            "gcl": {
                "bridge_targets": compact_bridges,
                "guidance_target": {
                    key: guidance.get(key)
                    for key in (
                        "support_id", "goal_aligned_support", "planned_function",
                        "planned_realization", "planned_placement",
                    )
                    if guidance.get(key) not in (None, "", [], {})
                },
                "source_boundary": gcl.get("source_boundary", ""),
            },
        }
        logical_check = ""
        if compact_slots:
            logical_check = """
Logical execution check: realize every LR slot exactly once, preferably using its
`planned_transition` verbatim. Integrate it into the TO unit; do not print LR IDs.
Before returning, silently verify that each transition states both the shared source
basis and relation predicate. Preserve question/risk/possibility/attribution modality;
never upgrade source sequence or shared scope into a factual cause."""
        gcl_check = ""
        if guidance.get("planned_realization") or compact_bridges:
            gcl_check = """
GCL execution check: realize every planned bridge/guidance support exactly once at
its planned local placement. A necessary comprehension question is allowed when its
premise and answer are source-recoverable; place it immediately after the sentence
that explicitly states the answer relation. Do not print support IDs or add an extra
analogy, example, mechanism, or application."""
        return f"""## UNIFIED CLARR REWRITE — COMPACT AUTHORITATIVE PATH
Produce exactly one adapted article. Execute the three frozen strategies together;
do not generate a new strategy and do not defer a known obligation to Repair.

Priority on conflict: source claims/immutable slots > ICL term action > ECL
organization > GCL support > stylistic preference. Add no factual mechanism,
outcome, example, entity, number, application, or causal link.

### Hard limits
- At most {max_words} words (source: {orig_words}); condense before returning.
- Each required explanation/analogy: at most {MAX_ANALOGY_WORDS} words.
- Opening sentence: at most {MAX_OPENING_WORDS} words.
- One source-grounded clarification per explained term; four total maximum.

### Claim fidelity gate
{claim_guardrail}

### Compact ICL term actions
{json.dumps(compact_terms, ensure_ascii=False, indent=2)}

### Layer 1 — Frozen ICL base
{IL}

### Layer 2 — Frozen ECL organization delta
{EL}

### Layer 3 — Frozen GCL support delta
{GL}

### Deterministic execution packet
{json.dumps(execution_packet, ensure_ascii=False, indent=2)}
{logical_check}
{gcl_check}

### Source article
{text}

Return only:
<Optimized Content>
[adapted article]
</Optimized Content>
"""
    prompt = f"""
## Role Description:
Integrate the provided <Internal Cognitive Optimization Strategies>, <External Cognitive Load Reduction Strategies>, and <Relevant Cognitive Load Optimization> to produce an adapted article for the target reader.

## Task Description:
Rewrite the original article strictly following the three strategies below. Pay particular attention to the term-level decisions from the IL Strategy — these are NON-NEGOTIABLE:

### Term handling rules (from IL Strategy — enforce exactly):
- <Terms for Elaborative Scaffolding> (Core Expertise): MUST appear in the adapted text, each accompanied by an accessible explanation (analogy / metaphor / example) as specified in the GL Strategy.
- <Terms to Preserve> (HF Concept): MUST appear in the adapted text as-is; no explanation required.
- <Terms to Prune> (Peripheral Jargon): replace the jargon form with plain language when useful;
  NEVER delete a protected proposition containing that term.
- <Terms to Compress> (Redundant): shorten or merge wording; NEVER delete a protected claim.
- EXPLANATION PROPOSITION BUDGET: at most one source-grounded factual clarification
  per explained/glossed term and at most four across the whole article. Prefer short
  nonfactual glosses. Familiar substitutions add no new factual propositions. Never
  invent a mechanism, outcome, application, example, entity, number, or causal link.

### STRUCTURED IL TERM-TRANSFORMATION CONTRACT
This JSON is the authoritative term-by-term decision. The quadrant/action may change
surface wording, but it never licenses a factual change. For every term, follow
`required_action`, preserve every linked claim, and retain protected slot values.
{json.dumps(il_term_contract or [], ensure_ascii=False, indent=2)}

{claim_guardrail}

### Length and complexity (from IL Strategy):
Adhere to the word count range and complexity level specified in <Article Length> and <Complexity Strategy>.

### HARD LENGTH LIMIT (non-negotiable, overrides everything else):
The original article is {orig_words} words. The adapted article MUST contain at most {max_words}
words (i.e. no more than {int(MAX_INFLATION * 100)}% longer than the original). Do NOT pad,
duplicate, or over-explain. If honouring all term-explanation rules would exceed this limit,
shorten hooks, analogies, optional recommendations, repeated explanations, and decorative
transitions first. Do not treat a low-centrality term as permission to delete a source fact.
Count your output; if it is over {max_words} words, condense before returning.

Two element-level caps that also bound the total length:
- ANALOGY CAP: every analogy/explanation for a Core Expertise term must be ≤ {MAX_ANALOGY_WORDS}
  words. Analogies are the FIRST place to cut when trimming to fit the budget.
- OPENING SENTENCE CAP: the opening hook must be present but ≤ {MAX_OPENING_WORDS} words. Never
  delete it — only shorten it when space is tight.

### Structure and presentation (from EL Strategy):
Apply the bolding, paragraph structure, and logical guidance decisions exactly as specified.

### Narrative style (from GL Strategy):
Apply the explanation method for Core Expertise terms and the narrative / engagement style specified.

## Original Content:
{text}

## Internal Cognitive Optimization:
{IL}

## External Cognitive Load Reduction Strategies:
{EL}

## Relevant Cognitive Load Optimization:
{GL}

## Output Format:
Please output in the following format:
<Optimized Content> Output content
</Optimized Content>
"""
    if not upfront_strategy_contract:
        return prompt
    ecl_contract = upfront_strategy_contract.get("ecl", {}) or {}
    logical_gate = ""
    if (
        str(ecl_contract.get("active_preference_dimension", ""))
        == "S-LOGICAL-ORGANIZATION"
    ):
        logical_gate = f"""
### LOGICAL ECL EXECUTION GATE
The ECL relation network is a hard execution checklist, not optional advice.
Realize every `logical_relation_slots` item exactly once in the unified rewrite.
Each later major unit must contain a content-specific boundary/topic sentence that
states its relation to the preceding unit. Paragraph order, headings, bolding, and a
bare transition word do not satisfy a slot. The sentence must name the shared source
entity, problem, mechanism, or claim and state whether the next unit is a broader/
narrower level, qualification, evidence, consequence, or response when licensed; a
generic scope shift such as "the discussion next turns to X" is insufficient. From
the sentence alone, the reader must be able to answer why the units are adjacent.
Integrate the relation into existing content so it does not add a roadmap or recap.

If the source does not explicitly license causality, priority, dependency, or
contrast, use neutral meta-discursive wording such as a source-sequence, scope-shift,
or topic-extension. Never turn argumentative order into a new factual cause.
Preserve source modality: questions, risks, possibilities, and attributed arguments
must remain questions, risks, possibilities, and attributed arguments. For a
shared-scope relation, prefer wording such as "two levels/aspects of the same source
concern" instead of "disruption", "consequence", "leads to", or "creates".

Before returning the article, silently check every LR_* ID against the article and
revise any missing boundary in the SAME rewrite. When a slot contains
`planned_transition`, use that sentence verbatim whenever possible. If it must be
shortened, preserve its shared-source basis and relation predicate verbatim; never
paraphrase away the mechanism that makes the relation recoverable. Do not print the
checklist or IDs.

{json.dumps({
    "logical_relation_slots": ecl_contract.get("logical_relation_slots", []),
    "relation_execution_rule": ecl_contract.get("relation_execution_rule", ""),
    "relation_grounding_rule": ecl_contract.get("relation_grounding_rule", ""),
    "relation_quality_rule": ecl_contract.get("relation_quality_rule", ""),
    "relation_modality_rule": ecl_contract.get("relation_modality_rule", ""),
}, ensure_ascii=False, indent=2)}
"""
    contract_block = f"""
### UNIFIED UPFRONT STRATEGY-EXECUTION CONTRACT
This is the deterministic integration of the three strategies. Execute all three
lanes in this same rewrite. Claim preservation has precedence over ICL wording;
ECL controls organization only; GCL supplies the contracted bridges and cognitive
guidance without adding facts. Do not defer a known obligation to Repair. Repair is
reserved for evaluator-confirmed omissions, incorrect execution, or local regression.

{json.dumps(upfront_strategy_contract, ensure_ascii=False, indent=2)}
{logical_gate}
"""
    return prompt.replace("\n## Output Format:", "\n" + contract_block + "\n## Output Format:")


def prompt_condense(
    content: str, max_words: int, cur_words: int, claim_guardrail: str,
    il_term_contract: list[dict] | None = None,
    upfront_strategy_contract: dict | None = None,
) -> str:
    prompt = f"""## Task
The adapted article below is {cur_words} words, which exceeds the hard limit of {max_words} words.
Condense it to AT MOST {max_words} words while preserving:
  - every source-derived claim and all of its immutable slots,
  - every Core Expertise term and its accessible explanation,
  - every Preserved (HF Concept) term,
  - the existing structure, bolding, and narrative style.
Remove unsupported, redundant, and surplus explanatory propositions first. Keep at
most one source-grounded factual clarification per explained term and at most four
across the article; familiar substitutions must not add facts.

Apply these cuts IN THIS PRIORITY ORDER until the text fits the limit:
  1. Remove unsupported additions and optional source recommendations.
  2. SHRINK ANALOGIES. Reduce every Core Expertise analogy to its single core comparison,
     ≤ {MAX_ANALOGY_WORDS} words each. This is the primary simplification lever — exhaust it
     before touching anything else.
  3. Replace Peripheral Jargon lexically and merge redundant wording without deleting facts.
  4. Tighten general wording and remove repetition throughout.
  5. COMPRESS THE OPENING SENTENCE as much as possible (≤ {MAX_OPENING_WORDS} words), but NEVER
     delete it — the opening hook must still exist.

Do NOT drop a protected proposition, essential term, or immutable number/condition/scope.
Do NOT add new content.

Preserve the structured IL treatment decisions below. Shortening an explanation is
allowed, but do not remove a required term/gloss, restore pruned jargon, or replace a
protected immutable anchor.
{json.dumps(il_term_contract or [], ensure_ascii=False, indent=2)}

{claim_guardrail}

## Article to condense:
{content}

## Output Format:
<Optimized Content> Output content
</Optimized Content>
"""
    if not upfront_strategy_contract:
        return prompt
    preservation = {
        "repair_role": upfront_strategy_contract.get("repair_role", ""),
        "ecl": upfront_strategy_contract.get("ecl", {}),
        "gcl": upfront_strategy_contract.get("gcl", {}),
    }
    return prompt.replace(
        "\n## Article to condense:",
        "\n### ECL/GCL NON-REGRESSION DURING CONDENSING\n"
        "Preserve the active ECL relation/progression and every required GCL bridge/"
        "guidance function. Shorten their wording before deleting their only effective "
        "realization. Do not create a new repair obligation while enforcing length.\n"
        + json.dumps(preservation, ensure_ascii=False, indent=2)
        + "\n\n## Article to condense:",
    )


# ── Core pipeline ─────────────────────────────────────────────────────────────

def format_reader(profile: dict) -> str:
    """Convert a reader profile dict to a readable string for the LLM.

    The string leads with an EXPLICIT Reader Schema (RS) triplet — K / P / S —
    formatted the same way as the B_RS baseline, so the three controlled reader
    dimensions are *presented* identically in both experiments. This keeps the
    CLAP vs. B_RS comparison focused on the controlled use of rewriting
    strategies, not on how the reader is described.

    Prior Knowledge (K) is shown as a TEXT LABEL (novice / intermediate /
    expert) via K_LABELS — never as the raw k_reader number.
    """
    p = profile.get("persona", {})
    s = profile.get("schema", {})

    # ── Reader Schema (RS): the three controlled cognitive dimensions ────────
    k_reader   = s.get("k_reader", "")
    k_label    = K_LABELS.get(k_reader, f"k={k_reader}")   # numeric → text label
    motivation_raw = str(s.get("reading_motivation", "")).strip().lower()
    motivation = {
        "analysis": "learning",
        "analytic": "learning",
        "analytical": "learning",
        "analytical_reading": "learning",
        "practice": "utility/practice",
        "practical": "utility/practice",
        "application": "utility/practice",
        "applied": "utility/practice",
        "utility": "utility/practice",
    }.get(motivation_raw, motivation_raw)
    style      = s.get("cognitive_style", "")

    # background qualifies the K dimension (built the same way as in B_RS)
    bg_parts = []
    if p.get("field_of_study"):
        bg_parts.append(p["field_of_study"])
    if p.get("profession"):
        bg_parts.append(p["profession"])
    background = "; ".join(bg_parts) if bg_parts else "general background"

    lines = [
        "=== Reader Schema (RS) — controlled reader dimensions ===",
        f"- Prior Knowledge (K): {k_label} in this domain; background in {background}",
        f"- Reading Motivation (P): {motivation}-oriented",
        f"- Cognitive Style (S): {style}",
        "",
        "=== Reader Persona detail ===",
        f"Reader ID: {profile.get('id', '')}",
        f"Name: {p.get('name', '')}",
        f"Age: {p.get('age', '')}",
        f"Education: {p.get('education', '')}",
        f"Profession: {p.get('profession', '')}",
        f"Field of Study: {p.get('field_of_study', '')}",
        f"Domain Expertise: {json.dumps(p.get('domain_expertise', {}), ensure_ascii=False)}",
        f"Interests: {', '.join(p.get('interests', []))}",
        f"Reading Habits: {p.get('reading_habits', '')}",
        f"Typical Reading Context: {p.get('typical_reading_context', '')}",
    ]
    return "\n".join(lines)


def _compact_baseline_signal(
    source_baseline_score: dict,
    module: str,
) -> dict:
    """Keep only strategy-actionable source failures in a module prompt."""
    value = (source_baseline_score.get("modules") or {}).get(module, {}) or {}
    return {
        "source_score": value.get("score", 0.0),
        "hard_pass": bool(value.get("hard_pass", False)),
        "failed_target_ids": list(value.get("failed_target_ids", [])),
        "repair_signals": list(value.get("repair_signals", [])),
        "strategy_rule": (
            "Address these source failures inside this module's initial strategy; "
            "do not wait for post-rewrite Repair. Preserve passing targets."
        ),
    }


def evaluate_source_three_dimension_baseline(
    *,
    source_text: str,
    claim_contract: list[dict],
    il_term_contract: list[dict],
    schema_support_contract: dict,
    preference: str,
    item_id: str,
    policy: FidelityPolicy,
) -> dict:
    """Score the source with the exact validators later used after rewriting.

    The baseline is a pure function of (source, reader-derived contracts,
    policy, engine version), yet it re-billed ~18% of a part's spend on every
    rerun/comparison (part_2: ¥43 of ¥243).  A disk cache keyed by ALL inputs
    makes reruns free; bump the version whenever an audit prompt or scorer
    changes what the baseline would say.
    """
    try:
        import dataclasses
        cache_payload_key = json.dumps(
            [
                "source_baseline_v2_judge0901",
                source_text,
                claim_contract,
                il_term_contract,
                schema_support_contract,
                preference,
                dataclasses.asdict(policy),
            ],
            ensure_ascii=False, sort_keys=True,
        )
        cache_dir = Path(__file__).resolve().parent / "v4_cache" / "source_baseline"
        cache_path = cache_dir / f"{hashlib.sha256(cache_payload_key.encode('utf-8')).hexdigest()}.json"
        if os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower() != "refresh":
            try:
                cached = json.loads(cache_path.read_text(encoding="utf-8"))
                if cached.get("schema_version") == "source_baseline_v2_judge0901":
                    return cached["value"]
            except (OSError, ValueError, json.JSONDecodeError):
                pass
    except Exception:
        cache_path = None
    source_claim_validation = validate_candidate(
        source_text, source_text, claim_contract, call_llm, policy
    )
    with ThreadPoolExecutor(
        max_workers=3, thread_name_prefix="clarr-source-baseline"
    ) as pool:
        il_future = pool.submit(
            validate_il_compliance,
            source_text,
            source_text,
            il_term_contract,
            source_claim_validation,
            call_llm,
        )
        gcl_future = pool.submit(
            evaluate_schema_support,
            source_text,
            source_text,
            schema_support_contract,
            source_claim_validation,
            call_llm,
            {},
        )
        ecl_future = pool.submit(
            score_ecl_candidate,
            source_text,
            source_text,
            preference,
            item_id + "_source_baseline",
            call_ecl_feature_llm,
        )
        il_evaluation = il_future.result()
        schema_evaluation = gcl_future.result()
        ecl_evaluation = ecl_future.result()
    value = build_three_dimension_score(
        candidate=source_text,
        il_evaluation=il_evaluation,
        ecl_evaluation=ecl_evaluation,
        schema_evaluation=schema_evaluation,
        stage="source_before_strategy",
    )
    value["claim_validation"] = source_claim_validation
    if cache_path is not None and os.environ.get(
        "CLARR_V2_CACHE_MODE", "readwrite"
    ).strip().lower() != "off":
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = cache_path.with_suffix(".tmp")
            tmp_path.write_text(
                json.dumps(
                    {"schema_version": "source_baseline_v2_judge0901", "value": value},
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            os.replace(tmp_path, cache_path)
        except OSError:
            pass
    return value


def process_article_for_reader(
    article_id: str,
    article_text: str,
    reader_profile: dict,
    article_claim_record: dict,
    simplification_ledger: dict | None = None,
    article_title: str = "",
    fidelity_policy: FidelityPolicy | None = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    strategy_generation_fn=None,
    post_rewrite_fn=None,
) -> dict:
    """Run CLAP generation followed by complete four-part repair.

    Steps:
      1. Extract domain terms from the article (reader-agnostic).
      2. Score terms: V_cent programmatically (text-side) + V_tech via LLM reader persona.
      3. Score the source with the final ICL/ECL/GCL evaluators.
      4. Generate complete module-owned ICL/ECL/GCL strategies in parallel.
      5. Freeze/deduplicate the strategies and perform one unified rewrite.
      6. Audit Fidelity/ICL/GCL and source-targeted ECL on that same candidate.
      7. Coordinate target-scoped Repair commits, then apply joint Gate C/D release checks.
    """
    fidelity_policy = fidelity_policy or FidelityPolicy()
    reader_str = format_reader(reader_profile)
    claim_contract = normalize_claim_contract(
        article_claim_record, simplification_ledger or {}
    )
    if not claim_contract:
        raise ValueError(f"No source claim contract found for {article_id}")
    claim_guardrail = generation_guardrail(claim_contract)

    # Length budget: the adapted text may exceed the source by at most MAX_INFLATION.
    orig_words = count_words(article_text)
    max_words  = math.ceil(orig_words * (1 + MAX_INFLATION))

    print("  [1/7] Extracting terms...")
    terms_raw_text = call_llm(prompt_term_extraction(article_text))
    terms_list = normalize_extracted_terms(terms_raw_text, article_text)

    print("  [2/7] Scoring terms (V_cent=programmatic | V_tech=reader persona)...")
    scored_terms = score_terms_for_reader(
        terms_list, article_text, reader_str, article_title=article_title
    )
    scored_terms_block = format_scored_terms(scored_terms)
    provisional_il_term_contract = resolve_anchor_conflicts(
        build_il_term_contract(scored_terms, claim_contract)
    )
    icl_claim_alignment_contract = build_icl_claim_alignment_contract(
        claim_contract, provisional_il_term_contract
    )

    schema_support_contract = build_schema_support_contract(
        reader_profile, provisional_il_term_contract, claim_contract
    )
    ecl_preference_alignment_contract = build_ecl_preference_alignment_contract(
        reader_profile, article_text
    )
    gcl_schema_alignment_contract = build_gcl_schema_alignment_contract(
        schema_support_contract
    )
    presentation_preference = str(
        reader_profile.get("schema", {}).get("cognitive_style", "")
    ).strip().title()
    print("  [baseline] Scoring source on ICL/ECL/GCL with Repair evaluators...")
    source_baseline_score = evaluate_source_three_dimension_baseline(
        source_text=article_text,
        claim_contract=claim_contract,
        il_term_contract=provisional_il_term_contract,
        schema_support_contract=schema_support_contract,
        preference=presentation_preference,
        item_id=f"{article_id}_{reader_profile.get('id', 'reader')}",
        policy=fidelity_policy,
    )
    icl_claim_alignment_contract = {
        **icl_claim_alignment_contract,
        "source_baseline_evaluation": _compact_baseline_signal(
            source_baseline_score, "icl"
        ),
    }
    ecl_preference_alignment_contract = {
        **ecl_preference_alignment_contract,
        "source_baseline_evaluation": _compact_baseline_signal(
            source_baseline_score, "ecl"
        ),
    }
    gcl_schema_alignment_contract = {
        **gcl_schema_alignment_contract,
        "source_baseline_evaluation": _compact_baseline_signal(
            source_baseline_score, "gcl"
        ),
    }
    # Each parallel call emits only its module-owned delta. Deterministic contracts,
    # not another strategy's free-form prose, coordinate the three calls.
    parallel_coordination_note = (
        "Other strategy layers are generated in parallel; emit only this module's delta."
    )

    print(
        f"  [3-5/7] Generating complete ICL/ECL/GCL strategies in parallel "
        f"(budget ≤ {max_words} words, orig {orig_words})..."
    )
    strategy_prompts = {
        "IL": prompt_IL_strategy(
            article_text, scored_terms_block, reader_str, orig_words,
            max_words, icl_claim_alignment_contract,
        ),
        "EL": prompt_EL_strategy(
            article_text, reader_str, parallel_coordination_note,
            ecl_preference_alignment_contract,
        ),
        "GL": prompt_GL_strategy(
            article_text, reader_str, parallel_coordination_note,
            gcl_schema_alignment_contract,
        ),
    }
    strategy_pipeline_artifact = None
    strategy_bundle_metadata = None
    if strategy_generation_fn is not None:
        generated = strategy_generation_fn(
            source_text=article_text,
            prompts=strategy_prompts,
            llm_call=call_llm,
            context={
                "reader_profile": reader_profile,
                "article_id": article_id,
                "article_title": article_title,
                "claim_contract": claim_contract,
                "reader_text": reader_str,
                "scored_terms": scored_terms,
                "provisional_il_term_contract": provisional_il_term_contract,
                "icl_claim_alignment_contract": icl_claim_alignment_contract,
                "ecl_preference_alignment_contract": ecl_preference_alignment_contract,
                "gcl_schema_alignment_contract": gcl_schema_alignment_contract,
                "orig_words": orig_words,
                "max_words": max_words,
            },
        )
        IL, EL, GL = (str(generated[key]) for key in ("IL", "EL", "GL"))
        strategy_pipeline_artifact = generated.get("_pipeline_artifact")
        strategy_bundle_metadata = generated.get("_strategy_bundle_metadata")
    else:
        with ThreadPoolExecutor(max_workers=3, thread_name_prefix="clarr-strategy") as pool:
            futures = {
                key: pool.submit(call_llm, prompt)
                for key, prompt in strategy_prompts.items()
            }
            IL = futures["IL"].result()
            EL = futures["EL"].result()
            GL = futures["GL"].result()

    ecl_preference_alignment_contract = compile_ecl_relation_plan(
        ecl_preference_alignment_contract, EL
    )

    il_term_contract = resolve_anchor_conflicts(
        build_il_term_contract(scored_terms, claim_contract, IL)
    )
    icl_claim_alignment_contract = build_icl_claim_alignment_contract(
        claim_contract, il_term_contract
    )
    icl_claim_alignment_contract["source_baseline_evaluation"] = (
        _compact_baseline_signal(source_baseline_score, "icl")
    )
    schema_support_contract = build_schema_support_contract(
        reader_profile, il_term_contract, claim_contract
    )
    gcl_schema_alignment_contract = build_gcl_schema_alignment_contract(
        schema_support_contract
    )
    gcl_schema_alignment_contract["source_baseline_evaluation"] = (
        _compact_baseline_signal(source_baseline_score, "gcl")
    )
    gcl_schema_alignment_contract = compile_gcl_support_plan(
        gcl_schema_alignment_contract, GL
    )
    strategy_bundle = freeze_strategy_bundle(IL, EL, GL)
    if isinstance(strategy_bundle_metadata, dict):
        strategy_bundle.update(strategy_bundle_metadata)
    upfront_strategy_contract = build_upfront_strategy_contract(
        icl_claim_alignment=icl_claim_alignment_contract,
        ecl_preference_alignment=ecl_preference_alignment_contract,
        gcl_schema_alignment=gcl_schema_alignment_contract,
        strategy_bundle=strategy_bundle,
        source_baseline_score=source_baseline_score,
    )
    if post_rewrite_fn is not None:
        composition = dict(upfront_strategy_contract.get("composition", {}) or {})
        composition.update({
            "execution_topology": "primary_icl_ecl_then_local_il_then_local_gcl",
            "layer_order": [
                "icl_ecl_primary", "il_gloss_local", "gcl_guidance_local"
            ],
            "execution_rule": (
                "perform one ICL/ECL primary rewrite with term-bound GCL bridges; "
                "then repair only missing hard IL glosses and GCL guidance locally "
                "before the unchanged integrated audit"
            ),
        })
        upfront_strategy_contract["composition"] = composition
        upfront_strategy_contract["post_rewrite_il"] = {
            "enabled": True,
            "position": "after_icl_ecl_before_gcl_and_integrated_audit",
            "full_article_rewrite_calls": 0,
            "fallback_scope": "missing_hard_retain_and_gloss_terms_only",
        }
        upfront_strategy_contract["post_rewrite_gcl"] = {
            "enabled": True,
            "position": "after_local_il_before_integrated_audit",
            "full_article_rewrite_calls": 0,
            "fallback_api_calls_max_shared_with_il": 1,
        }
        hash_payload = dict(upfront_strategy_contract)
        hash_payload.pop("contract_sha256", None)
        upfront_strategy_contract["contract_sha256"] = hashlib.sha256(
            json.dumps(
                hash_payload, ensure_ascii=False, sort_keys=True
            ).encode("utf-8")
        ).hexdigest()
    strategy_execution_contract = build_strategy_execution_contract(
        reader_profile=reader_profile,
        icl_strategy=IL,
        ecl_strategy=EL,
        gcl_strategy=GL,
        il_term_contract=il_term_contract,
        schema_support_contract=schema_support_contract,
        max_words=max_words,
        upfront_strategy_contract=upfront_strategy_contract,
    )

    print("  [6/7] Generating adapted article with claim guardrails...")
    final_text = call_llm(prompt_regenerate(
        article_text, IL, EL, GL, orig_words, max_words, claim_guardrail,
        il_term_contract, upfront_strategy_contract,
    ))

    # ── Hard enforcement: condense if the rewrite blew the budget ────────────
    content      = extract_optimized_content(final_text)
    final_words  = count_words(content)
    condensed    = False
    if final_words > max_words:
        print(f"      over budget ({final_words} > {max_words}); condensing...")
        final_text  = call_llm(prompt_condense(
            content, max_words, final_words, claim_guardrail, il_term_contract,
            upfront_strategy_contract,
        ))
        content     = extract_optimized_content(final_text)
        new_words   = count_words(content)
        condensed   = True
        print(f"      after condense: {new_words} words "
              f"({'within' if new_words <= max_words else 'STILL OVER'} budget)")
        final_words = new_words

    post_rewrite_pipeline_artifact = None
    if post_rewrite_fn is not None:
        print("  [6.5/7] Applying post-rewrite IL/GCL gates locally...")
        post_result = post_rewrite_fn(
            candidate=content,
            source_text=article_text,
            article_id=article_id,
            article_title=article_title,
            reader_profile=reader_profile,
            claim_contract=claim_contract,
            il_term_contract=il_term_contract,
            schema_support_contract=schema_support_contract,
            strategy_pipeline_artifact=strategy_pipeline_artifact,
            upfront_strategy_contract=upfront_strategy_contract,
            max_words=max_words,
            count_words=count_words,
            llm_call=call_llm,
        )
        if not isinstance(post_result, dict):
            raise TypeError("post_rewrite_fn must return a result object")
        proposed_content = str(post_result.get("content", ""))
        post_rewrite_pipeline_artifact = post_result.get("artifact", {})
        if not proposed_content:
            raise ValueError("post_rewrite_fn returned empty content")
        proposed_words = count_words(proposed_content)
        if proposed_words > max_words:
            # Same ceiling tolerance as the condense stage above: an overrun
            # here means the primary rewrite already sat over budget (the
            # local pipeline drops its own additions when that restores
            # compliance).  The release length gate judges it; raising only
            # discarded completed pairs on short-register articles.
            print(
                f"      post_local: STILL OVER word budget "
                f"({proposed_words} > {max_words}) — left for length gate",
                flush=True,
            )
        content = proposed_content
        final_words = proposed_words
        print(
            "      post_local="
            f"{post_rewrite_pipeline_artifact.get('status', 'unknown')}; "
            f"il={(post_rewrite_pipeline_artifact.get('il') or {}).get('status', 'n/a')}; "
            f"gcl={(post_rewrite_pipeline_artifact.get('gcl') or {}).get('status', 'n/a')}; "
            f"api_calls={post_rewrite_pipeline_artifact.get('api_calls', 0)}; "
            f"words={final_words}",
            flush=True,
        )

    pre_repair_text = content
    if enable_repair:
        print("  [7/7] Running integrated fidelity/ICL/schema/ECL repair...")
        repair_result = run_integrated_repair(
            source_text=article_text,
            candidate=content,
            contract=claim_contract,
            llm_call=call_llm,
            feature_llm_call=call_ecl_feature_llm,
            count_words=count_words,
            extract_content=extract_optimized_content,
            max_words=max_words,
            item_id=f"{article_id}_{reader_profile.get('id', 'reader')}",
            presentation_preference=presentation_preference,
            policy=fidelity_policy,
            reader_constraints=reader_str,
            il_term_contract=il_term_contract,
            schema_support_contract=schema_support_contract,
            strategy_execution_contract=strategy_execution_contract,
            ecl_max_rounds=ecl_repair_rounds,
            max_total_attempts=max_total_repair_attempts,
            audit_initial_strategy_execution=True,
            source_baseline_score=source_baseline_score,
            ecl_calibration_mode=ecl_calibration_mode,
        )
        content = repair_result["analysis_content"]
        release_content = repair_result["release_content"]
        release_text = (
            f"<Optimized Content>\n{release_content}\n</Optimized Content>"
            if repair_result["release_ready"] else None
        )
        # Gate failure must remain visible to research users.  `final_text` is the
        # best bounded rewrite in every completed run; `release_text` and
        # `release_ready` retain the stricter publishable-output distinction.
        final_text = f"<Optimized Content>\n{content}\n</Optimized Content>"
        final_words = count_words(content)
        print(
            f"      integrated={repair_result['status']}; "
            f"ecl={repair_result.get('ecl_result', {}).get('status', 'not_run')}; "
            f"core={repair_result['selected_validation']['metrics']['core_claim_recall']:.3f}; "
            f"critical={repair_result['selected_validation']['metrics']['critical_claim_recall']:.3f}"
        )
    else:
        release_text = f"<Optimized Content>\n{content}\n</Optimized Content>"
        repair_result = {
            "status": "disabled",
            "analysis_content": content,
            "release_content": content,
            "release_ready": True,
            "release_block_reasons": [],
            "repair_rounds_used": 0,
            "selected_validation": None,
            "history": [],
            "method": "repair-disabled",
            "ecl_result": {"status": "disabled"},
        }

    fidelity_component = repair_result.get(
        "fidelity_icl_schema_result", repair_result
    )
    repair_audit = {
        key: repair_result.get(key)
        for key in (
            "method",
            "schema_version",
            "status",
            "release_ready",
            "release_block_reasons",
            "repair_rounds_used",
            "accepted_repair_rounds",
            "stage_history",
            "module_isolation",
            "final_module_gate",
            "attempt_budget",
            "source_baseline_score",
            "initial_three_dimension_score",
            "initial_improvement",
            "final_three_dimension_score",
            "final_improvement",
        )
        if key in repair_result
    }

    return {
        "final_text": final_text,
        "release_text": release_text,
        "candidate_text": f"<Optimized Content>\n{content}\n</Optimized Content>",
        "output_disposition": repair_result.get(
            "output_disposition",
            "returned_release_ready"
            if repair_result.get("release_ready") else "returned_not_release_ready",
        ),
        "release_ready": bool(repair_result.get("release_ready", False)),
        "release_block_reasons": repair_result.get("release_block_reasons", []),
        "pre_repair_text": pre_repair_text,
        "extracted_terms": terms_raw_text,
        "scored_terms": scored_terms,
        "il_term_contract": il_term_contract,
        "schema_support_contract": schema_support_contract,
        "strategy_execution_contract": strategy_execution_contract,
        "upfront_strategy_contract": upfront_strategy_contract,
        "strategy_bundle": strategy_bundle,
        **(
            {"strategy_pipeline_artifact": strategy_pipeline_artifact}
            if strategy_pipeline_artifact is not None else {}
        ),
        **(
            {
                "post_rewrite_pipeline_artifact": post_rewrite_pipeline_artifact,
                "post_rewrite_il_artifact": (
                    post_rewrite_pipeline_artifact.get("il", {})
                ),
                "post_rewrite_gcl_artifact": (
                    post_rewrite_pipeline_artifact.get(
                        "gcl", post_rewrite_pipeline_artifact
                    )
                ),
            }
            if post_rewrite_pipeline_artifact is not None else {}
        ),
        "repair_method": repair_result.get("method", INTEGRATED_REPAIR_VERSION),
        "repair": repair_audit,
        "initial_strategy_execution_audit": repair_result.get(
            "initial_strategy_execution_audit", {}
        ),
        "final_strategy_execution_audit": repair_result.get(
            "final_strategy_execution_audit", {}
        ),
        "three_dimension_evaluation": {
            "source_baseline": source_baseline_score,
            "initial_rewrite": repair_result.get(
                "initial_three_dimension_score", {}
            ),
            "initial_comparison": repair_result.get("initial_improvement"),
            "post_repair": repair_result.get("final_three_dimension_score", {}),
            "final_comparison": repair_result.get("final_improvement"),
        },
        "ecl": repair_result.get("ecl_result", {"status": "disabled"}),
        "strategies": {"IL": IL, "EL": EL, "GL": GL},
        "fidelity": {
            "policy": asdict(fidelity_policy),
            "claim_contract": claim_contract,
            **fidelity_component,
        },
        "length": {
            "original_words":    orig_words,
            "max_words":         max_words,
            "max_inflation":     MAX_INFLATION,
            "final_words":       final_words,
            "within_budget":     final_words <= max_words,
            "condensed":         condensed,
            "pre_repair_words":  count_words(pre_repair_text),
            "max_analogy_words": MAX_ANALOGY_WORDS,
            "max_opening_words": MAX_OPENING_WORDS,
        },
    }


# ── Batch runner ──────────────────────────────────────────────────────────────

def load_data():
    with open(ARTICLES_FILE, encoding="utf-8") as f:
        articles = json.load(f)
    with open(READERS_FILE, encoding="utf-8") as f:
        readers_data = json.load(f)
    with open(CLAIMS_FILE, encoding="utf-8") as f:
        claim_registry = json.load(f)
    if SIMPLIFICATIONS_FILE.exists():
        with open(SIMPLIFICATIONS_FILE, encoding="utf-8") as f:
            simplification_ledger = json.load(f)
    else:
        simplification_ledger = {}
    readers = {p["id"]: p for p in readers_data["profiles"]}
    return articles, readers, claim_registry, simplification_ledger


def run_batch(
    article_ids: list[str],
    reader_ids: list[str],
    fidelity_policy: FidelityPolicy | None = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    force: bool = False,
    workers: int = 1,
):
    fidelity_policy = fidelity_policy or FidelityPolicy()
    OUTPUT_DIR.mkdir(exist_ok=True)
    articles, readers, claim_registry, simplification_ledger = load_data()

    summary_path = OUTPUT_DIR / "batch_summary.json"
    # Load existing summary if present
    if summary_path.exists():
        with open(summary_path, encoding="utf-8") as f:
            summary = json.load(f)
    else:
        summary = {}

    total = len(article_ids) * len(reader_ids)

    # Enumerate every (article, reader) pair up front, skipping pairs whose
    # result file already exists (resume support), then run the remainder
    # either serially or on a thread pool. One pair = one output JSON + one
    # summary entry; there is no cross-pair mutable state.
    pending: list[tuple[int, str, str]] = []
    done = 0
    for art_id in article_ids:
        if art_id not in articles:
            print(f"[SKIP] Article '{art_id}' not found in data file.")
            continue
        for r_id in reader_ids:
            done += 1
            if r_id not in readers:
                print(f"[{done}/{total}] SKIP — reader '{r_id}' not found.")
                continue
            if (OUTPUT_DIR / f"{art_id}_{r_id}.json").exists() and not force:
                print(f"[{done}/{total}] SKIP (already done): {art_id}_{r_id}")
                continue
            pending.append((done, art_id, r_id))

    def process_pair(idx: int, art_id: str, r_id: str) -> tuple[str, dict]:
        key = f"{art_id}_{r_id}"
        out_path = OUTPUT_DIR / f"{key}.json"
        article_text = articles[art_id]["Content"]
        article_title = articles[art_id].get("Title", art_id)
        print(f"\n[{idx}/{total}] Processing: article={art_id}  reader={r_id}")
        llm_client.start_call_recording(pair_id=key)
        t0 = time.time()

        try:
            result = process_article_for_reader(
                art_id,
                article_text,
                readers[r_id],
                claim_registry[art_id],
                simplification_ledger.get(art_id, {}),
                article_title=article_title,
                fidelity_policy=fidelity_policy,
                enable_repair=enable_repair,
                ecl_repair_rounds=ecl_repair_rounds,
                max_total_repair_attempts=max_total_repair_attempts,
                ecl_calibration_mode=ecl_calibration_mode,
            )
            elapsed = round(time.time() - t0, 1)
            calls = llm_client.collect_call_recording()
            api_calls = [c for c in calls if not c.get("local_cache_hit")]
            local_cache_hits = [c for c in calls if c.get("local_cache_hit")]
            stage_stats: dict[str, dict] = {}
            for call in calls:
                stage = str(call.get("stage", "unclassified"))
                bucket = stage_stats.setdefault(stage, {
                    "api_calls": 0,
                    "local_cache_hits": 0,
                    "prompt_tokens": 0,
                    "cache_hit_tokens": 0,
                    "completion_tokens": 0,
                    "seconds": 0.0,
                })
                if call.get("local_cache_hit"):
                    bucket["local_cache_hits"] += 1
                else:
                    bucket["api_calls"] += 1
                bucket["prompt_tokens"] += int(call.get("prompt_tokens") or 0)
                bucket["cache_hit_tokens"] += int(
                    call.get("cache_hit_tokens") or 0
                )
                bucket["completion_tokens"] += int(
                    call.get("completion_tokens") or 0
                )
                bucket["seconds"] += float(call.get("seconds") or 0.0)
            for bucket in stage_stats.values():
                bucket["seconds"] = round(bucket["seconds"], 1)
            llm_stats = {
                # Legacy fields are retained for downstream readers, but their
                # scope is now the complete pair including nested worker pools.
                "model": llm_client.MODEL,
                "thinking_mode": llm_client.THINKING_OVERRIDE or "auto",
                "calls_on_pair_thread": len(api_calls),
                "llm_seconds_on_pair_thread": round(
                    sum(float(c.get("seconds") or 0.0) for c in api_calls), 1
                ),
                "recording_scope": "pair_including_nested_threads",
                "api_calls_for_pair": len(api_calls),
                "local_artifact_cache_hits": len(local_cache_hits),
                "prompt_tokens": sum(
                    int(c.get("prompt_tokens") or 0) for c in api_calls
                ),
                "cache_hit_tokens": sum(
                    int(c.get("cache_hit_tokens") or 0) for c in api_calls
                ),
                "completion_tokens": sum(
                    int(c.get("completion_tokens") or 0) for c in api_calls
                ),
                "max_call_seconds": max(
                    (float(c.get("seconds") or 0.0) for c in api_calls),
                    default=0.0,
                ),
                "retries": sum(
                    1 for c in api_calls if int(c.get("attempt") or 0) > 0
                ),
                "by_stage": stage_stats,
            }

            output = {
                "article_id": art_id,
                "article_title": article_title,
                "reader_id": r_id,
                "reader_label": readers[r_id].get("label", ""),
                "timestamp": datetime.now().isoformat(),
                "elapsed_seconds": elapsed,
                "llm_call_stats": llm_stats,
                **result,
            }

            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(output, f, ensure_ascii=False, indent=2)

            print(
                f"  Done in {elapsed}s "
                f"(llm {llm_stats['calls_on_pair_thread']} calls / "
                f"{llm_stats['llm_seconds_on_pair_thread']}s, "
                f"max {llm_stats['max_call_seconds']}s) → {out_path.name}"
            )
            return key, {
                "article_id": art_id,
                "reader_id": r_id,
                "status": (
                    "done_output_release_ready" if result["release_ready"]
                    else "done_output_not_release_ready"
                ),
                "release_ready": result["release_ready"],
                "release_block_reasons": result["release_block_reasons"],
                "timestamp": output["timestamp"],
                "elapsed_seconds": elapsed,
                "llm_call_stats": llm_stats,
                "output_file": str(out_path.name),
                "fidelity_status": result["fidelity"]["status"],
                "fidelity_metrics": (
                    result["fidelity"].get("selected_validation") or {}
                ).get("metrics"),
                "repair_method": result.get("repair_method"),
                "ecl_status": result.get("ecl", {}).get("status"),
                "attempt_budget": result.get("repair", {}).get(
                    "attempt_budget"
                ),
            }

        except Exception as e:
            elapsed = round(time.time() - t0, 1)
            llm_client.collect_call_recording()
            print(f"  ERROR after {elapsed}s: {e}")
            traceback.print_exc()
            return key, {
                "article_id": art_id,
                "reader_id": r_id,
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
            }

    def record(entry: tuple[str, dict]) -> None:
        summary[entry[0]] = entry[1]
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

    if workers > 1 and len(pending) > 1:
        print(
            f"Running {len(pending)} of {total} pair(s) on {workers} workers..."
        )
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [
                pool.submit(process_pair, idx, art_id, r_id)
                for idx, art_id, r_id in pending
            ]
            for fut in as_completed(futures):
                record(fut.result())
    else:
        for idx, art_id, r_id in pending:
            record(process_pair(idx, art_id, r_id))

    print(f"\nAll done. Results in: {OUTPUT_DIR}")
    print(f"Summary: {summary_path}")


# ── CLI entry point ────────────────────────────────────────────────────────────

ALL_READER_IDS = [
    "P-L-E", "P-L-M", "P-L-X",
    "L-L-E", "L-L-M", "L-L-X",
    "U-L-E", "U-L-M", "U-L-X",
    "P-E-E", "P-E-M", "P-E-X",
    "L-E-E", "L-E-M", "L-E-X",
    "U-E-E", "U-E-M", "U-E-X",
]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Batch CLAP article adaptation")
    parser.add_argument(
        "--article", nargs="+", default=["A01"],
        help="Article ID(s) to process (default: A01)"
    )
    parser.add_argument(
        "--readers", nargs="+", default=ALL_READER_IDS,
        help="Reader ID(s) to process (default: all 18)"
    )
    parser.add_argument(
        "--repair-rounds", type=int, default=2,
        help="Maximum targeted repair rounds after initial validation (default: 2)",
    )
    parser.add_argument(
        "--min-core-recall", type=float, default=1.0,
        help="Hard-gate minimum fully preserved core-claim recall (default: 1.0)",
    )
    parser.add_argument(
        "--length-repair-rounds", type=int, default=1,
        help="Extra repair rounds reserved for a content-passing but over-length candidate (default: 1)",
    )
    parser.add_argument(
        "--no-repair", action="store_true",
        help="Disable validation/repair for an ablation run",
    )
    parser.add_argument(
        "--ecl-repair-rounds", type=int, default=1,
        help="Maximum guarded ECL structure repair rounds (default: 1)",
    )
    parser.add_argument(
        "--max-total-repair-attempts", type=int, default=3,
        help=(
            "Shared maximum repair proposals across fidelity/ICL/schema and ECL "
            "(default: 3)"
        ),
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Overwrite an existing result for the selected pair(s)",
    )
    parser.add_argument(
        "--ecl-calibration-mode", action="store_true",
        help=(
            "Read-only repeated v3.4-r4 scoring of ECL proposals rejected by the "
            "shared safety gate; never changes acceptance or released content"
        ),
    )
    parser.add_argument(
        "--workers", type=int, default=1,
        help="Number of (article, reader) pairs to process concurrently (default: 1)",
    )
    args = parser.parse_args()

    if not 0 <= args.min_core_recall <= 1:
        parser.error("--min-core-recall must be between 0 and 1")
    if args.workers < 1:
        parser.error("--workers must be >= 1")
    if (
        args.repair_rounds < 0
        or args.length_repair_rounds < 0
        or args.ecl_repair_rounds < 0
        or args.max_total_repair_attempts < 0
    ):
        parser.error("repair-round arguments must be non-negative")
    if args.ecl_repair_rounds > 1:
        parser.error("--ecl-repair-rounds is frozen at a maximum of 1")
    policy = FidelityPolicy(
        min_core_recall=args.min_core_recall,
        max_repair_rounds=args.repair_rounds,
        max_length_repair_rounds=args.length_repair_rounds,
    )
    run_batch(
        article_ids=args.article,
        reader_ids=args.readers,
        fidelity_policy=policy,
        enable_repair=not args.no_repair,
        ecl_repair_rounds=args.ecl_repair_rounds,
        max_total_repair_attempts=args.max_total_repair_attempts,
        ecl_calibration_mode=args.ecl_calibration_mode,
        force=args.force,
        workers=args.workers,
    )
