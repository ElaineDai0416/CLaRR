"""Claim-aware fidelity validation and targeted repair for CLaRR.

The module implements the validation--repair loop described in the method:

1. validate every source-derived core claim against the candidate;
2. distinguish faithful plain-language paraphrases from material changes;
3. identify the failed claim, immutable slot, and affected candidate span;
4. repair only the implicated spans and rerun the *full* validation;
5. return the best candidate and an auditable history if the retry limit is hit.

The LLM call is injected, which keeps this module independent of a specific API and
makes its control logic unit-testable without network access.
"""

from __future__ import annotations

import json
import re
import difflib
import hashlib
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Callable


# Optional v3 hook.  The default remains the original full three-module
# re-evaluation, so v1/v2 behavior is byte-for-byte unchanged unless a versioned
# entry point installs a callable here.
REPAIR_PROPOSAL_EVALUATOR = None

from il_fidelity import failed_il_spans, validate_il_compliance
from schema_support import (
    build_explanation_protection_contract,
    evaluate_schema_support,
    failed_schema_support_targets,
    failed_schema_support_spans,
)
from strategy_execution import (
    REPAIR_ALIGNMENT_MODE,
    build_repair_alignment_packet,
    build_strategy_realization_audit,
    render_repair_alignment_packet,
)

SHEMA_SUPPORT_ICL_CLAP_METHOD = "shema-support+ICL_CLAP"

SCHEMA_NONREGRESSION_SCORES = ("A_B", "A_Q", "P_gcl")
SCHEMA_HARD_GATE_KEYS = (
    "guidance_coverage_pass",
    "bridge_fit_pass",
    "grounding_boundary_pass",
    "analogy_semantic_pass",
    "narrative_mapping_pass",
    "analogy_complexity_pass",
    "necessary_explanations_pass",
    "analogy_fallback_pass",
)


FULLY_PRESERVED = {
    "entailed_exact",
    "entailed_via_approved_simplification",
}
VALID_VERDICTS = FULLY_PRESERVED | {
    "partial_coverage",
    "omitted",
    "material_alteration",
    "contradicted",
}
MATERIAL_FAILURES = {"material_alteration", "contradicted"}

# Only high-precision values receive a deterministic surface-form backstop.  Other
# slots (relations, causality, scope, modality, conditions, comparisons, etc.) are
# semantic obligations and must not be rejected merely because a faithful rewrite
# changes their wording.
LEXICAL_ANCHOR_SLOT_TYPES = {"entity", "quantity", "unit", "date"}


@dataclass(frozen=True)
class FidelityPolicy:
    """Pre-registered decision policy for the hard fidelity gate."""

    min_core_recall: float = 1.0
    require_all_critical: bool = True
    max_material_failures: int = 0
    max_unsupported_claims: int = 0
    max_repair_rounds: int = 2
    max_length_repair_rounds: int = 1
    max_style_repair_rounds: int = 1
    max_redundancy_cleanup_rounds: int = 1
    max_schema_support_repair_rounds: int = 1
    max_total_repair_attempts: int = 3
    max_patch_plan_attempts_per_round: int = 2
    use_adversarial_double_check: bool = True
    min_initial_token_retention: float = 0.70
    min_non_target_token_retention: float = 0.90
    require_all_protected_paragraphs: bool = True
    reader_style_margin: int = 1
    max_patches_per_round: int = 4
    max_patch_replacement_words: int = 32
    max_patch_growth_words: int = 16
    max_short_gloss_words: int = 12
    max_total_patches: int = 6
    max_total_replacement_words: int = 96
    max_total_changed_words: int = 120
    min_schema_support_score: float = 0.70
    min_schema_bridging_score: float = 0.70
    min_cognitive_guidance_score: float = 0.70
    integrate_schema_support_into_content_il: bool = True

    def __post_init__(self) -> None:
        for field_name in (
            "max_repair_rounds", "max_length_repair_rounds",
            "max_style_repair_rounds", "max_redundancy_cleanup_rounds",
            "max_schema_support_repair_rounds", "max_total_repair_attempts",
            "max_patch_plan_attempts_per_round",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError(f"{field_name} must be a non-negative integer")
        if self.max_patch_plan_attempts_per_round == 0:
            raise ValueError("max_patch_plan_attempts_per_round must be at least 1")
        if not isinstance(self.integrate_schema_support_into_content_il, bool):
            raise ValueError("integrate_schema_support_into_content_il must be boolean")


REPAIR_KINDS = (
    "redundancy_cleanup",
    "content_and_il",
    "schema_support",
    "length",
    "minimal_edit_and_style",
)


def introduced_sentence_repetitions(
    before: str,
    after: str,
    *,
    minimum_tokens: int = 8,
) -> list[str]:
    """Return substantive exact sentence repetitions introduced by a patch.

    Repair is local and must not copy an already-present claim sentence into a
    second location.  Short discourse fragments are ignored to avoid false alarms.
    """
    def entries(value: str) -> list[tuple[str, str, set[str]]]:
        found: list[tuple[str, str, set[str]]] = []
        for sentence in re.split(r"(?<=[.!?])\s+", str(value).strip()):
            display = sentence.strip()
            normalized = " ".join(re.findall(r"[a-z0-9]+", display.lower()))
            if len(normalized.split()) < minimum_tokens:
                continue
            found.append((normalized, display, set(normalized.split())))
        return found

    def duplicate_pairs(
        values: list[tuple[str, str, set[str]]]
    ) -> list[tuple[int, int]]:
        pairs = []
        for right in range(1, len(values)):
            for left in range(right):
                left_tokens = values[left][2]
                right_tokens = values[right][2]
                union = left_tokens | right_tokens
                similarity = len(left_tokens & right_tokens) / len(union) if union else 0.0
                if similarity >= 0.9:
                    pairs.append((left, right))
        return pairs

    previous = entries(before)
    current = entries(after)
    extra_pair_count = len(duplicate_pairs(current)) - len(duplicate_pairs(previous))
    if extra_pair_count <= 0:
        return []
    current_pairs = duplicate_pairs(current)
    return list(dict.fromkeys(
        current[right][1] for _, right in current_pairs[-extra_pair_count:]
    ))


def repair_budget(policy: FidelityPolicy) -> dict[str, int]:
    """Return the predeclared maximum number of attempts for each repair kind."""
    return {
        "content_and_il": policy.max_repair_rounds,
        "length": policy.max_length_repair_rounds,
        "minimal_edit_and_style": policy.max_style_repair_rounds,
        "redundancy_cleanup": policy.max_redundancy_cleanup_rounds,
        "schema_support": policy.max_schema_support_repair_rounds,
    }


def repair_usage_summary(
    policy: FidelityPolicy,
    patch_history: list[dict[str, Any]],
) -> dict[str, Any]:
    """Distinguish strategy rounds from actual repair-planner attempts.

    Every call that asks the repair model for a patch plan consumes one attempt,
    including a malformed or rejected response. Strategy-round counters remain
    observable but do not define the shared external-call budget.
    """
    budget = repair_budget(policy)
    attempted = {kind: 0 for kind in REPAIR_KINDS}
    accepted = {kind: 0 for kind in REPAIR_KINDS}
    for item in patch_history:
        kind = str(item.get("repair_kind", ""))
        if kind not in attempted:
            continue
        attempted[kind] += 1
        if item.get("accepted"):
            accepted[kind] += 1
    total_attempt_limit = policy.max_total_repair_attempts
    planner_calls = sum(
        int(item["patch_plan_calls"])
        if "patch_plan_calls" in item else (
            int(item.get("attempt", 1)) if item.get("accepted")
            else max(1, len(item.get("errors", [])))
        )
        for item in patch_history
    )
    strategy_rounds_attempted = sum(attempted.values())
    return {
        "budget": budget,
        "attempted_by_kind": attempted,
        "accepted_by_kind": accepted,
        "remaining_by_kind": {
            kind: max(0, budget[kind] - attempted[kind]) for kind in REPAIR_KINDS
        },
        "total_attempt_limit": total_attempt_limit,
        "strategy_rounds_attempted": strategy_rounds_attempted,
        "total_attempts": planner_calls,
        "total_attempts_remaining": max(0, total_attempt_limit - planner_calls),
        "total_accepted": sum(accepted.values()),
        "patch_plan_attempts_per_round_limit": policy.max_patch_plan_attempts_per_round,
        "patch_plan_calls": planner_calls,
        "patch_plan_call_limit": total_attempt_limit,
    }


def select_repair_strategy(
    controls: dict[str, bool],
    il_evaluation: dict[str, Any] | None,
    attempted_by_kind: dict[str, int],
    policy: FidelityPolicy,
) -> dict[str, Any]:
    """Select the next repair kind using a fixed, auditable priority order."""
    if not controls.get("cumulative_patch_burden_pass", True):
        return {
            "repair_kind": "", "triggered_by": ["cumulative_patch_burden"],
            "attempts_used_before": sum(
                int(attempted_by_kind.get(kind, 0)) for kind in REPAIR_KINDS
            ),
            "budget_limit": policy.max_total_repair_attempts,
            "remaining_before": 0, "exhausted_triggered_kinds": [],
            "stopped_reason": "cumulative_patch_burden_exceeded_fail_closed",
        }
    il_metrics = (il_evaluation or {}).get("metrics", {})
    cleanup_flags = (
        int(il_metrics.get("n_redundant_introduced_propositions", 0))
        + int(il_metrics.get("n_excessive_supported_details", 0))
    )
    joint_schema_failure = bool(
        policy.integrate_schema_support_into_content_il
        and not controls["schema_support_pass"]
    )
    candidates = [
        (
            "redundancy_cleanup",
            bool(controls["fidelity_pass"] and cleanup_flags > 0),
            ["redundant_or_excessive_explanation"],
        ),
        (
            "content_and_il",
            bool(
                not controls["fidelity_pass"]
                or not controls["il_strategy_pass"]
                or joint_schema_failure
            ),
            [
                key for key, failed in (
                    ("claim_or_il_semantics", not controls["fidelity_pass"]),
                    ("il_strategy", not controls["il_strategy_pass"]),
                    ("schema_support", joint_schema_failure),
                ) if failed
            ],
        ),
        (
            "schema_support",
            bool(
                not policy.integrate_schema_support_into_content_il
                and controls["fidelity_pass"] and controls["il_strategy_pass"]
                and not controls["schema_support_pass"]
            ),
            ["schema_support"],
        ),
        (
            "length",
            bool(controls["fidelity_pass"] and not controls["length_pass"]),
            ["length"],
        ),
        (
            "minimal_edit_and_style",
            bool(
                controls["fidelity_pass"]
                and controls["il_strategy_pass"]
                and controls["schema_support_pass"]
                and controls["length_pass"]
                and not controls["overall_pass"]
            ),
            [
                key for key in (
                    "minimal_edit_pass", "protected_paragraphs_pass",
                    "passing_claim_sentences_pass",
                    "reader_style_noninferiority_pass",
                ) if not controls.get(key, True)
            ],
        ),
    ]
    budget = repair_budget(policy)
    total_used = sum(int(attempted_by_kind.get(kind, 0)) for kind in REPAIR_KINDS)
    total_limit = min(sum(budget.values()), policy.max_total_repair_attempts)
    if total_used >= total_limit:
        return {
            "repair_kind": "", "triggered_by": [],
            "attempts_used_before": total_used, "budget_limit": total_limit,
            "remaining_before": 0, "exhausted_triggered_kinds": [],
            "stopped_reason": "total_repair_budget_exhausted",
        }
    exhausted: list[str] = []
    for kind, triggered, reasons in candidates:
        if not triggered:
            continue
        used = int(attempted_by_kind.get(kind, 0))
        if used >= budget[kind]:
            exhausted.append(kind)
            continue
        return {
            "repair_kind": kind,
            "triggered_by": reasons,
            "attempts_used_before": used,
            "budget_limit": budget[kind],
            "remaining_before": budget[kind] - used,
            "exhausted_triggered_kinds": exhausted,
            "stopped_reason": "",
        }
    triggered_kinds = [kind for kind, triggered, _ in candidates if triggered]
    return {
        "repair_kind": "",
        "triggered_by": [],
        "attempts_used_before": 0,
        "budget_limit": 0,
        "remaining_before": 0,
        "exhausted_triggered_kinds": exhausted,
        "stopped_reason": (
            "triggered_repair_budgets_exhausted" if triggered_kinds
            else "no_applicable_repair_strategy"
        ),
    }


def _json_object(raw: str) -> dict[str, Any]:
    """Parse a JSON object from a model response, tolerating markdown fences."""
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", raw)
        if not match:
            raise ValueError("LLM response did not contain a JSON object")
        value = json.loads(match.group())
    if not isinstance(value, dict):
        raise ValueError("LLM response JSON must be an object")
    return value


def normalize_patch_rejection(message: str) -> dict[str, str]:
    """Turn a deterministic patch rejection into a compact retry instruction."""
    text = str(message)
    rules = (
        ("PASSING_CLAIM_ANCHOR_LOSS", "claim anchor"),
        ("PASSING_CLAIM_ANCHOR_LOSS", "claim anchors"),
        ("INSTRUCTION_SCOPE_MISMATCH", "instruction_scope"),
        ("STALE_PACKET", "packet_id"),
        ("SCOPE_MISMATCH", "strategy_scope_id"),
        ("MISSING_INSTRUCTION", "instruction_id"),
        ("NONEXACT_SOURCE_EVIDENCE", "source_evidence"),
        ("NONUNIQUE_ANCHOR", "anchor_sentence"),
        ("PROTECTED_CONTENT", "protected"),
        ("TARGET_SCOPE", "target_span"),
        ("PATCH_BURDEN", "burden"),
        ("NONREGRESSION", "non-regression"),
        ("NO_TARGET_IMPROVEMENT", "improve"),
    )
    lowered = text.lower()
    error_code = "INVALID_PATCH_RESPONSE"
    field = "response"
    for code, marker in rules:
        if marker.lower() in lowered:
            error_code = code
            field = marker
            break
    required_correction = (
        "keep the same packet and selected instructions; correct only the rejected field"
    )
    if error_code == "PASSING_CLAIM_ANCHOR_LOSS":
        anchors = re.findall(r"\[([^\]]+)\]", text)
        instruction_match = re.search(
            r"instruction_ids\s+([^:]+):", text
        )
        instruction_label = (
            instruction_match.group(1).strip() if instruction_match else "the rejected patch"
        )
        required_correction = (
            f"edit replacement_text for {instruction_label} so it retains these exact "
            "passing-claim anchors: " + ", ".join(anchors)
        )
    return {
        "error_code": error_code,
        "field": field,
        "message": text[:1200],
        "required_correction": required_correction,
    }


def attach_repair_alignment_scope(
    packet: dict[str, Any],
    candidate: str,
    explanation_protection_contract: dict[str, Any] | None,
    claim_contract: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Attach target-specific anchor and protection allow-lists without an LLM call."""
    def overlaps(left: int, right: int, other_left: int, other_right: int) -> bool:
        return left < other_right and other_left < right

    scoped = deepcopy(packet)
    sentence_values = [
        value for _, _, value in _sentence_spans(candidate)
        if candidate.count(value) == 1
    ]
    protection = explanation_protection_contract or {}
    protected_entries: list[dict[str, Any]] = []
    active_target_ids = scoped.get("active_target_ids", {}) or {}
    active_failed_term_ids = {
        str(value) for value in active_target_ids.get("il", []) if str(value)
    }
    active_failed_support_ids = {
        str(value) for value in active_target_ids.get("schema", []) if str(value)
    }
    for group, span_keys in (
        ("explanations", ("protected_explanation_span",)),
        ("knowledge_bridges", ("protected_bridge_span",)),
        ("guidance_strategies", ("protected_guidance_span",)),
        ("analogies", ("protected_analogy_span",)),
    ):
        for item in protection.get(group, []) or []:
            span = next(
                (
                    str(item.get(key, "")).strip()
                    for key in span_keys if str(item.get(key, "")).strip()
                ),
                "",
            )
            if span:
                protected_entries.append({**item, "span": span})

    blocked: list[str] = list(scoped.get("blocked_instruction_ids", []))
    instruction_ranges: dict[str, list[tuple[int, int]]] = {}
    unique_claim_anchors = _unique_claim_ngrams(claim_contract or [])
    normalized_candidate = " ".join(
        re.findall(r"\b\w+(?:[-']\w+)*\b", candidate.lower())
    )
    for instruction in scoped.get("instructions", []):
        target_spans = [
            str(value) for value in instruction.get("target_spans", []) if str(value)
        ]
        allowed_anchors: list[str] = []
        target_ranges: list[tuple[int, int]] = []
        for target in target_spans:
            target_ranges.extend(_surface_equivalent_ranges(candidate, target))
        instruction_ranges[str(instruction.get("instruction_id", ""))] = target_ranges
        for start, end, sentence in _sentence_spans(candidate):
            if candidate.count(sentence) != 1:
                continue
            if any(overlaps(start, end, left, right) for left, right in target_ranges):
                allowed_anchors.append(sentence)
        if not target_spans and instruction.get("required_action") in {
            "insert_missing_claim", "shorten_without_strategy_or_claim_regression",
        }:
            allowed_anchors = sentence_values
        instruction["allowed_anchor_sentences"] = list(dict.fromkeys(allowed_anchors))

        required_term_ids: set[str] = set()
        required_support_ids: set[str] = set()
        for protected in protected_entries:
            protected_ranges = _surface_equivalent_ranges(
                candidate, str(protected["span"])
            )
            if not any(
                overlaps(left, right, p_left, p_right)
                for left, right in target_ranges
                for p_left, p_right in protected_ranges
            ):
                continue
            term_id = str(protected.get("term_id", "")).strip()
            support_id = str(protected.get("support_id", "")).strip()
            if term_id and term_id not in active_failed_term_ids:
                required_term_ids.add(term_id)
            if support_id and support_id not in active_failed_support_ids:
                required_support_ids.add(support_id)
            required_support_ids.update(
                str(value).strip()
                for value in protected.get("linked_support_ids", [])
                if str(value).strip()
                and str(value).strip() not in active_failed_support_ids
            )
        instruction["required_protected_term_ids"] = sorted(required_term_ids)
        instruction["required_protected_support_ids"] = sorted(required_support_ids)
        if required_term_ids or required_support_ids:
            instruction["allowed_operations"] = [
                value for value in instruction.get("allowed_operations", [])
                if value != "delete_within_sentence"
            ]
            instruction["protected_target_action"] = (
                "replace locally and preserve an information-equivalent form of every "
                "required passing strategy; deletion is not allowed"
            )
        normalized_targets = [
            " ".join(re.findall(r"\b\w+(?:[-']\w+)*\b", value.lower()))
            for value in target_spans
        ]
        required_claim_anchors: list[dict[str, str]] = []
        replaceable_source_anchor = ""
        if (
            instruction.get("module") == "icl"
            and instruction.get("required_action") in {
                "replace_with_familiar_equivalent",
                "replace_with_approved_familiar_form",
            }
        ):
            # A passing claim protects its proposition, but it must not freeze the
            # exact jargon surface that this ICL instruction is explicitly allowed
            # to replace.  Other unique claim n-grams inside the same target remain
            # protected and the post-patch claim validator still checks equivalence.
            replaceable_source_anchor = " ".join(re.findall(
                r"\b\w+(?:[-']\w+)*\b",
                str(instruction.get("source_anchor", "")).lower(),
            ))
        for claim_id, anchors in unique_claim_anchors.items():
            matches = sorted(
                {
                    anchor for anchor in anchors
                    if any(anchor in target for target in normalized_targets)
                    and anchor != replaceable_source_anchor
                    and normalized_candidate.count(anchor) == 1
                },
                key=lambda value: (-len(value.split()), value),
            )
            if matches:
                required_claim_anchors.append({
                    "claim_id": claim_id,
                    "anchor": matches[0],
                })
        instruction["required_preserved_claim_anchors"] = required_claim_anchors
        if not instruction["allowed_anchor_sentences"]:
            instruction["executable"] = False
            instruction["blocked_reason"] = "missing_unique_target_anchor"
            blocked.append(str(instruction.get("instruction_id", "")))

    instructions = scoped.get("instructions", [])
    for instruction in instructions:
        instruction_id = str(instruction.get("instruction_id", ""))
        ranges = instruction_ranges.get(instruction_id, [])
        instruction_anchors = set(instruction.get("allowed_anchor_sentences", []))
        compatible: list[str] = []
        for other in instructions:
            other_id = str(other.get("instruction_id", ""))
            if not other_id or other_id == instruction_id:
                continue
            other_ranges = instruction_ranges.get(other_id, [])
            ranges_overlap = any(
                overlaps(left, right, other_left, other_right)
                for left, right in ranges
                for other_left, other_right in other_ranges
            )
            same_sentence_icl = bool(
                instruction.get("module") == "icl"
                and other.get("module") == "icl"
                and instruction_anchors.intersection(
                    other.get("allowed_anchor_sentences", [])
                )
            )
            if ranges_overlap or same_sentence_icl:
                compatible.append(other_id)
        instruction["compatible_composite_instruction_ids"] = compatible

    scoped["blocked_instruction_ids"] = list(dict.fromkeys(blocked))
    scoped["scope_ready"] = not any(
        not instruction.get("executable", True)
        for instruction in scoped.get("instructions", [])
    )
    return scoped


def _string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def _json_llm_response(
    llm_call: Callable[..., str],
    prompt: str,
    max_tokens: int,
) -> str:
    """Request provider JSON mode while retaining compatibility with test doubles."""
    try:
        return llm_call(
            prompt,
            max_tokens=max_tokens,
            temperature=0,
            response_format={"type": "json_object"},
        )
    except TypeError as exc:
        if "response_format" not in str(exc):
            raise
        return llm_call(prompt, max_tokens=max_tokens, temperature=0)


def _unsupported_severity(item: dict[str, Any]) -> str:
    """Apply a conservative consistency check to the verifier's severity label.

    A model sometimes labels an addition as nonmaterial while its own explanation
    says the source lacks a new mechanism or causal relation.  Such a response is
    internally inconsistent.  Treat it as material: the repair loop may make one
    extra edit, but an unsupported scientific mechanism cannot silently pass.
    """
    severity = str(item.get("severity", "material")).lower()
    if severity not in {"material", "nonmaterial"}:
        severity = "material"
    reason = str(item.get("reason", "")).lower()
    candidate_span = str(item.get("candidate_span", "")).lower()
    missing_source = any(
        marker in reason
        for marker in (
            "does not explain", "does not state", "does not support", "not stated",
            "not explicitly", "not present", "not in the source", "unstated",
        )
    )
    material_topic = any(
        marker in reason
        for marker in (
            "mechanism", "causal", "caus", "risk factor", "number", "unit",
            "condition", "scope", "population", "comparison", "time relation",
            "leads to", "inference", "entity", "agency", "organizational role",
            "institutional role", "creator", "created", "outcome", "assurance",
            "enforcement", "checks", "checking", "checked", "before problems",
            "example", "application", "identity", "function",
        )
    )
    assertive_assurance = any(
        marker in candidate_span
        for marker in (
            "makes sure", "make sure", "ensure that", "ensures that",
            "guarantee", "guarantees", "prevent harm", "prevents harm",
            "before problems reach", "gets checked", "is checked",
            "who checks",
        )
    )
    if severity == "nonmaterial" and (assertive_assurance or (missing_source and material_topic)):
        return "material"
    return severity


def _source_evidence(article_record: dict[str, Any], claim: dict[str, Any]) -> list[str]:
    sentence_index = {
        item.get("id"): item.get("text", "")
        for item in article_record.get("sentences", [])
    }
    return [
        sentence_index[sid]
        for sid in claim.get("evidence_sentence_ids", [])
        if sentence_index.get(sid)
    ]


def normalize_claim_contract(
    article_record: dict[str, Any],
    simplification_ledger: dict[str, list[dict[str, str]]] | None = None,
) -> list[dict[str, Any]]:
    """Convert the existing source claim registry into a repair contract.

    The original registry already contains source-grounded propositions and slot
    types.  This function enriches it with exact evidence and a human-editable
    simplification ledger; no new factual content is inferred here.
    """
    ledger = simplification_ledger or {}
    contract: list[dict[str, Any]] = []
    for claim in article_record.get("claims", []):
        item = deepcopy(claim)
        item["canonical_proposition"] = item.pop("claim_text", "")
        item["immutable_slots"] = item.pop("slots_to_preserve", [])
        item["source_evidence"] = _source_evidence(article_record, claim)
        item["approved_simplifications"] = [
            x
            for x in ledger.get(item.get("claim_id", ""), [])
            if x.get("approved", True)
        ]
        item.setdefault("compressible_evidence_details", [])
        contract.append(item)
    return contract


def compact_contract(contract: list[dict[str, Any]]) -> str:
    """Render the claim contract for generation, validation, and repair prompts."""
    blocks: list[str] = []
    for claim in contract:
        substitutions = claim.get("approved_simplifications", [])
        sub_text = "; ".join(
            f"{x.get('source_form', '')} -> {x.get('allowed_form', '')}"
            for x in substitutions
        ) or "none pre-approved"
        evidence = " | ".join(claim.get("source_evidence", []))
        slot_values = claim.get("immutable_slot_values", [])
        slot_value_text = "; ".join(
            f"{value.get('slot_type', '')}={value.get('value', '')}"
            for value in slot_values
            if isinstance(value, dict) and value.get("value")
        ) or "recover from canonical proposition and source evidence"
        blocks.append(
            f"[{claim['claim_id']}] tier={claim.get('tier', 'core')}\n"
            f"proposition: {claim.get('canonical_proposition', '')}\n"
            f"immutable slot types: {', '.join(claim.get('immutable_slots', []))}\n"
            f"immutable slot values: {slot_value_text}\n"
            f"source evidence: {evidence}\n"
            f"approved simplifications: {sub_text}"
        )
    return "\n\n".join(blocks)


def generation_guardrail(contract: list[dict[str, Any]]) -> str:
    """Content rules embedded in both initial generation and condensing prompts."""
    return f"""### SOURCE-DERIVED FIDELITY CONTRACT (higher priority than term pruning)
Every proposition below must remain recoverable from the rewrite. Preserve its
entities, numbers/units, negation, modality, comparison, causal direction, scope,
population, time, and conditions whenever present.

Plain-language explanation is encouraged, but every listed immutable slot value is a
lexical anchor: keep that source term/value in the rewrite unless the claim ledger
explicitly approves a replacement. For an unfamiliar anchor, retain it once and add
a short familiar explanation immediately beside it; do not replace `trustworthiness`
with only `safety` or `reliability`, for example. Numerical/unit conversion is allowed
only when it appears under that claim's approved simplifications. A term may be
pruned, but the proposition containing it may not be pruned. If space is tight,
shorten hooks, analogies, recommendations, formatting, and repeated explanations
before removing source facts.

Use only the supplied source for factual content. Do not add background facts about
named people or organizations, assign them roles not stated in the source, or turn
voluntary guidance into an assurance, enforcement, checking, prevention, or realized
outcome. An analogy is allowed only when it cannot reasonably be read as asserting
such a new fact. Each contract entry is a distinct proposition: preserving a nearby
or topically similar entry never substitutes for its own relation, purpose, object,
or immutable slots.
Do not invent concrete applications, harms, people, institutions, or scenarios that
are absent from the source. If the source has no example, explain its abstract terms
directly instead of creating a hypothetical example.

{compact_contract(contract)}"""


def validation_prompt(
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
) -> str:
    """Build the full claim-coverage and unsupported-fact validation prompt."""
    return f"""You are a conservative fidelity verifier for reader-adapted rewriting.
Compare the candidate only with the supplied source and source-derived claim
contract. Do not reward readability and do not use outside knowledge.

VALIDATION RULES
1. Judge semantic content, not exact wording. A familiar-word paraphrase is valid
   if it preserves the proposition and every immutable fact slot.
   Treat every contract row as deliberately distinct. Audit its subject, main
   relation, purpose, object, modality, and slot values independently. Coverage of
   a neighboring or topically similar claim is not evidence for this claim. A span
   may support two claims only if it independently expresses both relations.
2. Use `entailed_via_approved_simplification` only for a transformation explicitly
   listed in the ledger. Ordinary wording changes with unchanged values count as
   `entailed_exact`.
3. `partial_coverage`: the main relation is recoverable, but a required list member,
   scope, condition, comparison target, causal link, number, or other slot is absent.
4. `omitted`: the main proposition is not recoverable.
5. `material_alteration`: the candidate mentions the topic but changes a number,
   unit, entity, polarity, modality, causal direction, comparison, scope, condition,
   population, or time.
6. `contradicted`: the candidate asserts the opposite of the source.
7. Classify every candidate addition that deserves attention as either:
   - `material`: it introduces or changes a factual entity, number/unit, condition,
     scope, population, causal/mechanistic relation, comparison, polarity, modality,
     time relation, institutional role, creator attribution, operational process,
     assurance, enforcement, prevention, checking behavior, or realized outcome.
     This blocks the hard gate. A comparison or analogy is still material when it
     implies one of these factual roles or outcomes.
   - `nonmaterial`: rhetoric, a reader-facing transition, an evaluative adjective,
     or a wording-level restatement that does not change any fact slot. This is
     logged for review but MUST NOT block the hard gate or trigger repair.
   Do not list purely rhetorical analogies, generic navigation, ordinary semantic
   paraphrases, or reader-addressed framing as material facts. However, calling an
   organization "like" another regulator, saying it checks products, or promising
   that harms are prevented is factual despite the analogy or second-person style.
   Questions and hooks can also assert or presuppose facts: wording such as "who
   makes sure", "ensures", "guarantees", "prevents", or "gets checked" is material
   unless the source supports that assurance or operational process.
   A more specific claim than the source is material even if plausible or true by
   outside knowledge.
8. For each listed addition, quote the candidate span and the closest source span.
   If the closest source span supports the candidate proposition, classify it as
   `nonmaterial` or omit it; never call it a material unsupported claim.
9. For every non-preserved claim, identify failed slots and quote the shortest
   implicated candidate span. Never invent a span when the claim is absent.
10. Before assigning a preserved verdict, explicitly verify that the candidate span
    states the claim's own main relation and every listed immutable value. If any
    required value or relation must be supplied from the source rather than recovered
    from the candidate, use `partial_coverage` or `omitted`.

Return valid JSON only:
{{
  "assessments": [
    {{
      "claim_id": "...",
      "verdict": "entailed_exact|entailed_via_approved_simplification|partial_coverage|omitted|material_alteration|contradicted",
      "failed_slots": ["..."],
      "candidate_span": "...",
      "reason": "one concise source-grounded explanation"
    }}
  ],
  "unsupported_claims": [
    {{
      "candidate_span": "...",
      "severity": "material|nonmaterial",
      "closest_source_span": "...",
      "reason": "why the source does or does not support it"
    }}
  ]
}}

SOURCE ARTICLE
{source_text}

CLAIM CONTRACT
{compact_contract(contract)}

CANDIDATE REWRITE
{candidate}"""


def adversarial_validation_prompt(
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
) -> str:
    """Build an independent second-pass prompt that tries to falsify preservation.

    The first verifier is comprehensive.  This pass is deliberately asymmetric: it
    looks for false-positive entailment, conflation of neighboring claims, and facts
    hidden inside hooks or analogies.  The two outputs are merged conservatively.
    """
    return f"""You are a conservative fidelity verifier performing an adversarial
second check. Use only the source and claim contract. Your job is to find errors the
first verifier could miss; do not assume a fluent or related sentence entails a claim.

For every contract entry, independently test:
1. Does the candidate explicitly or unambiguously express this claim's own subject,
   main relation, purpose, and object?
2. Does it preserve every immutable value and complete list member?
3. Is the supporting candidate span actually about this claim, rather than a nearby
   claim with the same entities or topic?

Use `partial_coverage` when the main relation is recoverable but any required value is
missing; use `omitted` when the claim's own relation or purpose is absent. Treat factual
presuppositions in questions, hooks, comparisons, and analogies as material additions.
Institutional roles, creator attributions, examples of real-world applications,
checking/enforcement behavior, safety assurances, prevention promises, and realized
outcomes are material unless the source states them. Do not use outside knowledge.

Return valid JSON only using exactly this schema:
{{
  "assessments": [{{"claim_id":"...","verdict":"entailed_exact|entailed_via_approved_simplification|partial_coverage|omitted|material_alteration|contradicted","failed_slots":[],"candidate_span":"","reason":""}}],
  "unsupported_claims": [{{"candidate_span":"...","severity":"material|nonmaterial","closest_source_span":"...","reason":""}}]
}}

SOURCE ARTICLE
{source_text}

CLAIM CONTRACT
{compact_contract(contract)}

CANDIDATE REWRITE
{candidate}"""


def normalize_validation(
    raw_result: dict[str, Any], contract: list[dict[str, Any]]
) -> dict[str, Any]:
    """Make model output total, ordered, and safe for deterministic scoring."""
    by_id = {
        str(x.get("claim_id", "")): x
        for x in raw_result.get("assessments", [])
        if isinstance(x, dict)
    }
    assessments: list[dict[str, Any]] = []
    for claim in contract:
        claim_id = claim["claim_id"]
        found = by_id.get(claim_id, {})
        verdict = str(found.get("verdict", "omitted")).strip().lower()
        if verdict not in VALID_VERDICTS:
            verdict = "omitted"
        assessments.append({
            "claim_id": claim_id,
            "tier": claim.get("tier", "core"),
            "canonical_proposition": claim.get("canonical_proposition", ""),
            "verdict": verdict,
            "failed_slots": _string_list(found.get("failed_slots")),
            "candidate_span": str(found.get("candidate_span", "")),
            "reason": str(found.get("reason", "")),
        })

    unsupported = []
    for item in raw_result.get("unsupported_claims", []):
        if isinstance(item, dict) and item.get("candidate_span"):
            unsupported.append({
                "candidate_span": str(item.get("candidate_span", "")),
                "severity": _unsupported_severity(item),
                "closest_source_span": str(item.get("closest_source_span", "")),
                "reason": str(item.get("reason", "")),
            })
    return {"assessments": assessments, "unsupported_claims": unsupported}


VERDICT_SEVERITY = {
    "entailed_exact": 0,
    "entailed_via_approved_simplification": 0,
    "partial_coverage": 1,
    "omitted": 2,
    "material_alteration": 3,
    "contradicted": 4,
}


def merge_validation_results(
    primary: dict[str, Any], adversarial: dict[str, Any]
) -> dict[str, Any]:
    """Conservatively merge two total, normalized fidelity judgments."""
    second = {item["claim_id"]: item for item in adversarial["assessments"]}
    assessments: list[dict[str, Any]] = []
    for first in primary["assessments"]:
        other = second[first["claim_id"]]
        first_rank = VERDICT_SEVERITY[first["verdict"]]
        other_rank = VERDICT_SEVERITY[other["verdict"]]
        chosen = first if first_rank >= other_rank else other
        merged = deepcopy(chosen)
        merged["failed_slots"] = list(dict.fromkeys(
            _string_list(first.get("failed_slots"))
            + _string_list(other.get("failed_slots"))
        ))
        reasons = [
            value for value in (str(first.get("reason", "")).strip(), str(other.get("reason", "")).strip())
            if value
        ]
        merged["reason"] = " | adversarial check: ".join(dict.fromkeys(reasons))
        merged["verifier_disagreement"] = first["verdict"] != other["verdict"]
        assessments.append(merged)

    unsupported_by_span: dict[str, dict[str, Any]] = {}
    for item in primary.get("unsupported_claims", []) + adversarial.get("unsupported_claims", []):
        key = re.sub(r"\s+", " ", str(item.get("candidate_span", "")).strip().lower())
        if not key:
            continue
        existing = unsupported_by_span.get(key)
        if existing is None or (
            existing.get("severity") != "material" and item.get("severity") == "material"
        ):
            unsupported_by_span[key] = deepcopy(item)
    return {
        "assessments": assessments,
        "unsupported_claims": list(unsupported_by_span.values()),
        "double_checked": True,
    }


def _normalized_phrase(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", value.lower()))


def _surface_equivalent_ranges(text: str, value: str) -> list[tuple[int, int]]:
    """Locate judge spans despite harmless Markdown/quote normalization.

    Evaluators occasionally omit emphasis markers or normalize straight/curly
    quotation marks while still returning the correct candidate span.  Repair
    authorization remains range-based: this helper maps the normalized match back
    to exact offsets in the unchanged candidate and never invents a fuzzy semantic
    match.
    """
    quote_chars = {'"', "'", "“", "”", "‘", "’"}

    def normalized_with_positions(source: str) -> tuple[str, list[int]]:
        chars: list[str] = []
        positions: list[int] = []
        previous_space = False
        for index, char in enumerate(source):
            if char in {"*", "_", "`"}:
                continue
            if char.isspace():
                if previous_space:
                    continue
                chars.append(" ")
                positions.append(index)
                previous_space = True
                continue
            previous_space = False
            chars.append("'" if char in quote_chars else char.lower())
            positions.append(index)
        while chars and chars[0] == " ":
            chars.pop(0)
            positions.pop(0)
        while chars and chars[-1] == " ":
            chars.pop()
            positions.pop()
        return "".join(chars), positions

    normalized_text, positions = normalized_with_positions(text)
    normalized_value, _ = normalized_with_positions(value)
    if not normalized_value or not normalized_text or not positions:
        return []
    ranges: list[tuple[int, int]] = []
    cursor = 0
    while True:
        start = normalized_text.find(normalized_value, cursor)
        if start < 0:
            break
        end_index = start + len(normalized_value) - 1
        if end_index < len(positions):
            ranges.append((positions[start], positions[end_index] + 1))
        cursor = start + 1
    return ranges


def _claim_context(candidate: str, span: str) -> str:
    """Return the paragraph containing a localized span, or the span itself."""
    for paragraph in re.split(r"\n\s*\n", candidate):
        if span and span in paragraph:
            return paragraph
    return span


def apply_lexical_anchor_checks(
    result: dict[str, Any],
    candidate: str,
    contract: list[dict[str, Any]],
) -> dict[str, Any]:
    """Downgrade false-positive entailment when frozen lexical anchors disappear.

    High-precision entity/quantity/unit/date anchors receive a surface-form check.
    Relational slots are deliberately left to the semantic double-check, because
    requiring their frozen descriptive labels verbatim rejects faithful paraphrases.
    Entity anchors may occur anywhere in the article to avoid repetitive naming.
    Replacements are accepted only when the frozen claim ledger approves them.
    """
    contract_by_id = {claim["claim_id"]: claim for claim in contract}
    candidate_norm = _normalized_phrase(candidate)
    for assessment in result["assessments"]:
        if assessment["verdict"] not in FULLY_PRESERVED:
            continue
        claim = contract_by_id[assessment["claim_id"]]
        span = str(assessment.get("candidate_span", ""))
        context_norm = _normalized_phrase(_claim_context(candidate, span))
        failed: list[str] = []
        approved = claim.get("approved_simplifications", [])
        for slot in claim.get("immutable_slot_values", []):
            if not isinstance(slot, dict) or not slot.get("value"):
                continue
            slot_type = str(slot.get("slot_type", "slot"))
            if slot_type not in LEXICAL_ANCHOR_SLOT_TYPES:
                continue
            source_form = str(slot["value"])
            alternatives = [source_form] + [
                str(item.get("allowed_form", ""))
                for item in approved
                if str(item.get("source_form", "")).strip().lower()
                == source_form.strip().lower()
            ]
            haystack = candidate_norm if slot_type == "entity" else context_norm
            haystack_tokens = set(haystack.split())
            if not any(
                normalized and set(normalized.split()).issubset(haystack_tokens)
                for normalized in (_normalized_phrase(value) for value in alternatives)
            ):
                failed.append(f"{slot_type}: {source_form}")
        if failed:
            assessment["verdict"] = "partial_coverage" if span.strip() else "omitted"
            assessment["failed_slots"] = list(dict.fromkeys(
                _string_list(assessment.get("failed_slots")) + failed
            ))
            suffix = "Frozen lexical anchors absent: " + "; ".join(failed)
            assessment["reason"] = (
                str(assessment.get("reason", "")).rstrip() + " | " + suffix
            ).strip(" |")
            assessment["lexical_anchor_failure"] = True
    result["lexical_anchor_checked"] = True
    return result


def score_validation(
    result: dict[str, Any], policy: FidelityPolicy
) -> dict[str, Any]:
    assessments = result["assessments"]
    preserved = [x for x in assessments if x["verdict"] in FULLY_PRESERVED]
    critical = [x for x in assessments if x.get("tier") == "critical"]
    critical_preserved = [x for x in critical if x["verdict"] in FULLY_PRESERVED]
    material = [x for x in assessments if x["verdict"] in MATERIAL_FAILURES]
    unsupported = result.get("unsupported_claims", [])
    unsupported_count = sum(item.get("severity", "material") == "material" for item in unsupported)
    nonmaterial_count = sum(item.get("severity") == "nonmaterial" for item in unsupported)
    core_recall = len(preserved) / len(assessments) if assessments else 1.0
    critical_recall = len(critical_preserved) / len(critical) if critical else 1.0
    hard_pass = (
        core_recall >= policy.min_core_recall
        and (not policy.require_all_critical or critical_recall == 1.0)
        and len(material) <= policy.max_material_failures
        and unsupported_count <= policy.max_unsupported_claims
    )
    return {
        "core_claim_recall": round(core_recall, 4),
        "critical_claim_recall": round(critical_recall, 4),
        "n_claims": len(assessments),
        "n_preserved": len(preserved),
        "n_partial": sum(x["verdict"] == "partial_coverage" for x in assessments),
        "n_omitted": sum(x["verdict"] == "omitted" for x in assessments),
        "n_material_alteration": sum(
            x["verdict"] == "material_alteration" for x in assessments
        ),
        "n_contradicted": sum(x["verdict"] == "contradicted" for x in assessments),
        "n_unsupported_claims": unsupported_count,
        "n_nonmaterial_framing_flags": nonmaterial_count,
        "hard_fidelity_pass": hard_pass,
    }


def validate_candidate(
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
    llm_call: Callable[..., str],
    policy: FidelityPolicy,
) -> dict[str, Any]:
    def call_once(prompt: str, role: str) -> dict[str, Any]:
        parse_error: Exception | None = None
        for attempt in range(2):
            retry_prompt = prompt
            if attempt:
                retry_prompt += "\n\nYour previous response was invalid. Return the requested JSON object only."
            raw = _json_llm_response(llm_call, retry_prompt, max_tokens=4096)
            try:
                return normalize_validation(_json_object(raw), contract)
            except (ValueError, json.JSONDecodeError) as exc:
                parse_error = exc
        raise ValueError(f"{role} fidelity verifier returned invalid JSON twice: {parse_error}")

    normalized = call_once(
        validation_prompt(source_text, candidate, contract), "primary"
    )
    if policy.use_adversarial_double_check:
        adversarial = call_once(
            adversarial_validation_prompt(source_text, candidate, contract),
            "adversarial",
        )
        normalized = merge_validation_results(normalized, adversarial)
    else:
        normalized["double_checked"] = False
    normalized = apply_lexical_anchor_checks(normalized, candidate, contract)
    normalized["metrics"] = score_validation(normalized, policy)
    return normalized


def _failed_contract(
    contract: list[dict[str, Any]], validation: dict[str, Any]
) -> list[dict[str, Any]]:
    failed_ids = {
        item["claim_id"]
        for item in validation["assessments"]
        if item["verdict"] not in FULLY_PRESERVED
    }
    return [claim for claim in contract if claim["claim_id"] in failed_ids]


def remove_exact_material_spans(candidate: str, validation: dict[str, Any]) -> str:
    """Deterministically remove verifier-localised factual additions.

    This is deliberately narrow: only an exact quoted span classified as material is
    removed.  Any paraphrased residue is left for the next full validation round,
    which supplies a new span.  The operation therefore cannot silently delete an
    unflagged source proposition.
    """
    revised = candidate
    for item in validation.get("unsupported_claims", []):
        if item.get("severity") != "material":
            continue
        span = str(item.get("candidate_span", "")).strip()
        if span and span in revised:
            revised = revised.replace(span, " ")
    revised = re.sub(r"[ \t]+", " ", revised)
    revised = re.sub(r"\n{3,}", "\n\n", revised)
    return revised.strip()


def remove_empty_markdown_sections(candidate: str) -> str:
    """Remove heading-only sections whose next paragraph starts another heading."""
    paragraphs = [value.strip() for value in re.split(r"\n\s*\n", candidate) if value.strip()]
    heading_only = re.compile(r"^(?:#{1,6}\s+.+|\*\*[^\n]+\*\*)$")
    starts_heading = re.compile(r"^(?:#{1,6}\s+|\*\*[^\n]+\*\*)")
    kept: list[str] = []
    for index, paragraph in enumerate(paragraphs):
        next_paragraph = paragraphs[index + 1] if index + 1 < len(paragraphs) else ""
        if heading_only.fullmatch(paragraph) and (
            not next_paragraph or starts_heading.match(next_paragraph)
        ):
            continue
        kept.append(paragraph)
    return "\n\n".join(kept).strip()


def protected_passing_paragraphs(
    candidate: str,
    validation: dict[str, Any],
    extra_failed_spans: list[str] | None = None,
) -> list[str]:
    """Return passing paragraphs that contain no known repair target."""
    def comparable(value: str) -> str:
        value = re.sub(r"[*_`#]", "", value)
        value = re.sub(r"\[([^]]+)\]\([^)]+\)", r"\1", value)
        value = value.translate(str.maketrans({
            '"': "'", "“": "'", "”": "'", "‘": "'", "’": "'",
        }))
        value = re.sub(r"\s+", " ", value)
        return value.strip().lower()

    def overlaps(paragraph: str, span: str) -> bool:
        normalized_paragraph = comparable(paragraph)
        normalized_span = comparable(span)
        return bool(
            normalized_span
            and (
                normalized_span in normalized_paragraph
                or normalized_paragraph in normalized_span
            )
        )

    material_spans = [
        str(item.get("candidate_span", "")).strip()
        for item in validation.get("unsupported_claims", [])
        if item.get("severity") == "material" and str(item.get("candidate_span", "")).strip()
    ]
    failed_spans = [
        str(item.get("candidate_span", "")).strip()
        for item in validation.get("assessments", [])
        if item.get("verdict") not in FULLY_PRESERVED and str(item.get("candidate_span", "")).strip()
    ]
    passed_spans = [
        str(item.get("candidate_span", "")).strip()
        for item in validation.get("assessments", [])
        if item.get("verdict") in FULLY_PRESERVED and str(item.get("candidate_span", "")).strip()
    ]
    protected: list[str] = []
    for paragraph in (value.strip() for value in re.split(r"\n\s*\n", candidate)):
        if not paragraph or not any(overlaps(paragraph, span) for span in passed_spans):
            continue
        if any(overlaps(paragraph, span) for span in material_spans + failed_spans + (extra_failed_spans or [])):
            continue
        protected.append(paragraph)
    return list(dict.fromkeys(protected))


def minimal_edit_metrics(
    initial_candidate: str,
    current_candidate: str,
    protected_paragraphs: list[str],
    editable_spans: list[str] | None = None,
) -> dict[str, Any]:
    """Measure edit scope against the exact B candidate without judging semantics."""
    token_pattern = r"\b\w+(?:[-']\w+)*\b"
    initial_tokens = re.findall(token_pattern, initial_candidate.lower())
    current_tokens = re.findall(token_pattern, current_candidate.lower())
    matcher = difflib.SequenceMatcher(a=initial_tokens, b=current_tokens, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    retained = matched / len(initial_tokens) if initial_tokens else 1.0
    sequence_ratio = matcher.ratio() if initial_tokens or current_tokens else 1.0
    retained_paragraphs = [p for p in protected_paragraphs if p in current_candidate]
    paragraph_ratio = (
        len(retained_paragraphs) / len(protected_paragraphs)
        if protected_paragraphs else 1.0
    )
    editable_token_indexes: set[int] = set()
    for span in editable_spans or []:
        span_tokens = re.findall(token_pattern, span.lower())
        if not span_tokens:
            continue
        width = len(span_tokens)
        for start in range(0, len(initial_tokens) - width + 1):
            if initial_tokens[start:start + width] == span_tokens:
                editable_token_indexes.update(range(start, start + width))
                break
    non_target_tokens = [
        token for index, token in enumerate(initial_tokens)
        if index not in editable_token_indexes
    ]
    non_target_matcher = difflib.SequenceMatcher(
        a=non_target_tokens, b=current_tokens, autojunk=False
    )
    non_target_matched = sum(
        block.size for block in non_target_matcher.get_matching_blocks()
    )
    non_target_retention = (
        non_target_matched / len(non_target_tokens) if non_target_tokens else 1.0
    )
    return {
        "initial_candidate_sha256": hashlib.sha256(initial_candidate.encode("utf-8")).hexdigest(),
        "current_candidate_sha256": hashlib.sha256(current_candidate.encode("utf-8")).hexdigest(),
        "initial_token_count": len(initial_tokens),
        "non_target_initial_token_count": len(non_target_tokens),
        "initial_token_retention": round(retained, 4),
        "token_sequence_ratio": round(sequence_ratio, 4),
        "non_target_token_retention": round(non_target_retention, 4),
        "n_editable_spans": len(editable_spans or []),
        "n_protected_paragraphs": len(protected_paragraphs),
        "n_protected_paragraphs_retained": len(retained_paragraphs),
        "protected_paragraph_retention": round(paragraph_ratio, 4),
        "missing_protected_paragraphs": [
            p for p in protected_paragraphs if p not in current_candidate
        ],
    }


STYLE_DIMENSIONS = ("clarity", "reader_fit", "familiar_word_strategy", "structure")


def reader_style_prompt(
    initial_candidate: str,
    current_candidate: str,
    reader_constraints: str,
) -> str:
    return f"""You are a paired reader-style evaluator. Compare BEFORE and AFTER for
the supplied reader only. Ignore factual fidelity; another gate evaluates it. Score
each text independently from 1 (poor) to 5 (excellent) on clarity, reader fit,
familiar-word strategy, and structure. Do not reward the AFTER text merely for being
more formal or source-like. A technical term counts as reader-friendly only when it is
replaced or locally explained. Return JSON only.

{{"before":{{"clarity":1,"reader_fit":1,"familiar_word_strategy":1,"structure":1}},
"after":{{"clarity":1,"reader_fit":1,"familiar_word_strategy":1,"structure":1}},
"reason":"brief paired explanation"}}

TARGET READER
{reader_constraints}

BEFORE (exact B candidate)
{initial_candidate}

AFTER (current repair candidate)
{current_candidate}"""


def evaluate_reader_style_noninferiority(
    initial_candidate: str,
    current_candidate: str,
    reader_constraints: str,
    llm_call: Callable[..., str],
    margin: int,
) -> dict[str, Any]:
    if current_candidate == initial_candidate:
        return {
            "evaluated": False,
            "reason": "same_as_initial_candidate",
            "margin": margin,
            "noninferior": True,
            "before": {},
            "after": {},
            "deltas": {key: 0 for key in STYLE_DIMENSIONS},
        }
    if not reader_constraints.strip():
        return {
            "evaluated": False,
            "reason": "no_reader_constraints_supplied",
            "margin": margin,
            "noninferior": True,
            "before": {},
            "after": {},
            "deltas": {},
        }
    prompt = reader_style_prompt(initial_candidate, current_candidate, reader_constraints)
    last_error: Exception | None = None
    for attempt in range(2):
        retry = prompt if not attempt else prompt + "\nReturn the requested JSON object only."
        try:
            raw = _json_object(_json_llm_response(llm_call, retry, max_tokens=1600))
            before = {key: int(raw.get("before", {}).get(key)) for key in STYLE_DIMENSIONS}
            after = {key: int(raw.get("after", {}).get(key)) for key in STYLE_DIMENSIONS}
            if any(value < 1 or value > 5 for value in before.values()) or any(
                value < 1 or value > 5 for value in after.values()
            ):
                raise ValueError("style score outside 1..5")
            deltas = {key: after[key] - before[key] for key in STYLE_DIMENSIONS}
            return {
                "evaluated": True,
                "reason": str(raw.get("reason", "")),
                "margin": margin,
                "noninferior": all(delta >= -margin for delta in deltas.values()),
                "before": before,
                "after": after,
                "deltas": deltas,
            }
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc
    raise ValueError(f"Reader-style evaluator returned invalid JSON twice: {last_error}")


PATCH_OPERATIONS = {
    "replace_within_sentence",
    "delete_within_sentence",
    "insert_before_sentence",
    "insert_after_sentence",
}


def _sentence_spans(text: str) -> list[tuple[int, int, str]]:
    """Return exact non-empty sentence-like spans, including markdown headings.

    The splitter is deliberately deterministic.  It is not used for semantics; it
    only supplies an immutable anchor boundary for a model-proposed local patch.
    """
    def nonterminal_period(index: int) -> bool:
        if index > 0 and index + 1 < len(text):
            if text[index - 1].isdigit() and text[index + 1].isdigit():
                return True
        left = text[max(0, index - 8):index + 1]
        if re.search(r"(?:e\.g|i\.e|U\.S|U\.K)\.$", left, re.IGNORECASE):
            return True
        if re.search(r"(?:Mr|Mrs|Ms|Dr|Prof|No|Fig)\.$", left, re.IGNORECASE):
            return True
        # Periods inside initialisms (U.S., U.N., A.I.) are not boundaries.
        if index + 2 < len(text) and text[index - 1:index].isalpha():
            if text[index + 1:index + 2].isalpha() and text[index + 2:index + 3] == ".":
                return True
        if index >= 2 and text[index - 2:index - 1] == ".":
            if text[index - 3:index - 2].isalpha() and text[index - 1:index].isalpha():
                return True
        return False

    spans: list[tuple[int, int, str]] = []
    start = 0
    for index, char in enumerate(text):
        boundary = char in "!?。！？\n" or (char == "." and not nonterminal_period(index))
        if not boundary:
            continue
        end = index + (0 if char == "\n" else 1)
        raw = text[start:end]
        left = len(raw) - len(raw.lstrip())
        right = len(raw.rstrip())
        if right > left:
            span_start = start + left
            span_end = start + right
            spans.append((span_start, span_end, text[span_start:span_end]))
        start = index + 1
    if start < len(text):
        raw = text[start:]
        left = len(raw) - len(raw.lstrip())
        right = len(raw.rstrip())
        if right > left:
            span_start = start + left
            span_end = start + right
            spans.append((span_start, span_end, text[span_start:span_end]))
    return spans


def passing_claim_protection_templates(
    candidate: str,
    validation: dict[str, Any],
    allowed_il_spans: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Freeze passed wording except exact IL/schema spans already marked erroneous."""
    allowed_il_spans = [value for value in (allowed_il_spans or []) if value]
    templates: list[dict[str, Any]] = []
    for assessment in validation.get("assessments", []):
        span = str(assessment.get("candidate_span", "")).strip()
        if assessment.get("verdict") not in FULLY_PRESERVED or not span or span not in candidate:
            continue
        allowed = [
            value for value in allowed_il_spans
            if value in span and value != span and len(value) <= int(len(span) * 0.6)
        ]
        fragments = [span]
        for value in sorted(set(allowed), key=lambda item: span.find(item)):
            next_fragments: list[str] = []
            for fragment in fragments:
                if value in fragment:
                    left, right = fragment.split(value, 1)
                    next_fragments.extend([left, right])
                else:
                    next_fragments.append(fragment)
            fragments = next_fragments
        fixed = [value for value in fragments if value]
        templates.append({
            "claim_id": str(assessment.get("claim_id", "")),
            "original_span": span,
            "allowed_il_spans": sorted(set(allowed)),
            "fixed_fragments": fixed,
        })
    return templates


def evaluate_passing_claim_protection(
    candidate: str,
    templates: list[dict[str, Any]],
) -> dict[str, Any]:
    """Require each immutable fragment of every initially passed claim in order."""
    failed: list[str] = []
    for template in templates:
        cursor = 0
        for fragment in template.get("fixed_fragments", []):
            position = candidate.find(str(fragment), cursor)
            if position < 0:
                failed.append(str(template.get("claim_id", "")))
                break
            cursor = position + len(str(fragment))
    failed = sorted(set(failed))
    return {
        "pass": not failed,
        "n_templates": len(templates),
        "n_passed": len(templates) - len(failed),
        "failed_claim_ids": failed,
    }


def cumulative_patch_burden(
    patch_history: list[dict[str, Any]],
    proposed: dict[str, Any] | None = None,
) -> dict[str, int]:
    """Summarize accepted edits across rounds; rejected attempts cost no budget."""
    applications = [item for item in patch_history if item.get("accepted")]
    if proposed is not None:
        applications.append(proposed)
    patches = [patch for item in applications for patch in item.get("patches", [])]
    word_pattern = r"\b\w+(?:[-']\w+)*\b"
    return {
        "n_patches": len(patches),
        "replacement_words": sum(
            len(re.findall(word_pattern, str(patch.get("replacement_text", ""))))
            for patch in patches
        ),
        "changed_words": sum(
            max(
                len(re.findall(word_pattern, str(patch.get("replacement_text", "")))),
                len(re.findall(word_pattern, str(patch.get("target_span", "")))),
            )
            for patch in patches
        ),
    }


def patch_burden_passes(burden: dict[str, int], policy: FidelityPolicy) -> bool:
    return bool(
        burden.get("n_patches", 0) <= policy.max_total_patches
        and burden.get("replacement_words", 0) <= policy.max_total_replacement_words
        and burden.get("changed_words", 0) <= policy.max_total_changed_words
    )


def _exact_unique_offset(text: str, value: str, label: str) -> int:
    if not value:
        raise ValueError(f"{label} must not be empty")
    first = text.find(value)
    if first < 0:
        raise ValueError(f"{label} is not an exact substring of the current candidate")
    if text.find(value, first + 1) >= 0:
        raise ValueError(f"{label} is not unique in the current candidate")
    return first


def _unique_claim_ngrams(
    claim_contract: list[dict[str, Any]],
    min_n: int = 3,
    max_n: int = 6,
) -> dict[str, set[str]]:
    """Return claim-specific surface anchors for cross-claim patch protection."""
    token_pattern = r"\b\w+(?:[-']\w+)*\b"
    per_claim: dict[str, set[str]] = {}
    owners: dict[str, set[str]] = {}
    for claim in claim_contract:
        claim_id = str(claim.get("claim_id", ""))
        tokens = re.findall(
            token_pattern, str(claim.get("canonical_proposition", "")).lower()
        )
        phrases = {
            " ".join(tokens[start:start + width])
            for width in range(min_n, min(max_n, len(tokens)) + 1)
            for start in range(0, len(tokens) - width + 1)
        }
        per_claim[claim_id] = phrases
        for phrase in phrases:
            owners.setdefault(phrase, set()).add(claim_id)
    return {
        claim_id: {phrase for phrase in phrases if owners.get(phrase) == {claim_id}}
        for claim_id, phrases in per_claim.items()
    }


def cross_claim_surface_losses(
    candidate: str,
    edit_start: int,
    edit_end: int,
    replacement: str,
    named_claim_ids: list[str],
    claim_contract: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Detect removal of another claim's unique phrase by a single local patch."""
    if edit_start == edit_end or not claim_contract:
        return []
    normalize = lambda value: " ".join(
        re.findall(r"\b\w+(?:[-']\w+)*\b", value.lower())
    )
    target = normalize(candidate[edit_start:edit_end])
    replacement_norm = normalize(replacement)
    remaining = normalize(candidate[:edit_start] + " " + candidate[edit_end:])
    losses: list[dict[str, str]] = []
    for claim_id, phrases in _unique_claim_ngrams(claim_contract).items():
        if claim_id in named_claim_ids:
            continue
        matches = sorted(
            (
                phrase for phrase in phrases
                if phrase in target
                and phrase not in replacement_norm
                and phrase not in remaining
            ),
            key=lambda value: (-len(value.split()), value),
        )
        if matches:
            losses.append({"claim_id": claim_id, "anchor": matches[0]})
    return losses


def apply_sentence_patches(
    candidate: str,
    source_text: str,
    patch_object: dict[str, Any],
    protected_paragraphs: list[str] | None = None,
    policy: FidelityPolicy | None = None,
    valid_claim_ids: set[str] | None = None,
    valid_term_ids: set[str] | None = None,
    valid_schema_support_ids: set[str] | None = None,
    repair_kind: str = "content_and_il",
    passing_claim_templates: list[dict[str, Any]] | None = None,
    claim_contract: list[dict[str, Any]] | None = None,
    explanation_protection_contract: dict[str, Any] | None = None,
    repair_targets: dict[str, Any] | None = None,
    repair_alignment_packet: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate and apply exact sentence-anchored patches without rewriting context.

    Every byte outside an explicitly targeted span or insertion point is copied from
    the input candidate. Invalid, ambiguous, broad, or ungrounded patch sets fail
    closed before any edit is applied.
    """
    policy = policy or FidelityPolicy()
    alignment_packet = repair_alignment_packet or {}
    alignment_instructions: dict[str, dict[str, Any]] = {}
    expected_instruction_ids: set[str] = set()
    expected_scope = ""
    if alignment_packet:
        if patch_object.get("mode") != REPAIR_ALIGNMENT_MODE:
            raise ValueError("repair alignment response must echo mode=repair_alignment")
        if patch_object.get("packet_id") != alignment_packet.get("packet_id"):
            raise ValueError("repair alignment response packet_id is missing or stale")
        expected_scope = str(alignment_packet.get("strategy_scope_id", ""))
        if patch_object.get("strategy_scope_id") != expected_scope:
            raise ValueError("repair alignment response strategy_scope_id mismatch")
        alignment_instructions = {
            str(item.get("instruction_id", "")): item
            for item in alignment_packet.get("instructions", [])
            if str(item.get("instruction_id", ""))
        }
        expected_instruction_ids = set(alignment_instructions)
        self_check = patch_object.get("self_check")
        if not isinstance(self_check, dict):
            raise ValueError("repair alignment response requires self_check")
        addressed = self_check.get("addressed_instruction_ids")
        if not isinstance(addressed, list) or set(map(str, addressed)) != expected_instruction_ids:
            raise ValueError("self_check must address every selected instruction exactly")
        if self_check.get("scope_respected") is not True:
            raise ValueError("self_check.scope_respected must be true")
    raw_patches = patch_object.get("patches")
    if not isinstance(raw_patches, list) or not raw_patches:
        raise ValueError("patches must be a non-empty list")
    if len(raw_patches) > policy.max_patches_per_round:
        raise ValueError("too many patches in one repair round")

    sentence_lookup = {
        value: (start, end)
        for start, end, value in _sentence_spans(candidate)
        if candidate.count(value) == 1
    }
    protected = protected_paragraphs or []
    support_protection = explanation_protection_contract or {}
    valid_protected_support_ids: set[str] = set()
    valid_protected_term_ids: set[str] = set()
    for group in (
        "explanations", "knowledge_bridges", "guidance_strategies", "analogies",
    ):
        for requirement in support_protection.get(group, []):
            term_id = str(requirement.get("term_id", "")).strip()
            if term_id:
                valid_protected_term_ids.add(term_id)
            support_id = str(requirement.get("support_id", "")).strip()
            if support_id:
                valid_protected_support_ids.add(support_id)
            valid_protected_support_ids.update(
                str(value).strip()
                for value in requirement.get("linked_support_ids", [])
                if str(value).strip()
            )
    active_targets = repair_targets or {}
    if active_targets:
        failed_schema_ids = sorted(active_targets.get(
            "failed_schema_support_ids", active_targets.get("schema", {})
        ))
        allowed_schema_ids = sorted(active_targets.get(
            "allowed_schema_support_ids", active_targets.get("schema", {})
        ))
        if allowed_schema_ids != failed_schema_ids:
            raise ValueError(
                "allowed_schema_support_ids must equal failed_schema_support_ids"
            )
    prepared: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    seen_instruction_ids: set[str] = set()
    seen_ranges: list[tuple[int, int]] = []
    for index, raw in enumerate(raw_patches, 1):
        if not isinstance(raw, dict):
            raise ValueError(f"patch {index} must be an object")
        patch_id = str(raw.get("patch_id", f"P{index:02d}")).strip()
        raw_instruction_ids = raw.get("instruction_ids")
        if raw_instruction_ids is None:
            raw_instruction_ids = [raw.get("instruction_id", "")]
        if not isinstance(raw_instruction_ids, list):
            raise ValueError("instruction_ids must be a list")
        instruction_ids = list(dict.fromkeys(
            str(value).strip() for value in raw_instruction_ids if str(value).strip()
        ))
        instruction_id = instruction_ids[0] if instruction_ids else ""
        patch_scope = str(raw.get("strategy_scope_id", "")).strip()
        raw_instruction_scopes = raw.get("instruction_scope_ids")
        if raw_instruction_scopes is None:
            raw_instruction_scopes = [raw.get("instruction_scope_id", "")]
        if not isinstance(raw_instruction_scopes, list):
            raise ValueError("instruction_scope_ids must be a list")
        instruction_scopes = list(dict.fromkeys(
            str(value).strip() for value in raw_instruction_scopes if str(value).strip()
        ))
        instruction_scope = instruction_scopes[0] if instruction_scopes else ""
        operation = str(raw.get("operation", "")).strip()
        anchor = str(raw.get("anchor_sentence", ""))
        target = str(raw.get("target_span", ""))
        replacement = str(raw.get("replacement_text", "")).strip()
        evidence = str(raw.get("source_evidence", "")).strip()
        reader_note = str(raw.get("reader_language_note", "")).strip()
        raw_claim_ids = raw.get("claim_ids", [])
        raw_term_ids = raw.get("term_ids", [])
        raw_schema_support_ids = raw.get("schema_support_ids", [])
        raw_protected_term_ids = raw.get("protected_term_ids", [])
        raw_protected_support_ids = raw.get("protected_support_ids", [])
        if not isinstance(raw_claim_ids, list):
            raise ValueError("claim_ids must be a list")
        if not isinstance(raw_term_ids, list):
            raise ValueError("term_ids must be a list")
        if not isinstance(raw_schema_support_ids, list):
            raise ValueError("schema_support_ids must be a list")
        if not isinstance(raw_protected_term_ids, list):
            raise ValueError("protected_term_ids must be a list")
        if not isinstance(raw_protected_support_ids, list):
            raise ValueError("protected_support_ids must be a list")
        claim_ids = [str(value) for value in raw_claim_ids]
        term_ids = [str(value) for value in raw_term_ids]
        schema_support_ids = [str(value) for value in raw_schema_support_ids]
        patch_instructions: list[dict[str, Any]] = []
        if alignment_packet:
            if not instruction_ids:
                raise ValueError("repair alignment patch requires instruction_ids")
            unknown_instruction_ids = [
                value for value in instruction_ids if value not in alignment_instructions
            ]
            if unknown_instruction_ids:
                raise ValueError(
                    "patch instruction_ids are not selected by the repair packet: "
                    + ", ".join(unknown_instruction_ids)
                )
            duplicate_instruction_ids = sorted(
                set(instruction_ids).intersection(seen_instruction_ids)
            )
            if duplicate_instruction_ids:
                raise ValueError(
                    "duplicate instruction_ids: " + ", ".join(duplicate_instruction_ids)
                )
            if patch_scope != expected_scope:
                raise ValueError("patch strategy_scope_id mismatch")
            patch_instructions = [alignment_instructions[value] for value in instruction_ids]
            all_composite_evidence_choices = [
                str(choice)
                for instruction in patch_instructions
                for choice in (
                    instruction.get(
                        "source_evidence_choices",
                        instruction.get("source_evidence", []),
                    ) or []
                )
                if str(choice)
            ]
            evidence_is_exact_bound_choice = bool(
                evidence and evidence in all_composite_evidence_choices
            )
            expected_instruction_scopes = {
                str(value.get("instruction_scope_id", ""))
                for value in patch_instructions
            }
            normalized_instruction_scopes: list[str] = []
            for supplied_scope in instruction_scopes:
                matching_scopes: list[str] = []
                if supplied_scope == "icl":
                    matching_scopes = sorted(
                        value for value in expected_instruction_scopes
                        if value.startswith("icl/")
                    )
                elif supplied_scope in {"gcl", "schema_support"}:
                    matching_scopes = sorted(
                        value for value in expected_instruction_scopes
                        if value == "gcl_schema_support"
                    )
                if len(matching_scopes) == 1:
                    normalized_instruction_scopes.append(matching_scopes[0])
                else:
                    normalized_instruction_scopes.append(supplied_scope)
            instruction_scopes = list(dict.fromkeys(normalized_instruction_scopes))
            instruction_scope = instruction_scopes[0] if instruction_scopes else ""
            if set(instruction_scopes) != expected_instruction_scopes:
                raise ValueError("patch instruction_scope_ids mismatch")
            if len(instruction_ids) > 1:
                for current_id, current_instruction in zip(
                    instruction_ids, patch_instructions
                ):
                    compatible = {
                        str(value) for value in current_instruction.get(
                            "compatible_composite_instruction_ids", []
                        )
                    }
                    if not (set(instruction_ids) - {current_id}).issubset(compatible):
                        raise ValueError(
                            "composite patch may bind only overlapping compatible instructions"
                        )
            for instruction in patch_instructions:
                allowed_anchors = {
                    str(value)
                    for value in instruction.get("allowed_anchor_sentences", [])
                }
                if allowed_anchors and anchor not in allowed_anchors:
                    raise ValueError(
                        "anchor_sentence is outside a selected instruction anchor allow-list"
                    )
                instruction_target = str(instruction.get("target_id", ""))
                instruction_module = str(instruction.get("module", ""))
                allowed_operations = {
                    str(value) for value in instruction.get("allowed_operations", [])
                }
                if allowed_operations and operation not in allowed_operations:
                    raise ValueError(
                        "patch operation is not allowed by every bound repair instruction"
                    )
                evidence_choices = instruction.get(
                    "source_evidence_choices", instruction.get("source_evidence", [])
                )
                if isinstance(evidence_choices, str):
                    evidence_choices = [evidence_choices]
                evidence_choices = [
                    str(value) for value in (evidence_choices or []) if str(value)
                ]
                evidence_matches_instruction = bool(
                    evidence in evidence_choices
                    or (
                        len(instruction_ids) > 1
                        and evidence_is_exact_bound_choice
                        and any(
                            choice in evidence or evidence in choice
                            for choice in evidence_choices
                        )
                    )
                )
                if evidence and evidence_choices and not evidence_matches_instruction:
                    raise ValueError(
                        "source_evidence must exactly equal one bound instruction choice"
                    )
                if instruction_module == "icl" and instruction_target not in term_ids:
                    raise ValueError(
                        "ICL alignment patch must reference its instruction term_id"
                    )
                if (
                    instruction_module == "gcl_schema_support"
                    and instruction_target not in schema_support_ids
                ):
                    raise ValueError(
                        "GCL alignment patch must reference its instruction support_id"
                    )
                if (
                    instruction_module == "fidelity"
                    and not instruction_target.startswith("unsupported:")
                    and instruction_target not in claim_ids
                ):
                    raise ValueError(
                        "fidelity alignment patch must reference its instruction claim_id"
                    )
        protected_term_ids = [
            str(value) for value in raw_protected_term_ids
            if str(value) in valid_protected_term_ids
        ]
        removed_unknown_protected_term_ids = [
            str(value) for value in raw_protected_term_ids
            if str(value) not in valid_protected_term_ids
        ]
        protected_support_ids = [
            str(value) for value in raw_protected_support_ids
            if str(value) in valid_protected_support_ids
        ]
        removed_unknown_protected_support_ids = [
            str(value) for value in raw_protected_support_ids
            if str(value) not in valid_protected_support_ids
        ]
        required_preserved_claim_anchors: list[dict[str, str]] = []
        if alignment_packet:
            required_protected_term_ids = {
                str(value)
                for instruction in patch_instructions
                for value in instruction.get("required_protected_term_ids", [])
            }
            required_protected_support_ids = {
                str(value)
                for instruction in patch_instructions
                for value in instruction.get("required_protected_support_ids", [])
            }
            required_preserved_claim_anchors = [
                {
                    "claim_id": str(value.get("claim_id", "")),
                    "anchor": str(value.get("anchor", "")),
                }
                for instruction in patch_instructions
                for value in instruction.get("required_preserved_claim_anchors", [])
                if isinstance(value, dict) and str(value.get("anchor", ""))
            ]
            if not required_protected_term_ids.issubset(protected_term_ids):
                raise ValueError(
                    "patch omits a packet-required protected_term_id"
                )
            if not required_protected_support_ids.issubset(protected_support_ids):
                raise ValueError(
                    "patch omits a packet-required protected_support_id"
                )

        if not active_targets:
            for namespace, identifiers, valid_ids in (
                ("claim", claim_ids, valid_claim_ids),
                ("il", term_ids, valid_term_ids),
                ("schema", schema_support_ids, valid_schema_support_ids),
            ):
                if valid_ids is None:
                    continue
                unknown = sorted(set(identifiers) - set(valid_ids))
                if unknown:
                    raise ValueError(
                        f"unknown {namespace} target IDs: {', '.join(unknown)}"
                    )

        if repair_kind == "schema_support" and not schema_support_ids:
            raise ValueError("schema-support repair patch must reference schema_support_ids")

        if patch_id in seen_ids:
            raise ValueError(f"duplicate patch_id: {patch_id}")
        normalized_from_operation = ""
        if operation == "replace_within_sentence" and not replacement:
            normalized_from_operation = operation
            operation = "delete_within_sentence"
        if operation not in PATCH_OPERATIONS:
            raise ValueError(f"unsupported patch operation: {operation}")
        if anchor not in sentence_lookup:
            raise ValueError("anchor_sentence must exactly match one unique current sentence")
        anchor_start, anchor_end = sentence_lookup[anchor]
        protected_matches = [paragraph for paragraph in protected if anchor in paragraph]
        if (
            protected_matches
            and operation not in {"insert_before_sentence", "insert_after_sentence"}
            and not active_targets
        ):
            raise ValueError("protected passing paragraphs cannot be replaced or deleted")
        if protected_matches and operation == "insert_after_sentence" and not all(
            paragraph.rstrip().endswith(anchor) for paragraph in protected_matches
        ):
            raise ValueError("an after-insertion anchor in a protected paragraph must be its final sentence")
        if protected_matches and operation == "insert_before_sentence" and not all(
            paragraph.lstrip().startswith(anchor) for paragraph in protected_matches
        ):
            raise ValueError("a before-insertion anchor in a protected paragraph must be its first sentence")

        if operation in {"insert_before_sentence", "insert_after_sentence"}:
            if target:
                raise ValueError("sentence insertion requires an empty target_span")
            if not replacement:
                raise ValueError("sentence insertion requires replacement_text")
            edit_start = edit_end = anchor_start if operation == "insert_before_sentence" else anchor_end
        else:
            if target and target not in anchor:
                equivalent_ranges = _surface_equivalent_ranges(anchor, target)
                if len(equivalent_ranges) == 1:
                    local_left, local_right = equivalent_ranges[0]
                    matched_surface = anchor[local_left:local_right]
                    for marker in ("**", "__", "`", "*", "_"):
                        if (
                            local_left >= len(marker)
                            and anchor[local_left - len(marker):local_left] == marker
                            and marker in matched_surface
                        ):
                            local_left -= len(marker)
                            break
                    matched_surface = anchor[local_left:local_right]
                    for marker in ("**", "__", "`", "*", "_"):
                        if (
                            anchor[local_right:local_right + len(marker)] == marker
                            and marker in matched_surface
                        ):
                            local_right += len(marker)
                            break
                    # Canonicalize harmless Markdown/quote normalization to the
                    # exact current bytes before applying the patch.  This is not
                    # fuzzy matching: the normalized surface must occur once.
                    target = anchor[local_left:local_right]
            if not target or target not in anchor:
                raise ValueError("target_span must be an exact substring of anchor_sentence")
            if anchor.count(target) != 1:
                raise ValueError("target_span must be unique within anchor_sentence")
            local_start = anchor.find(target)
            edit_start = anchor_start + local_start
            edit_end = edit_start + len(target)
            if operation == "delete_within_sentence" and replacement:
                raise ValueError("delete_within_sentence requires empty replacement_text")
            if operation == "replace_within_sentence" and not replacement:
                raise ValueError("replace_within_sentence requires replacement_text")

        for prior_start, prior_end in seen_ranges:
            if edit_start == edit_end and prior_start == prior_end:
                conflict = edit_start == prior_start
            elif edit_start == edit_end:
                conflict = prior_start < edit_start < prior_end
            elif prior_start == prior_end:
                conflict = edit_start < prior_start < edit_end
            else:
                conflict = max(edit_start, prior_start) < min(edit_end, prior_end)
            if conflict:
                raise ValueError("patch target ranges overlap")

        replacement_words = len(re.findall(r"\b\w+(?:[-']\w+)*\b", replacement))
        target_words = len(re.findall(r"\b\w+(?:[-']\w+)*\b", target))
        if replacement_words > policy.max_patch_replacement_words:
            raise ValueError("replacement_text exceeds the per-patch word ceiling")
        if replacement_words - target_words > policy.max_patch_growth_words:
            raise ValueError("patch growth exceeds the per-patch word ceiling")
        if term_ids and max(0, replacement_words - target_words) > policy.max_short_gloss_words:
            raise ValueError("IL patch exceeds the short-gloss word ceiling")
        if repair_kind == "redundancy_cleanup":
            if operation in {"insert_before_sentence", "insert_after_sentence"} or replacement_words > target_words:
                raise ValueError("redundancy cleanup may only delete or shorten an exact span")
        if replacement and not reader_note:
            raise ValueError("reader_language_note is required for inserted/replaced text")
        nonfactual_schema_patch = bool(schema_support_ids) and (
            repair_kind == "schema_support"
            or (
                repair_kind == "content_and_il"
                and not claim_ids
                and not term_ids
            )
        )
        if replacement and not nonfactual_schema_patch and (not evidence or evidence not in source_text):
            raise ValueError("source_evidence must be an exact substring of the source article")
        def touches_target_spans(spans: list[str]) -> bool:
            if not spans:
                # Missing content has no existing candidate span, so a locally
                # anchored insertion/replacement may create the required support.
                return True
            for value in spans:
                if not value:
                    continue
                if operation in {"insert_before_sentence", "insert_after_sentence"}:
                    if (
                        value in anchor
                        or anchor in value
                        or _surface_equivalent_ranges(anchor, value)
                        or _surface_equivalent_ranges(value, anchor)
                    ):
                        return True
                    continue
                cursor = 0
                while True:
                    position = candidate.find(value, cursor)
                    if position < 0:
                        break
                    if max(edit_start, position) < min(edit_end, position + len(value)):
                        return True
                    cursor = position + 1
                for position, range_end in _surface_equivalent_ranges(candidate, value):
                    if max(edit_start, position) < min(edit_end, range_end):
                        return True
            return False

        removed_inactive_or_non_touching_ids: dict[str, list[str]] = {
            "claim": [], "il": [], "schema": [],
        }
        filtered_identifiers: dict[str, list[str]] = {}
        for namespace, identifiers in (
            ("claim", claim_ids), ("il", term_ids), ("schema", schema_support_ids),
        ):
            namespace_targets = active_targets.get(namespace, {})
            if not active_targets:
                filtered_identifiers[namespace] = list(identifiers)
                break
            kept: list[str] = []
            for identifier in identifiers:
                if identifier not in namespace_targets:
                    removed_inactive_or_non_touching_ids[namespace].append(identifier)
                    continue
                if not touches_target_spans(namespace_targets[identifier]):
                    # A model may attach every linked ID to a local patch. An ID
                    # whose localized failed span is untouched grants no authority;
                    # strip it deterministically and let the remaining target checks
                    # decide whether the patch itself is authorized.
                    removed_inactive_or_non_touching_ids[namespace].append(identifier)
                    continue
                kept.append(identifier)
            filtered_identifiers[namespace] = kept
        if active_targets:
            claim_ids = filtered_identifiers.get("claim", [])
            term_ids = filtered_identifiers.get("il", [])
            schema_support_ids = filtered_identifiers.get("schema", [])
        if repair_kind == "schema_support" and not schema_support_ids:
            raise ValueError(
                "schema-support repair patch has no active schema_support_id after filtering"
            )

        surface_losses = cross_claim_surface_losses(
            candidate, edit_start, edit_end, replacement, claim_ids,
            claim_contract or [],
        )
        normalize_surface = lambda value: " ".join(
            re.findall(r"\b\w+(?:[-']\w+)*\b", value.lower())
        )
        edited_surface = normalize_surface(candidate[edit_start:edit_end])
        replacement_surface = normalize_surface(replacement)
        remaining_surface = normalize_surface(
            candidate[:edit_start] + " " + candidate[edit_end:]
        )
        missing_required_claim_anchors = [
            value for value in required_preserved_claim_anchors
            if value["anchor"] in edited_surface
            and value["anchor"] not in replacement_surface
            and value["anchor"] not in remaining_surface
        ]
        if missing_required_claim_anchors:
            detail = ", ".join(
                f"{value['claim_id']}[{value['anchor']}]"
                for value in missing_required_claim_anchors
            )
            raise ValueError(
                "replacement_text for instruction_ids "
                + ",".join(instruction_ids)
                + ": must preserve packet-required passing claim anchors: "
                + detail
            )
        if surface_losses:
            detail = ", ".join(
                f"{item['claim_id']}[{item['anchor']}]" for item in surface_losses
            )
            raise ValueError(
                "patch removes a unique surface anchor of an unlisted claim: " + detail
            )
        declared_ids = {
            "claim": set(claim_ids),
            "il": set(term_ids),
            "schema": set(schema_support_ids),
        }
        identifier_lists = {
            "claim": claim_ids,
            "il": term_ids,
            "schema": schema_support_ids,
        }
        auto_added_touching_target_ids: dict[str, list[str]] = {
            "claim": [], "il": [], "schema": [],
        }
        for namespace in ("claim", "il", "schema"):
            for identifier, spans in active_targets.get(namespace, {}).items():
                if (
                    identifier not in declared_ids[namespace]
                    and spans
                    and touches_target_spans(spans)
                ):
                    if declared_ids[namespace]:
                        identifier_lists[namespace].append(identifier)
                        declared_ids[namespace].add(identifier)
                        auto_added_touching_target_ids[namespace].append(identifier)
                        continue
                    raise ValueError(
                        "patch crosses into an undeclared failed target: "
                        f"{namespace} ID {identifier}"
                    )
        if term_ids and max(0, replacement_words - target_words) > policy.max_short_gloss_words:
            raise ValueError("IL patch exceeds the short-gloss word ceiling")
        unsupported_targets = active_targets.get("unsupported_spans", [])
        touched_unsupported = [
            value for value in unsupported_targets
            if value and touches_target_spans([value])
        ]
        if (
            active_targets
            and repair_kind == "content_and_il"
            and not claim_ids and not term_ids and not schema_support_ids
            and (
                not unsupported_targets
                or not touched_unsupported
            )
        ):
            raise ValueError(
                "content_and_il patch must reference or touch an active failed target"
            )

        def overlaps_protected_span(value: str) -> bool:
            if not value or edit_start == edit_end:
                return False
            cursor = 0
            while True:
                position = candidate.find(value, cursor)
                if position < 0:
                    return False
                if max(edit_start, position) < min(edit_end, position + len(value)):
                    return True
                cursor = position + 1

        for requirement in support_protection.get("explanations", []):
            protected_span = str(
                requirement.get("protected_explanation_span", "")
            )
            if not overlaps_protected_span(protected_span):
                continue
            required_term = str(requirement.get("term_id", ""))
            required_support = str(requirement.get("support_id", ""))
            if (
                (not required_term or required_term in active_targets.get("il", {}))
                and (
                    not required_support
                    or required_support in active_targets.get("schema", {})
                )
            ):
                continue
            if not replacement:
                raise ValueError(
                    "protected necessary explanation cannot be deleted without an "
                    "information-equivalent replacement"
                )
            if (
                required_term
                and required_term not in term_ids
                and required_term not in protected_term_ids
            ):
                raise ValueError(
                    "patch touching a protected explanation must reference its term_id "
                    "in term_ids or protected_term_ids"
                )
            if required_support and required_support not in protected_support_ids:
                raise ValueError(
                    "patch touching a protected explanation must reference its "
                    "support_id in protected_support_ids"
                )

        for requirement in support_protection.get("knowledge_bridges", []):
            protected_span = str(requirement.get("protected_bridge_span", ""))
            if not overlaps_protected_span(protected_span):
                continue
            required_support = str(requirement.get("support_id", ""))
            if required_support in active_targets.get("schema", {}):
                continue
            if not replacement:
                raise ValueError(
                    "protected passing knowledge bridge cannot be deleted"
                )
            if required_support and required_support not in protected_support_ids:
                raise ValueError(
                    "patch touching a protected passing knowledge bridge must "
                    "reference its support_id in protected_support_ids"
                )

        for requirement in support_protection.get("guidance_strategies", []):
            protected_span = str(requirement.get("protected_guidance_span", ""))
            if not overlaps_protected_span(protected_span):
                continue
            required_support = str(requirement.get("support_id", "GS_Q_001"))
            if required_support in active_targets.get("schema", {}):
                continue
            if not replacement:
                raise ValueError(
                    "protected countable guidance strategy cannot be deleted"
                )
            if required_support and required_support not in protected_support_ids:
                raise ValueError(
                    "patch touching a protected countable guidance strategy must "
                    "reference its support_id in protected_support_ids"
                )

        for requirement in support_protection.get("analogies", []):
            protected_span = str(requirement.get("protected_analogy_span", ""))
            if not overlaps_protected_span(protected_span):
                continue
            required_ids = {
                str(value) for value in requirement.get("linked_support_ids", [])
                if str(value)
            }
            analogy_support_id = str(requirement.get("support_id", ""))
            if analogy_support_id:
                required_ids.add(analogy_support_id)
            if required_ids and required_ids.issubset(
                set(active_targets.get("schema", {}))
            ):
                continue
            if required_ids and not required_ids.intersection(protected_support_ids):
                raise ValueError(
                    "patch touching a protected helpful analogy must reference its support_id"
                )
            if not replacement and not requirement.get(
                "has_existing_direct_explanation", False
            ):
                declared_fallback = any(
                    isinstance(other, dict)
                    and str(other.get("replacement_text", "")).strip()
                    and required_ids.intersection(
                        str(value) for value in other.get("protected_support_ids", [])
                    )
                    for other in raw_patches
                )
                if not declared_fallback:
                    raise ValueError(
                        "deleting a protected helpful analogy requires an explicit "
                        "information-equivalent direct-explanation replacement"
                    )

        seen_ids.add(patch_id)
        if alignment_packet:
            seen_instruction_ids.update(instruction_ids)
        seen_ranges.append((edit_start, edit_end))
        prepared.append({
            "patch_id": patch_id,
            "instruction_id": instruction_id,
            "instruction_ids": instruction_ids,
            "strategy_scope_id": patch_scope,
            "instruction_scope_id": instruction_scope,
            "instruction_scope_ids": instruction_scopes,
            "operation": operation,
            "anchor_sentence": anchor,
            "target_span": target,
            "replacement_text": replacement,
            "source_evidence": evidence,
            "claim_ids": claim_ids,
            "term_ids": term_ids,
            "schema_support_ids": schema_support_ids,
            "protected_term_ids": protected_term_ids,
            "protected_support_ids": protected_support_ids,
            "removed_inactive_or_non_touching_ids": (
                removed_inactive_or_non_touching_ids
            ),
            "auto_added_touching_target_ids": auto_added_touching_target_ids,
            "removed_unknown_protected_support_ids": (
                removed_unknown_protected_support_ids
            ),
            "removed_unknown_protected_term_ids": (
                removed_unknown_protected_term_ids
            ),
            "touched_unsupported_spans": touched_unsupported,
            "reader_language_note": reader_note,
            "normalized_from_operation": normalized_from_operation,
            "start": edit_start,
            "end": edit_end,
        })

    if alignment_packet and seen_instruction_ids != expected_instruction_ids:
        raise ValueError(
            "patches must execute every selected repair instruction exactly once"
        )

    revised = candidate
    for patch in sorted(prepared, key=lambda value: value["start"], reverse=True):
        replacement = patch["replacement_text"]
        if patch["operation"] == "insert_after_sentence":
            following = revised[patch["end"]:]
            separator = "\n" if following.startswith("\n") else " "
            replacement = separator + replacement
        elif patch["operation"] == "insert_before_sentence":
            following = revised[patch["end"]:]
            separator = "\n" if following.startswith("\n") else " "
            replacement = replacement + separator
        revised = revised[:patch["start"]] + replacement + revised[patch["end"]:]
    if revised == candidate:
        raise ValueError("patch set produced no change")
    claim_protection = evaluate_passing_claim_protection(
        revised, passing_claim_templates or []
    )
    if not claim_protection["pass"]:
        raise ValueError(
            "patch set alters an initially passed claim outside an approved IL span: "
            + ", ".join(claim_protection["failed_claim_ids"])
        )
    return {
        "content": revised,
        "input_sha256": hashlib.sha256(candidate.encode("utf-8")).hexdigest(),
        "output_sha256": hashlib.sha256(revised.encode("utf-8")).hexdigest(),
        "patches": prepared,
        "n_patches": len(prepared),
        "passing_claim_protection": claim_protection,
    }


def repair_alignment_patch_prompt(
    *,
    source_text: str,
    candidate: str,
    max_words: int,
    current_words: int,
    packet: dict[str, Any],
    active_repair_targets: dict[str, Any] | None,
    protected_paragraphs: list[str] | None,
    explanation_protection_contract: dict[str, Any] | None,
    reader_constraints: str,
) -> str:
    """Return the concise production prompt for one isolated repair lane."""
    return f"""You are executing one bounded repair packet. Do not rewrite the article.
The packet may merge compatible Fidelity, ICL and GCL instructions so they can be
executed in this single call. Return JSON only. The caller applies exact local patches and then re-scores fidelity,
ICL, GCL/schema-support, ECL continuity, length, and non-regression.

{render_repair_alignment_packet(packet)}

EXECUTION PROTOCOL
1. Execute every selected instruction in this one response. Normally use one patch per
   instruction. When selected instructions name each other in
   compatible_composite_instruction_ids, combine them into one smallest shared patch
   and list every bound ID in instruction_ids and every scope in instruction_scope_ids.
   Each patch must echo the packet strategy_scope_id. Never combine non-overlapping
   instructions or borrow permission across their scopes.
2. Use only that instruction's allowed_operations, target_spans, target ID namespace,
   and exact source_evidence_choices. If no choices are listed, source_evidence must
   still be an exact non-empty SOURCE ARTICLE quote, except nonfactual GCL support or deletion.
   Put fidelity IDs in claim_ids, ICL IDs in term_ids, and GCL IDs in
   schema_support_ids; never copy an ID into another namespace.
3. anchor_sentence must be one exact unique sentence from CURRENT CANDIDATE SENTENCE ANCHORS.
   It must also appear in that instruction's allowed_anchor_sentences.
   replace/delete must use an exact target_span in that anchor. Insertions use target_span="".
4. Make the smallest change. Text outside the target span is immutable. Do not fix a
   deferred instruction and do not change an unselected ICL/ECL/GCL strategy. Deferred
   instruction bodies are intentionally hidden; if an ID is not in
   selected_instruction_ids, it must not appear in patches or self_check.
5. Preserve every protected paragraph, claim, explanation, bridge, guidance strategy,
   analogy, term, number, condition, scope, modality, comparison, and causal direction.
   Copy every required_protected_term_id and required_protected_support_id from the
   instruction into the matching patch fields. If an edited target contains a
   required_preserved_claim_anchor, retain that exact phrase in replacement_text;
   it is the sole surviving surface evidence of a passing claim.
   When protected_target_action is present, replacement is mandatory: do not delete
   the target and do not keep the rejected text unchanged. Ground the smallest safe
   replacement in one exact source_evidence_choice.
6. For familiar substitution, replace only the technical surface form; preserve any
   adjacent explanation and all linked facts. Never replace it with a broader/narrower term.
7. For GCL support, use only a nonfactual bridge/cue/direct explanation or an accurate
   relation-preserving analogy. Never invent a mechanism, outcome, application, or example.
8. Current length is {current_words}; final length must be <= {max_words}. Do not add padding.
9. In self_check, echo every selected instruction_id, assert scope only after checking,
   and state the expected local candidate evidence. The deterministic caller does not
   trust this report and will reject any mismatch.

OUTPUT SCHEMA
{{"mode":"repair_alignment","packet_id":"exact packet_id","strategy_scope_id":"exact packet strategy_scope_id","patches":[{{"patch_id":"P01","instruction_ids":["one or compatible overlapping selected RA-* IDs"],"strategy_scope_id":"exact packet strategy_scope_id","instruction_scope_ids":["exact scopes of all bound instructions"],"operation":"operation allowed by every bound instruction","anchor_sentence":"exact current sentence","target_span":"exact selected shared span or empty for insertion","replacement_text":"small local replacement","source_evidence":"exact packet choice/source quote or allowed empty","claim_ids":[],"term_ids":[],"schema_support_ids":[],"protected_term_ids":[],"protected_support_ids":[],"reader_language_note":"how local reader language and protected strategy are retained"}}],"self_check":{{"addressed_instruction_ids":["all selected IDs"],"scope_respected":true,"source_evidence_exact":true,"postconditions":[{{"instruction_id":"RA-*","expected_satisfied":true,"candidate_evidence":"expected local result"}}]}}}}

SELECTED TARGET NAMESPACES (the packet instructions are the sole edit authority)
{json.dumps(packet.get("active_target_ids", {}), ensure_ascii=False, indent=2)}

PROTECTED PASSING PARAGRAPHS
{json.dumps(protected_paragraphs or [], ensure_ascii=False, indent=2)}

EXPLANATION/GUIDANCE/ANALOGY PROTECTION
{json.dumps(explanation_protection_contract or {}, ensure_ascii=False, indent=2)}

TARGET READER (preserve register; never infer beliefs/preferences)
{reader_constraints}

SOURCE ARTICLE
{source_text}

CURRENT CANDIDATE
{candidate}

CURRENT CANDIDATE SENTENCE ANCHORS
{json.dumps([value for _, _, value in _sentence_spans(candidate)], ensure_ascii=False, indent=2)}"""


def sentence_patch_prompt(
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
    validation: dict[str, Any],
    max_words: int,
    current_words: int,
    reader_constraints: str = "",
    protected_paragraphs: list[str] | None = None,
    edit_metrics: dict[str, Any] | None = None,
    style_evaluation: dict[str, Any] | None = None,
    il_term_contract: list[dict[str, Any]] | None = None,
    il_evaluation: dict[str, Any] | None = None,
    schema_support_contract: dict[str, Any] | None = None,
    schema_support_evaluation: dict[str, Any] | None = None,
    explanation_protection_contract: dict[str, Any] | None = None,
    active_repair_targets: dict[str, Any] | None = None,
    min_initial_token_retention: float = 0.70,
    min_non_target_token_retention: float = 0.90,
    reader_style_margin: int = 1,
    repair_kind: str = "content",
    repair_alignment_packet: dict[str, Any] | None = None,
) -> str:
    failures = [
        x for x in validation["assessments"] if x["verdict"] not in FULLY_PRESERVED
    ]
    if repair_alignment_packet:
        return repair_alignment_patch_prompt(
            source_text=source_text,
            candidate=candidate,
            max_words=max_words,
            current_words=current_words,
            packet=repair_alignment_packet,
            active_repair_targets=active_repair_targets,
            protected_paragraphs=protected_paragraphs,
            explanation_protection_contract=explanation_protection_contract,
            reader_constraints=reader_constraints,
        )
    alignment_block = render_repair_alignment_packet(repair_alignment_packet)
    return f"""You are the sentence-patch planner in a controlled rewrite pipeline.
Do not return an article. Return only a JSON object containing exact, local patches.
The deterministic caller will reject any patch whose anchors are not exact and unique.

{alignment_block}

NON-NEGOTIABLE RULES
- Repair kind: {repair_kind}. Propose at most four patches and only those necessary.
- `content_and_il` is a joint repair channel: when its failed assessments include
  schema support, repair claim/IL and schema failures together with separate local
  patches. Do not trade one dimension for another.
- The ACTIVE REPAIR TARGET CONTRACT is the complete allow-list for this round.
  Claim, IL, and schema IDs are separate namespaces. Every ID on a patch must appear
  in its own namespace and the patch must touch that ID's failed span when one exists.
  Never borrow permission from another namespace.
- If `schema_pass_through` is true, schema already passed: use
  `schema_support_ids=[]` on every patch and do not alter any protected bridge or
  guidance span unless the same exact span is also an active claim/IL target.
  When such overlap is unavoidable, keep `schema_support_ids=[]`, list the passing
  support ID only in `protected_support_ids`, and preserve an information-equivalent
  bridge/guidance function. A protected ID records a preservation obligation; it
  never grants permission to repair schema support.
- `term_ids` contains only active failed IL targets. If a claim, unsupported-content,
  or other active repair overlaps an explanation belonging to an IL term that already
  passes, keep that passing term out of `term_ids` and list it only in
  `protected_term_ids`. A protected term ID records a preservation obligation and
  never grants permission to repair IL.
- A touched namespace must show post-repair improvement on at least one named failed
  target. Merely changing wording or attaching a valid-looking ID is not a repair.
- Each patch must name one complete `anchor_sentence` copied character-for-character
  from CURRENT CANDIDATE. Never target a paragraph or the full article.
- Copy anchors only from CURRENT CANDIDATE SENTENCE ANCHORS below. Every patch in the
  array is applied to that same unmodified candidate: never reference wording created
  by another patch in the array.
- Multiple patches may share an anchor only when their exact target spans do not
  overlap. Every target must refer to the original CURRENT CANDIDATE wording.
- `replace_within_sentence` and `delete_within_sentence` also require one exact
  `target_span` inside that anchor. Both insertion operations require target_span="".
- Text outside target_span or the insertion point is immutable and will be preserved
  byte-for-byte by the caller.
- A PROTECTED PASSING PARAGRAPH is not a repair target by itself. A local
  replacement/deletion inside one is allowed only when its exact edit range overlaps
  an active failed/material target; preserve all passing claims in that paragraph.
  The caller re-scores every passing claim and rejects any regression. An insertion
  may use the paragraph's final sentence as an anchor because the paragraph itself
  remains unchanged.
- Edit only a failed claim span, a material unsupported span, or the shortest sentence
  needed to insert a genuinely omitted relation/slot. Do not replace the article with
  a compressed restatement of the source.
- Preserve every claim that already passed.
- Prefer the shortest safe patch. Restore only the missing relation or slot phrase;
  never paste a full source sentence when a shorter local correction is sufficient.
- Obey the IL TERM CONTRACT. A factually safe but wrong treatment still needs a local
  IL repair (for example, replace peripheral jargon when familiar substitution was
  required). A strategy-shaped change with meaning drift must be restored to a safe
  equivalent. Never use IL as permission to change or delete a linked claim.
- For retain_and_explain / retain_and_gloss, keep the term and add only a short local
  explanation of at most 12 added words. For familiar substitution, preserve the same referent and proposition;
  do not use a broader, narrower, causal, evaluative, or more certain near-synonym.
- When an IL assessment reports `material_meaning_drift`, replace only the wrong
  familiar word/explanation span with an equivalent familiar form, or restore the
  source term plus a short gloss when no safe equivalent is available.
- Delete or source-ground every `unsupported_material` or `inappropriate_inference`
  introduced by an explanation. Remove only the unsupported proposition, not the
  useful explanation around it. Shorten/delete `redundant_restatement` unless that
  repetition is explicitly required by the reader strategy. Never solve redundancy by
  deleting the sole occurrence of a linked claim.
- Delete `excessive_supported_detail` locally even when it is source-grounded: an
  explanation may introduce at most one factual clarification for its term and at
  most four across the article. Preserve the shortest useful familiar gloss and the
  linked source proposition; remove only the surplus explanatory proposition.
- If repair kind is `redundancy_cleanup`, use only deletion or a strictly shorter
  replacement of the exact redundant/excessive span. Do not insert any new text.
- Restore every failed immutable slot from source evidence, including complete list
  members, exact numbers/units, conditions, scope, comparisons, modality, and causal
  chains. Never add a more specific fact than the source.
- Treat each failed contract entry as a distinct proposition. Do not repair it with
  language that merely covers a neighboring claim; explicitly restore its own main
  relation, purpose, object, and immutable slots.
- Familiar wording is encouraged; a technical term itself need not be restored when
  the contract explicitly approves its replacement. Otherwise retain every immutable
  slot value once as a lexical anchor and add a familiar local gloss; do not replace
  the anchor with a narrower or broader near-synonym.
- Remove or correct every unsupported assertion marked `material`. Do not rewrite a
  claim merely because it is marked `nonmaterial`; preserve reader-friendly style.
- For each material span listed below, perform a literal copy-edit: DELETE that
  assertion or replace it only with its quoted closest source span. Do not preserve
  the assertion by paraphrasing it, turning it into a hook, or presenting it as an
  analogy unless the source itself supports that meaning.
- The final body must be at most {max_words} words. To make room, cut or shorten in
  this order: unsupported material, generic recommendations, closing source advice,
  analogies, hooks, repeated explanations, decorative transitions. Never cut a
  source-derived core claim merely because its terminology was marked low-centrality.
- Preserve B's reader-facing words, tone, directness, headings, hooks, and explanatory
  structure. New text must match the local register. If a technical source term must
  be restored, keep the exact term as an anchor and immediately explain it with a
  familiar local gloss. Record this decision in `reader_language_note`.
- Preserve at least {round(min_non_target_token_retention * 100)}% of B's tokens after
  excluding the explicitly identified failed/material spans. Removing a factual error
  is allowed; deleting headings, explanations, safe analogies, or unrelated sentences
  is not. Overall B-token retention is logged separately and is expected to exceed
  {round(min_initial_token_retention * 100)}% when the error burden permits it.
  Reader-style scores may fall by at most {reader_style_margin} point(s) on any 1--5
  dimension relative to B.
- Every inserted/replacement patch must include an exact non-empty `source_evidence`
  quote copied from SOURCE ARTICLE, except a nonfactual schema-support patch.
  Deletions may use an empty source_evidence.
- Every IL-driven patch must list its `term_ids`; every claim-driven patch must list
  its `claim_ids`. Either list may be empty only when that contract type is unrelated.
- Every listed claim/term/schema target ID with a non-empty failed span must be
  touched by that patch's exact target_span. Do not attach an ID to a neighboring
  sentence or to a patch that only repairs another target.
- A schema-support patch must list `schema_support_ids`. It may add only a clearly
  nonfactual bridge, question, summary, or reader-navigation cue. Never add a factual
  application, mechanism, outcome, named example, or assurance absent from the source.
  Prefer an accurate direct explanation to a forced analogy.
- Cognitive guidance may occur at the beginning, middle, or end; never require an
  opener template. Preserve every reasonable existing strategy even when it is not
  aligned with the current reading goal: it earns no goal-alignment credit but is not
  a defect. If goal-aligned support is missing, add a short distinct strategy at the
  most useful location instead of rewriting or deleting the reasonable strategy.
- Each distinct countable strategy type adds positive coverage with diminishing returns.
  Repetition does not create another type. Unsupported guidance does not count and may
  be removed; do not delete source propositions or add unsupported applications/advice.
- Every proposed repair is accepted only if A_B, A_Q, and P_gcl do not decrease and
  no previously passing schema hard gate becomes false. The same acceptance gate
  protects already-passing claim-fidelity and IL semantics/strategy outcomes.
- A familiar analogy still fails when it is a forced binding: it shares only a word,
  position, shape, or vague theme without preserving the target relation or mechanism.
  If `semantic_distance` is high or `explanatory_gain` is low, keep the necessary term
  explanation but replace the forced analogy with a short direct explanation.
- Reader role, prior knowledge, interests, and familiar contexts may appear only in
  a local, optional analogy adjacent to the relevant term explanation. Never use a
  role/profile analogy as the article opener or global frame. Never write "as a X,
  you understand/know/value/prefer/believe/care..." or otherwise infer the reader's
  values, attitudes, opinions, emotions, preferences, or actual knowledge from the
  profile. Rewrite such language non-assumptively ("One way to think about X is ...").
- For `misplaced_opener`, delete the role-based lead or replace it with a neutral,
  goal-aligned cue. If its comparison remains useful, relocate a compact version next
  to the matching term explanation; do not preserve the personal assumption.
- For a failed analogy/personification, preserve source semantic roles. Do not make
  an organ, institution, treatment, or abstract concept perform a person's action,
  hold a preference, form an intention, or receive a benefit assigned to another
  entity. Keep an established protagonist/villain/helper mapping coherent. Use
  schema support ID `GS_A_001` for these patches.
- Do not delete all explanation to satisfy analogy-load control. Preserve every
  `protected_primary_span` and ensure each retain_and_explain term keeps one complete
  familiar explanation. In an overloaded paragraph, edit only
  `excess_analogy_spans`: keep the best accurate primary analogy and convert remaining
  figurative wording to short direct explanation without deleting its source claim.
- The EXPLANATION-PROTECTION CONTRACT is a hard gate. If a patch touches a protected
  explanation, list its `term_id` in `term_ids` when it is an active failed IL target,
  otherwise list it in `protected_term_ids`; put the bridge support ID in
  `protected_support_ids` (not `schema_support_ids` unless that schema ID itself
  failed), and retain a non-empty information-equivalent explanation. Keeping only
  the technical term is invalid.
- Passing knowledge bridges and countable cognitive-guidance strategies in the
  protection contract are immutable unless an overlapping active claim/IL repair
  names their support ID in `protected_support_ids` and retains an equivalent passing
  bridge/strategy. Deletion without replacement fails.
- If a patch removes or shortens a protected required/helpful analogy, list its
  support ID and either preserve the same accurate mapping or supply a local direct
  explanation carrying the same information in reader-comprehensible language.
- Output JSON only in this schema. In repair-alignment mode, echo the exact packet_id
  and strategy_scope_id. Use instruction_ids/instruction_scope_ids; multiple IDs on
  one patch are allowed only for packet-declared compatible overlapping instructions.
  Complete self_check in the same response (this does not consume another call):
{{"mode":"repair_alignment","packet_id":"RAP_...","strategy_scope_id":"icl/replace_with_familiar_equivalent","patches":[{{"patch_id":"P01","instruction_ids":["RA-I-001"],"instruction_scope_ids":["icl/replace_with_familiar_equivalent"],"strategy_scope_id":"icl/replace_with_familiar_equivalent","operation":"replace_within_sentence|delete_within_sentence|insert_before_sentence|insert_after_sentence","anchor_sentence":"exact current sentence","target_span":"exact old span or empty for insertion","replacement_text":"local replacement or empty for deletion","source_evidence":"exact source quote; empty only for nonfactual schema support","claim_ids":["C01"],"term_ids":["IL_T001"],"schema_support_ids":[],"protected_term_ids":[],"protected_support_ids":["GS_Q_001"],"reader_language_note":"how B's reader language/register and support treatment are preserved"}}],"self_check":{{"addressed_instruction_ids":["RA-I-001"],"scope_respected":true,"source_evidence_exact":true,"postconditions":[{{"instruction_id":"RA-I-001","expected_satisfied":true,"candidate_evidence":"expected local evidence after applying patch"}}]}}}}

LENGTH STATUS
Current length: {current_words} words. Maximum: {max_words} words.
{"This candidate violates the length cap. Remove at least " + str(current_words - max_words) + " words while retaining the full claim contract." if current_words > max_words else "The candidate is within the length cap; do not add unnecessary text."}

FAILED CLAIM ASSESSMENTS
{json.dumps(failures, ensure_ascii=False, indent=2)}

ACTIVE REPAIR TARGET CONTRACT (the only IDs/spans that may be changed)
{json.dumps(active_repair_targets or {}, ensure_ascii=False, indent=2)}

MATERIAL UNSUPPORTED CANDIDATE CLAIMS
{json.dumps([x for x in validation.get('unsupported_claims', []) if x.get('severity', 'material') == 'material'], ensure_ascii=False, indent=2)}

NONMATERIAL REVIEW FLAGS (do not repair solely for these)
{json.dumps([x for x in validation.get('unsupported_claims', []) if x.get('severity') == 'nonmaterial'], ensure_ascii=False, indent=2)}

PROTECTED PASSING PARAGRAPHS (copy each one exactly)
{json.dumps(protected_paragraphs or [], ensure_ascii=False, indent=2)}

CURRENT MINIMAL-EDIT STATUS
{json.dumps(edit_metrics or {}, ensure_ascii=False, indent=2)}

CURRENT READER-STYLE NON-INFERIORITY STATUS
{json.dumps(style_evaluation or {}, ensure_ascii=False, indent=2)}

IL TERM-TRANSFORMATION CONTRACT
{json.dumps(il_term_contract or [], ensure_ascii=False, indent=2)}

FAILED OR NONCOMPLIANT IL TERM ASSESSMENTS
{json.dumps([
    item for item in (il_evaluation or {}).get('assessments', [])
    if not item.get('meaning_preserved', False)
    or (item.get('hard_required', True) and not item.get('strategy_compliant', False))
], ensure_ascii=False, indent=2)}

SCHEMA-SUPPORT CONTRACT (P_gcl = weighted A_Q guidance + A_B knowledge bridging)
{json.dumps(schema_support_contract or {}, ensure_ascii=False, indent=2)}

FAILED SCHEMA-SUPPORT ASSESSMENTS
{json.dumps({
    "bridges": [
        item for item in (schema_support_evaluation or {}).get("bridges", [])
        if item.get("status") != "adequate"
        or item.get("forced_binding", False)
        or float(item.get("semantic_distance", 0)) > 0.60
        or float(item.get("relational_alignment", 1)) < 0.50
        or float(item.get("explanatory_gain", 1)) < 0.50
    ],
    "guidance": (schema_support_evaluation or {}).get("guidance", {})
    if (schema_support_evaluation or {}).get("guidance", {}).get("status") != "adequate" else {},
    "reader_grounding": (schema_support_evaluation or {}).get("reader_grounding", {})
    if (schema_support_evaluation or {}).get("reader_grounding", {}).get("status") != "adequate" else {},
    "analogies": [item for item in (schema_support_evaluation or {}).get("analogies", []) if item.get("status") != "appropriate"],
    "narrative_mapping": (schema_support_evaluation or {}).get("narrative_mapping", {})
    if (schema_support_evaluation or {}).get("narrative_mapping", {}).get("status") != "adequate" else {},
    "analogy_complexity": [item for item in (schema_support_evaluation or {}).get("analogy_complexity", []) if item.get("status") != "adequate"],
    "protected_support": [
        item for item in (schema_support_evaluation or {}).get("protected_support", [])
        if item.get("status") not in {"preserved", "equivalent_direct_explanation"}
        or not item.get("information_equivalent", False)
        or not item.get("reader_comprehensible", False)
        or not item.get("source_grounded", False)
    ],
    "metrics": (schema_support_evaluation or {}).get("metrics", {}),
}, ensure_ascii=False, indent=2)}

EXPLANATION AND ANALOGY PROTECTION CONTRACT
{json.dumps(explanation_protection_contract or {}, ensure_ascii=False, indent=2)}

FAILED SOURCE CONTRACT ENTRIES
{compact_contract(_failed_contract(contract, validation))}

TARGET-READER CONSTRAINTS (lower priority than fidelity)
{reader_constraints}

SOURCE ARTICLE
{source_text}

CURRENT CANDIDATE
{candidate}

CURRENT CANDIDATE SENTENCE ANCHORS
{json.dumps([value for _, _, value in _sentence_spans(candidate)], ensure_ascii=False, indent=2)}"""


def repair_control_gate(
    validation: dict[str, Any],
    word_count: int,
    max_words: int,
    edit_metrics: dict[str, Any],
    style_evaluation: dict[str, Any],
    policy: FidelityPolicy,
    il_evaluation: dict[str, Any] | None = None,
    schema_support_evaluation: dict[str, Any] | None = None,
    passing_claim_protection: dict[str, Any] | None = None,
    patch_burden: dict[str, int] | None = None,
) -> dict[str, bool]:
    length_forced_ceiling = (
        min(1.0, max_words / edit_metrics["initial_token_count"])
        if edit_metrics["initial_token_count"] else 1.0
    )
    editable_span_ceiling = (
        edit_metrics["non_target_initial_token_count"] / edit_metrics["initial_token_count"]
        if edit_metrics["initial_token_count"] and edit_metrics.get("n_editable_spans", 0)
        else 1.0
    )
    required_non_target_retention = min(
        policy.min_non_target_token_retention, length_forced_ceiling
    )
    required_initial_retention = min(
        policy.min_initial_token_retention, length_forced_ceiling, editable_span_ceiling
    )
    retention_tolerance = 1e-4
    minimal_edit_pass = (
        edit_metrics["initial_token_retention"]
        >= required_initial_retention - retention_tolerance
        and
        edit_metrics["non_target_token_retention"]
        >= required_non_target_retention - retention_tolerance
    )
    protected_pass = (
        not policy.require_all_protected_paragraphs
        or edit_metrics["protected_paragraph_retention"] == 1.0
    )
    style_pass = bool(style_evaluation.get("noninferior", False))
    il_metrics = (il_evaluation or {}).get("metrics", {})
    il_semantic_pass = bool(il_metrics.get("semantic_pass", True))
    il_strategy_pass = bool(il_metrics.get("hard_il_pass", True))
    schema_metrics = (schema_support_evaluation or {}).get("metrics", {})
    schema_support_pass = (
        not schema_support_evaluation
        or (
            float(schema_metrics.get("P_gcl", 1.0)) >= policy.min_schema_support_score
            and float(schema_metrics.get("A_B", 1.0)) >= policy.min_schema_bridging_score
            and float(schema_metrics.get("A_Q", 1.0)) >= policy.min_cognitive_guidance_score
            and bool(schema_metrics.get("guidance_coverage_pass", True))
            and bool(schema_metrics.get("bridge_fit_pass", True))
            and bool(schema_metrics.get("grounding_boundary_pass", True))
            and bool(schema_metrics.get("analogy_semantic_pass", True))
            and bool(schema_metrics.get("narrative_mapping_pass", True))
            and bool(schema_metrics.get("analogy_complexity_pass", True))
            and bool(schema_metrics.get("necessary_explanations_pass", True))
            and bool(schema_metrics.get("analogy_fallback_pass", True))
        )
    )
    claim_fidelity_pass = bool(validation["metrics"]["hard_fidelity_pass"])
    joint_fidelity_pass = claim_fidelity_pass and il_semantic_pass
    passing_claims_pass = bool((passing_claim_protection or {"pass": True}).get("pass"))
    burden_pass = patch_burden_passes(patch_burden or {}, policy)
    return {
        "claim_fidelity_pass": claim_fidelity_pass,
        "il_semantic_pass": il_semantic_pass,
        "fidelity_pass": joint_fidelity_pass,
        "il_strategy_pass": il_strategy_pass,
        "schema_support_pass": schema_support_pass,
        "necessary_explanations_pass": bool(
            schema_metrics.get("necessary_explanations_pass", True)
        ),
        "analogy_fallback_pass": bool(
            schema_metrics.get("analogy_fallback_pass", True)
        ),
        "length_pass": word_count <= max_words,
        "minimal_edit_pass": minimal_edit_pass,
        "protected_paragraphs_pass": protected_pass,
        "passing_claim_sentences_pass": passing_claims_pass,
        "cumulative_patch_burden_pass": burden_pass,
        "reader_style_noninferiority_pass": style_pass,
        "overall_pass": bool(
            joint_fidelity_pass
            and il_strategy_pass
            and schema_support_pass
            and word_count <= max_words
            and minimal_edit_pass
            and protected_pass
            and passing_claims_pass
            and burden_pass
            and style_pass
        ),
    }


def _candidate_rank(
    validation: dict[str, Any],
    word_count: int,
    max_words: int,
    edit_metrics: dict[str, Any],
    style_evaluation: dict[str, Any],
    policy: FidelityPolicy,
    il_evaluation: dict[str, Any] | None = None,
    schema_support_evaluation: dict[str, Any] | None = None,
    passing_claim_protection: dict[str, Any] | None = None,
    patch_burden: dict[str, int] | None = None,
) -> tuple:
    """Deterministic best-candidate ordering when no round reaches the hard gate."""
    m = validation["metrics"]
    controls = repair_control_gate(
        validation, word_count, max_words, edit_metrics, style_evaluation, policy,
        il_evaluation, schema_support_evaluation, passing_claim_protection, patch_burden,
    )
    il_metrics = (il_evaluation or {}).get("metrics", {})
    return (
        int(controls["overall_pass"]),
        int(controls["passing_claim_sentences_pass"]),
        int(controls["cumulative_patch_burden_pass"]),
        int(controls["necessary_explanations_pass"]),
        int(controls["analogy_fallback_pass"]),
        int(controls["fidelity_pass"] and controls["il_strategy_pass"] and controls["schema_support_pass"] and word_count <= max_words),
        m["critical_claim_recall"],
        m["core_claim_recall"],
        -m["n_contradicted"],
        -m["n_material_alteration"],
        -m["n_unsupported_claims"],
        -int(il_metrics.get("n_semantic_failures", 0)),
        -int(il_metrics.get("n_unsupported_introduced_propositions", 0)),
        -int(il_metrics.get("n_required_strategy_failures", 0)),
        float((schema_support_evaluation or {}).get("metrics", {}).get("P_gcl", 1.0)),
        int(controls["minimal_edit_pass"]),
        int(controls["protected_paragraphs_pass"]),
        int(controls["reader_style_noninferiority_pass"]),
        edit_metrics["initial_token_retention"],
        int(word_count <= max_words),
        -max(0, word_count - max_words),
    )


def claim_regressions(
    previous: dict[str, Any], current: dict[str, Any]
) -> list[str]:
    """Return claims that were preserved before an edit but fail afterwards."""
    before = {
        item["claim_id"]: item["verdict"]
        for item in previous.get("assessments", [])
    }
    return sorted(
        item["claim_id"]
        for item in current.get("assessments", [])
        if before.get(item["claim_id"]) in FULLY_PRESERVED
        and item.get("verdict") not in FULLY_PRESERVED
    )


def failed_claim_targets(validation: dict[str, Any]) -> dict[str, list[str]]:
    """Map only failed claim IDs to their editable candidate spans."""
    return {
        str(item["claim_id"]): [str(item.get("candidate_span", "")).strip()]
        if str(item.get("candidate_span", "")).strip() else []
        for item in validation.get("assessments", [])
        if item.get("verdict") not in FULLY_PRESERVED
    }


def failed_il_targets(
    evaluation: dict[str, Any], candidate: str | None = None
) -> dict[str, list[str]]:
    """Map only failed IL term IDs to their observed or introduced spans."""
    targets: dict[str, list[str]] = {}
    for item in evaluation.get("assessments", []):
        failed = bool(
            not item.get("meaning_preserved", False)
            or (
                item.get("hard_required", True)
                and not item.get("strategy_compliant", False)
            )
        )
        bad_propositions = [
            proposition
            for proposition in item.get("introduced_propositions", [])
            if proposition.get("verdict") in {
                "unsupported_material", "inappropriate_inference",
                "redundant_restatement", "excessive_supported_detail",
            }
        ]
        if not failed and not bad_propositions:
            continue
        spans = [str(item.get("observed_span", "")).strip()] + [
            str(value.get("candidate_span", "")).strip()
            for value in bad_propositions
        ]
        unique_spans = list(dict.fromkeys(value for value in spans if value))
        if candidate is not None:
            unique_spans = [
                value for value in unique_spans
                if value in candidate or _surface_equivalent_ranges(candidate, value)
            ]
            source_term = str(item.get("source_term", "")).strip()
            if (
                not unique_spans
                and source_term
                and (
                    source_term in candidate
                    or _surface_equivalent_ranges(candidate, source_term)
                )
            ):
                unique_spans = [source_term]
            if not unique_spans and not bool(item.get("hard_required", True)):
                # Optional lexical treatment with no candidate-grounded locator
                # cannot authorize an insertion or a broad edit.  The strategy
                # realization audit separately records it as a safe omission.
                continue
        targets[str(item["term_id"])] = unique_spans
    return targets


def repair_target_contract(
    validation: dict[str, Any],
    il_evaluation: dict[str, Any] | None,
    schema_evaluation: dict[str, Any] | None,
    controls: dict[str, bool],
    policy: FidelityPolicy,
    candidate: str | None = None,
) -> dict[str, Any]:
    """Build disjoint per-dimension allow-lists for one repair round."""
    schema_targets = (
        failed_schema_support_targets(
            schema_evaluation or {},
            policy.min_schema_bridging_score,
            policy.min_cognitive_guidance_score,
        )
        if schema_evaluation and not controls.get("schema_support_pass", True)
        else {}
    )
    return {
        "claim": failed_claim_targets(validation),
        "il": failed_il_targets(il_evaluation or {}, candidate),
        "schema": schema_targets,
        "failed_schema_support_ids": sorted(schema_targets),
        "allowed_schema_support_ids": sorted(schema_targets),
        "unsupported_spans": [
            str(item.get("candidate_span", "")).strip()
            for item in validation.get("unsupported_claims", [])
            if item.get("severity", "material") == "material"
            and str(item.get("candidate_span", "")).strip()
        ],
        "schema_pass_through": bool(controls.get("schema_support_pass", True)),
    }


def schema_support_nonregression(
    previous: dict[str, Any] | None,
    current: dict[str, Any] | None,
    tolerance: float = 1e-4,
) -> dict[str, Any]:
    """Enforce monotone GCL scores and preserve every passing schema hard gate."""
    if not previous or not current:
        return {
            "pass": True,
            "score_regressions": [],
            "hard_gate_regressions": [],
            "before": {},
            "after": {},
        }
    before = previous.get("metrics", {})
    after = current.get("metrics", {})
    score_regressions = []
    for key in SCHEMA_NONREGRESSION_SCORES:
        if key not in before or key not in after:
            continue
        old_value = float(before[key])
        new_value = float(after[key])
        if new_value < old_value - tolerance:
            score_regressions.append({
                "metric": key,
                "before": old_value,
                "after": new_value,
                "delta": round(new_value - old_value, 4),
            })
    hard_gate_regressions = [
        key for key in SCHEMA_HARD_GATE_KEYS
        if bool(before.get(key, False)) and not bool(after.get(key, True))
    ]
    return {
        "pass": not score_regressions and not hard_gate_regressions,
        "score_regressions": score_regressions,
        "hard_gate_regressions": hard_gate_regressions,
        "before": {key: before.get(key) for key in SCHEMA_NONREGRESSION_SCORES},
        "after": {key: after.get(key) for key in SCHEMA_NONREGRESSION_SCORES},
    }


def joint_repair_nonregression(
    previous_validation: dict[str, Any],
    current_validation: dict[str, Any],
    previous_il: dict[str, Any] | None,
    current_il: dict[str, Any] | None,
    previous_schema: dict[str, Any] | None,
    current_schema: dict[str, Any] | None,
) -> dict[str, Any]:
    """Hard acceptance gate preventing cross-dimensional repair regressions."""
    claim_failures = claim_regressions(previous_validation, current_validation)
    before_claim = previous_validation.get("metrics", {})
    after_claim = current_validation.get("metrics", {})
    claim_metric_regressions: list[dict[str, Any]] = []
    for key in ("critical_claim_recall", "core_claim_recall"):
        if key in before_claim and key in after_claim:
            old_value = float(before_claim[key])
            new_value = float(after_claim[key])
            if new_value < old_value - 1e-4:
                claim_metric_regressions.append({
                    "metric": key, "before": old_value, "after": new_value,
                })
    for key in ("n_contradicted", "n_material_alteration", "n_unsupported_claims"):
        if key in before_claim and key in after_claim:
            old_value = int(before_claim[key])
            new_value = int(after_claim[key])
            if new_value > old_value:
                claim_metric_regressions.append({
                    "metric": key, "before": old_value, "after": new_value,
                })
    claim_hard_gate_regressions = []
    if (
        bool(before_claim.get("hard_fidelity_pass", False))
        and not bool(after_claim.get("hard_fidelity_pass", True))
    ):
        claim_hard_gate_regressions.append("hard_fidelity_pass")

    before_il = (previous_il or {}).get("metrics", {})
    after_il = (current_il or {}).get("metrics", {})
    il_regressions: list[dict[str, Any] | str] = []
    for key in ("semantic_pass", "hard_il_pass"):
        if bool(before_il.get(key, False)) and not bool(after_il.get(key, True)):
            il_regressions.append(key)
    for key in (
        "n_semantic_failures",
        "n_unsupported_introduced_propositions",
        "n_required_strategy_failures",
    ):
        if key in before_il and key in after_il:
            old_value = int(before_il[key])
            new_value = int(after_il[key])
            if new_value > old_value:
                il_regressions.append({
                    "metric": key, "before": old_value, "after": new_value,
                })

    schema_gate = schema_support_nonregression(previous_schema, current_schema)
    passed = not (
        claim_failures
        or claim_metric_regressions
        or claim_hard_gate_regressions
        or il_regressions
        or not schema_gate["pass"]
    )
    return {
        "method": SHEMA_SUPPORT_ICL_CLAP_METHOD,
        "pass": passed,
        "regressed_claim_ids": claim_failures,
        "claim_metric_regressions": claim_metric_regressions,
        "claim_hard_gate_regressions": claim_hard_gate_regressions,
        "il_regressions": il_regressions,
        "schema_support": schema_gate,
    }


def _claim_target_state(
    evaluation: dict[str, Any], target_id: str,
) -> tuple[bool, float]:
    verdict_rank = {
        "contradicted": 0.0,
        "material_alteration": 0.5,
        "omitted": 1.0,
        "partial_coverage": 2.0,
        "entailed_via_approved_simplification": 3.0,
        "entailed_exact": 3.0,
    }
    item = next(
        (value for value in evaluation.get("assessments", [])
         if str(value.get("claim_id")) == target_id),
        {},
    )
    verdict = str(item.get("verdict", "contradicted"))
    score = verdict_rank.get(verdict, 0.0) - 0.01 * len(item.get("failed_slots", []))
    return verdict in FULLY_PRESERVED, score


def _il_target_state(
    evaluation: dict[str, Any] | None, target_id: str,
) -> tuple[bool, float]:
    item = next(
        (value for value in (evaluation or {}).get("assessments", [])
         if str(value.get("term_id")) == target_id),
        {},
    )
    meaning = bool(item.get("meaning_preserved", False))
    strategy = bool(
        item.get("strategy_compliant", False)
        or not item.get("hard_required", True)
    )
    bad_introductions = sum(
        proposition.get("verdict") in {
            "unsupported_material", "inappropriate_inference",
            "redundant_restatement", "excessive_supported_detail",
        }
        for proposition in item.get("introduced_propositions", [])
    )
    return meaning and strategy and not bad_introductions, (
        float(meaning) + float(strategy) - 0.1 * bad_introductions
    )


def _schema_target_state(
    evaluation: dict[str, Any] | None, target_id: str,
) -> tuple[bool, float]:
    value = evaluation or {}
    for item in value.get("bridges", []):
        if str(item.get("support_id")) != target_id:
            continue
        score = (
            sum(float(item.get(key, 0)) for key in (
                "coverage", "accuracy", "familiarity", "mapping_completeness",
                "relational_alignment", "explanatory_gain",
            ))
            + 1.0 - float(item.get("semantic_distance", 1))
        ) / 7
        passed = bool(
            item.get("status") == "adequate"
            and not item.get("forced_binding", False)
            and float(item.get("semantic_distance", 0)) <= 0.60
            and float(item.get("relational_alignment", 1)) >= 0.50
            and float(item.get("explanatory_gain", 1)) >= 0.50
        )
        return passed, score
    metrics = value.get("metrics", {})
    guidance = value.get("guidance", {})
    if target_id == str(guidance.get("support_id", "GS_Q_001")):
        return bool(metrics.get("guidance_coverage_pass", False)), float(
            metrics.get("A_Q", 0)
        )
    grounding = value.get("reader_grounding", {})
    if target_id == str(grounding.get("support_id", "GS_R_001")):
        passed = bool(metrics.get("grounding_boundary_pass", False))
        return passed, float(passed)
    analogy_ids = {
        str(item.get("support_id", "GS_A_001"))
        for item in value.get("analogies", []) + value.get("analogy_complexity", [])
    } | {"GS_A_001"}
    if target_id in analogy_ids:
        keys = (
            "analogy_semantic_pass", "narrative_mapping_pass",
            "analogy_complexity_pass", "analogy_fallback_pass",
        )
        passed_count = sum(bool(metrics.get(key, True)) for key in keys)
        return passed_count == len(keys), passed_count / len(keys)
    for item in value.get("protected_support", []):
        if str(item.get("support_id")) == target_id:
            passed = bool(
                item.get("status") in {"preserved", "equivalent_direct_explanation"}
                and item.get("information_equivalent", False)
                and item.get("reader_comprehensible", False)
                and item.get("source_grounded", False)
            )
            return passed, float(passed)
    return False, 0.0


def repair_target_improvement(
    patch_application: dict[str, Any],
    previous_validation: dict[str, Any],
    current_validation: dict[str, Any],
    previous_il: dict[str, Any] | None,
    current_il: dict[str, Any] | None,
    previous_schema: dict[str, Any] | None,
    current_schema: dict[str, Any] | None,
    tolerance: float = 1e-4,
) -> dict[str, Any]:
    """Require each touched objective namespace to resolve a failed target."""
    touched_unsupported = sorted({
        str(value)
        for patch in patch_application.get("patches", [])
        for value in patch.get("touched_unsupported_spans", [])
        if str(value)
    })
    identifiers = {
        "claim": sorted({
            str(value) for patch in patch_application.get("patches", [])
            for value in patch.get("claim_ids", []) if str(value)
        }),
        "il": sorted({
            str(value) for patch in patch_application.get("patches", [])
            for value in patch.get("term_ids", []) if str(value)
        }),
        "schema": sorted({
            str(value) for patch in patch_application.get("patches", [])
            for value in patch.get("schema_support_ids", []) if str(value)
        }),
    }
    state_functions = {
        "claim": (
            lambda target: _claim_target_state(previous_validation, target),
            lambda target: _claim_target_state(current_validation, target),
        ),
        "il": (
            lambda target: _il_target_state(previous_il, target),
            lambda target: _il_target_state(current_il, target),
        ),
        "schema": (
            lambda target: _schema_target_state(previous_schema, target),
            lambda target: _schema_target_state(current_schema, target),
        ),
    }
    namespaces: dict[str, Any] = {}
    for namespace, target_ids in identifiers.items():
        details = []
        for target_id in target_ids:
            before_pass, before_score = state_functions[namespace][0](target_id)
            after_pass, after_score = state_functions[namespace][1](target_id)
            improved = bool(
                (not before_pass and after_pass)
                or after_score > before_score + tolerance
            )
            details.append({
                "target_id": target_id,
                "before_pass": before_pass, "after_pass": after_pass,
                "before_score": round(before_score, 4),
                "after_score": round(after_score, 4),
                "improved": improved,
            })
        if namespace == "claim" and touched_unsupported:
            before_unsupported = [
                item for item in previous_validation.get("unsupported_claims", [])
                if item.get("severity", "material") == "material"
            ]
            after_unsupported = [
                item for item in current_validation.get("unsupported_claims", [])
                if item.get("severity", "material") == "material"
            ]
            improved = len(after_unsupported) < len(before_unsupported)
            details.append({
                "target_id": "UNSUPPORTED_CONTENT",
                "target_spans": touched_unsupported,
                "before_count": len(before_unsupported),
                "after_count": len(after_unsupported),
                "improved": improved,
            })
        namespaces[namespace] = {
            "target_ids": target_ids,
            "touched_unsupported_spans": (
                touched_unsupported if namespace == "claim" else []
            ),
            "pass": (
                not target_ids
                and not (namespace == "claim" and touched_unsupported)
            ) or any(item["improved"] for item in details),
            "details": details,
        }
    return {
        "pass": all(item["pass"] for item in namespaces.values()),
        "namespaces": namespaces,
    }


def repair_alignment_improvement(
    packet: dict[str, Any],
    target_resolution: dict[str, Any],
) -> dict[str, Any]:
    """Require every selected alignment instruction to improve its own target."""
    resolved: list[dict[str, Any]] = []
    namespaces = target_resolution.get("namespaces", {})
    for instruction in packet.get("instructions", []):
        module = str(instruction.get("module", ""))
        target_id = str(instruction.get("target_id", ""))
        if module == "length":
            detail = target_resolution.get("length", {})
            resolved.append({
                "instruction_id": str(instruction.get("instruction_id", "")),
                "module": module,
                "target_id": target_id,
                "improved": bool(detail.get("improved")),
                "evaluator_detail": detail,
            })
            continue
        namespace = {
            "fidelity": "claim",
            "icl": "il",
            "gcl_schema_support": "schema",
        }.get(module, "")
        detail_id = "UNSUPPORTED_CONTENT" if target_id.startswith("unsupported:") else target_id
        details = (namespaces.get(namespace, {}) or {}).get("details", [])
        detail = next(
            (value for value in details if str(value.get("target_id", "")) == detail_id),
            None,
        )
        resolved.append({
            "instruction_id": str(instruction.get("instruction_id", "")),
            "module": module,
            "target_id": target_id,
            "improved": bool(detail and detail.get("improved")),
            "evaluator_detail": detail or {},
        })
    return {
        "pass": bool(resolved) and all(item["improved"] for item in resolved),
        "instructions": resolved,
    }


def validate_and_repair(
    source_text: str,
    candidate: str,
    contract: list[dict[str, Any]],
    llm_call: Callable[..., str],
    count_words: Callable[[str], int],
    extract_content: Callable[[str], str],
    max_words: int,
    policy: FidelityPolicy | None = None,
    reader_constraints: str = "",
    il_term_contract: list[dict[str, Any]] | None = None,
    schema_support_contract: dict[str, Any] | None = None,
    strategy_execution_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run claim, IL, and schema-support validation with bounded local repair."""
    policy = policy or FidelityPolicy()
    il_term_contract = il_term_contract or []
    schema_support_contract = schema_support_contract or {}
    explanation_protection_contract: dict[str, Any] = {}
    initial_candidate = extract_content(candidate)
    current = initial_candidate
    history: list[dict[str, Any]] = []
    patch_history: list[dict[str, Any]] = []
    ever_regressed: set[str] = set()
    protected_paragraphs: list[str] = []
    passing_claim_templates: list[dict[str, Any]] = []
    initial_editable_spans: list[str] = []
    best: tuple[Any, ...] | None = None
    prevalidated: tuple[
        dict[str, Any], dict[str, Any], dict[str, Any] | None
    ] | None = None

    attempted_repair_counts = {kind: 0 for kind in REPAIR_KINDS}
    total_round_limit = min(
        sum(repair_budget(policy).values()), policy.max_total_repair_attempts
    )
    for round_index in range(total_round_limit + 1):
        if prevalidated is not None:
            validation, il_evaluation, schema_support_evaluation = prevalidated
            prevalidated = None
        else:
            validation = validate_candidate(
                source_text, current, contract, llm_call, policy
            )
            il_evaluation = validate_il_compliance(
                source_text,
                current,
                il_term_contract,
                validation,
                llm_call,
            )
            schema_support_evaluation = (
                evaluate_schema_support(
                    source_text, current, schema_support_contract, validation, llm_call,
                    explanation_protection_contract,
                ) if schema_support_contract else None
            )
        il_failed = failed_il_spans(il_evaluation)
        schema_failed = failed_schema_support_spans(schema_support_evaluation or {})
        if round_index == 0:
            explanation_protection_contract = build_explanation_protection_contract(
                current, schema_support_evaluation or {}
            )
            editable_support_spans = list(dict.fromkeys(il_failed + schema_failed))
            protected_paragraphs = protected_passing_paragraphs(
                current, validation, editable_support_spans
            )
            initial_editable_spans = list(dict.fromkeys(
                [
                    str(item.get("candidate_span", "")).strip()
                    for item in validation.get("unsupported_claims", [])
                    if item.get("severity") == "material"
                    and str(item.get("candidate_span", "")).strip()
                ]
                + [
                    str(item.get("candidate_span", "")).strip()
                    for item in validation.get("assessments", [])
                    if item.get("verdict") not in FULLY_PRESERVED
                    and str(item.get("candidate_span", "")).strip()
                ]
                + il_failed
                + schema_failed
            ))
            passing_claim_templates = passing_claim_protection_templates(
                current, validation, editable_support_spans
            )
        elif schema_support_evaluation:
            # Promote every newly passing bridge/guidance span to the protection
            # contract before planning another edit.  The just-completed evaluation
            # already checked equivalence against the prior contract.
            explanation_protection_contract = build_explanation_protection_contract(
                current, schema_support_evaluation
            )
        words = count_words(current)
        edit_metrics = minimal_edit_metrics(
            initial_candidate, current, protected_paragraphs, initial_editable_spans
        )
        style_evaluation = evaluate_reader_style_noninferiority(
            initial_candidate,
            current,
            reader_constraints,
            llm_call,
            policy.reader_style_margin,
        )
        claim_protection = evaluate_passing_claim_protection(
            current, passing_claim_templates
        )
        burden = cumulative_patch_burden(patch_history)
        controls = repair_control_gate(
            validation, words, max_words, edit_metrics, style_evaluation, policy,
            il_evaluation, schema_support_evaluation, claim_protection, burden,
        )
        strategy_execution_audit = build_strategy_realization_audit(
            candidate=current,
            claim_contract=contract,
            strategy_execution_contract=strategy_execution_contract,
            claim_validation=validation,
            il_evaluation=il_evaluation,
            schema_evaluation=schema_support_evaluation or {},
            ecl_score=None,
        )
        audit_modules = strategy_execution_audit.get("modules", {}) or {}
        missing_icl = [
            value for value in (audit_modules.get("icl", {}) or {}).get("targets", [])
            if value.get(
                "release_blocking_target",
                not value.get("executed", False),
            )
        ]
        missing_gcl = [
            value for value in (audit_modules.get("gcl", {}) or {}).get("targets", [])
            if not value.get("executed", False)
        ]
        if missing_icl or missing_gcl:
            # Only release-blocking ICL failures enter Repair.  A safe optional,
            # unlinked strategy miss remains visible in the realization audit as
            # ``advisory_miss`` but cannot consume Repair budget or block release.
            # Namespace ownership is retained: ICL failures may only enter ICL;
            # GCL omissions only schema.
            controls = dict(controls)
            if missing_icl:
                controls["il_strategy_pass"] = False
            if missing_gcl:
                controls["schema_support_pass"] = False
            controls["strategy_execution_pass"] = False
            controls["overall_pass"] = False
        else:
            controls = {**controls, "strategy_execution_pass": True}
        active_targets = repair_target_contract(
            validation,
            il_evaluation,
            schema_support_evaluation,
            controls,
            policy,
            current,
        )
        for value in missing_icl:
            target_id = str(value.get("target_id", ""))
            evidence = str(value.get("evidence", "")).strip()
            if not evidence:
                requirement = next(
                    (
                        item for item in (strategy_execution_contract or {})
                        .get("icl", {}).get("term_actions", [])
                        if str(item.get("term_id", "")) == target_id
                    ),
                    {},
                )
                source_term = str(requirement.get("source_term", "")).strip()
                evidence = source_term if source_term and source_term in current else ""
            active_targets["il"].setdefault(target_id, [])
            if evidence and evidence not in active_targets["il"][target_id]:
                active_targets["il"][target_id].append(evidence)

        gcl_execution = (strategy_execution_contract or {}).get("gcl", {}) or {}
        planned_gcl = {
            str(value.get("support_id", "")): value
            for value in gcl_execution.get("planned_bridge_targets", []) or []
            if isinstance(value, dict) and str(value.get("support_id", ""))
        }
        planned_guidance = gcl_execution.get("planned_guidance_target", {}) or {}
        if isinstance(planned_guidance, dict) and str(
            planned_guidance.get("support_id", "")
        ):
            planned_gcl[str(planned_guidance["support_id"])] = planned_guidance
        sentence_values = [value for _, _, value in _sentence_spans(current)]
        for value in missing_gcl:
            target_id = str(value.get("target_id", ""))
            evidence = str(value.get("evidence", "")).strip()
            plan = planned_gcl.get(target_id, {})
            if not evidence and sentence_values:
                concept = str(plan.get("concept", "")).strip().casefold()
                evidence = next(
                    (
                        sentence for sentence in sentence_values
                        if concept and concept in sentence.casefold()
                    ),
                    sentence_values[0],
                )
            active_targets["schema"].setdefault(target_id, [])
            if evidence and evidence not in active_targets["schema"][target_id]:
                active_targets["schema"][target_id].append(evidence)
        active_targets["failed_schema_support_ids"] = sorted(active_targets["schema"])
        active_targets["allowed_schema_support_ids"] = sorted(active_targets["schema"])
        active_targets["schema_pass_through"] = not bool(active_targets["schema"])
        record = {
            "round": round_index,
            "stage": "initial_validation" if round_index == 0 else "post_repair_validation",
            "word_count": words,
            "candidate_sha256": hashlib.sha256(current.encode("utf-8")).hexdigest(),
            "candidate_content": current,
            "minimal_edit": edit_metrics,
            "reader_style": style_evaluation,
            "il_compliance": il_evaluation,
            "schema_support": schema_support_evaluation,
            "explanation_protection_contract": explanation_protection_contract,
            "passing_claim_protection": claim_protection,
            "cumulative_patch_burden": burden,
            "control_gate": controls,
            "strategy_execution_audit": strategy_execution_audit,
            "active_repair_targets": active_targets,
            **validation,
        }
        if history:
            regressed = claim_regressions(history[-1], validation)
            record["regressed_claim_ids"] = regressed
            ever_regressed.update(regressed)
        else:
            record["regressed_claim_ids"] = []
        history.append(record)
        rank = _candidate_rank(
            validation, words, max_words, edit_metrics, style_evaluation, policy,
            il_evaluation, schema_support_evaluation, claim_protection, burden,
        )
        if best is None or rank > best[0]:
            best = (
                rank, current, validation, words, edit_metrics, style_evaluation,
                il_evaluation, schema_support_evaluation, controls, claim_protection, burden
            )

        if controls["overall_pass"]:
            usage = repair_usage_summary(policy, patch_history)
            distinct_candidates = len({
                item["candidate_sha256"] for item in history
            })
            return {
                "method": SHEMA_SUPPORT_ICL_CLAP_METHOD,
                "final_content": current,
                "analysis_content": current,
                "release_content": current,
                "release_ready": True,
                "release_block_reasons": [],
                "status": "passed_without_repair" if round_index == 0 else "passed_after_repair",
                "repair_rounds_used": usage["total_accepted"],
                "post_repair_validations": max(0, distinct_candidates - 1),
                "repair_attempts_used": usage["total_attempts"],
                "accepted_repair_rounds": usage["total_accepted"],
                "repair_usage": usage,
                "ever_regressed_claim_ids": sorted(ever_regressed),
                "selected_validation": validation,
                "selected_minimal_edit": edit_metrics,
                "selected_reader_style": style_evaluation,
                "selected_il_compliance": il_evaluation,
                "schema_support_contract": schema_support_contract,
                "strategy_execution_contract": strategy_execution_contract or {},
                "explanation_protection_contract": explanation_protection_contract,
                "selected_schema_support": schema_support_evaluation,
                "selected_passing_claim_protection": claim_protection,
                "selected_cumulative_patch_burden": burden,
                "il_term_contract": il_term_contract,
                "selected_control_gate": controls,
                "protected_passing_paragraphs": protected_paragraphs,
                "passing_claim_protection_templates": passing_claim_templates,
                "patch_history": patch_history,
                "history": history,
            }

        planner_calls_used = sum(
            int(item.get("patch_plan_calls", 0)) for item in patch_history
        )
        if planner_calls_used >= policy.max_total_repair_attempts:
            history[-1]["repair_decision"] = {
                "repair_kind": "",
                "triggered_by": [],
                "attempts_used_before": planner_calls_used,
                "budget_limit": policy.max_total_repair_attempts,
                "remaining_before": 0,
                "exhausted_triggered_kinds": [],
                "stopped_reason": "total_repair_attempt_budget_exhausted",
            }
            break
        repair_decision = select_repair_strategy(
            controls, il_evaluation, attempted_repair_counts, policy
        )
        history[-1]["repair_decision"] = repair_decision
        repair_kind = str(repair_decision["repair_kind"])
        if not repair_kind:
            break
        attempted_repair_counts[repair_kind] += 1

        repair_alignment_packet = None
        if strategy_execution_contract:
            repair_alignment_packet = build_repair_alignment_packet(
                repair_kind=repair_kind,
                triggered_by=list(repair_decision.get("triggered_by", [])),
                active_targets=active_targets,
                claim_contract=contract,
                validation=validation,
                il_term_contract=il_term_contract,
                il_evaluation=il_evaluation,
                schema_evaluation=schema_support_evaluation,
                strategy_execution_contract=strategy_execution_contract,
                max_instructions=policy.max_patches_per_round,
            )
            repair_alignment_packet = attach_repair_alignment_scope(
                repair_alignment_packet,
                current,
                explanation_protection_contract,
                contract,
            )
            if not repair_alignment_packet["selected_instruction_ids"]:
                history[-1]["repair_decision"] = {
                    **repair_decision,
                    "stopped_reason": "no_executable_repair_alignment_targets",
                }
                break
            if not repair_alignment_packet.get("scope_ready", False):
                history[-1]["repair_decision"] = {
                    **repair_decision,
                    "stopped_reason": "repair_alignment_target_scope_not_executable",
                    "blocked_instruction_ids": repair_alignment_packet.get(
                        "blocked_instruction_ids", []
                    ),
                }
                history[-1]["repair_alignment_packet"] = repair_alignment_packet
                break
            history[-1]["repair_alignment_packet"] = repair_alignment_packet

        prompt = sentence_patch_prompt(
                source_text,
                current,
                contract,
                validation,
                max_words,
                count_words(current),
                reader_constraints,
                protected_paragraphs,
                edit_metrics,
                style_evaluation,
                il_term_contract,
                il_evaluation,
                schema_support_contract,
                schema_support_evaluation,
                explanation_protection_contract,
                active_targets,
                policy.min_initial_token_retention,
                policy.min_non_target_token_retention,
                policy.reader_style_margin,
                repair_kind,
                repair_alignment_packet,
            )
        application: dict[str, Any] | None = None
        patch_errors: list[str] = []
        rejected_patch_objects: list[dict[str, Any]] = []
        patch_plan_calls = 0
        remaining_plan_calls = max(
            0, policy.max_total_repair_attempts - planner_calls_used
        )
        for patch_attempt in range(min(
            policy.max_patch_plan_attempts_per_round, remaining_plan_calls
        )):
            candidate_application: dict[str, Any] | None = None
            patch_object: dict[str, Any] | None = None
            retry_prompt = prompt if patch_attempt == 0 else (
                prompt
                + "\nSTRUCTURED REPAIR RESPONSE REJECTION\n"
                + json.dumps(
                    {
                        "machine_rejection": normalize_patch_rejection(
                            patch_errors[-1]
                        ),
                        "prior_response": (
                            rejected_patch_objects[-1]
                            if rejected_patch_objects else {}
                        ),
                        "retry_rule": (
                            "Reuse the exact packet_id, strategy_scope_id, selected "
                            "instruction_ids and target scope. Correct only the rejected "
                            "field; return one corrected JSON object."
                        ),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            try:
                patch_plan_calls += 1
                patch_object = _json_object(
                    _json_llm_response(llm_call, retry_prompt, max_tokens=3200)
                )
                candidate_application = apply_sentence_patches(
                    current,
                    source_text,
                    patch_object,
                    protected_paragraphs,
                    policy,
                    set(active_targets["claim"]),
                    set(active_targets["il"]),
                    set(active_targets["allowed_schema_support_ids"]),
                    repair_kind,
                    passing_claim_templates,
                    contract,
                    explanation_protection_contract,
                    active_targets,
                    repair_alignment_packet,
                )
                proposed_burden = cumulative_patch_burden(
                    patch_history, candidate_application
                )
                if not patch_burden_passes(proposed_burden, policy):
                    raise ValueError(
                        "cumulative patch burden hard gate exceeded: "
                        + json.dumps(proposed_burden, sort_keys=True)
                    )
                candidate_application["cumulative_patch_burden"] = proposed_burden
                candidate_application["repair_kind"] = repair_kind
                candidate_application["attempt"] = patch_attempt + 1
                proposed_content = str(candidate_application["content"])
                new_repetitions = introduced_sentence_repetitions(
                    current, proposed_content
                )
                if new_repetitions:
                    raise ValueError(
                        "repair introduced substantive sentence repetition: "
                        + json.dumps(new_repetitions, ensure_ascii=False)
                    )
                if callable(REPAIR_PROPOSAL_EVALUATOR):
                    (
                        proposed_validation,
                        proposed_il_evaluation,
                        proposed_schema_evaluation,
                    ) = REPAIR_PROPOSAL_EVALUATOR(
                        source_text=source_text,
                        previous_content=current,
                        proposed_content=proposed_content,
                        claim_contract=contract,
                        previous_validation=validation,
                        il_term_contract=il_term_contract,
                        previous_il_evaluation=il_evaluation,
                        schema_support_contract=schema_support_contract,
                        previous_schema_evaluation=schema_support_evaluation,
                        explanation_protection_contract=explanation_protection_contract,
                        active_targets=active_targets,
                        candidate_application=candidate_application,
                        llm_call=llm_call,
                        policy=policy,
                    )
                else:
                    proposed_validation = validate_candidate(
                        source_text, proposed_content, contract, llm_call, policy
                    )
                    proposed_il_evaluation = validate_il_compliance(
                        source_text,
                        proposed_content,
                        il_term_contract,
                        proposed_validation,
                        llm_call,
                    )
                    proposed_schema_evaluation = (
                        evaluate_schema_support(
                            source_text,
                            proposed_content,
                            schema_support_contract,
                            proposed_validation,
                            llm_call,
                            explanation_protection_contract,
                        ) if schema_support_contract else None
                    )
                nonregression = joint_repair_nonregression(
                    validation,
                    proposed_validation,
                    il_evaluation,
                    proposed_il_evaluation,
                    schema_support_evaluation,
                    proposed_schema_evaluation,
                )
                if not nonregression["pass"]:
                    raise ValueError(
                        "joint claim/IL/schema non-regression hard gate failed: "
                        + json.dumps(nonregression, ensure_ascii=False, sort_keys=True)
                    )
                target_resolution = repair_target_improvement(
                    candidate_application,
                    validation,
                    proposed_validation,
                    il_evaluation,
                    proposed_il_evaluation,
                    schema_support_evaluation,
                    proposed_schema_evaluation,
                )
                target_resolution["length"] = {
                    "before_words": count_words(current),
                    "after_words": count_words(proposed_content),
                    "maximum_words": max_words,
                    "improved": bool(
                        count_words(proposed_content) < count_words(current)
                        and count_words(proposed_content) <= max_words
                    ),
                }
                if not target_resolution["pass"]:
                    raise ValueError(
                        "patch set did not improve a failed target in every touched "
                        "namespace: "
                        + json.dumps(
                            target_resolution, ensure_ascii=False, sort_keys=True
                        )
                    )
                alignment_resolution = (
                    repair_alignment_improvement(
                        repair_alignment_packet, target_resolution
                    ) if repair_alignment_packet else {"pass": True, "instructions": []}
                )
                if not alignment_resolution["pass"]:
                    raise ValueError(
                        "repair alignment did not improve every selected instruction: "
                        + json.dumps(
                            alignment_resolution, ensure_ascii=False, sort_keys=True
                        )
                    )
                candidate_application["joint_nonregression"] = nonregression
                candidate_application["target_resolution"] = target_resolution
                candidate_application["repair_alignment_resolution"] = (
                    alignment_resolution
                )
                prevalidated = (
                    proposed_validation,
                    proposed_il_evaluation,
                    proposed_schema_evaluation,
                )
                application = candidate_application
                break
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                application = None
                patch_errors.append(str(exc))
                if isinstance(patch_object, dict):
                    rejected_patch_objects.append(deepcopy(patch_object))
        patch_record = {
            "round_from": round_index,
            "repair_kind": repair_kind,
            "accepted": application is not None,
            "patch_plan_calls": patch_plan_calls,
            "errors": patch_errors,
            "rejected_patch_objects": rejected_patch_objects,
            "repair_alignment_packet": repair_alignment_packet,
        }
        if application is not None:
            patch_record.update(application)
        patch_history.append(patch_record)
        if application is None:
            # A rejected plan consumes its attempt but not the entire repair loop.
            # Reuse the unchanged evaluations and let the bounded strategy budget
            # select a fresh plan or stop explicitly on the next iteration.
            prevalidated = (
                validation, il_evaluation, schema_support_evaluation,
            )
            continue
        current = str(application["content"])

    assert best is not None
    (
        _, best_content, best_validation, _, best_edit_metrics,
        best_style_evaluation, best_il_evaluation, best_schema_support_evaluation, best_controls,
        best_claim_protection, best_burden,
    ) = best
    block_reasons = [
        key for key, passed in best_controls.items()
        if key != "overall_pass" and not passed
    ]
    usage = repair_usage_summary(policy, patch_history)
    distinct_candidates = len({item["candidate_sha256"] for item in history})
    return {
        "method": SHEMA_SUPPORT_ICL_CLAP_METHOD,
        "final_content": None,
        "analysis_content": best_content,
        "release_content": None,
        "release_ready": False,
        "release_block_reasons": block_reasons,
        "status": "failed_retry_limit",
        "repair_rounds_used": usage["total_accepted"],
        "post_repair_validations": max(0, distinct_candidates - 1),
        "repair_attempts_used": usage["total_attempts"],
        "accepted_repair_rounds": usage["total_accepted"],
        "repair_usage": usage,
        "ever_regressed_claim_ids": sorted(ever_regressed),
        "selected_validation": best_validation,
        "selected_minimal_edit": best_edit_metrics,
        "selected_reader_style": best_style_evaluation,
        "selected_il_compliance": best_il_evaluation,
        "schema_support_contract": schema_support_contract,
        "strategy_execution_contract": strategy_execution_contract or {},
        "explanation_protection_contract": explanation_protection_contract,
        "selected_schema_support": best_schema_support_evaluation,
        "selected_passing_claim_protection": best_claim_protection,
        "selected_cumulative_patch_burden": best_burden,
        "il_term_contract": il_term_contract,
        "selected_control_gate": best_controls,
        "protected_passing_paragraphs": protected_paragraphs,
        "passing_claim_protection_templates": passing_claim_templates,
        "patch_history": patch_history,
        "history": history,
    }
