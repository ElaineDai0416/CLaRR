"""Schema-support contracts, scoring, and audit prompts for CLAP repair.

This module implements the GCL-supporting text-feature evaluation in the method:

    P_gcl(z | x, u) = beta_Q A_Q(z | x, g) + beta_B A_B(z | x, k, i)

``A_B`` is prior-knowledge bridging: whether concepts that require support are
connected accurately, familiarly, and completely to the reader's existing
knowledge.  ``A_Q`` is cognitive-engagement guidance: whether the text provides
coverage and relevance for the reader's reading goal.  These are observable text
support scores, not estimates of a reader's experienced cognitive load.
"""

from __future__ import annotations

import json
from typing import Any, Callable


BRIDGE_FAILURES = {
    "missing", "inaccurate", "unfamiliar", "incomplete_mapping",
    "forced_binding", "misleading_mapping",
}
GUIDANCE_FAILURES = {"missing", "partial", "misaligned", "irrelevant"}
GROUNDING_BOUNDARY_FAILURES = {
    "misplaced_opener",
    "projected_stance",
    "stereotyped_inference",
    "multiple_violations",
}
ANALOGY_FAILURES = {
    "subject_mismatch", "agency_mismatch", "patient_or_beneficiary_mismatch",
    "relation_mismatch", "causal_overreach", "unsupported_mapping",
    "narrative_incoherence",
}
ANALOGY_COMPLEXITY_FAILURES = {
    "overloaded", "mixed_frames", "role_collision", "unfamiliar_scaffold",
}
PROTECTED_SUPPORT_PASS = {"preserved", "equivalent_direct_explanation"}
# R004F adds one judgment per protected explanation/analogy. The former 6k
# completion cap can truncate otherwise valid JSON for long contract packets.
SCHEMA_SUPPORT_MAX_TOKENS = 12000
GOAL_CUES = {
    "entertainment": (
        "source-grounded curiosity, anticipation, narrative payoff, vivid consequence, "
        "or surprising contrast anywhere in the text"
    ),
    "learning": (
        "knowledge-gap framing, advance organization, comparison, self-explanation, "
        "comprehension monitoring, integration, or recap anywhere in the text"
    ),
    "utility": (
        "source-licensed decision relevance, conditional guidance, practical takeaway, "
        "prioritization, application cue, or recap anywhere in the text"
    ),
}
GUIDANCE_STRATEGY_TYPES = {
    "curiosity_or_surprise", "knowledge_gap_or_question", "goal_or_relevance_framing",
    "advance_organizer_or_preview", "attention_cue", "causal_or_process_signposting",
    "comparison_or_contrast_prompt", "self_explanation_prompt",
    "comprehension_checkpoint", "integration_or_connection_prompt",
    "source_licensed_application", "practical_takeaway", "recap_or_summary",
    "narrative_anticipation_or_payoff", "other",
}
GUIDANCE_COGNITIVE_FUNCTIONS = {
    "orient", "activate", "focus", "organize", "elaborate", "monitor",
    "integrate", "apply", "reflect", "summarize", "other",
}
GUIDANCE_LOCATIONS = {"beginning", "middle", "end"}


def _clamp_score(value: Any) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return 0.0


def _profile_values(reader_profile: dict[str, Any]) -> tuple[str, str, list[str]]:
    schema = reader_profile.get("schema", {}) if isinstance(reader_profile, dict) else {}
    persona = reader_profile.get("persona", {}) if isinstance(reader_profile, dict) else {}
    k_value = schema.get("k_reader", "")
    knowledge = {0.2: "novice", 0.5: "intermediate", 0.8: "expert"}.get(
        k_value, str(k_value or "intermediate").lower()
    )
    goal_raw = str(schema.get("reading_motivation", "learning")).lower()
    goal = {
        "analysis": "learning",
        "analytic": "learning",
        "analytical": "learning",
        "analytical_reading": "learning",
        "practice": "utility",
        "practical": "utility",
        "application": "utility",
        "applied": "utility",
    }.get(goal_raw, goal_raw)
    interests = persona.get("interests", [])
    if not isinstance(interests, list):
        interests = [interests]
    contexts = [str(value) for value in interests if str(value).strip()]
    for key in ("field_of_study", "profession", "typical_reading_context"):
        value = str(persona.get(key, "")).strip()
        if value:
            contexts.append(value)
    return knowledge, goal if goal in GOAL_CUES else "learning", list(dict.fromkeys(contexts))


def build_schema_support_contract(
    reader_profile: dict[str, Any],
    il_term_contract: list[dict[str, Any]],
    claim_contract: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Compile GCL support obligations from the reader and IL routing decisions.

    Only Core-Expertise terms routed to ``retain_and_explain`` need a bridge.
    A reliable direct explanation is explicitly allowed: the method forbids
    forcing an analogy when no accurate familiar mapping is available.
    """
    knowledge, goal, contexts = _profile_values(reader_profile)
    claim_index = {
        str(item.get("claim_id", "")): item for item in (claim_contract or [])
    }
    bridges = []
    for term in il_term_contract:
        if term.get("required_action") != "retain_and_explain":
            continue
        linked_claims = [
            claim_index[claim_id]
            for claim_id in term.get("linked_claim_ids", [])
            if claim_id in claim_index
        ]
        bridges.append({
            "support_id": f"GS_B_{term['term_id']}",
            "explanation_contract_id": f"EP_{term['term_id']}",
            "term_id": str(term["term_id"]),
            "concept": str(term.get("source_term", "")),
            "knowledge_level": knowledge,
            "familiar_contexts": contexts,
            "acceptable_support": (
                "a two-step everyday-to-concept bridge or an accurate direct explanation"
                if knowledge == "novice" else
                "a concise domain-adjacent bridge or an accurate direct explanation"
                if knowledge == "intermediate" else
                "a contrastive clarification only when needed, otherwise direct use"
            ),
            "direct_explanation_allowed": True,
            "explanation_protection_rule": (
                "Preserve a complete, source-bounded, reader-comprehensible explanation of the "
                "concept. Wording may change, but the explanation's meaning relation and necessary "
                "information units may not be deleted, weakened, or replaced by an unexplained term."
            ),
            "analogy_fit_rule": (
                "A familiar-domain analogy is acceptable only when its relations or mechanism map "
                "to the concept, the mapping is stated, and it reduces explanation effort. A shared "
                "word, position, shape, or vague theme alone is a forced binding."
            ),
            "linked_claim_ids": list(term.get("linked_claim_ids", [])),
            "linked_claim_context": [
                {
                    "claim_id": str(item.get("claim_id", "")),
                    "proposition": str(item.get("canonical_proposition", "")),
                    "immutable_slots": list(item.get("immutable_slots", [])),
                    "source_evidence": list(item.get("source_evidence", [])),
                }
                for item in linked_claims
            ],
        })
    return {
        "score_name": "P_gcl",
        "weights": {"guidance": 0.5, "bridging": 0.5},
        "reader": {
            "knowledge_level": knowledge,
            "reading_goal": goal,
            "familiar_contexts": contexts,
        },
        "bridges": bridges,
        "guidance": {
            "support_id": "GS_Q_001",
            "reading_goal": goal,
            "goal_aligned_support": GOAL_CUES[goal],
            "coverage_rule": (
                "Count distinct effective cognitive-engagement strategies across the full text. "
                "Each distinct countable strategy type adds positive coverage with diminishing "
                "returns; cognitive functions and locations are diagnostic statistics, not weights."
            ),
            "position_rule": (
                "A strategy may occur at the beginning, middle, or end. No location, including "
                "the opener, is mandatory. Judge whether the rewrite made relevant reader-facing "
                "adaptations, not whether it followed one fixed template."
            ),
            "anti_padding_rule": (
                "Do not reward decorative questions, generic summaries, repeated cues, unsupported "
                "applications, or strategy count that adds cognitive burden."
            ),
        },
        "reader_grounding": {
            "support_id": "GS_R_001",
            "placement_rule": (
                "Use role, prior knowledge, interests, or familiar contexts only as an optional local "
                "analogy adjacent to a relevant term explanation; do not make them the article opener "
                "or the global frame."
            ),
            "stance_rule": (
                "Never claim or imply that the reader knows, understands, values, prefers, believes, "
                "cares about, or identifies with something merely because of their role or profile."
            ),
            "safe_pattern": (
                "Use non-assumptive wording such as 'One way to think about X is ...' and explicitly "
                "map the comparison back to X."
            ),
        },
        "analogy_support": {
            "support_id": "GS_A_001",
            "scope": "all analogies, metaphors, narrative roles, and personification",
            "role_rule": (
                "Preserve source subject, agent, action, patient, beneficiary, causal "
                "direction, and modality; personification cannot transfer agency, "
                "preference, intention, benefit, or causal power to another entity."
            ),
            "continuity_rule": (
                "Keep protagonist, villain, helper, setting, and action mappings stable "
                "within one narrative frame."
            ),
            "complexity_rule": (
                "Prefer one primary frame per paragraph. Multiple roles may extend one "
                "stable story, but stacked independent mechanisms, frame switches, role "
                "collisions, or an unfamiliar scaffold fail."
            ),
            "minimum_sufficient_support_rule": (
                "Every retain_and_explain term keeps one complete familiar explanation. "
                "Protect an accurate useful primary analogy; remove or literalize only "
                "erroneous, redundant, or lower-value figurative spans."
            ),
            "direct_explanation_fallback": True,
            "analogy_deletion_rule": (
                "A required-for-reader or helpful analogy may be removed only when it is erroneous "
                "or lower-value and an information-equivalent, source-grounded, reader-comprehensible "
                "direct explanation remains adjacent to the linked concept."
            ),
        },
    }


def build_explanation_protection_contract(
    candidate: str,
    evaluation: dict[str, Any],
) -> dict[str, Any]:
    """Freeze acceptable explanation meaning without requiring exact wording."""
    explanations = []
    for item in evaluation.get("bridges", []):
        span = str(item.get("candidate_span", "")).strip()
        if item.get("status") != "adequate" or not span or span not in candidate:
            continue
        units = item.get("explanation_information_units", [])
        if not isinstance(units, list):
            units = [units]
        units = [str(value).strip() for value in units if str(value).strip()]
        if not units:
            proposition = str(item.get("explanation_proposition", "")).strip()
            units = [proposition or span]
        explanations.append({
            "contract_id": str(
                item.get("explanation_contract_id")
                or f"EP_{item.get('term_id', item.get('support_id', ''))}"
            ),
            "support_id": str(item.get("support_id", "")),
            "term_id": str(item.get("term_id", "")),
            "concept": str(item.get("concept", "")),
            "protected_explanation_span": span,
            "explanation_proposition": str(
                item.get("explanation_proposition", "")
            ).strip() or span,
            "information_units": units,
            "was_direct_explanation": bool(item.get("uses_direct_explanation", False)),
            "required_outcome": "information_equivalent_and_reader_comprehensible",
        })

    direct_support_ids = {
        str(item.get("support_id", ""))
        for item in evaluation.get("bridges", [])
        if item.get("status") == "adequate"
        and item.get("uses_direct_explanation", False)
    }
    analogies = []
    for item in evaluation.get("analogies", []):
        span = str(item.get("candidate_span", "")).strip()
        value = str(item.get("support_value", "helpful"))
        if (
            item.get("status") != "appropriate"
            or value not in {"required_for_reader", "helpful"}
            or not span
            or span not in candidate
        ):
            continue
        linked = [str(value) for value in item.get("linked_support_ids", []) if str(value)]
        analogies.append({
            "contract_id": f"AP_{item.get('analogy_id', len(analogies) + 1)}",
            "analogy_id": str(item.get("analogy_id", "")),
            "support_id": str(item.get("support_id", "GS_A_001")),
            "protected_analogy_span": span,
            "support_value": value,
            "linked_support_ids": linked,
            "shared_relation": str(item.get("shared_relation", "")),
            "has_existing_direct_explanation": bool(
                linked and all(value in direct_support_ids for value in linked)
            ),
            "required_outcome": "preserved_or_equivalent_direct_explanation",
        })
    knowledge_bridges = [
        {
            "contract_id": item["contract_id"],
            "support_id": item["support_id"],
            "term_id": item["term_id"],
            "protected_bridge_span": item["protected_explanation_span"],
            "required_outcome": item["required_outcome"],
        }
        for item in explanations
    ]
    guidance_strategies = []
    for item in evaluation.get("guidance", {}).get("strategies", []):
        span = str(item.get("candidate_span", "")).strip()
        strategy_type = str(item.get("strategy_type", "other"))
        cognitive_function = str(item.get("cognitive_function", "other"))
        status = str(item.get("status", "weak"))
        relevance = float(item.get("relevance", 0))
        goal_alignment = float(item.get("goal_alignment", 0))
        named_countable = (
            strategy_type != "other"
            and (
                cognitive_function != "other"
                or relevance >= 0.50
                or goal_alignment >= 0.50
            )
        )
        strict_other_countable = (
            strategy_type == "other"
            and status == "effective"
            and cognitive_function != "other"
            and relevance >= 0.50
            and goal_alignment >= 0.50
            and bool(str(item.get("other_strategy_label", "")).strip())
            and bool(str(item.get("reader_cognitive_action", "")).strip())
            and bool(str(item.get("why_not_named_type", "")).strip())
        )
        if (
            not span or span not in candidate or status == "unsupported"
            or not (named_countable or strict_other_countable)
        ):
            continue
        guidance_strategies.append({
            "contract_id": f"GP_{item.get('strategy_id', len(guidance_strategies) + 1)}",
            "support_id": str(
                evaluation.get("guidance", {}).get("support_id", "GS_Q_001")
            ),
            "strategy_id": str(item.get("strategy_id", "")),
            "strategy_type": strategy_type,
            "cognitive_function": cognitive_function,
            "protected_guidance_span": span,
            "required_outcome": "preserved_as_countable_guidance",
        })
    return {
        "schema_version": "clarr-schema-protection-v2",
        "explanations": explanations,
        "knowledge_bridges": knowledge_bridges,
        "guidance_strategies": guidance_strategies,
        "analogies": analogies,
        "hard_rules": {
            "explanation_loss_allowed": False,
            "passing_bridge_loss_allowed": False,
            "countable_guidance_loss_allowed": False,
            "unexplained_term_substitution_allowed": False,
            "analogy_deletion_requires_equivalent_direct_explanation": True,
        },
    }


def schema_support_prompt(
    source_text: str,
    candidate: str,
    schema_support_contract: dict[str, Any],
    claim_validation: dict[str, Any],
    explanation_protection_contract: dict[str, Any] | None = None,
) -> str:
    return f"""You audit observable schema-support features in a reader-adapted
rewrite. This is not a judgement of the reader's experienced cognitive load.
Use only the supplied source, reader contract, and candidate. Do not reward an
unsupported factual application, mechanism, named example, or assurance claim.

Score prior-knowledge bridging A_B and cognitive-engagement guidance A_Q in
[0,1]. A_B concerns each requested concept: it must be covered and, when it
uses a bridge, be accurate, familiar to the reader, and state a complete mapping
back to the concept. An accurate direct explanation is acceptable when no
reliable familiar analogy is available; score its reader-friendly wording as
familiarity and its complete concept explanation as mapping completeness rather
than penalizing it merely because it is not an analogy. A_Q concerns cognitive-engagement
support across the ENTIRE rewrite, not compliance with a single opener template. A useful
strategy may appear at the beginning, middle, or end. Detect and list every candidate
strategy, then judge whether it is relevant, goal-aligned, and cognitively useful rather
than decorative or burdensome.

FULL-TEXT COGNITIVE-GUIDANCE TEST
- Do not require a goal-aligned opener. The opener is only one possible location.
- Apply a two-stage test. First decide whether a span is genuinely a cognitive-guidance
  strategy; only then score its cognitive function, content relevance, and goal alignment.
  An ordinary factual sentence does not become guidance merely because it is relevant,
  important, vivid, or connected by words such as "but", "therefore", "good news", or
  "in action". Plain exposition, rhetorical emphasis, and discourse transitions are not
  guidance unless they actually orient, activate, focus, organize, elaborate, monitor,
  integrate, apply, reflect, or summarize the reader's cognition.
- Count distinct effective strategy types, cognitive functions, and locations. Examples
  include curiosity/surprise, knowledge-gap questions, goal or relevance framing,
  advance organizers, attention and causal signposts, comparison or self-explanation
  prompts, comprehension checkpoints, integration prompts, source-licensed applications,
  practical takeaways, narrative payoff, and recap/summary.
- Count a distinct strategy type when it has an exact span, is not unsupported, and
  satisfies at least one condition: a clear cognitive function, content relevance,
  or alignment with the reader goal.
- Goal alignment is positive-only. A goal-aligned strategy earns goal-alignment credit.
  A reasonable strategy aimed at another goal earns no goal credit but does not subtract
  credit and must not be removed merely for that reason. Unsupported strategies do not count.
- Assess content relevance independently from goal alignment. You MUST still list a
  source-grounded, cognitively functional strategy when it is reasonable but aimed at a
  different goal. For example, a source-supported practical takeaway in an entertainment
  rewrite remains a `practical_takeaway` with content-relevance credit and zero goal credit;
  do not call the whole guidance inventory missing merely because that strategy is unaligned.
- Do not count repetitions as additional strategy types. Decorative questions, generic
  summaries, and unsupported advice/applications receive no relevance or goal credit.
- Goal alignment is strategy-neutral: entertainment, learning, and utility can each be
  supported by multiple valid methods and at multiple positions. Judge the function and
  evidence, not a prescribed surface form.
- `other` is a strict escape hatch, not a generic label. Use it only when the span performs
  a reader-facing cognitive operation that cannot be represented by any listed strategy
  type. For `other`, provide a concise new strategy label, name the reader's cognitive
  action, and explain why no listed type applies. A countable `other` must be effective,
  content-relevant, goal-aligned, and have a non-`other` cognitive function. Otherwise
  omit it or mark it weak/irrelevant; never use `other` for ordinary explanation or style.
- Named-type precedence is mandatory. Before returning `other`, check all listed types.
  In particular: "summarize" and "looking back" normally map to `recap_or_summary` or a
  checkpoint; "takeaway" and a source-grounded action cue map to `practical_takeaway` or
  `source_licensed_application`; "important", "matters", or "essential" can map to
  `goal_or_relevance_framing` when they genuinely frame reader relevance; and a focused
  source-grounded surprise/contrast maps to `curiosity_or_surprise`. Do not use `other`
  merely because the surface wording differs from an example.
- Boundary examples: "Next, X happened" is plain sequencing, while "Next, compare X with
  Y" is guidance. "The result was X" is exposition, while "Pause and predict the result"
  is guidance. "It is important" is mere emphasis unless it directs attention to a central
  distinction or consequence. A source-supported "You can..." application or takeaway is
  a strategy even when it is not aligned with the current entertainment/learning goal.
- List at most eight distinct strategy spans. Merge repetitions of the same strategy;
  include representative weak/irrelevant/unsupported spans for audit visibility.

ANALOGY-FIT AND SEMANTIC-DISTANCE TEST (hard requirement)
- Familiarity is necessary but not sufficient. Check whether the analogy preserves
  the concept's relevant relation, mechanism, constraint, direction, or contrast.
- Reject a bridge that shares only a surface word, position, visual feature, or vague
  theme. A vivid analogy can still be misleading.
- `semantic_distance` is 0 for a close, structurally relevant mapping and 1 for a
  remote/arbitrary mapping. Judge explanatory distance, not vocabulary overlap.
- `explanatory_gain` asks whether the analogy makes the target relation easier to
  understand than a short direct explanation. If not, prefer direct explanation.

READER-GROUNDING BOUNDARY (hard requirement)
- Reader profile fields are adaptation resources, not facts about the reader's
  beliefs, values, attitudes, preferences, emotions, or actual understanding.
- Do not reward a role/profile-based article opener or global frame. A sentence
  such as "As a designer, you understand that a strong foundation is key" is
  misplaced and projects a stance onto the reader.
- A role, interest, prior-knowledge area, or familiar context may be used only as
  an optional, non-assumptive LOCAL analogy next to the relevant term explanation,
  with an explicit mapping back to that term.
- Neutral second-person navigation (for example, "you will see") is not itself a
  violation. The violation is inferring what the reader already understands,
  values, believes, wants, prefers, feels, or does from their profile.

ANALOGY ROLE AND LOAD BOUNDARY (hard requirement)
- A correct direct explanation does not cancel an additional bad analogy. Audit
  every figurative span independently and return each one in `analogies`.
- Audit every analogy, metaphor, narrative role, and personification, including
  figurative assertions without `like` or `as`. Recover source subject, actual
  action agent, patient/affected entity, and beneficiary, then compare them with
  the figurative roles. A person may exercise while the heart benefits; wording
  that makes the heart choose, like, or perform the person's workout is an agency
  mismatch even when rhetorically natural.
- A protagonist/villain/helper mapping is allowed when its shared relation is clear,
  source roles and modality remain explicit, and the same story roles remain stable.
- Audit load paragraph by paragraph. Several roles may extend one coherent story,
  but system load -> server capacity -> memory leak -> pipes -> garbage collector ->
  software patches stacks independent mechanisms and increases cognitive load.
  A scaffold unfamiliar to this reader also fails.
- This is not an anti-analogy rule. Mark each analogy required/helpful/decorative.
  Protect an accurate high-value primary analogy and one complete familiar
  explanation per retain_and_explain term. Identify only the excess or erroneous
  spans for repair; convert those spans to direct explanation rather than deleting
  the source proposition.

EXPLANATION-PROTECTION TEST (hard requirement)
- For every protected explanation, determine whether the current wording preserves
  all protected information units and remains understandable at the specified reader
  level. Exact wording is not required. Merely retaining the technical term without
  its necessary meaning is a loss.
- For every protected required/helpful analogy, first determine whether the same
  accurate analogy remains. If it was removed or shortened, accept the change only
  when a local direct explanation preserves the same relevant relation/information,
  is source-grounded, and is at least as understandable for this reader.
- Do not mark an explanation equivalent merely because it mentions the same term.

Return JSON only:
{{"bridges":[{{"support_id":"GS_B_IL_T001","candidate_span":"exact short span or empty",
"status":"adequate|missing|inaccurate|unfamiliar|incomplete_mapping|forced_binding|misleading_mapping",
"coverage":0.0,"accuracy":0.0,"familiarity":0.0,"mapping_completeness":0.0,
"relational_alignment":0.0,"explanatory_gain":0.0,"semantic_distance":0.0,
"forced_binding":false,
"uses_direct_explanation":false,
"explanation_proposition":"the minimum meaning conveyed by this explanation",
"explanation_information_units":["one necessary meaning unit"],
"information_equivalent_to_protected":true,"reader_comprehensible":true,
"reason":"brief source-grounded reason"}}],
"guidance":{{"support_id":"GS_Q_001","candidate_span":"representative exact guidance span or empty",
"status":"adequate|missing|partial|misaligned|irrelevant",
"strategies":[{{"strategy_id":"Q01","candidate_span":"exact span",
"strategy_type":"knowledge_gap_or_question","cognitive_function":"orient",
"location":"beginning|middle|end","status":"effective|reasonable_but_goal_unaligned|weak|irrelevant|unsupported",
"relevance":0.0,"goal_alignment":0.0,
"other_strategy_label":"required only for other; otherwise empty",
"reader_cognitive_action":"required only for other; otherwise empty",
"why_not_named_type":"required only for other; otherwise empty",
"reason":"brief reason"}}],
"reason":"overall guidance reason"}},
"reader_grounding":{{"support_id":"GS_R_001",
"status":"adequate|misplaced_opener|projected_stance|stereotyped_inference|multiple_violations",
"violation_spans":["exact candidate span"],"placement_safe":true,"stance_safe":true,
"localized_to_term_explanation":true,"reason":"brief reason"}},
"analogies":[{{"analogy_id":"A01","candidate_span":"exact complete figurative span",
"mapped_source_span":"closest exact source span or empty","linked_support_ids":["GS_B_IL_T001"],
"source_subject":"source entity","figurative_subject":"figurative entity",
"source_agent":"actual action agent","figurative_agent":"apparent action agent",
"source_patient_or_beneficiary":"actual affected/benefiting entity",
"figurative_patient_or_beneficiary":"apparent affected/benefiting entity",
"shared_relation":"precise defensible similarity or empty",
"support_value":"required_for_reader|helpful|decorative",
"preservation_decision":"keep|shorten|replace|remove",
"status":"appropriate|subject_mismatch|agency_mismatch|patient_or_beneficiary_mismatch|relation_mismatch|causal_overreach|unsupported_mapping|narrative_incoherence",
"reason":"brief role- and source-grounded reason"}}],
"narrative_mapping":{{"status":"adequate|narrative_incoherence",
"established_roles":[{{"source_entity":"heart","story_role":"protagonist"}}],
"conflicting_span":"exact span or empty","reason":"brief continuity judgement"}},
"analogy_complexity":[{{"paragraph_id":"P01","candidate_span":"exact paragraph or shortest overloaded span",
"primary_frame":"movie story|computer system|none","frame_labels":["computer system","plumbing"],
"n_analogy_units":3,"n_mapping_switches":2,
"protected_primary_spans":["exact useful analogy span to retain"],
"excess_analogy_spans":["exact redundant/mixed span to remove or literalize"],
"status":"adequate|overloaded|mixed_frames|role_collision|unfamiliar_scaffold",
"reason":"why this scaffold reduces or increases cognitive load"}}],
"protected_support":[{{"contract_id":"EP_IL_T001|AP_A01",
"status":"preserved|equivalent_direct_explanation|lost",
"replacement_span":"exact current explanation/analogy span or empty",
"information_equivalent":true,"reader_comprehensible":true,
"source_grounded":true,"reason":"brief comparison with the protected contract"}}]}}

SOURCE ARTICLE
{source_text}

CLAIM VALIDATION (a failed claim cannot be treated as an accurate bridge)
{json.dumps(claim_validation, ensure_ascii=False)}

SCHEMA-SUPPORT CONTRACT
{json.dumps(schema_support_contract, ensure_ascii=False)}

EXPLANATION AND ANALOGY PROTECTION CONTRACT
{json.dumps(explanation_protection_contract or {}, ensure_ascii=False)}

CANDIDATE REWRITE
{candidate}"""


def _json_response(llm_call: Callable[..., str], prompt: str) -> dict[str, Any]:
    try:
        raw = llm_call(
            prompt,
            max_tokens=SCHEMA_SUPPORT_MAX_TOKENS,
            temperature=0.0,
            response_format={"type": "json_object"},
        )
    except TypeError as exc:
        if "response_format" not in str(exc):
            raise
        raw = llm_call(prompt, max_tokens=SCHEMA_SUPPORT_MAX_TOKENS, temperature=0.0)
    value = json.loads(str(raw).strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip())
    if not isinstance(value, dict):
        raise ValueError("schema-support response must be a JSON object")
    return value


def _guidance_span_location(candidate: str, span: str, fallback: str) -> str:
    if not candidate or not span:
        return fallback
    start = candidate.find(span)
    if start < 0:
        return fallback
    midpoint_ratio = (start + len(span) / 2) / max(1, len(candidate))
    if midpoint_ratio <= 0.25:
        return "beginning"
    if midpoint_ratio >= 0.75:
        return "end"
    return "middle"


def _named_strategy_from_other(
    span: str, status: str, relevance: float, goal_alignment: float,
) -> str | None:
    """Recover an obvious named type without reopening the generic `other` gate.

    Remapping requires either an explicit reader-facing cognitive cue or an effective,
    relevant, goal-aligned model judgement. Plain transitions such as "but" or factual
    result statements therefore remain uncounted.
    """
    lowered = span.lower().strip()
    if not lowered:
        return None
    explicit_cue = bool(
        "?" in span
        or any(marker in lowered for marker in (
            "as you read", "pause", "ask yourself", "in your own words",
            "check your understanding", "notice", "keep in mind", "looking back",
            "using only the article", "using the article", "what you check next",
        ))
    )
    supported_judgement = (
        status == "effective" and relevance >= 0.50 and goal_alignment >= 0.50
    )
    if not (explicit_cue or supported_judgement):
        return None
    if any(marker in lowered for marker in (
        "using only the article", "using the article", "stated information",
        "what you check next", "next practical step", "apply this",
    )):
        return "source_licensed_application"
    if any(marker in lowered for marker in (
        "takeaway", "you can help", "you can use", "in practice", "practical step",
    )):
        return "practical_takeaway"
    if any(marker in lowered for marker in (
        "check your understanding", "looking back", "pause here",
    )) and ("?" in span or "check your understanding" in lowered):
        return "comprehension_checkpoint"
    if any(marker in lowered for marker in (
        "summarize", "in summary", "to sum up", "in short", "recap",
    )):
        return "recap_or_summary"
    if any(marker in lowered for marker in (
        "in your own words", "explain to yourself", "explain how",
    )):
        return "self_explanation_prompt"
    if any(marker in lowered for marker in (
        "compare", "contrast", "distinguish", "difference between",
    )):
        return "comparison_or_contrast_prompt"
    if any(marker in lowered for marker in (
        "connect", "connection", "relate this", "fits together",
    )):
        return "integration_or_connection_prompt"
    if any(marker in lowered for marker in (
        "important", "matters", "essential", "relevant", "why this matters",
    )):
        return "goal_or_relevance_framing"
    if any(marker in lowered for marker in (
        "surpris", "unexpected", "good news", "even though", "read on",
    )):
        return "curiosity_or_surprise"
    if any(marker in lowered for marker in (
        "notice", "focus on", "keep in mind", "pay attention",
    )):
        return "attention_cue"
    if "?" in span:
        return "knowledge_gap_or_question"
    return None


def normalize_schema_support(
    raw: dict[str, Any], schema_support_contract: dict[str, Any],
    candidate_word_count: int = 0, candidate_text: str = "",
    explanation_protection_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    raw_bridges = {
        str(item.get("support_id", "")): item
        for item in raw.get("bridges", []) if isinstance(item, dict)
    }
    bridges = []
    for requirement in schema_support_contract.get("bridges", []):
        found = raw_bridges.get(requirement["support_id"], {})
        status = str(found.get("status", "missing"))
        if status not in BRIDGE_FAILURES | {"adequate"}:
            status = "missing"
        semantic_distance = _clamp_score(found.get("semantic_distance", 1.0))
        relational_alignment = _clamp_score(found.get("relational_alignment"))
        explanatory_gain = _clamp_score(found.get("explanatory_gain"))
        forced_binding = bool(found.get("forced_binding", False))
        if forced_binding or (
            semantic_distance > 0.60 and relational_alignment < 0.50
        ):
            status = "forced_binding"
            forced_binding = True
        bridges.append({
            **requirement,
            "candidate_span": str(found.get("candidate_span", "")),
            "status": status,
            "coverage": _clamp_score(found.get("coverage")),
            "accuracy": _clamp_score(found.get("accuracy")),
            "familiarity": _clamp_score(found.get("familiarity")),
            "mapping_completeness": _clamp_score(found.get("mapping_completeness")),
            "relational_alignment": relational_alignment,
            "explanatory_gain": explanatory_gain,
            "semantic_distance": semantic_distance,
            "forced_binding": forced_binding,
            "uses_direct_explanation": bool(found.get("uses_direct_explanation", False)),
            "explanation_proposition": str(found.get("explanation_proposition", "")),
            "explanation_information_units": [
                str(value) for value in found.get("explanation_information_units", [])
                if str(value).strip()
            ] if isinstance(found.get("explanation_information_units", []), list) else [],
            "information_equivalent_to_protected": bool(
                found.get("information_equivalent_to_protected", status == "adequate")
            ),
            "reader_comprehensible": bool(
                found.get("reader_comprehensible", status == "adequate")
            ),
            "reason": str(found.get("reason", "missing bridge assessment")),
        })
    requirement = schema_support_contract.get("guidance", {})
    found_guidance = raw.get("guidance", {}) if isinstance(raw.get("guidance", {}), dict) else {}
    raw_strategies = found_guidance.get("strategies")
    has_structured_strategies = isinstance(raw_strategies, list)
    strategies = []
    if has_structured_strategies:
        for index, found in enumerate(raw_strategies, 1):
            if not isinstance(found, dict):
                continue
            strategy_type = str(found.get("strategy_type", "other"))
            if strategy_type not in GUIDANCE_STRATEGY_TYPES:
                strategy_type = "other"
            original_strategy_type = strategy_type
            cognitive_function = str(found.get("cognitive_function", "other"))
            if cognitive_function not in GUIDANCE_COGNITIVE_FUNCTIONS:
                cognitive_function = "other"
            candidate_span = str(found.get("candidate_span", "")).strip()
            location = str(found.get("location", "middle"))
            if location not in GUIDANCE_LOCATIONS:
                location = "middle"
            location = _guidance_span_location(candidate_text, candidate_span, location)
            strategy_status = str(found.get("status", "weak"))
            if strategy_status not in {
                "effective", "reasonable_but_goal_unaligned", "weak",
                "irrelevant", "unsupported",
            }:
                strategy_status = "weak"
            relevance = _clamp_score(found.get("relevance"))
            goal_alignment = _clamp_score(found.get("goal_alignment"))
            if strategy_type == "other":
                strategy_type = _named_strategy_from_other(
                    candidate_span, strategy_status, relevance, goal_alignment,
                ) or "other"
            strategies.append({
                "strategy_id": str(found.get("strategy_id", f"Q{index:02d}")),
                "candidate_span": candidate_span,
                "strategy_type": strategy_type,
                "original_strategy_type": original_strategy_type,
                "deterministic_remap_from_other": (
                    original_strategy_type == "other" and strategy_type != "other"
                ),
                "cognitive_function": cognitive_function,
                "location": location,
                "status": strategy_status,
                "relevance": relevance,
                "goal_alignment": goal_alignment,
                "other_strategy_label": str(found.get("other_strategy_label", "")).strip(),
                "reader_cognitive_action": str(found.get("reader_cognitive_action", "")).strip(),
                "why_not_named_type": str(found.get("why_not_named_type", "")).strip(),
                "reason": str(found.get("reason", "missing strategy assessment")),
            })

    countable_strategies = [
        item for item in strategies
        if item["candidate_span"]
        and item["status"] != "unsupported"
        and (
            (
                item["strategy_type"] != "other"
                and (
                    item["cognitive_function"] != "other"
                    or item["relevance"] >= 0.50
                    or item["goal_alignment"] >= 0.50
                )
            )
            or (
                item["strategy_type"] == "other"
                and item["status"] == "effective"
                and item["cognitive_function"] != "other"
                and item["relevance"] >= 0.50
                and item["goal_alignment"] >= 0.50
                and bool(item["other_strategy_label"])
                and bool(item["reader_cognitive_action"])
                and bool(item["why_not_named_type"])
            )
        )
    ]
    counted_strategy_keys = {
        item["strategy_type"]
        if item["strategy_type"] != "other"
        else f"other:{item['cognitive_function']}"
        for item in countable_strategies
    }
    distinct_functions = {
        item["cognitive_function"] for item in countable_strategies
        if item["cognitive_function"] != "other"
    }
    distinct_locations = {item["location"] for item in countable_strategies}
    n_counted_strategy_types = len(counted_strategy_keys)
    count_score = 1.0 - (0.30 ** n_counted_strategy_types)
    content_relevant_keys = {
        item["strategy_type"]
        if item["strategy_type"] != "other"
        else f"other:{item['cognitive_function']}"
        for item in countable_strategies
        if item["relevance"] >= 0.50
    }
    goal_aligned_keys = {
        item["strategy_type"]
        if item["strategy_type"] != "other"
        else f"other:{item['cognitive_function']}"
        for item in countable_strategies
        if item["goal_alignment"] >= 0.50
    }
    relevance_score = 1.0 - (0.30 ** len(content_relevant_keys))
    goal_alignment_score = 1.0 - (0.30 ** len(goal_aligned_keys))

    if has_structured_strategies:
        coverage = count_score
        relevance = relevance_score
        goal_alignment = goal_alignment_score
        if not strategies:
            status = "missing"
        elif not countable_strategies:
            status = "irrelevant"
        elif not goal_aligned_keys:
            status = "misaligned"
        elif min(coverage, relevance, goal_alignment) >= 0.70:
            status = "adequate"
        else:
            status = "partial"
    else:
        status = str(found_guidance.get("status", "missing"))
        if status not in GUIDANCE_FAILURES | {"adequate"}:
            status = "missing"
        coverage = _clamp_score(found_guidance.get("coverage"))
        relevance = _clamp_score(found_guidance.get("relevance"))
        goal_alignment = _clamp_score(found_guidance.get("goal_alignment"))
        count_score = coverage
        relevance_score = relevance
        goal_alignment_score = goal_alignment

    guidance = {
        **requirement,
        "candidate_span": str(found_guidance.get("candidate_span", "")),
        "status": status,
        "coverage": _clamp_score(coverage),
        "relevance": _clamp_score(relevance),
        "goal_alignment": _clamp_score(goal_alignment),
        "strategies": strategies,
        "n_detected_strategies": len(strategies),
        "n_countable_strategies": len(countable_strategies),
        "n_counted_strategy_types": n_counted_strategy_types,
        "n_content_relevant_strategy_types": len(content_relevant_keys),
        "n_goal_aligned_strategy_types": len(goal_aligned_keys),
        "n_distinct_cognitive_functions": len(distinct_functions),
        "n_guidance_locations": len(distinct_locations),
        "guidance_count_score": round(count_score, 4),
        "content_relevance_score": round(relevance_score, 4),
        "goal_alignment_score": round(goal_alignment_score, 4),
        "reason": str(found_guidance.get("reason", "missing cognitive-guidance assessment")),
    }
    grounding_requirement = schema_support_contract.get("reader_grounding", {})
    found_grounding = raw.get("reader_grounding", {}) if isinstance(raw.get("reader_grounding", {}), dict) else {}
    grounding_status = str(found_grounding.get("status", "multiple_violations"))
    if grounding_status not in GROUNDING_BOUNDARY_FAILURES | {"adequate"}:
        grounding_status = "multiple_violations"
    violation_spans = found_grounding.get("violation_spans", [])
    if not isinstance(violation_spans, list):
        violation_spans = [violation_spans]
    reader_grounding = {
        **grounding_requirement,
        "status": grounding_status,
        "violation_spans": [str(value) for value in violation_spans if str(value).strip()],
        "placement_safe": bool(found_grounding.get("placement_safe", False)),
        "stance_safe": bool(found_grounding.get("stance_safe", False)),
        "localized_to_term_explanation": bool(
            found_grounding.get("localized_to_term_explanation", False)
        ),
        "reason": str(found_grounding.get("reason", "missing reader-grounding boundary assessment")),
    }
    analogies = []
    seen_ids: set[str] = set()
    for index, found in enumerate(raw.get("analogies", []), 1):
        if not isinstance(found, dict):
            continue
        analogy_id = str(found.get("analogy_id", f"A{index:02d}"))
        if analogy_id in seen_ids:
            analogy_id = f"A{index:02d}"
        seen_ids.add(analogy_id)
        analogy_status = str(found.get("status", "unsupported_mapping"))
        if analogy_status not in ANALOGY_FAILURES | {"appropriate"}:
            analogy_status = "unsupported_mapping"
        support_value = str(found.get("support_value", "helpful"))
        if support_value not in {"required_for_reader", "helpful", "decorative"}:
            support_value = "helpful"
        preservation = str(found.get("preservation_decision", "keep"))
        if preservation not in {"keep", "shorten", "replace", "remove"}:
            preservation = "keep"
        analogies.append({
            "analogy_id": analogy_id,
            "support_id": schema_support_contract.get("analogy_support", {}).get(
                "support_id", "GS_A_001"
            ),
            "candidate_span": str(found.get("candidate_span", "")),
            "mapped_source_span": str(found.get("mapped_source_span", "")),
            "linked_support_ids": [str(value) for value in found.get("linked_support_ids", [])],
            "source_subject": str(found.get("source_subject", "")),
            "figurative_subject": str(found.get("figurative_subject", "")),
            "source_agent": str(found.get("source_agent", "")),
            "figurative_agent": str(found.get("figurative_agent", "")),
            "source_patient_or_beneficiary": str(found.get("source_patient_or_beneficiary", "")),
            "figurative_patient_or_beneficiary": str(found.get("figurative_patient_or_beneficiary", "")),
            "shared_relation": str(found.get("shared_relation", "")),
            "support_value": support_value,
            "preservation_decision": preservation,
            "status": analogy_status,
            "reason": str(found.get("reason", "missing analogy assessment")),
        })
    raw_mapping = raw.get("narrative_mapping", {})
    if not isinstance(raw_mapping, dict):
        raw_mapping = {}
    mapping_status = str(raw_mapping.get("status", "adequate"))
    if mapping_status not in {"adequate", "narrative_incoherence"}:
        mapping_status = "narrative_incoherence"
    narrative_mapping = {
        "status": mapping_status,
        "established_roles": raw_mapping.get("established_roles", []),
        "conflicting_span": str(raw_mapping.get("conflicting_span", "")),
        "reason": str(raw_mapping.get("reason", "")),
    }
    analogy_complexity = []
    for index, found in enumerate(raw.get("analogy_complexity", []), 1):
        if not isinstance(found, dict):
            continue
        complexity_status = str(found.get("status", "overloaded"))
        if complexity_status not in ANALOGY_COMPLEXITY_FAILURES | {"adequate"}:
            complexity_status = "overloaded"
        analogy_complexity.append({
            "paragraph_id": str(found.get("paragraph_id", f"P{index:02d}")),
            "support_id": schema_support_contract.get("analogy_support", {}).get(
                "support_id", "GS_A_001"
            ),
            "candidate_span": str(found.get("candidate_span", "")),
            "primary_frame": str(found.get("primary_frame", "")),
            "frame_labels": [str(value) for value in found.get("frame_labels", [])],
            "n_analogy_units": max(0, int(found.get("n_analogy_units", 0))),
            "n_mapping_switches": max(0, int(found.get("n_mapping_switches", 0))),
            "protected_primary_spans": [
                str(value) for value in found.get("protected_primary_spans", [])
                if str(value).strip()
            ],
            "excess_analogy_spans": [
                str(value) for value in found.get("excess_analogy_spans", [])
                if str(value).strip()
            ],
            "status": complexity_status,
            "reason": str(found.get("reason", "missing analogy-load assessment")),
        })
    protection_contract = explanation_protection_contract or {}
    raw_protected = {
        str(item.get("contract_id", "")): item
        for item in raw.get("protected_support", []) if isinstance(item, dict)
    }
    bridge_index = {str(item.get("support_id", "")): item for item in bridges}
    protected_support = []
    for requirement in protection_contract.get("explanations", []):
        contract_id = str(requirement.get("contract_id", ""))
        found = raw_protected.get(contract_id, {})
        bridge = bridge_index.get(str(requirement.get("support_id", "")), {})
        inferred_pass = bool(
            bridge.get("status") == "adequate"
            and bridge.get("information_equivalent_to_protected", False)
            and bridge.get("reader_comprehensible", False)
        )
        status = str(found.get(
            "status", "equivalent_direct_explanation" if inferred_pass else "lost"
        ))
        if status not in PROTECTED_SUPPORT_PASS | {"lost"}:
            status = "lost"
        protected_support.append({
            **requirement,
            "kind": "explanation",
            "status": status,
            "replacement_span": str(
                found.get("replacement_span", bridge.get("candidate_span", ""))
            ),
            "information_equivalent": bool(
                found.get("information_equivalent", inferred_pass)
            ),
            "reader_comprehensible": bool(
                found.get("reader_comprehensible", inferred_pass)
            ),
            "source_grounded": bool(found.get("source_grounded", inferred_pass)),
            "reason": str(found.get("reason", "inferred from the linked bridge audit")),
        })
    analogy_by_span = {
        str(item.get("candidate_span", "")): item for item in analogies
    }
    for requirement in protection_contract.get("analogies", []):
        contract_id = str(requirement.get("contract_id", ""))
        found = raw_protected.get(contract_id, {})
        original = analogy_by_span.get(str(requirement.get("protected_analogy_span", "")))
        linked = [
            bridge_index.get(str(value), {})
            for value in requirement.get("linked_support_ids", [])
        ]
        direct_fallback = bool(
            linked
            and all(
                item.get("status") == "adequate"
                and item.get("uses_direct_explanation", False)
                and item.get("information_equivalent_to_protected", False)
                and item.get("reader_comprehensible", False)
                for item in linked
            )
        )
        inferred_status = (
            "preserved" if original and original.get("status") == "appropriate"
            else "equivalent_direct_explanation" if direct_fallback else "lost"
        )
        status = str(found.get("status", inferred_status))
        if status not in PROTECTED_SUPPORT_PASS | {"lost"}:
            status = "lost"
        inferred_pass = status in PROTECTED_SUPPORT_PASS
        protected_support.append({
            **requirement,
            "kind": "analogy",
            "status": status,
            "replacement_span": str(found.get(
                "replacement_span",
                original.get("candidate_span", "") if original else (
                    linked[0].get("candidate_span", "") if linked else ""
                ),
            )),
            "information_equivalent": bool(
                found.get("information_equivalent", inferred_pass)
            ),
            "reader_comprehensible": bool(
                found.get("reader_comprehensible", inferred_pass)
            ),
            "source_grounded": bool(found.get("source_grounded", inferred_pass)),
            "reason": str(found.get("reason", "inferred from analogy/bridge audit")),
        })
    return {
        "bridges": bridges,
        "guidance": guidance,
        "reader_grounding": reader_grounding,
        "analogies": analogies,
        "narrative_mapping": narrative_mapping,
        "analogy_complexity": analogy_complexity,
        "explanation_protection_contract": protection_contract,
        "protected_support": protected_support,
    }


def score_schema_support(normalized: dict[str, Any], weights: dict[str, Any] | None = None) -> dict[str, Any]:
    bridges = normalized.get("bridges", [])
    bridge_scores = [
        (
            item["coverage"] + item["accuracy"] + item["familiarity"]
            + item["mapping_completeness"] + item["relational_alignment"]
            + item["explanatory_gain"] + (1.0 - item["semantic_distance"])
        ) / 7
        for item in bridges
    ]
    bridging = sum(bridge_scores) / len(bridge_scores) if bridge_scores else 1.0
    guidance_item = normalized["guidance"]
    reader_grounding = normalized["reader_grounding"]
    guidance = (
        guidance_item["coverage"]
        + guidance_item["relevance"]
        + guidance_item["goal_alignment"]
    ) / 3
    selected_weights = weights or {"guidance": 0.5, "bridging": 0.5}
    w_guidance = _clamp_score(selected_weights.get("guidance", 0.5))
    w_bridging = _clamp_score(selected_weights.get("bridging", 0.5))
    total = w_guidance + w_bridging
    if not total:
        w_guidance = w_bridging = 0.5
        total = 1.0
    bridge_fit_failures = [
        item for item in bridges
        if item["forced_binding"]
        or item["status"] in {"forced_binding", "misleading_mapping"}
        or item["semantic_distance"] > 0.60
        or item["relational_alignment"] < 0.50
        or item["explanatory_gain"] < 0.50
    ]
    analogy_failures = [
        item for item in normalized.get("analogies", [])
        if item.get("status") != "appropriate"
    ]
    narrative_mapping_pass = (
        normalized.get("narrative_mapping", {}).get("status", "adequate") == "adequate"
    )
    complexity_failures = [
        item for item in normalized.get("analogy_complexity", [])
        if item.get("status") != "adequate"
    ]
    necessary_explanation_failures = [
        item for item in bridges
        if (
            item.get("status") != "adequate"
            or not str(item.get("candidate_span", "")).strip()
            or float(item.get("coverage", 0)) < 0.50
            or float(item.get("accuracy", 0)) < 0.50
            or float(item.get("familiarity", 0)) < 0.50
            or float(item.get("mapping_completeness", 0)) < 0.50
        )
    ]
    protected_explanation_failures = [
        item for item in normalized.get("protected_support", [])
        if item.get("kind") == "explanation" and (
            item.get("status") not in PROTECTED_SUPPORT_PASS
            or not item.get("information_equivalent", False)
            or not item.get("reader_comprehensible", False)
            or not item.get("source_grounded", False)
        )
    ]
    analogy_fallback_failures = [
        item for item in normalized.get("protected_support", [])
        if item.get("kind") == "analogy" and (
            item.get("status") not in PROTECTED_SUPPORT_PASS
            or not item.get("information_equivalent", False)
            or not item.get("reader_comprehensible", False)
            or not item.get("source_grounded", False)
        )
    ]
    return {
        "A_B": round(bridging, 4),
        "A_Q": round(guidance, 4),
        "P_gcl": round((w_guidance * guidance + w_bridging * bridging) / total, 4),
        "n_bridge_targets": len(bridges),
        "n_bridge_failures": sum(
            item["status"] != "adequate" or item in bridge_fit_failures
            for item in bridges
        ),
        "n_forced_bridge_bindings": sum(item["forced_binding"] for item in bridges),
        "bridge_fit_pass": not bridge_fit_failures,
        "guidance_status": guidance_item["status"],
        "guidance_coverage_pass": guidance_item["status"] == "adequate",
        "n_guidance_strategies": guidance_item.get("n_detected_strategies", 0),
        "n_countable_guidance_strategies": guidance_item.get("n_countable_strategies", 0),
        "n_counted_guidance_strategy_types": guidance_item.get("n_counted_strategy_types", 0),
        "n_content_relevant_strategy_types": guidance_item.get("n_content_relevant_strategy_types", 0),
        "n_goal_aligned_strategy_types": guidance_item.get("n_goal_aligned_strategy_types", 0),
        "n_distinct_guidance_functions": guidance_item.get("n_distinct_cognitive_functions", 0),
        "n_guidance_locations": guidance_item.get("n_guidance_locations", 0),
        "guidance_count_score": guidance_item.get("guidance_count_score", 0.0),
        "guidance_relevance_score": guidance_item.get("content_relevance_score", 0.0),
        "guidance_goal_alignment_score": guidance_item.get("goal_alignment_score", 0.0),
        "reader_grounding_status": reader_grounding["status"],
        "grounding_boundary_pass": bool(
            reader_grounding["status"] == "adequate"
            and reader_grounding["placement_safe"]
            and reader_grounding["stance_safe"]
        ),
        "n_grounding_boundary_violations": len(reader_grounding["violation_spans"]),
        "n_analogies": len(normalized.get("analogies", [])),
        "n_analogy_failures": len(analogy_failures),
        "analogy_semantic_pass": not analogy_failures,
        "narrative_mapping_pass": narrative_mapping_pass,
        "n_analogy_complexity_failures": len(complexity_failures),
        "analogy_complexity_pass": not complexity_failures,
        "n_necessary_explanation_failures": len(necessary_explanation_failures),
        "necessary_explanations_pass": not (
            necessary_explanation_failures or protected_explanation_failures
        ),
        "n_protected_explanation_failures": len(protected_explanation_failures),
        "n_analogy_fallback_failures": len(analogy_fallback_failures),
        "analogy_fallback_pass": not analogy_fallback_failures,
    }


def evaluate_schema_support(
    source_text: str,
    candidate: str,
    schema_support_contract: dict[str, Any],
    claim_validation: dict[str, Any],
    llm_call: Callable[..., str],
    explanation_protection_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    prompt = schema_support_prompt(
        source_text, candidate, schema_support_contract, claim_validation,
        explanation_protection_contract,
    )
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = _json_response(
                llm_call,
                prompt if not attempt else prompt + (
                    "\nReturn complete valid JSON only. Keep every reason under 20 words; "
                    "do not repeat source or candidate text outside required candidate_span fields."
                ),
            )
            normalized = normalize_schema_support(
                raw, schema_support_contract, len(candidate.split()), candidate,
                explanation_protection_contract,
            )
            return {**normalized, "metrics": score_schema_support(normalized, schema_support_contract.get("weights")), "evaluated": True}
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc
    raise ValueError(f"schema-support evaluator returned invalid JSON twice: {last_error}")


def failed_schema_support_spans(evaluation: dict[str, Any]) -> list[str]:
    spans = [
        str(item.get("candidate_span", "")).strip()
        for item in evaluation.get("bridges", [])
        if (
            item.get("status") != "adequate"
            or item.get("forced_binding", False)
            or float(item.get("semantic_distance", 0)) > 0.60
            or float(item.get("relational_alignment", 1)) < 0.50
            or float(item.get("explanatory_gain", 1)) < 0.50
        ) and str(item.get("candidate_span", "")).strip()
    ]
    guidance = evaluation.get("guidance", {})
    if guidance.get("status") != "adequate":
        spans.extend(
            str(item.get("candidate_span", "")).strip()
            for item in guidance.get("strategies", [])
            if item.get("status") == "unsupported"
            and str(item.get("candidate_span", "")).strip()
        )
    grounding = evaluation.get("reader_grounding", {})
    if grounding.get("status") != "adequate":
        spans.extend(
            str(value).strip() for value in grounding.get("violation_spans", [])
            if str(value).strip()
        )
    spans.extend(
        str(item.get("candidate_span", "")).strip()
        for item in evaluation.get("analogies", [])
        if item.get("status") != "appropriate"
        and str(item.get("candidate_span", "")).strip()
    )
    narrative = evaluation.get("narrative_mapping", {})
    if narrative.get("status") != "adequate" and str(narrative.get("conflicting_span", "")).strip():
        spans.append(str(narrative["conflicting_span"]).strip())
    for item in evaluation.get("analogy_complexity", []):
        if item.get("status") == "adequate":
            continue
        excess = [
            str(value).strip() for value in item.get("excess_analogy_spans", [])
            if str(value).strip()
        ]
        if excess:
            spans.extend(excess)
        elif str(item.get("candidate_span", "")).strip():
            spans.append(str(item["candidate_span"]).strip())
    spans.extend(
        str(item.get("replacement_span", "")).strip()
        for item in evaluation.get("protected_support", [])
        if (
            item.get("status") not in PROTECTED_SUPPORT_PASS
            or not item.get("information_equivalent", False)
            or not item.get("reader_comprehensible", False)
            or not item.get("source_grounded", False)
        ) and str(item.get("replacement_span", "")).strip()
    )
    return list(dict.fromkeys(spans))


def _bridge_score(item: dict[str, Any]) -> float:
    return sum(
        float(item.get(key, 0))
        for key in (
            "coverage", "accuracy", "familiarity", "mapping_completeness",
            "relational_alignment", "explanatory_gain",
        )
    ) / 7 + (1.0 - float(item.get("semantic_distance", 1))) / 7


def failed_schema_support_targets(
    evaluation: dict[str, Any],
    min_bridging_score: float = 0.70,
    min_guidance_score: float = 0.70,
) -> dict[str, list[str]]:
    """Return only support IDs that are explicitly failed in this evaluation.

    The returned mapping is the complete schema edit allow-list for one repair
    round.  An empty mapping means the schema dimension is pass-through and no
    patch may claim a schema-support target.
    """
    targets: dict[str, list[str]] = {}

    def add(support_id: Any, spans: Any = ()) -> None:
        key = str(support_id).strip()
        if not key:
            return
        if isinstance(spans, str):
            spans = [spans]
        values = [str(value).strip() for value in spans if str(value).strip()]
        targets.setdefault(key, [])
        targets[key] = list(dict.fromkeys(targets[key] + values))

    for item in evaluation.get("bridges", []):
        failed = bool(
            item.get("status") != "adequate"
            or item.get("forced_binding", False)
            or float(item.get("semantic_distance", 0)) > 0.60
            or float(item.get("relational_alignment", 1)) < 0.50
            or float(item.get("explanatory_gain", 1)) < 0.50
            or _bridge_score(item) < min_bridging_score
        )
        if failed:
            add(item.get("support_id"), item.get("candidate_span", ""))

    metrics = evaluation.get("metrics", {})
    guidance = evaluation.get("guidance", {})
    if (
        guidance.get("status") != "adequate"
        or not bool(metrics.get("guidance_coverage_pass", True))
        or float(metrics.get("A_Q", 1.0)) < min_guidance_score
    ):
        spans = [guidance.get("candidate_span", "")] + [
            item.get("candidate_span", "")
            for item in guidance.get("strategies", [])
            if item.get("status") in {"unsupported", "irrelevant", "weak"}
        ]
        add(guidance.get("support_id", "GS_Q_001"), spans)

    grounding = evaluation.get("reader_grounding", {})
    if not bool(metrics.get("grounding_boundary_pass", True)):
        add(
            grounding.get("support_id", "GS_R_001"),
            grounding.get("violation_spans", []),
        )

    analogy_support_ids: set[str] = set()
    analogy_spans: list[str] = []
    for item in evaluation.get("analogies", []):
        if item.get("status") != "appropriate":
            analogy_support_ids.add(str(item.get("support_id", "GS_A_001")))
            analogy_spans.append(str(item.get("candidate_span", "")))
    narrative = evaluation.get("narrative_mapping", {})
    if narrative.get("status", "adequate") != "adequate":
        analogy_support_ids.add("GS_A_001")
        analogy_spans.append(str(narrative.get("conflicting_span", "")))
    for item in evaluation.get("analogy_complexity", []):
        if item.get("status") == "adequate":
            continue
        analogy_support_ids.add(str(item.get("support_id", "GS_A_001")))
        analogy_spans.extend(
            item.get("excess_analogy_spans", [])
            or [item.get("candidate_span", "")]
        )
    if not all(bool(metrics.get(key, True)) for key in (
        "analogy_semantic_pass", "narrative_mapping_pass",
        "analogy_complexity_pass", "analogy_fallback_pass",
    )):
        analogy_support_ids.add("GS_A_001")
    for support_id in analogy_support_ids:
        add(support_id, analogy_spans)

    for item in evaluation.get("protected_support", []):
        if (
            item.get("status") not in PROTECTED_SUPPORT_PASS
            or not item.get("information_equivalent", False)
            or not item.get("reader_comprehensible", False)
            or not item.get("source_grounded", False)
        ):
            add(
                item.get("support_id"),
                item.get("replacement_span", ""),
            )
    return targets
