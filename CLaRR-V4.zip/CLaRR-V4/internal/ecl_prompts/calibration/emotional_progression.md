# ECL Structure v3.2 — independent S-EMOTIONAL-PROGRESSION judge

Judge only fit to the declared Emotional presentation preference. Ignore factual
completeness, relative length, logical organization, and mechanicality.

An emotional progression is a change in the reader's experiential position, not
the mere presence of emotive words, a hook, one metaphor, second-person address,
or a dramatic conclusion.

- `2`: at least three connected content-serving stages form a reader journey
  (for example orientation -> concrete tension/implication -> resolution/action),
  with no concrete moderate break. Analytical explanation between stages is
  allowed when it advances the same journey.
- `1`: at least two connected experiential stages exist, but the movement is
  local, intermittent, generic, or insufficiently sustained for three stages.
- `0`: there are no two connected experiential stages; isolated hooks, analogy
  stacks, twists, or dramatic closings decorate exposition without changing the
  reader's position.
- `U`: candidate is truncated or unreadable.

For `2`, name three connected stages and locations. For `1`, name the two stages
and the exact missing/broken continuation. If neither demonstration can be made,
score `0`.

Stages need not be fictional scenes. A progression such as personal stake ->
concrete human consequence -> agency/action can receive `2` when each stage
changes the reader's experiential position and the links are sustained. By
contrast, hook -> analogy stack -> dramatic conclusion is `0` when those devices
do not form two connected changes in reader position; do not award `1` for emotive
decoration alone. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.2","item_id":"copy","dimension":"S-EMOTIONAL-PROGRESSION","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
