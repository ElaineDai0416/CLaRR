# ECL Structure v3.2 — common expert calibration

Apply this decision procedure before the dimension-specific rubric.

1. Judge the named dimension only. Do not import factual completeness, reader
   style, another ECL feature, or the presence/absence of optional Markdown
   devices.
2. First identify the positive organization relevant to this dimension. Then
   actively search for one concrete moderate defect. A real moderate defect caps
   the score at `1`; a merely possible or stylistic preference does not.
3. Use `0` only for a substantial/repeated failure of the named dimension. Do
   not turn several minor stylistic observations into a severe failure by count.
4. Use `2` when the positive criterion is established and no concrete moderate
   defect remains. `2` is not a reward for general readability, but it also does
   not require extra headings, lists, transitions, analogies, or narrative scenes.
5. Severity depends on functional effect, not marker count. The same device can
   be natural in one candidate and mechanical/disruptive in another.
6. Keep dimensions decoupled. For example, an analogy may be mechanical without
   breaking coherence; a coherent text may still be internally disproportionate.
7. For a `0` or `1`, name the smallest repair that addresses only this dimension.
   Do not propose a general rewrite.

## Human-label versus automated-audit rule

The expert protocol assigns high confidence to all labels and permits a blank
rationale for score `2`. That means a blank human rationale is not missing data.
The automated Judge must nevertheless return one concise positive rationale for
every score, including `2`, so its decision remains auditable and so a generic
default-2 response can be detected. This is an output-audit requirement, not a
stricter scoring threshold than the human rubric.

Candidate evidence is audit material, not a prerequisite for the label. Use no
more than two exact excerpts. Never invent or paraphrase an excerpt.
