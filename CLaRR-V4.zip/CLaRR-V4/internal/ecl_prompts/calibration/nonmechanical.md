# ECL Structure v3.2 — independent S-NONMECHANICAL judge

Judge only whether organizational devices naturally serve the candidate's
content. Ignore coherence, relative length, factual quality, and preference fit.

Inspect headings, repeated bold labels, lists, hooks, metaphors, analogies,
transitions, summaries, action blocks, and template-like section patterns.

- `2`: devices are content-specific and unobtrusive or necessary; no concrete
  moderate template, decorative, repeated-label, or formulaic scaffolding issue.
- `1`: content still leads, but at least one visible moderate device feels
  inserted, repetitive, over-labelled, generic, or more elaborate than needed.
- `0`: repeated/mechanical scaffolding dominates the organization, or the text is
  substantially built around a template, fabricated scene, or decorative device.
- `U`: candidate is truncated or unreadable.

Do not penalize the number of analogies mechanically. A repeated device lowers
the score only when its recurrence creates a visible template rhythm or competes
with the content. Conversely, prose without headings/lists is not automatically
`2`: repeated framing, rhetorical restatement of the same claim, repeated
intensification, or a redundant conclusion can still be mechanical even when the
candidate uses continuous prose and no explicit template.

Boundary test: mentally remove the device. If content relations remain equally
clear and the device mainly supplies a generic performance layer, it supports
`1`. If removing it would make a content-specific distinction/grouping harder to
follow, it can support `2`. Do not use coherence or emotional-fit defects as a
substitute for this test. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.2","item_id":"copy","dimension":"S-NONMECHANICAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
