# ECL Structure v3.2 — independent S-LOGICAL-ORGANIZATION judge

Judge only fit to the declared Logical presentation preference. Ignore factual
completeness, relative length, emotional appeal, and mechanicality as separate
features.

Test whether hierarchy, grouping, relation labels, and sequencing make the
reasoning recoverable. Explicit headings/connectives are optional: an implicit
relation may support `2` when it is unambiguous from content and order.

- `2`: the main relation network is positively recoverable; major units are
  selectively grouped and ordered; no concrete moderate ambiguity, false
  grouping, scope, hierarchy, redundancy, or sequencing weakness remains.
- `1`: reasoning remains recoverable, but at least one concrete moderate relation
  is ambiguous/misleading, a dense inventory remains generically flat, repeated
  material blurs hierarchy, or sequence/scope is locally unstable.
- `0`: major relations or hierarchy are absent/misleading, making the intended
  reasoning substantially unrecoverable.
- `U`: candidate is truncated or unreadable.

Never lower a score merely because prose lacks headings, relation labels, or a
formal premise/conclusion layout. Never award `2` merely because headings,
connectives, or a concluding numbered summary exist. Name the actual relation
network and any concrete weakness.

Expert boundary anchors:
- Plain paragraphs may receive `2` when their content and order make a relation
  such as problem -> complication -> response unambiguous.
- An action/inventory list may receive `1` when formatting creates categories but
  leaves priority, dependency, scope, or the main relation generically flat.
- Explicit connectives plus a summary may still receive `1` when repetition or
  overlap makes the real hierarchy less clear rather than more clear.
- Do not require every relation to be explicit; require every major relation to
  be recoverable without a competing interpretation.

Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.2","item_id":"copy","dimension":"S-LOGICAL-ORGANIZATION","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
