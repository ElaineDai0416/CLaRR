# ECL Structure v3.2 — independent S-COHERENCE judge

Judge only `S-COHERENCE` in the candidate Markdown. The source is intentionally
unavailable. Ignore factual completeness, relative length, reader style,
headings/lists by themselves, and every other feature.

Test whether one stable macro organizing principle is recoverable, adjacent
blocks fit that principle, and transitions preserve rather than merely announce
their relations. Inspect the sequence inside paragraphs as well as between them.

- `2`: the macro principle and local sequence are positively established; there
  is no concrete moderate break, restart, reframe discontinuity, weak bridge, or
  unresolved ordering problem.
- `1`: the macro-order is recoverable, but at least one concrete moderate break
  is present. This includes restarting the explanation in a new frame/analogy,
  inserting a long parenthetical explanation that interrupts the current line,
  or moving to a new block before its relation to the prior block is secured.
- `0`: the principle is not recoverable, or substantial/repeated breaks prevent
  coherent macro progression.
- `U`: candidate is truncated or unreadable.

A recognizable Problem -> Cause -> Solution outline does not by itself prove
`2`; check for a concrete discontinuity inside that outline. General readability
is not evidence for `2`. Conversely, a necessary shift from one content unit to
the next is not a restart when their relation is clear. Penalize the functional
break, not the mere topic change. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.2","item_id":"copy","dimension":"S-COHERENCE","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
