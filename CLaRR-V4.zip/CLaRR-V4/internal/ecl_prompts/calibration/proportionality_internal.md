# ECL Structure v3.2 — independent S-PROPORTIONALITY-INTERNAL judge

Judge only the candidate's internal structural proportionality. The program
separately applies a deterministic source/candidate expansion cap; do not guess
source length, factual completeness, or source content.

Identify meaningful content units and organizational/explanatory overhead:
hooks, framing, headings, bridges, summaries, examples, analogies, parenthetical
glosses, and repeated takeaways. Judge overhead inside blocks as well as the
allocation of whole blocks.

- `2`: meaningful units receive balanced structural attention; every major block
  develops a distinct unit or necessary relation; no concrete moderate inflation,
  compression, repetition, decorative micro-block, or over-segmentation exists.
- `1`: the organization remains functional, but at least one unit is noticeably
  over/under-developed, or a modest repeated explanation, long analogy/gloss,
  extra frame, thin block, repeated summary, or unnecessary segmentation consumes
  structural attention.
- `0`: substantial or repeated inflation/compression/fragmentation materially
  distorts the candidate's own organizational scale.
- `U`: candidate is truncated or unreadable.

One topic per paragraph does not prove balance. For `2`, name at least two
content-unit-to-block alignments and verify that framing/analogy overhead within
those blocks is not moderate. If that demonstration cannot be made, score at
most `1`. A short candidate is not automatically compressed and a long candidate
is not automatically inflated; the separate deterministic expansion cap handles
relative length. Judge where the candidate spends its own structural attention.
Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.2","item_id":"copy","dimension":"S-PROPORTIONALITY-INTERNAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
