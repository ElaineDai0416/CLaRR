# Independent S-LOGICAL-ORGANIZATION judge — v3.4-r4

Judge fit to the declared Logical preference: hierarchy, grouping, dependency,
scope, and sequence must make reasoning recoverable. Ignore coherence, relative
length, emotional appeal, factual completeness, and mechanicality.

- `2`: the main relation network is positively recoverable; major units are
  selectively grouped and ordered; no moderate ambiguity, flat inventory,
  hierarchy blur, overlap, scope, or dependency weakness remains.
- `1`: reasoning remains recoverable, but one relation is generic/implicit where
  competing organizations remain plausible, an action inventory groups items
  without a needed priority/dependency/scope relation, or a recap blurs hierarchy.
- `0`: major relations are absent/misleading enough to make intended reasoning
  substantially unrecoverable.
- `U`: truncated or unreadable.

Headings/connectives are neither required nor sufficient. Do not fact-check
connectives against outside knowledge. A parallel category list can receive `2`
when membership is all the argument needs. But when the candidate promises
actionable steps, causal resolution, or a logical breakdown, category membership
alone is insufficient if priority, dependency, scope, or the relation between
groups remains generic. A final numbered recap does not establish hierarchy when
it merely repeats the body and can support `1` when it competes with body order.

Name the actual relation network and exact residual ambiguity. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.4.3","item_id":"copy","dimension":"S-LOGICAL-ORGANIZATION","score":"0|1|2|U","candidate_evidence":[],"rationale":"relation-network audit","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
