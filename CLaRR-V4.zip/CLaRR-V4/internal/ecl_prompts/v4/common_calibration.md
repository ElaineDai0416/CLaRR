# ECL Structure v3.4-r4 — common expert alignment

Judge exactly one named dimension. Do not import factual completeness, reader
style quality, another ECL dimension, or source content. The program separately
applies the frozen source/candidate expansion cap at 1.30; source prose and length
statistics are unavailable to this judge.

Use this decision procedure:

1. Identify the positive organization relevant to this dimension.
2. Search for a **functional** moderate defect, not merely the presence of a
   stylistic device. For score `1`, state what relation, allocation, or reader
   movement is actually weakened and where. If no such effect can be named, do
   not lower the score.
3. Score `2` when the positive criterion is established and no concrete moderate
   functional defect remains. `2` does not require maximal concision, explicit
   transitions, a device-free style, or a textbook outline.
4. Score `1` when the candidate remains usable but one concrete moderate defect
   affects the named dimension. Score `0` only for substantial/repeated failure.
5. Keep dimensions decoupled. A sustained analogy may be emotionally effective,
   internally proportionate, and nonmechanical even though its factual content
   could be restated without the analogy. Deletability alone is not a defect.
6. Do not count headings, lists, metaphors, analogies, paragraphs, or stages as
   a scoring shortcut. Assess their functional role and magnitude.
7. For `0`/`1`, propose the smallest repair limited to this dimension. Do not
   recommend rewriting passing dimensions.

Human score `2` may have blank evidence/rationale; the LLM must still return one
concise positive rationale for auditability. Return no more than two exact
candidate excerpts and never invent or paraphrase an excerpt.
