# Independent S-EMOTIONAL-PROGRESSION judge — v3.4-r4

Judge only fit to the declared Emotional preference. Ignore factual completeness,
coherence, logical organization, proportionality, and mechanicality.

Emotional progression means a reader position, felt stake, or experiential frame
is carried meaningfully through the candidate. It does **not** require three
explicitly named stages, continuous metaphor wording, a dramatic climax, a change
of emotion, an action request, or a separate resolution paragraph.

- `2`: a reader position or felt stake is sustained across multiple major regions
  and gives later explanations or recommendations experiential meaning. The frame
  may stay stable; related metaphors may change while serving the same stake.
- `1`: a genuine thread exists, but remains local/intermittent, depends on a hook
  and conclusion while a substantial middle is generic, or consists mainly of a
  static technical renaming without a felt consequence or reader orientation.
- `0`: emotive moments are isolated decoration; no common reader position is
  carried between them.
- `U`: truncated or unreadable.

For `2`, cite at least two separated major regions and explain their shared reader
position or felt stake. Opening-middle-ending evidence is welcome but not a hard
three-stage condition. Health threat/resilience, material cost/community impact,
or narrative danger/resolution can sustain a stake without transforming it.
Purely technical system/computer vocabulary that only renames facts, metrics, or
instructions—without a felt consequence, concern, agency, or reader orientation—
is a static teaching analogy and supports at most `1`.

Positive anchors include a movie-villain frame that changes from threat to
countermeasure, a design frame connecting foundation and resilient health, and a
restaurant/community frame connecting cost pressure and resource impact. Related
sub-metaphors do not break progression when the felt stake persists. A vivid hook
plus unrelated analogy stack plus dramatic closing remains `0` when no reader
position connects the major regions.

Calibration boundaries:

- Foundation/building, palette/choice, and thoughtful pairing can jointly sustain
  one designer position; do not require every middle sentence to repeat the word
  "design".
- Villain, scene, camera, plot twist, and rewritten ending can jointly sustain one
  movie-story position when they preserve threat and resolution.
- Calling the reader a system architect and renaming blood pressure, cholesterol,
  diet, and exercise as load, leaks, patches, and APIs is still only `1` when the
  frame mainly translates instructions and never develops a felt or narrative
  movement beyond technical optimization.

For `1`/`0`, identify the span where experiential connection is static or lost;
do not cite the absence of a third named stage as the defect. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.4.3","item_id":"copy","dimension":"S-EMOTIONAL-PROGRESSION","score":"0|1|2|U","candidate_evidence":[],"rationale":"reader-position continuity audit","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
