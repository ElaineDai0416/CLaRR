# Independent S-COHERENCE judge — v3.4-r4

Judge whether the candidate sustains one macro line and advances it without a
moderate restart, reframe discontinuity, weak bridge, long interruption, or local
sequence jump. Ignore factual completeness, proportionality, mechanicality,
hierarchy quality, and presentation-preference fit.

Before scoring, map the major boundaries as `prior function -> next function ->
linking relation` and inspect sequence inside dense blocks. Look for an observable
break; do not manufacture one merely to avoid score `2`.

- `2`: one macro line is clear and the major boundaries are adequately linked;
  no concrete moderate restart, frame discontinuity, weak bridge, or unresolved
  ordering problem remains. Explicit connectives are not required.
- `1`: the macro line remains recoverable, but one boundary/internal sequence
  restarts an established point in a new analogy or audience frame, inserts a
  long parenthetical explanation, moves to a new block before securing its link,
  or concludes by reintroducing rather than advancing the thesis.
- `0`: repeated/substantial breaks make progression unrecoverable.
- `U`: truncated or unreadable.

A familiar outline or fluent prose is not by itself proof of `2`. Conversely, a
topic change, list, analogy, or recap is not a defect unless it creates an actual
continuity break. A new analogy within the same larger narrative frame may remain
coherent; penalize only when the reader must reconstruct the connection. Do not
import hierarchy blur or mechanical framing from another dimension.

Boundary anchors from expert practice:

- A replacement list introduced by "instead" can still be `1` when the preceding
  inventory has not established the comparison scope and the reader must infer
  why the new list follows.
- A new analogy that changes the relation being explained can be `1` when its
  mapping to the prior claim is left implicit.
- A signposted exception, false alarm, or diagnostic contrast remains coherent
  when it narrows the same topic; a change of sub-metaphor inside that contrast is
  not by itself a jump.

For `1`, quote both sides of the weakest boundary and state the missing or abrupt
relation. A bare assertion that the text is merely "recoverable" is insufficient
for the machine audit. PSJ012's expert score remains valid, but its precise
coherence failure point is still pending; do not invent a candidate-specific rule.

Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.4.3","item_id":"copy","dimension":"S-COHERENCE","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific boundary audit","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
