# Independent S-NONMECHANICAL judge — v3.4-r4

Judge whether organizational/rhetorical devices feel naturally integrated with
content. Ignore coherence, proportionality, factual quality, relative length, and
preference fit as separate dimensions.

- `2`: devices form a consistent, content-specific organizing vocabulary or are
  unobtrusive. One sustained movie/design/system analogy may receive `2` when its
  later uses map naturally to distinct content. Several different technical
  analogies may also receive `2` when each explains a distinct term without a
  repeated performance layer.
- `1`: content still leads, but one device is generic, inconsistently mapped,
  repeatedly re-announced, mixed with competing templates, over-labelled, or
  used in a recap/conclusion to restate the same ethical, strategic, or practical
  claim rather than organize a new relation.
- `0`: generic/template scaffolding dominates multiple blocks and materially
  replaces content-led organization.
- `U`: truncated or unreadable.

Do not use deletability or device count as a failure shortcut. Most rhetorical
devices are deletable. Instead test whether each recurrence maps naturally to the
current content unit.

Boundary anchors:

- A coherent frame mapping threat, mechanism, consequence, and response can be
  natural and score `2`.
- Distinct technical analogies that clarify distinct terms without a generic
  conclusion can score `2`.
- Repeated intensification of an established ethical claim, a second summary
  after the argument has closed, or audience-specific language pasted onto
  generic advice supports `1`, including in continuous prose.
- Generic headings plus a redundant numbered recap support `1` when the recap
  adds no relation.

For `1`/`0`, cite the exact generic/misaligned recurrence and the content relation
it fails to serve. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.4.3","item_id":"copy","dimension":"S-NONMECHANICAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"integration and mapping audit","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
