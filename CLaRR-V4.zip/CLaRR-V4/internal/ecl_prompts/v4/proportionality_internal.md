# Independent S-PROPORTIONALITY-INTERNAL judge — v3.4-r4

Judge only structural-attention allocation inside the candidate. Code separately
applies the 1.30 source-expansion cap; do not infer source content or use total
length alone.

Identify the major content units, then compare the attention they receive and the
magnitude of framing, analogy, gloss, repetition, examples, summaries, lists, and
segmentation.

- `2`: meaningful units receive defensible attention; every major block develops
  a distinct unit or necessary relation; no concrete moderate inflation,
  compression, repeated summary, or thin split remains. Multiple analogies can
  receive `2` when each carries a distinct content unit and displaces nothing.
- `1`: one unit is noticeably over/under-developed; an elaboration block crowds
  out a comparable unit; or a hook/conclusion repeats an already developed
  relation. The imbalance need not make another unit literally absent.
- `0`: substantial/repeated inflation, compression, or fragmentation distorts the
  candidate across multiple blocks, or a major unit is nearly absent.
- `U`: truncated or unreadable.

Magnitude rule: the mere existence, number, vividness, or deletability of
analogies is insufficient for `1`. Name the exact over-attended block or repeated
relation and compare it with a second major unit. Relevant framing embedded in
content-bearing sentences is not overhead. A complete explanatory body followed
by a long application inventory, recap, or ethical/business imperative can be an
imbalance when those supplements receive more space than the central mechanism.

Severe-inflation anchor for `0`: mark substantial overbuilding when a central
explanatory thesis is already complete, but the candidate then adds several
standalone supplemental layers—such as a role-specific hook, detailed phase
breakdown, multi-item application inventory, and long ethical/business
imperative—whose combined attention dominates the core mechanism. Relevance of
each supplement does not erase the aggregate imbalance. Do not lower a compact,
content-mapped analogy stack merely because it contains several metaphors. Code
also reports a separate deterministic severe-expansion audit flag; do not try to
guess that flag from candidate length.

For `2`, name two unit-to-block alignments and confirm neither is displaced.
Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.4.3","item_id":"copy","dimension":"S-PROPORTIONALITY-INTERNAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"unit allocation plus magnitude audit","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
