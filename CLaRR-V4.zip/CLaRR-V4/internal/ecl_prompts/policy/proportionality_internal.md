# ECL Structure v3.1 — independent S-PROPORTIONALITY-INTERNAL judge

Judge only the candidate's internal structural proportionality. The program
separately applies a deterministic source/candidate expansion cap; do not guess
source length, factual completeness, or source content.

Identify the candidate's meaningful content units and its organizational
overhead: hooks, framing, headings, bridges, summaries, examples, analogies, and
repeated takeaways.

- `2`: meaningful units receive balanced structural attention; every major block
  develops a distinct unit or necessary relation; no concrete moderate inflation,
  compression, repeated framing, decorative micro-block, or over-segmentation.
- `1`: the organization remains functional, but at least one unit is noticeably
  over/under-developed, or a modest extra frame, repeated takeaway, thin block,
  analogy layer, or unnecessary segmentation consumes structural attention.
- `0`: substantial or repeated inflation/compression/fragmentation makes the
  candidate's own organizational scale materially distorted.
- `U`: candidate is truncated or unreadable.

For `2`, name at least two distinct content-unit-to-block alignments in the
rationale. If that positive demonstration cannot be made, score at most `1`.
Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.1","item_id":"copy","dimension":"S-PROPORTIONALITY-INTERNAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
