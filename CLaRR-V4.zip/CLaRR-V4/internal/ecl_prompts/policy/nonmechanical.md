# ECL Structure v3.1 — independent S-NONMECHANICAL judge

Judge only whether organizational devices naturally serve the candidate's
content. Ignore coherence, relative length, factual quality, and preference fit.

Inspect headings, repeated bold labels, lists, hooks, metaphors, analogies,
transitions, summaries, action blocks, and template-like section patterns.

- `2`: devices are content-specific and necessary or unobtrusive; no concrete
  moderate template, decorative, repeated-label, analogy-stack, or formulaic
  scaffolding problem is visible.
- `1`: content still leads, but at least one visible moderate device feels
  inserted, repetitive, over-labelled, generic, or more elaborate than needed.
- `0`: repeated/mechanical scaffolding dominates the organization, or the text is
  substantially built around a template, fabricated scene, or decorative device.
- `U`: candidate is truncated or unreadable.

Strict-2 checks: repeated `The X:`/`Key Concept:`/`Action:` labels, multiple
analogy layers, a generic hook plus generic closing, or recurring bold cue phrases
normally prevent `2` unless the rationale demonstrates why each is necessary and
content-specific. General readability is not evidence for `2`.

Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.1","item_id":"copy","dimension":"S-NONMECHANICAL","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
