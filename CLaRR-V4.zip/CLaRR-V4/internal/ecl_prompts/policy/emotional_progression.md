# ECL Structure v3.1 — independent S-EMOTIONAL-PROGRESSION judge

Judge only fit to the declared Emotional presentation preference. Ignore factual
completeness, relative length, logical organization, and mechanicality as
separate features.

An emotional progression is a reader journey, not the mere presence of emotive
words, a hook, one metaphor, second-person address, or a dramatic conclusion.

- `2`: at least three connected stages form a content-serving reader journey
  (for example orientation -> tension/implication -> resolution/action); the
  movement is sustained across the candidate and each experiential device
  materially supports explanation; no concrete moderate break or decorative
  stage remains.
- `1`: some content-serving experiential movement exists, but it is local,
  intermittent, generic, or depends mainly on a hook/conclusion/metaphor rather
  than a sustained journey.
- `0`: no meaningful emotional progression exists, or decorative/dramatized
  framing replaces rather than supports explanation.
- `U`: candidate is truncated or unreadable.

For `2`, name the three or more connected stages and their candidate locations.
If this demonstration cannot be made, score at most `1`. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.1","item_id":"copy","dimension":"S-EMOTIONAL-PROGRESSION","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
