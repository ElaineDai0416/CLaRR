# ECL Structure v3.1 — independent S-COHERENCE judge

Judge only `S-COHERENCE` in the candidate Markdown. The source is intentionally
unavailable. Ignore factual completeness, relative length, reader style,
headings/lists by themselves, and every other feature.

Test whether a stable macro organizing principle is recoverable, adjacent blocks
fit that principle, and transitions preserve rather than merely announce their
relations.

- `2`: all three requirements are positively established; no concrete moderate
  break, abrupt track change, repeated restart, or unresolved ordering problem.
- `1`: the macro-order is recoverable, but at least one concrete moderate break,
  restart, weak bridge, or locally unstable relation is present.
- `0`: the principle is not recoverable, or substantial/repeated breaks prevent a
  coherent macro progression.
- `U`: candidate is truncated or unreadable.

Do not infer `2` from general readability. Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.1","item_id":"copy","dimension":"S-COHERENCE","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
