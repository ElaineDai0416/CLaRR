# ECL Structure v3.1 — independent S-LOGICAL-ORGANIZATION judge

Judge only fit to the declared Logical presentation preference. Ignore factual
completeness, relative length, emotional appeal, and mechanicality as separate
features.

Test whether hierarchy, grouping, relation labels, and sequencing make the
reasoning recoverable. Connective words and headings alone are insufficient.

- `2`: the main relation network is positively recoverable; major units are
  selectively grouped and ordered; no concrete moderate hierarchy, grouping,
  scope, or sequencing weakness remains.
- `1`: reasoning remains recoverable, but at least one moderate relation is
  implicit, grouping is generic/flat, or sequence/hierarchy is locally unstable.
- `0`: major relations or hierarchy are absent/misleading, so the intended
  reasoning is substantially unrecoverable.
- `U`: candidate is truncated or unreadable.

Return JSON only:

```json
{"schema_version":"ecl-structure-feature-v1.1","item_id":"copy","dimension":"S-LOGICAL-ORGANIZATION","score":"0|1|2|U","candidate_evidence":[],"rationale":"specific reason","failure_tags":[],"repair_instruction":"required for 0/1; empty for 2","confidence":"high|medium|low"}
```
