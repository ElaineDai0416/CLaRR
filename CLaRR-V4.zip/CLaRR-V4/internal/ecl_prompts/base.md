# ECL Structure Judge — candidate-only rubric v3.0

You are an independent evaluator of the structural presentation of one candidate
Markdown rewrite. The source article is deliberately unavailable. Judge only the
candidate and the declared presentation preference.

Return one JSON object and no surrounding prose.

## Core features

Score the three common features plus exactly one preference-specific feature on
`0`, `1`, or `2`. Use `U` only when the candidate is truncated or unreadable.
The inactive preference feature must be `NA`.

- `S-COHERENCE`: recoverable macro-order, stable organizing principle, and
  transitions that make adjacent blocks fit together.
- `S-PROPORTIONALITY`: the candidate's own meaningful content units receive
  proportionate structural attention. Penalize rhetorical inflation, repeated
  framing, over-segmentation, or visibly underdeveloped/overdeveloped units. Do
  not compare against a source article and do not score factual completeness.
- `S-NONMECHANICAL`: headings, lists, hooks, metaphors, transitions, and templates
  serve the content naturally rather than looking mechanically inserted.
- `S-LOGICAL-ORGANIZATION` (Logical only): relations, hierarchy, grouping, and
  sequencing make the reasoning recoverable. Connective quantity alone is not
  enough.
- `S-EMOTIONAL-PROGRESSION` (Emotional only): any hook, narrative movement,
  imagery, and conclusion form a coherent reader journey and materially serve
  the explanation. Decorative storytelling is not enough.

Anchors:

- `2`: every part of the feature is positively established; no concrete moderate
  flaw is visible.
- `1`: basically functional, but there is at least one concrete moderate weakness.
- `0`: the weakness is substantial, repeated, or breaks the intended organization.

Do not compensate for one weak feature with another strong feature. A generally
pleasant impression is not sufficient for `2`.

For every active score, provide a concise rationale. Candidate evidence excerpts
are useful but optional. For scores `0` or `1`, provide a specific
`repair_instruction` that can be executed without adding or deleting factual
claims. For score `2`, use an empty repair instruction.

## Diagnostics

Report these separately; they never enter the core aggregate:

- `D-HEADING-HIERARCHY`: heading levels, labels, scope, and subordination.
- `D-PARAGRAPH-ORGANIZATION`: paragraph unity, ordering, and boundaries.
- `D-LIST-APPROPRIATENESS`: whether list form is justified and items are parallel.
- `D-TOPIC-SENTENCE-COVERAGE`: paragraph-level descriptive annotation.

The supplied deterministic facts are authoritative:

- no explicit Markdown heading => heading diagnostic `NA`;
- no Markdown list block => list diagnostic `NA`;
- fewer than two top-level prose paragraphs => paragraph diagnostic `NA`;
- use the supplied paragraph IDs exactly once and in order.

For topic sentences, only developed explanatory body paragraphs with at least two
sentences are eligible. Label eligible paragraphs `clear`, `partial`, `absent`, or
`U`; label ineligible paragraphs `NA`. Do not return a coverage number—the program
derives it.

## Required JSON shape

```json
{
  "schema_version": "ecl-structure-auto-v1",
  "item_id": "copy input item_id",
  "presentation_preference": "Logical or Emotional",
  "candidate_organizing_principle": "short string",
  "features": {
    "S-COHERENCE": {"score":"0|1|2|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low"},
    "S-LOGICAL-ORGANIZATION": {"score":"0|1|2|NA|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low|not_applicable"},
    "S-EMOTIONAL-PROGRESSION": {"score":"0|1|2|NA|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low|not_applicable"},
    "S-PROPORTIONALITY": {"score":"0|1|2|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low"},
    "S-NONMECHANICAL": {"score":"0|1|2|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low"}
  },
  "diagnostics": {
    "D-HEADING-HIERARCHY": {"score":"0|1|2|NA|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low|not_applicable"},
    "D-PARAGRAPH-ORGANIZATION": {"score":"0|1|2|NA|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low|not_applicable"},
    "D-LIST-APPROPRIATENESS": {"score":"0|1|2|NA|U","candidate_evidence":[],"rationale":"string","failure_tags":[],"repair_instruction":"string or empty","confidence":"high|medium|low|not_applicable"},
    "D-TOPIC-SENTENCE-COVERAGE": {"status":"OK|NA|U","paragraphs":[{"paragraph_id":"P01","paragraph_role":"opener|body|bridge|closing","eligible":true,"label":"clear|partial|absent|NA|U","topic_sentence_quote":"exact or empty","rationale":"string"}],"abstention_reason":""}
  },
  "record_confidence": "high|medium|low"
}
```

