"""V4 = V3 + output-contract suffixes (T6a/T6c) + two-tier prefix (T7).

V3 gave: shared-prefix dedup (T1), contract slimming (T2), verifier brevity
(T3), compact JSON (T4), repair dedup (T5), prompt memoization, the ECL-judge
echo guard, and per-call usage instrumentation.  V4 adds four levers aimed at
the measured cost anatomy (output tokens = ~40% of per-pair cost; frozen
call-type instructions re-billed as cache misses on the main lane):

  T6a  ECL judge output contract — append-only suffix on the feature lane:
       free-text justifications ≤12 words, never quote the candidate.  The
       prose is not consumed anywhere downstream (parser takes scores only).
  T6b  REMOVED after the 2026-08-31 smoke: "never restate the claim text"
       made the model drop candidate_span quotes, and the frozen
       lexical-anchor logic then downgraded every preserved claim to
       `omitted` (recall 0.0 on all 4 smoke pairs, 9/9 empty spans).  The
       measured saving was nil (verifier out/call 963 vs T3's 942), so the
       verifier lane keeps V3's 25-word reason cap (T3) — strictly safer.
  T6c  term-extraction output-only suffix.  The term-SCORING prompt is
       deliberately untouched: its strategy/rationale fields feed the frozen
       ICL strategy text — a treatment variable, not a cost problem.
  T7   two-tier prefix — frozen instruction headers are hoisted ABOVE the
       shared article block, giving [global instructions][article block]
       [reader tail].  Instruction segments (identical across the entire
       corpus) then hit the provider prefix cache like the judge lane's
       common rubric already does (87% measured) instead of being re-billed
       per call after the block (main lane was 28%).

All levers are append-only or reorder-only: frozen prompt bytes are never
rewritten, so provider prefix caching is preserved.  Levers can be toggled
individually via CLARR_V4_LEVERS="T6a,T6b,T6c,T7" for smoke attribution.

Provenance: every output record is stamped schema_version
clarr-module-ablation-v4.0.0 with the active lever list.
"""

from __future__ import annotations

import atexit
import json
import os
import re
import threading
import time
from pathlib import Path
from typing import Any, Callable

import ablation_core as ap
from ablation_core import AblationSpec, resolve_spec  # noqa: F401
import ablation_cost as v3
from ablation_cache import PersistentPromptCache

HERE = Path(__file__).resolve().parent
CACHE_DIR = HERE / "cache_v4"
CACHE_PATH = CACHE_DIR / "llm_cache.json"
USAGE_PATH = CACHE_DIR / "usage.jsonl"

ABLATION_SCHEMA_VERSION_V4 = "clarr-module-ablation-v4.0.0"

CACHE = PersistentPromptCache(CACHE_PATH)


# ── Lever switches ─────────────────────────────────────────────────────────────

DEFAULT_LEVERS = ("T6A", "T6C", "T7")  # canonical form is uppercase; T6b removed


def set_levers(spec: str | None) -> None:
    """Runtime lever control (env at import; tests use this for isolation).

    None → env var CLARR_V4_LEVERS → default all four.  An empty string (or
    unset-but-explicitly-empty env) disables every V4 lever, i.e. pure V3
    behaviour — the state smoke tests use as their baseline configuration.
    """
    global LEVERS
    raw = spec if spec is not None else os.environ.get("CLARR_V4_LEVERS")
    if raw is None:
        LEVERS = set(DEFAULT_LEVERS)
    else:
        LEVERS = {name.strip().upper() for name in raw.split(",") if name.strip()}


LEVERS: set[str] = set()
set_levers(None)

# ── T6a/T6b/T6c output-contract suffixes (append-only) ────────────────────────

_JUDGE_SUFFIX = (
    "\n\nOUTPUT CONTRACT (no new task): respond with exactly the JSON object "
    "this rubric requires and nothing else. In every free-text justification "
    "or assessment field write at most 12 words. Never quote or restate the "
    "candidate text; refer to it as \"the candidate\" if needed."
)
_TERM_SUFFIX = (
    "\n\nOUTPUT CONTRACT (no new task): output only the term list in the "
    "requested format — no preamble, no commentary."
)

# idempotence keys (unique substrings of each suffix)
_JUDGE_KEY = "Never quote or restate the candidate text"
_TERM_KEY = "no preamble, no commentary"

_TERM_EXTRACTION_SIG = "You are a computational linguist"
# the term-SCORING prompt is the ICL treatment generator — never suffixed
_TERM_SCORING_SIG = "You are simulating the reader described below"


def apply_output_contracts(prompt: str) -> str:
    """T6c on the main lane.  T6a is applied on the feature lane.

    The verifier branch always uses V3's T3 brevity suffix: T6b was removed
    after the smoke showed it zeroes recall (empty candidate_span → frozen
    anchor logic downgrades preserved claims to `omitted`) for no saving.
    """
    head = prompt.lstrip()
    if head.startswith(v3._VERIFIER_HEADER):
        return v3.apply_brevity(prompt)
    if ("T6C" in LEVERS and _TERM_EXTRACTION_SIG in prompt[:400]
            and _TERM_SCORING_SIG not in prompt[:400]
            and _TERM_KEY not in prompt):
        return prompt + _TERM_SUFFIX
    return prompt


# ── T7: two-tier prefix (instructions above the shared block) ─────────────────

class PairContextV4(v3.PairContext):
    """[frozen instructions][shared article block][reader tail].

    V3 put the block first, which hides the per-call-type instruction text
    behind per-article divergence; hoisting the instructions that precede the
    source restores their cross-article identity (and is closer to the frozen
    prompts' own order than V3's layout).
    """

    def transform(self, prompt: str) -> str:
        if not self.enabled or v3._BLOCK_HEADER in prompt:
            _stat("passthrough")
            return prompt
        source = self.source or ""
        index = prompt.find(source)
        if index < 0:
            _stat("passthrough")  # no article inside → a block would only add cost
            return prompt
        header = prompt[:index].rstrip()
        tail = prompt[index:].replace(source, v3._SOURCE_MARKER)
        removed = len(source) * (prompt.count(source) - 1)
        if self.claims and self.claims in tail:
            removed += len(self.claims) * (tail.count(self.claims) - 1)
            tail = tail.replace(self.claims, v3._CLAIMS_MARKER)
        _stat("two_tier", header_chars=len(header), tail_chars_removed=removed,
              block_chars_added=len(self.block))
        if header:
            return header + "\n\n" + self.block + "\n\n" + tail
        return self.block + "\n\n" + tail  # source led the prompt → V3 layout

    def transform_v3(self, prompt: str) -> str:
        return v3.PairContext.transform(self, prompt)  # block-first (lever off)


_V4_STATS = {
    "two_tier": 0, "block_first": 0, "passthrough": 0,
    "header_chars": 0, "tail_chars_removed": 0, "block_chars_added": 0,
}
_STATS_LOCK = threading.Lock()


def _stat(kind: str, **extra: int) -> None:
    with _STATS_LOCK:
        _V4_STATS[kind] = _V4_STATS.get(kind, 0) + 1
        for key, value in extra.items():
            _V4_STATS[key] = _V4_STATS.get(key, 0) + value


# ── Feature lane: T6a suffix + V4 echo guard (raw_decode payload id) ──────────

def _expected_item_id_v4(prompt: str) -> str | None:
    """item_id from the payload JSON; tolerates a suffix appended after it."""
    _, sep, tail = prompt.rpartition("## Item")
    if sep:
        try:
            obj, _end = json.JSONDecoder().raw_decode(tail.lstrip())
            value = obj.get("item_id") if isinstance(obj, dict) else None
            if value:
                return str(value)
        except (ValueError, json.JSONDecodeError):
            pass
    match = None
    for match in re.finditer(r'"item_id":\s*"([^"]+)"', prompt):
        pass
    return match.group(1) if match else None


def _guarded_feature_underlying_v4(prompt: str, **kwargs: Any) -> str:
    """V3's guard semantics on a possibly suffixed prompt (T6a appended).

    Echo typos are normalized in place; unusable responses raise so nothing
    poisoned ever enters the persistent cache.
    """
    expected = _expected_item_id_v4(prompt)
    for attempt in (0, 1):
        request = prompt if attempt == 0 else prompt + v3._JSON_HINT
        response = v3._feature_underlying(request, **kwargs)
        try:
            data = json.loads(response)
        except (ValueError, json.JSONDecodeError):
            continue
        if expected is None:
            return response
        echoed = str(data.get("item_id", ""))
        if echoed == expected:
            return response
        if v3._echo_typo(echoed, expected):
            data["item_id"] = expected
            return json.dumps(data, ensure_ascii=False)
    raise RuntimeError(
        "v4 feature guard: judge response unusable after 2 attempts; "
        "raising so nothing enters the cache"
    )


# ── Per-kind usage instrumentation ─────────────────────────────────────────────

_KIND_TLS = threading.local()

_KIND_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("fidelity_verifier", ("You are a conservative fidelity verifier",)),
    ("term_scoring", ("You are simulating the reader described below",)),
    ("term_extraction", ("You are a computational linguist",)),
    ("rewrite_or_condense", ("## CLaRR CONTROLLED ABLATION",)),
)


def classify_prompt(prompt: str) -> str:
    head = prompt.lstrip()[:400]
    for kind, signatures in _KIND_RULES:
        if any(sig in head for sig in signatures):
            return kind
    return "main_other"


_USAGE_LOCK = threading.Lock()
_usage_installed = False


def install_usage_recorder() -> None:
    global _usage_installed
    if _usage_installed or not os.environ.get("CLARR_V4_USAGE"):
        return
    try:
        completions = ap.core.get_client().chat.completions
        original = completions.create
    except Exception:
        return  # no credential / no client: instrumentation stays off

    def recording_create(**request: Any) -> Any:
        response = original(**request)
        try:
            usage = getattr(response, "usage", None)
            if usage is not None:
                kind = getattr(_KIND_TLS, "kind", None)
                if not kind:
                    messages = request.get("messages") or [{}]
                    content = messages[0].get("content", "") if messages else ""
                    kind = classify_prompt(str(content))
                row = {
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "kind": kind or "unknown",
                    "prompt_tokens": getattr(usage, "prompt_tokens", None),
                    "completion_tokens": getattr(usage, "completion_tokens", None),
                    "cache_hit_tokens": getattr(usage, "prompt_cache_hit_tokens", None),
                    "cache_miss_tokens": getattr(usage, "prompt_cache_miss_tokens", None),
                }
                with _USAGE_LOCK:
                    with open(USAGE_PATH, "a", encoding="utf-8") as handle:
                        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
        except Exception:
            pass  # instrumentation must never break a batch
        return response

    with _USAGE_LOCK:  # 16 workers install concurrently at pair startup
        if _usage_installed:
            return
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        completions.create = recording_create
        _usage_installed = True


def _usage_by_kind() -> dict[str, dict[str, int]]:
    totals: dict[str, dict[str, int]] = {}
    path = Path(USAGE_PATH)
    if not path.is_file():
        return totals
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = row.get("kind") or "unknown"
            bucket = totals.setdefault(
                kind, {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0,
                       "cache_hit_tokens": 0, "cache_miss_tokens": 0})
            bucket["calls"] += 1
            for key in ("prompt_tokens", "completion_tokens",
                        "cache_hit_tokens", "cache_miss_tokens"):
                if row.get(key) is not None:
                    bucket[key] += int(row[key])
    return totals


# ── LLM closures: contracts → T7 transform → memo cache ───────────────────────

def make_pair_llm_calls_v4(
    article_text: str,
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None,
) -> tuple[Callable[..., str], Callable[..., str]]:
    """Build the (llm_call, feature_llm_call) pair carrying this article."""
    from fidelity_repair import compact_contract

    contract = ap.normalize_claim_contract(
        article_claim_record, simplification_ledger or {}
    )
    context = PairContextV4(article_text, compact_contract(contract))

    def main_llm(prompt: str, **kwargs: Any) -> str:
        request = apply_output_contracts(prompt)
        _KIND_TLS.kind = classify_prompt(request)
        if "T7" in LEVERS:
            transformed = context.transform(request)
        else:
            transformed = context.transform_v3(request)
        return CACHE.call("main", v3._main_underlying, transformed, **kwargs)

    def feature_llm(prompt: str, **kwargs: Any) -> str:
        # T1 stays OFF here (judge prompts keep their byte-identity for the
        # provider prefix cache); T6a appends an output contract instead.
        request = prompt + _JUDGE_SUFFIX if ("T6A" in LEVERS and _JUDGE_KEY not in prompt) else prompt
        _KIND_TLS.kind = "ecl_judge"
        return CACHE.call("feature", _guarded_feature_underlying_v4, request, **kwargs)

    return main_llm, feature_llm


# ── Process entry ──────────────────────────────────────────────────────────────

def _stamp_v4(result: dict[str, Any]) -> dict[str, Any]:
    ablation = dict(result.get("ablation") or {})
    ablation["schema_version"] = ABLATION_SCHEMA_VERSION_V4
    ablation["pipeline_variant"] = "v4-output-contracts-two-tier-prefix"
    ablation["token_optimization"] = {
        "mode": "v3 transformations + output-contract suffixes + two-tier prefix",
        "prompts_modified": True,
        "levers_active": sorted(LEVERS),
        "transformations": {
            "T1_shared_prefix_dedup": "inherited from v3 (main lane)",
            "T2_contract_slimming": "inherited from v3",
            "T3_verifier_brevity": "active (T6b removed after smoke: zeroed recall via empty spans)",
            "T4_compact_json": "inherited from v3",
            "T5_repair_packet_dedup": "inherited from v3 (via T1)",
            "T6a_judge_output_contract": (
                "append-only suffix on ECL judge prompts: justifications ≤12 "
                "words, no candidate quotation (prose unconsumed downstream)"
            ),
            "T6b_verifier_output_contract": (
                "REMOVED after 2026-08-31 smoke: the 'never restate the claim "
                "text' clause made the model drop candidate_span quotes and the "
                "frozen anchor logic downgraded all claims to omitted (recall "
                "0.0); no token saving measured either"
            ),
            "T6c_term_extraction_output_only": (
                "term list without preamble; term-scoring prompt untouched"
            ),
            "T7_two_tier_prefix": (
                "frozen instruction headers hoisted above the shared article "
                "block: [global instructions][article block][reader tail]"
            ),
        },
        "protected_from_compression": [
            "rewrite candidate (the product)",
            "frozen strategy text and term rationale (treatment variables; "
            "rationale consumed when formatting the ICL strategy block)",
            "repair patch spans (byte-exact frozen consumers)",
        ],
        "cache_shared_across": ["readers", "variants", "resume_passes"],
        "stochastic_note": (
            "temperature-0.2 calls are memoized: identical requests return the "
            "recorded sample instead of resampling"
        ),
        "parent_schema_version": v3.ABLATION_SCHEMA_VERSION_V3,
    }
    result["ablation"] = ablation
    return result


def process_article_for_reader_ablation_v4(
    article_id: str,
    article_text: str,
    reader_profile: dict[str, Any],
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None = None,
    *,
    variant: str | AblationSpec,
    article_title: str = "",
    fidelity_policy: Any = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    llm_call: Callable[..., str] | None = None,
    feature_llm_call: Callable[..., str] | None = None,
) -> dict[str, Any]:
    """V3 flow + the four V4 levers."""
    resolve_spec(variant)  # fail fast on an unknown variant, before any LLM call
    install_usage_recorder()
    pair_llm, pair_feature_llm = make_pair_llm_calls_v4(
        article_text, article_claim_record, simplification_ledger
    )
    result = ap.process_article_for_reader_ablation(
        article_id,
        article_text,
        reader_profile,
        article_claim_record,
        simplification_ledger,
        variant=variant,
        article_title=article_title,
        fidelity_policy=fidelity_policy,
        enable_repair=enable_repair,
        ecl_repair_rounds=ecl_repair_rounds,
        max_total_repair_attempts=max_total_repair_attempts,
        ecl_calibration_mode=ecl_calibration_mode,
        llm_call=llm_call or pair_llm,
        feature_llm_call=feature_llm_call or pair_feature_llm,
    )
    return _stamp_v4(result)


# ── Exit report ────────────────────────────────────────────────────────────────

def _report() -> None:
    CACHE._flush()
    cache_stats = CACHE.summary()
    with _STATS_LOCK:
        stats = dict(_V4_STATS)
    lines = [f"[v4] levers={','.join(sorted(LEVERS)) or 'none'}",
             f"[v4] cache hits={cache_stats['hits']} live={cache_stats['misses']} "
             f"entries={cache_stats['entries']}",
             f"[v4] prefix two_tier={stats.get('two_tier', 0)} "
             f"block_first={stats.get('block_first', 0)} "
             f"passthrough={stats.get('passthrough', 0)}; header chars hoisted≈"
             f"{stats.get('header_chars', 0):,} tail chars removed≈"
             f"{stats.get('tail_chars_removed', 0):,}"]
    by_kind = _usage_by_kind()
    if by_kind:
        print("[v4] usage by kind (calls | prompt hit/miss | completion):")
        for kind, bucket in sorted(by_kind.items(),
                                   key=lambda kv: -kv[1]["completion_tokens"]):
            lines.append(
                f"[v4]   {kind:20s} {bucket['calls']:5d} | "
                f"{bucket['cache_hit_tokens']:,}/{bucket['cache_miss_tokens']:,} | "
                f"{bucket['completion_tokens']:,}"
            )
    print("\n".join(lines))


atexit.register(_report)
atexit.unregister(v3._report)  # v4 replaces the v3 exit report (v3's cache is unused here)


__all__ = [
    "ABLATION_SCHEMA_VERSION_V4",
    "CACHE",
    "PairContextV4",
    "apply_output_contracts",
    "classify_prompt",
    "process_article_for_reader_ablation_v4",
    "set_levers",
]
