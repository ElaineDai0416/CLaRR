"""V3 ablation pipeline: V2 memoization + declared prompt-protocol optimizations.

Unlike V2 (prompt-identical memoization), V3 deliberately changes what the model
sees.  This is a new declared protocol version, stamped in every output record
under ``ablation.token_optimization``.  Five transformations, applied in order:

T1  shared-prefix dedup (the big lever, input-miss -> input-hit):
    every prompt for one (article, variant) family is rewritten as

        [SHARED ARTICLE CONTEXT block: source text + compact claim contract]
        <original prompt with the in-prompt source/contract copies replaced by
         short markers ``<source ref=1/>`` / ``<claims ref=2/>``>

    The block is byte-identical across all ~16 calls of a pair, all 18 readers
    of an article, and all three variants, so the provider's automatic prefix
    cache prices it at cache-hit instead of cache-miss.  All per-call content
    (instructions, candidate, anchors) stays in the tail.  Prompts that do not
    contain the source text pass through unchanged; transforming is fail-safe.

T2  rewrite/condense contract slimming: the JSON embedded in the unified
    rewrite and condense prompts drops evaluator bulk and bookkeeping
    (``raw_evaluations``, ``frozen_strategy_bundle``, ``strategy_sha256``,
    ``contract_sha256``) and compacts ``source_baseline_score`` to module
    scores.  The full contracts remain untouched in the result JSON and in
    every frozen gate/audit consumer.

T3  fidelity-verifier brevity: the two frozen verifier prompts get a suffix
    capping each ``reason`` at ~25 words.  ``candidate_span`` /
    ``closest_source_span`` must still be quoted exactly because the frozen
    repair machinery consumes them byte-exactly (span removal, offset
    matching, severity keyword logic).

T4  compact JSON: every JSON this layer embeds uses ``separators=(",", ":")``
    instead of ``indent=2``.

T5  repair-packet dedup: repair packets re-send the full source; T1's marker
    replacement deduplicates it, leaving candidate + anchors + packet scopes
    in the tail — the delta the repair model actually needs.

The per-pair context rides on a closure, not a thread-local: V1 hands the
injected ``llm_call`` down through every internal thread pool, so a closure
sees all calls from any thread.  Memoization (V2 semantics, fresh cache_v3/)
keys on the TRANSFORMED prompt, so identical transformed requests still
deduplicate; temperature-0.2 calls return the recorded sample.

Optional usage instrumentation: set CLARR_V3_USAGE=1 to append per-call
provider usage (prompt/hit/miss/completion tokens) to cache_v3/usage.jsonl.
"""

from __future__ import annotations

import atexit
import json
import os
import re
import threading
import time
from pathlib import Path
from typing import Any, Callable

import ablation_core as ap
from ablation_core import ABLATION_SPECS, AblationSpec, resolve_spec  # noqa: F401
from ablation_cache import PersistentPromptCache

HERE = Path(__file__).resolve().parent
CACHE_DIR = HERE / "cache_v3"
CACHE_PATH = CACHE_DIR / "llm_cache.json"
USAGE_PATH = CACHE_DIR / "usage.jsonl"

ABLATION_SCHEMA_VERSION_V3 = "clarr-module-ablation-v3.0.0"

CACHE = PersistentPromptCache(CACHE_PATH)

# ── T1: shared-prefix dedup ────────────────────────────────────────────────────

_BLOCK_HEADER = (
    "[SHARED ARTICLE CONTEXT — byte-identical in every call for this article; "
    "the markers <source ref=1/> and <claims ref=2/> used below refer to this block]"
)
_SOURCE_MARKER = "<source ref=1/>"
_CLAIMS_MARKER = "<claims ref=2/>"
_MIN_SOURCE_CHARS = 1200   # below this the shared block saves nothing meaningful
_MIN_CLAIMS_CHARS = 500

# ── T3: verifier brevity ───────────────────────────────────────────────────────

_VERIFIER_HEADER = "You are a conservative fidelity verifier"
_BREVITY_SUFFIX = (
    "\n\nOUTPUT BREVITY: keep every `reason` field to at most 25 words while still "
    "naming the specific missing or added fact. Always quote `candidate_span` and "
    "`closest_source_span` exactly as before."
)


def apply_brevity(prompt: str) -> str:
    """T3: cap verifier reason verbosity; spans stay exact for frozen consumers."""
    if prompt.startswith(_VERIFIER_HEADER) and _BREVITY_SUFFIX not in prompt:
        return prompt + _BREVITY_SUFFIX
    return prompt

# ── T2: contract slimming ──────────────────────────────────────────────────────

_SLIM_DROP_KEYS = frozenset({
    "raw_evaluations",
    "frozen_strategy_bundle",
    "strategy_sha256",
    "contract_sha256",
})


def _compact_baseline(value: dict[str, Any]) -> dict[str, Any]:
    modules: dict[str, Any] = {}
    for name, module in (value.get("modules") or {}).items():
        if isinstance(module, dict):
            modules[name] = {
                "score": module.get("score"),
                "failed_target_ids": module.get("failed_target_ids", []),
            }
    return {
        "macro_score": value.get("macro_score"),
        "modules": modules,
        "note": "full raw evaluations omitted from prompt; see run record",
    }


def slim_contract_for_prompt(value: Any) -> Any:
    """Drop evaluator bulk and hash bookkeeping from contract JSON embeds.

    Only what this layer embeds in prompts is slimmed; the stored contracts and
    every frozen consumer keep the full objects.
    """
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, item in value.items():
            if key in _SLIM_DROP_KEYS:
                continue
            if key == "source_baseline_score" and isinstance(item, dict):
                item = _compact_baseline(item)
            out[key] = slim_contract_for_prompt(item)
        return out
    if isinstance(value, list):
        return [slim_contract_for_prompt(item) for item in value]
    return value


# ── T4: compact JSON ───────────────────────────────────────────────────────────

def _cdumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


class PairContext:
    """Per-(article, contract) prompt transformer carried on a closure."""

    def __init__(self, source_text: str, claims_text: str) -> None:
        self.source = (
            source_text if source_text and len(source_text) >= _MIN_SOURCE_CHARS
            else None
        )
        self.claims = (
            claims_text if claims_text and len(claims_text) >= _MIN_CLAIMS_CHARS
            else None
        )
        block_parts = [_BLOCK_HEADER]
        if self.source:
            block_parts.append(f"<source ref=1>\n{self.source}\n</source ref=1>")
        if self.claims:
            block_parts.append(f"<claims ref=2>\n{self.claims}\n</claims ref=2>")
        self.block = "\n\n".join(block_parts)
        self.enabled = bool(self.source)

    def transform(self, prompt: str) -> str:
        """Hoist the shared block to the head; marker out in-prompt copies.

        Fail-safe by construction: anything unexpected returns the prompt
        unchanged, so a transform bug can never kill a pair.
        """
        if not self.enabled or prompt.startswith(_BLOCK_HEADER):
            _record_passthrough()
            return prompt
        source = self.source or ""
        if source not in prompt:
            _record_passthrough()  # no article inside → a block would only add cost
            return prompt
        tail = prompt.replace(source, _SOURCE_MARKER)
        removed = len(source) * (prompt.count(source) - 1)
        if self.claims and self.claims in tail:
            removed += len(self.claims) * (tail.count(self.claims) - 1)
            tail = tail.replace(self.claims, _CLAIMS_MARKER)
        _record_transform(removed, len(self.block))
        return self.block + "\n\n" + tail


_TRANSFORM_STATS = {
    "calls_transformed": 0,
    "calls_passthrough": 0,
    "tail_chars_removed": 0,
    "block_chars_added": 0,
}
_STATS_LOCK = threading.Lock()


def _record_transform(removed: int, block_len: int) -> None:
    with _STATS_LOCK:
        _TRANSFORM_STATS["calls_transformed"] += 1
        _TRANSFORM_STATS["tail_chars_removed"] += removed
        _TRANSFORM_STATS["block_chars_added"] += block_len


def _record_passthrough() -> None:
    with _STATS_LOCK:
        _TRANSFORM_STATS["calls_passthrough"] += 1


# ── V3 rewrite / condense prompt builders (rebound onto ablation_core) ──────

def build_active_rewrite_prompt_v3(
    *,
    source_text: str,
    reader_text: str,
    strategies: Any,
    claim_guardrail: str,
    il_term_contract: list[dict[str, Any]],
    upfront_strategy_contract: dict[str, Any],
    orig_words: int,
    max_words: int,
) -> str:
    """V1 rewrite prompt with T2 slimming + T4 compact JSON (T1 applied later)."""
    labels = {"icl": "ICL", "ecl": "ECL", "gcl": "GCL/schema-support"}
    sections = "\n\n".join(
        f"### Frozen {labels[name]} strategy\n{strategies[name]}"
        for name in ("icl", "ecl", "gcl") if name in strategies
    )
    il_payload = (
        "\n\n### Active IL term contract\n" + _cdumps(il_term_contract)
        if "icl" in strategies else ""
    )
    return f"""## CLaRR CONTROLLED ABLATION — SINGLE UNIFIED REWRITE
Rewrite the source once for the target reader. Execute every obligation in the two
frozen strategy sections below. Merge compatible instructions into the same sentence;
do not create a third strategy layer or add an additional rewrite pass.

### Shared claim-fidelity boundary (always active)
{claim_guardrail}

### Source
{source_text}

### Reader
{reader_text}

### Length
Source length: {orig_words} units. Hard maximum: {max_words} units.

{sections}
{il_payload}

### Active upfront integration contract
{_cdumps(slim_contract_for_prompt(upfront_strategy_contract))}

### Output
Return only:
<Optimized Content>
[the complete rewritten article]
</Optimized Content>
Do not output plans, audits, strategy labels, or commentary.
"""


def build_active_condense_prompt_v3(
    *,
    candidate: str,
    max_words: int,
    current_words: int,
    claim_guardrail: str,
    strategies: Any,
    strategy_execution_contract: dict[str, Any],
) -> str:
    """V1 condense prompt with T2 slimming + T4 compact JSON (T1 applied later)."""
    active = ", ".join(name.upper() for name in strategies)
    return f"""Condense the candidate from {current_words} to at most {max_words} units.
Preserve every shared claim-fidelity obligation and every already-realized obligation
from the active strategy layers ({active}). Remove repetition and optional decoration
before shortening required explanations or relation/support sentences. Do not introduce
new facts and do not reconstruct an unlisted module.

CLAIM BOUNDARY:
{claim_guardrail}

ACTIVE EXECUTION CONTRACT:
{_cdumps(slim_contract_for_prompt(strategy_execution_contract))}

CANDIDATE:
{candidate}

Return only <Optimized Content>...</Optimized Content>.
"""


ap.build_active_rewrite_prompt = build_active_rewrite_prompt_v3   # noqa: F811
ap.build_active_condense_prompt = build_active_condense_prompt_v3


# ── LLM wrappers: closure context → transform → brevity → memo cache ──────────

_main_underlying = ap.raise_output_cap(ap.core.call_llm)
_feature_underlying = ap.raise_output_cap(ap.core.call_ecl_feature_llm)


_JSON_HINT = ("\n\nIMPORTANT: respond with a single valid JSON object and "
              "nothing else.")


def _expected_item_id(prompt: str) -> str | None:
    """The item_id of the judge payload (after the last '## Item' header).

    Parsed from the payload JSON itself, not regex-scanned: the rubric text
    may quote other item_ids.  The regex is a dead-code safety net for a
    payload we somehow cannot parse.
    """
    _, sep, tail = prompt.rpartition("## Item")
    if sep:
        try:
            value = json.loads(tail.strip()).get("item_id")
            if value:
                return str(value)
        except (ValueError, json.JSONDecodeError, AttributeError):
            pass
    match = None
    for match in re.finditer(r'"item_id":\s*"([^"]+)"', prompt):
        pass
    return match.group(1) if match else None


def _echo_typo(echoed: str, expected: str) -> bool:
    """True only for the observed hyphen/underscore echo confusion."""
    flat = echoed.replace("_", "-")
    return bool(echoed) and flat == expected.replace("_", "-")


def _guarded_feature_underlying(prompt: str, **kwargs: Any) -> str:
    """Normalize ECL judge echo typos; never cache an unusable response.

    The frozen v3.4 judge parser rejects a response whose echoed ``item_id``
    differs from the requested one and has NO retry — one temp-0 sampling
    flake (observed: ``L-E-E`` echoed as ``L-E_E``) kills the pair.  Under
    memoization a bad sample would additionally be frozen forever.  A
    hyphen/underscore echo typo is bookkeeping, not judging: the response is
    corrected in place and returned (deterministic, no resample needed).
    Malformed JSON, or a genuinely foreign item_id, is retried once with a
    validity hint; if still unusable the guard RAISES — an exception reaches
    no cache, so the catchup pass retries the pair with fresh draws instead
    of replaying a poisoned entry forever.
    """
    expected = _expected_item_id(prompt)
    for attempt in (0, 1):
        request = prompt if attempt == 0 else prompt + _JSON_HINT
        response = _feature_underlying(request, **kwargs)
        try:
            data = json.loads(response)
        except (ValueError, json.JSONDecodeError):
            continue  # invalid JSON — retry with the hint rather than freeze it
        if expected is None:
            return response
        echoed = str(data.get("item_id", ""))
        if echoed == expected:
            return response
        if _echo_typo(echoed, expected):
            data["item_id"] = expected
            return json.dumps(data, ensure_ascii=False)
        continue  # foreign item_id — one more attempt with the hint
    raise RuntimeError(
        "v3 feature guard: judge response unusable after 2 attempts "
        "(invalid JSON or foreign item_id); raising so nothing enters the cache"
    )


def make_pair_llm_calls(
    article_text: str,
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None,
) -> tuple[Callable[..., str], Callable[..., str]]:
    """Build the (llm_call, feature_llm_call) pair carrying this article's context."""
    from fidelity_repair import compact_contract

    contract = ap.normalize_claim_contract(
        article_claim_record, simplification_ledger or {}
    )
    context = PairContext(article_text, compact_contract(contract))

    def main_llm(prompt: str, **kwargs: Any) -> str:
        return CACHE.call(
            "main", _main_underlying, context.transform(apply_brevity(prompt)), **kwargs
        )

    def feature_llm(prompt: str, **kwargs: Any) -> str:
        # No T1 here: the ECL judge embeds the candidate inside an escaped JSON
        # payload (no raw-source match in the common case) and its rubric
        # prefixes already hit the provider prefix cache naturally (~67%
        # measured), so dedup adds nothing.  The guarded underlying corrects
        # item_id echo typos in place and refuses to cache unusable responses.
        return CACHE.call(
            "feature", _guarded_feature_underlying, prompt, **kwargs
        )

    return main_llm, feature_llm


# ── Optional per-call usage instrumentation (CLARR_V3_USAGE=1) ─────────────────

_USAGE_LOCK = threading.Lock()
_usage_installed = False


def install_usage_recorder() -> None:
    global _usage_installed
    if _usage_installed or not os.environ.get("CLARR_V3_USAGE"):
        return
    try:
        completions = ap.core.get_client().chat.completions
        original = completions.create
    except Exception:
        return  # no credential / no client: instrumentation stays off

    def recording_create(**request: Any) -> Any:
        response = original(**request)
        try:
            usage = getattr(response, "usage", None)
            if usage is not None:
                row = {
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "prompt_tokens": getattr(usage, "prompt_tokens", None),
                    "completion_tokens": getattr(usage, "completion_tokens", None),
                    "cache_hit_tokens": getattr(usage, "prompt_cache_hit_tokens", None),
                    "cache_miss_tokens": getattr(usage, "prompt_cache_miss_tokens", None),
                }
                with _USAGE_LOCK:
                    with open(USAGE_PATH, "a", encoding="utf-8") as handle:
                        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
        except Exception:
            pass  # instrumentation must never break a batch
        return response

    # 16 workers hit the per-pair install at startup: hold the lock through
    # patch+flag so exactly one wrapper layer is ever installed.
    with _USAGE_LOCK:
        if _usage_installed:  # another thread won the install race
            return
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        completions.create = recording_create
        _usage_installed = True


def _usage_totals() -> dict[str, Any] | None:
    if not USAGE_PATH.is_file():
        return None
    totals = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0,
              "cache_hit_tokens": 0, "cache_miss_tokens": 0}
    with open(USAGE_PATH, encoding="utf-8") as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            totals["calls"] += 1
            for key in ("prompt_tokens", "completion_tokens",
                        "cache_hit_tokens", "cache_miss_tokens"):
                if row.get(key) is not None:
                    totals[key] += int(row[key])
    return totals


# ── Process entry ──────────────────────────────────────────────────────────────

def process_article_for_reader_ablation_v3(
    article_id: str,
    article_text: str,
    reader_profile: dict[str, Any],
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None = None,
    *,
    variant: str | AblationSpec,
    article_title: str = "",
    fidelity_policy: Any = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    llm_call: Callable[..., str] | None = None,
    feature_llm_call: Callable[..., str] | None = None,
) -> dict[str, Any]:
    """V1 flow with V3 prompt transformations + V2-style memoization."""
    resolve_spec(variant)  # fail fast on an unknown variant, before any LLM call
    install_usage_recorder()
    pair_llm, pair_feature_llm = make_pair_llm_calls(
        article_text, article_claim_record, simplification_ledger
    )
    result = ap.process_article_for_reader_ablation(
        article_id,
        article_text,
        reader_profile,
        article_claim_record,
        simplification_ledger,
        variant=variant,
        article_title=article_title,
        fidelity_policy=fidelity_policy,
        enable_repair=enable_repair,
        ecl_repair_rounds=ecl_repair_rounds,
        max_total_repair_attempts=max_total_repair_attempts,
        ecl_calibration_mode=ecl_calibration_mode,
        llm_call=llm_call or pair_llm,
        feature_llm_call=feature_llm_call or pair_feature_llm,
    )
    ablation = dict(result.get("ablation") or {})
    ablation["schema_version"] = ABLATION_SCHEMA_VERSION_V3
    ablation["pipeline_variant"] = "v3-prefix-dedup-contract-slimming"
    ablation["token_optimization"] = {
        "mode": "shared-prefix dedup + contract slimming + prompt memoization",
        "prompts_modified": True,
        "transformations": {
            "T1_shared_prefix_dedup": (
                "source + compact claim contract hoisted to a byte-identical "
                "leading block; in-prompt copies replaced by <source ref=1/> "
                "and <claims ref=2/> markers (targets provider prefix cache); "
                "main-lane only — ECL judge (feature) prompts excluded to "
                "protect their strict item_id echo contract"
            ),
            "T2_contract_slimming": (
                "rewrite/condense prompt embeds drop raw_evaluations, "
                "frozen_strategy_bundle, and hash bookkeeping; baseline "
                "compacted to module scores (full contracts stay in this record)"
            ),
            "T3_verifier_brevity": (
                "fidelity verifier reasons capped at ~25 words; spans still exact"
            ),
            "T4_compact_json": "embedded JSON uses compact separators",
            "T5_repair_packet_dedup": (
                "repair packets deduplicated via T1 markers; tail keeps the delta"
            ),
        },
        "cache_shared_across": ["readers", "variants", "resume_passes"],
        "stochastic_note": (
            "temperature-0.2 calls are memoized: identical requests return the "
            "recorded sample instead of resampling"
        ),
        "parent_schema_version": ap.ABLATION_SCHEMA_VERSION,
    }
    result["ablation"] = ablation
    return result


# ── Exit report ────────────────────────────────────────────────────────────────

def _report() -> None:
    CACHE._flush()
    cache_stats = CACHE.summary()
    usage = _usage_totals()
    with _STATS_LOCK:
        transform = dict(_TRANSFORM_STATS)
    lines = [f"[v3] cache hits={cache_stats['hits']} live={cache_stats['misses']} "
             f"entries={cache_stats['entries']}"]
    lines.append(
        f"[v3] prefix-dedup transformed={transform['calls_transformed']} calls "
        f"(passthrough {transform['calls_passthrough']}); tail chars removed≈"
        f"{transform['tail_chars_removed']:,} "
        f"block chars added≈{transform['block_chars_added']:,}"
    )
    if usage:
        hit, miss = usage["cache_hit_tokens"], usage["cache_miss_tokens"]
        prompt = usage["prompt_tokens"] or (hit + miss)
        hit_rate = (hit / prompt * 100) if prompt else 0.0
        lines.append(
            f"[v3] usage calls={usage['calls']} prompt={prompt:,} "
            f"(hit {hit:,} / miss {miss:,} = {hit_rate:.1f}% hit) "
            f"completion={usage['completion_tokens']:,}"
        )
    print("\n".join(lines))


atexit.register(_report)


__all__ = [
    "ABLATION_SCHEMA_VERSION_V3",
    "ABLATION_SPECS",
    "CACHE",
    "PairContext",
    "build_active_rewrite_prompt_v3",
    "build_active_condense_prompt_v3",
    "process_article_for_reader_ablation_v3",
    "resolve_spec",
    "slim_contract_for_prompt",
]
