"""CLaRR v4.2.1 artifact-pipeline and output-cost controls.

V4.2.1 builds on v3 without changing older entry points.  It installs the
stateless Source/Strategy/Rewrite/Evaluation/Repair worker contracts from
``pipeline_v4`` while retaining the existing deterministic compilers and
fail-closed release gates.
"""

from __future__ import annotations

import os
import re
from typing import Any

import fidelity_repair
import il_fidelity
import schema_support
import cost_repair
import incremental_validation
import llm_client
import pipeline_v4


V4_SCHEMA = "clarr-v4.2.1-post-rewrite-il-gcl-pipeline-v1"


def _inject_before(prompt: str, marker: str, instruction: str) -> str:
    if marker in prompt:
        return prompt.replace(marker, instruction + "\n\n" + marker, 1)
    return prompt + "\n\n" + instruction


def _patch_output_contracts() -> None:
    original_primary = fidelity_repair.validation_prompt
    original_adversarial = fidelity_repair.adversarial_validation_prompt
    original_il = il_fidelity.il_compliance_prompt
    original_schema = schema_support.schema_support_prompt
    original_ecl = cost_repair._combined_ecl_prompt

    economy = (
        "OUTPUT ECONOMY OVERRIDE: Return every required ID, verdict, and exact shortest "
        "span. For a passing row set reason=\"\" and failed_slots=[]. For a failed row "
        "use a <=10-word reason. Do not restate the source, contract, candidate, or rubric."
    )

    def primary(source_text, candidate, contract):
        return _inject_before(
            original_primary(source_text, candidate, contract), "SOURCE ARTICLE", economy
        )

    def adversarial(source_text, candidate, contract):
        return _inject_before(
            original_adversarial(source_text, candidate, contract), "SOURCE ARTICLE", economy
        )

    def il_prompt(source_text, candidate, term_contract, claim_validation):
        instruction = (
            economy + " Return introduced_propositions only when the candidate actually "
            "introduces one; use <=8-word reasons and at most one closest source span."
        )
        return _inject_before(
            original_il(source_text, candidate, term_contract, claim_validation),
            "SOURCE ARTICLE", instruction,
        )

    def schema_prompt(
        source_text, candidate, schema_support_contract, claim_validation,
        explanation_protection_contract=None,
    ):
        instruction = (
            "OUTPUT ECONOMY OVERRIDE: Keep every numeric/status field required by the "
            "schema. Use reason=\"\" for adequate/effective rows and <=8 words for failures. "
            "Use the shortest exact candidate span. Return analogy_complexity rows only for "
            "failed paragraphs, analogies only when a figurative span exists, and no prose "
            "outside JSON. Do not echo contract text."
        )
        return _inject_before(
            original_schema(
                source_text, candidate, schema_support_contract, claim_validation,
                explanation_protection_contract,
            ),
            "SOURCE ARTICLE", instruction,
        )

    def ecl_prompt(candidate, preference, item_id):
        return original_ecl(candidate, preference, item_id) + (
            "\n\nOUTPUT ECONOMY OVERRIDE: Each rationale must be 4-8 words. Return at "
            "most one shortest candidate_evidence quote per dimension and at most two "
            "failure_tags. Do not restate any rubric."
        )

    fidelity_repair.validation_prompt = primary
    fidelity_repair.adversarial_validation_prompt = adversarial
    il_fidelity.il_compliance_prompt = il_prompt
    schema_support.schema_support_prompt = schema_prompt
    # Output caps only save money when they actually truncate (billed tokens
    # are actual output); 4500 cut part_2-scale schema verdict JSON mid-string
    # and killed the pair after the same-cap retry.  8k cleared the ~4.8k
    # typical ceiling but still truncated row-dense scholarly abstracts
    # (~21+ support rows: token-dense JSON hit 8k at ~10.3k chars) — the
    # row-scaled audit.gcl stage cap stays the effective limiter for normal
    # traffic; this constant is now just a runaway ceiling above it.
    schema_support.SCHEMA_SUPPORT_MAX_TOKENS = 14000
    cost_repair._combined_ecl_prompt = ecl_prompt


def _patch_vtech_output(v1) -> None:
    original_score = v1.score_terms_for_reader

    def score_terms_for_reader(
        terms_raw, article_text, reader_str, article_title="", llm_call_fn=None,
    ):
        real_call = llm_call_fn or v1.call_llm

        def compact_call(prompt, **kwargs):
            compact = str(prompt).replace(
                "For each term, reason from THIS READER'S perspective and score:",
                "For each term, silently judge THIS READER'S familiarity and score:",
            )
            compact = re.sub(
                r',?\s*"rationale":\s*"<one sentence:[^"]+"', "", compact
            )
            compact += (
                "\nOUTPUT ECONOMY OVERRIDE: Each evaluation contains only term and "
                "integer v_tech. Do not output rationale or any extra key."
            )
            kwargs["max_tokens"] = min(int(kwargs.get("max_tokens", 1200)), 1200)
            kwargs["temperature"] = 0
            return real_call(compact, **kwargs)

        return original_score(
            terms_raw, article_text, reader_str, article_title=article_title,
            llm_call_fn=compact_call,
        )

    v1.score_terms_for_reader = score_terms_for_reader


def _patch_repair_output() -> None:
    fidelity_repair.repair_alignment_patch_prompt = pipeline_v4.compact_repair_prompt


def _patch_rewrite_agent(v1) -> None:
    v1.prompt_regenerate = pipeline_v4.compact_rewrite_prompt


def _patch_stage_caps(v1) -> None:
    original_call = v1.call_llm
    original_ecl_call = v1.call_ecl_feature_llm

    def capped_call(prompt, *args, **kwargs):
        stage = str(kwargs.get("stage") or llm_client.infer_call_stage(prompt))
        requested = kwargs.get("max_tokens")
        cap = pipeline_v4.stage_token_cap(stage, str(prompt), requested)
        if cap is not None:
            kwargs["max_tokens"] = cap
        return original_call(prompt, *args, **kwargs)

    def capped_ecl_call(prompt, *args, **kwargs):
        stage = str(kwargs.get("stage") or llm_client.infer_call_stage(prompt))
        requested = kwargs.get("max_tokens")
        cap = pipeline_v4.stage_token_cap(stage, str(prompt), requested)
        if cap is not None:
            kwargs["max_tokens"] = cap
        return original_ecl_call(prompt, *args, **kwargs)

    v1.call_llm = capped_call
    v1.call_ecl_feature_llm = capped_ecl_call


def _schema_spans(evaluation: dict[str, Any]) -> list[str]:
    """Return all candidate spans whose schema function must be preserved."""
    spans: list[str] = []

    def add(value: Any) -> None:
        text = " ".join(str(value or "").split())
        if text and text not in spans:
            spans.append(text)

    for item in evaluation.get("bridges", []) or []:
        add(item.get("candidate_span"))
    guidance = evaluation.get("guidance", {}) or {}
    add(guidance.get("candidate_span"))
    for item in guidance.get("strategies", []) or []:
        add(item.get("candidate_span"))
    for key in (
        "analogies", "analogy_complexity", "protected_support",
        "grounding_violations",
    ):
        for item in evaluation.get(key, []) or []:
            add(item.get("candidate_span"))
            add(item.get("replacement_span"))
    return spans


_SCHEMA_INTRODUCTION_MARKERS = re.compile(
    r"(?:\?|\b(?:you|your|imagine|suppose|consider|remember|notice)\b|"
    r"\b(?:like|as if|think of|similar to|analogy|metaphor)\b)",
    flags=re.I,
)


def conservative_schema_recheck_decider(
    *, candidate_application: dict[str, Any], active_targets: dict[str, Any],
    support_ids: set[str], previous_schema_evaluation: dict[str, Any],
) -> bool:
    """Return False only when reusing the previous schema audit is provably safe.

    This deliberately recognizes a narrow class: literal in-sentence replacement
    or deletion outside every previously detected schema-support span.  Unknown,
    insertion, figurative, reader-addressing, and schema-targeted edits recheck.
    """
    del active_targets  # support_ids already contains active and patch targets.
    if support_ids:
        return True
    patches = candidate_application.get("patches", []) or []
    if not patches:
        return True
    protected_spans = _schema_spans(previous_schema_evaluation)
    for patch in patches:
        if patch.get("schema_support_ids"):
            return True
        if str(patch.get("operation", "")) not in {
            "replace_within_sentence", "delete_within_sentence",
        }:
            return True
        replacement = " ".join(str(patch.get("replacement_text", "")).split())
        if _SCHEMA_INTRODUCTION_MARKERS.search(replacement):
            return True
        touched = [
            " ".join(str(patch.get(key, "")).split())
            for key in ("anchor_sentence", "target_span")
            if str(patch.get(key, "")).strip()
        ]
        if any(
            protected in value or value in protected
            for value in touched for protected in protected_spans
        ):
            return True
    return False


def _patch_incremental_audit() -> None:
    incremental_validation.SCHEMA_RECHECK_DECIDER = (
        conservative_schema_recheck_decider
    )
    incremental_validation.LOCAL_REVIEW_PACKET_BUILDER = (
        pipeline_v4.build_local_review_packet
    )


def _patch_process(v1) -> None:
    original_process = v1.process_article_for_reader

    def process_article_for_reader(*args, **kwargs):
        kwargs["strategy_generation_fn"] = pipeline_v4.generate_pipeline_strategies
        kwargs["post_rewrite_fn"] = (
            pipeline_v4.execute_post_rewrite_local_pipeline
        )
        result = original_process(*args, **kwargs)
        result["cost_optimization_v4"] = {
            "schema_version": V4_SCHEMA,
            "source_datasets_modified": False,
            "vtech_output": "score_only",
            "judge_output": "pass_rows_without_rationale_failure_rows_short",
            "strategy_generation": "source_ir_plus_grounded_compact_strategy_agent",
            "rewrite_generation": "icl_ecl_primary_then_post_rewrite_il_then_gcl",
            "il_gloss_execution": (
                "existing_or_appositive_or_approved_or_cache_then_one_shared_micro_call"
            ),
            "gcl_guidance_execution": (
                "existing_guidance_or_zero_call_source_or_strategy_then_shared_micro_fallback"
            ),
            "gcl_guidance_word_reserve": pipeline_v4.POST_GCL_WORD_RESERVE,
            "post_rewrite_micro_api_calls_max": (
                pipeline_v4.POST_LOCAL_MICRO_CALL_BUDGET
            ),
            "il_gloss_words_each_max": pipeline_v4.POST_IL_GLOSS_MAX_WORDS,
            "il_added_words_total_max": pipeline_v4.POST_IL_TOTAL_WORD_CAP,
            "evaluation_routing": "deterministic_precheck_then_scoped_specialists",
            "repair_output": "selected_instructions_anchors_evidence_only",
            "repair_revalidation": "changed_sentences_plus_neighbors_or_safe_fallback",
            "source_data_policy": "read_only_unchanged",
            "pipeline_contract": pipeline_v4.pipeline_contract(),
            "minimum_output_token_floor": int(
                os.environ.get("CLARR_MIN_OUTPUT_TOKENS", "8000")
            ),
        }
        return result

    v1.process_article_for_reader = process_article_for_reader


_APPLIED = False


def apply_v4(verbose: bool = True):
    global _APPLIED
    os.environ.setdefault("LLM_RUN_TAG", "v4")
    v1 = cost_repair.apply_v3(verbose=False)
    if _APPLIED:
        return v1
    _patch_output_contracts()
    _patch_vtech_output(v1)
    _patch_repair_output()
    _patch_rewrite_agent(v1)
    _patch_stage_caps(v1)
    _patch_incremental_audit()
    _patch_process(v1)
    _APPLIED = True
    if verbose:
        print(
            "[v4.2.1] patched: Source IR + grounded Strategy Agent + ICL/ECL primary "
            "Rewrite + post-rewrite local IL/GCL gates + local Repair/Evaluation "
            "packets + conservative audit routing + stage-sized output caps",
            flush=True,
        )
    return v1
