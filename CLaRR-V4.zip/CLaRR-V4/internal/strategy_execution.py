"""Compile evaluator failures into executable rewrite instructions.

The existing ICL, ECL and GCL/schema-support strategies describe how an article
should be adapted.  A repair evaluator, however, returns evidence about a concrete
candidate.  This module keeps those two concerns separate: it converts only the
current failed targets into a small, ordered ``repair_alignment`` packet while
preserving the original strategies as non-regression constraints.
"""

from __future__ import annotations

import json
import hashlib
import re
from typing import Any, Iterable


REPAIR_ALIGNMENT_VERSION = "clarr-repair-alignment-v1.1.0-omission-targets"
UPFRONT_STRATEGY_VERSION = "clarr-upfront-strategy-integration-v1.4.0-min-safe-il-gate"
REPAIR_ALIGNMENT_MODE = "repair_alignment"
STANDARD_GENERATION_MODE = "strategy_generation"
_VALID_MODES = {STANDARD_GENERATION_MODE, REPAIR_ALIGNMENT_MODE}

_IL_RELEASE_UNSAFE_INTRODUCTIONS = {
    "unsupported_material",
    "inappropriate_inference",
    "redundant_restatement",
    "excessive_supported_detail",
}


def validate_generation_mode(mode: str) -> str:
    """Return a normalized prompt mode or fail before an LLM call."""
    normalized = str(mode or STANDARD_GENERATION_MODE).strip().lower()
    if normalized not in _VALID_MODES:
        raise ValueError(
            f"generation mode must be one of {sorted(_VALID_MODES)}, got {mode!r}"
        )
    return normalized


_QUADRANT_DEFAULT_ACTION = {
    "Core Expertise": "retain_and_explain",
    "Peripheral Jargon": "replace_with_familiar_equivalent",
    "HF Concept": "retain_exact",
    "Redundant": "compress_or_merge",
}


def _source_major_units(source_text: str) -> list[str]:
    """Recover coarse source units without an extra model call.

    Dataset articles are often stored as one physical paragraph. In that case,
    content-specific shift sentences define conservative boundaries; a balanced
    sentence grouping is used only when the source supplies no usable shift cues.
    The units guide presentation only and never assert a semantic relation.
    """
    text = str(source_text).strip()
    if not text:
        return []
    paragraphs = [
        value.strip() for value in re.split(r"\n\s*\n", text) if value.strip()
    ]
    if len(paragraphs) >= 2:
        return paragraphs
    sentences = [
        value.strip()
        for value in re.split(r"(?<=[.!?])\s+", text)
        if value.strip()
    ]
    if len(sentences) < 4:
        return [text]
    shift_pattern = re.compile(
        r"^(?:(?:but\s+)?beyond\b|the ethical core\b|the challenge for\b|"
        r"at the same time\b|in contrast\b|on the other hand\b|"
        r"another (?:issue|question|dimension|concern)\b|"
        r"the (?:next|final|central|main) (?:issue|question|dimension|concern)\b|"
        r"finally\b)",
        flags=re.IGNORECASE,
    )
    boundaries = [0]
    for index, sentence in enumerate(sentences[1:], 1):
        if (
            shift_pattern.search(sentence)
            and index - boundaries[-1] >= 2
            and len(sentences) - index >= 2
        ):
            boundaries.append(index)
    if len(boundaries) < 3:
        target_units = min(4, max(2, round(len(sentences) / 4)))
        boundaries = sorted({
            0,
            *(
                round(len(sentences) * part / target_units)
                for part in range(1, target_units)
            ),
        })
    boundaries.append(len(sentences))
    return [
        " ".join(sentences[left:right])
        for left, right in zip(boundaries, boundaries[1:])
        if right > left
    ]


def build_icl_claim_alignment_contract(
    claim_contract: list[dict[str, Any]] | None,
    il_term_contract: list[dict[str, Any]] | None,
) -> dict[str, Any]:
    """Bind every ICL lexical action to the propositions it must preserve.

    The conflict audit is deterministic and happens before ICL strategy generation.
    A quadrant may propose lexical pruning/compression, but an immutable claim anchor
    changes the executable action to retain/gloss or anchor-preserving compression.
    """
    claims = claim_contract or []
    terms = il_term_contract or []
    claim_ids = {str(value.get("claim_id", "")) for value in claims}
    detected: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    bindings: list[dict[str, Any]] = []
    for term in terms:
        term_id = str(term.get("term_id", ""))
        quadrant = str(term.get("quadrant", ""))
        default_action = _QUADRANT_DEFAULT_ACTION.get(quadrant, "compress_or_merge")
        resolved_action = str(term.get("required_action", default_action))
        anchors = [str(value) for value in term.get("immutable_anchor_claim_ids", [])]
        linked = [str(value) for value in term.get("linked_claim_ids", [])]
        protected_values = [
            value for value in term.get("protected_slot_values", [])
            if isinstance(value, dict)
        ]
        conflict_type = ""
        expected_safe_actions: set[str] = set()
        if anchors and default_action == "replace_with_familiar_equivalent":
            conflict_type = "immutable_claim_anchor_vs_lexical_pruning"
            expected_safe_actions = {
                "replace_with_approved_familiar_form", "retain_and_gloss"
            }
        elif anchors and default_action == "compress_or_merge":
            conflict_type = "immutable_claim_anchor_vs_compression"
            expected_safe_actions = {"retain_anchor_compress_context"}
        if conflict_type:
            record = {
                "term_id": term_id,
                "source_term": str(term.get("source_term", "")),
                "conflict_type": conflict_type,
                "quadrant_default_action": default_action,
                "resolved_action": resolved_action,
                "affected_claim_ids": anchors,
                "status": (
                    "resolved_before_strategy_generation"
                    if resolved_action in expected_safe_actions else "unresolved"
                ),
            }
            detected.append(record)
            if record["status"] == "unresolved":
                unresolved.append(record)
        unknown_claim_ids = sorted((set(linked) | set(anchors)) - claim_ids)
        if unknown_claim_ids:
            unresolved.append({
                "term_id": term_id,
                "conflict_type": "unknown_linked_claim_id",
                "affected_claim_ids": unknown_claim_ids,
                "status": "unresolved",
            })
        bindings.append({
            "term_id": term_id,
            "source_term": str(term.get("source_term", "")),
            "quadrant": quadrant,
            "required_action": resolved_action,
            "linked_claim_ids": linked,
            "immutable_anchor_claim_ids": anchors,
            "protected_slot_values": protected_values,
            "approved_familiar_forms": list(term.get("approved_familiar_forms", [])),
            "proposition_rule": (
                "change only the term treatment; preserve every linked claim's own "
                "subject, relation, object, scope, condition, modality, comparison, "
                "causal direction, quantity, population, and time"
            ),
        })
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "module": "icl_claim_alignment",
        "precedence": "claim preservation > immutable anchors > ICL lexical action",
        "claim_obligations": [
            {
                key: claim.get(key)
                for key in (
                    "claim_id", "tier", "canonical_proposition", "immutable_slots",
                    "immutable_slot_values", "source_evidence", "approved_simplifications",
                )
            }
            for claim in claims
        ],
        "term_claim_bindings": bindings,
        "detected_conflicts": detected,
        "unresolved_conflicts": unresolved,
        "strategy_rule": (
            "ICL chooses lexical treatment and explanation depth; it never chooses "
            "whether a source proposition survives"
        ),
    }


def build_ecl_preference_alignment_contract(
    reader_profile: dict[str, Any] | None,
    source_text: str = "",
) -> dict[str, Any]:
    """Compile the exact Logical/Emotional branch used by strategy and scorer."""
    profile = reader_profile or {}
    schema = profile.get("schema", {}) if isinstance(profile, dict) else {}
    style = str(schema.get("cognitive_style", "")).strip().lower()
    goal_raw = str(schema.get("reading_motivation", "learning")).strip().lower()
    goal = {
        "analysis": "learning",
        "analytic": "learning",
        "analytical": "learning",
        "analytical_reading": "learning",
        "practice": "utility",
        "practical": "utility",
        "application": "utility",
        "applied": "utility",
    }.get(goal_raw, goal_raw)
    if style not in {"logical", "emotional"}:
        style = "generic"
    common = {
        "active_common_dimensions": [
            "S-COHERENCE", "S-PROPORTIONALITY-INTERNAL", "S-NONMECHANICAL"
        ],
        "content_boundary": (
            "ECL controls organization and presentation only; it may not invent, "
            "delete, strengthen, or weaken a claim, ICL treatment, bridge, or guidance cue"
        ),
        "proportionality_rule": (
            "allocate space by source importance and reader need; avoid redundant recap, "
            "template padding, and explanation blocks larger than the claim they support"
        ),
        "nonmechanical_rule": (
            "use only devices that organize a concrete content relation; do not repeatedly "
            "announce a template, stack frames, or paste reader-specific language onto generic text"
        ),
    }
    if style == "emotional":
        if goal == "learning":
            goal_alignment = {
                "mode": "analytical_learning_with_experiential_continuity",
                "requirements": [
                    "use one source-grounded reader question, concern, or stake to orient analysis",
                    "carry that same orientation through at least two separated explanatory regions",
                    "preserve explicit conceptual distinctions and end with a source-supported synthesis",
                ],
                "forbidden_shortcuts": [
                    "do not invent a person, community, scene, human story, impact, or resolution",
                    "do not replace explanation with emotional persuasion or dramatic escalation",
                    "do not force a problem-solution arc when the source does not provide a solution",
                ],
            }
        elif goal == "utility":
            goal_alignment = {
                "mode": "decision_relevance_with_experiential_continuity",
                "requirements": [
                    "carry one source-grounded practical stake from the issue to its stated implication",
                    "make any usable takeaway conditional on what the source actually supports",
                ],
                "forbidden_shortcuts": [
                    "do not invent advice, action steps, benefits, harms, or stakeholder duties",
                    "do not manufacture a solution merely to create closure",
                ],
            }
        else:
            goal_alignment = {
                "mode": "curiosity_with_experiential_continuity",
                "requirements": [
                    "carry one source-grounded curiosity or felt contrast across separated regions",
                    "let the ending develop that same curiosity rather than add a detached hook",
                ],
                "forbidden_shortcuts": [
                    "do not invent suspense, danger, a protagonist, or a dramatic resolution",
                    "do not stack unrelated hooks or rhetorical questions",
                ],
            }
        branch = {
            "active_preference_dimension": "S-EMOTIONAL-PROGRESSION",
            "organization_mode": "source_grounded_experiential_continuity",
            "goal_alignment": goal_alignment,
            "positive_requirements": [
                "carry one reader position or felt stake across at least two separated major regions",
                "let later explanation or implication develop the same stake rather than repeat a hook",
                "use smooth transitions and continuous prose when they fit the source",
            ],
            "forbidden_shortcuts": [
                "do not invent a person, patient, community, lived event, harm, benefit, or resolution",
                "do not require a dramatic climax, emotional change, three named stages, or an action request",
                "do not substitute emotive decoration for source relations",
            ],
        }
    elif style == "logical":
        source_paragraphs = _source_major_units(source_text)
        source_units: list[dict[str, Any]] = []
        for index, paragraph in enumerate(source_paragraphs, 1):
            opening = re.split(r"(?<=[.!?])\s+", paragraph, maxsplit=1)[0].strip()
            source_units.append({
                "unit_id": f"P{index:02d}",
                "source_opening_anchor": opening[:240],
            })
        relation_slots = [
            {
                "relation_id": f"LR_{index:03d}",
                "from_unit_id": source_units[index - 1]["unit_id"],
                "to_unit_id": source_units[index]["unit_id"],
                "from_source_anchor": source_units[index - 1]["source_opening_anchor"],
                "to_source_anchor": source_units[index]["source_opening_anchor"],
                "required": True,
            }
            for index in range(1, len(source_units))
        ]
        branch = {
            "active_preference_dimension": "S-LOGICAL-ORGANIZATION",
            "organization_mode": "recoverable_relation_network",
            "positive_requirements": [
                "make hierarchy, grouping, dependency, scope, and sequence recoverable",
                "state priority or causal/dependency relations only when licensed by the source",
                "use headings, bullets, topic sentences, or connectors only when they clarify a real relation",
            ],
            "forbidden_shortcuts": [
                "do not force bullets, headings, or a recap when paragraph organization is clearer",
                "do not invent therefore, because, priority, sequence, or actionability relations",
                "do not repeat the body as a numbered summary merely to appear structured",
            ],
            "source_major_units": source_units,
            "logical_relation_slots": relation_slots,
            "relation_execution_rule": (
                "realize every LR_* boundary once with a content-specific topic or boundary "
                "sentence that names how the next major unit relates to the prior unit; "
                "paragraph order or a bare heading alone does not satisfy the slot"
            ),
            "relation_grounding_rule": (
                "use neutral source-sequence, scope-shift, or topic-extension language by "
                "default; use contrast, dependency, priority, or cause-effect only when the "
                "source text explicitly licenses that relation"
            ),
            "relation_quality_rule": (
                "name the shared source entity, problem, mechanism, or claim that makes the "
                "two units related and state the relation predicate: for example one unit is "
                "a broader/narrower level, qualification, consequence, evidence, or response "
                "to the other when source-licensed; shared_issue_different_scope must not use "
                "causal predicates such as consequence/leads/results/causes, while any causal "
                "or dependency predicate must include the exact source-supported mechanism; "
                "a generic next/beyond/turns-to topic shift is insufficient"
            ),
            "relation_modality_rule": (
                "preserve the source's epistemic status: a question, possibility, risk, "
                "argument, or prediction must remain one; never convert it into an observed "
                "disruption, established consequence, proven mechanism, or inevitable outcome. "
                "When two units are linked but causality is not asserted, describe them as two "
                "levels or aspects of the same source concern/question"
            ),
            "relation_anti_mechanical_rule": (
                "make each transition content-specific and integrate it into the next topic "
                "sentence; do not add a separate roadmap, repeated recap, or identical connector"
            ),
            "allowed_relation_types": [
                "shared_issue_different_scope", "shared_source_basis", "scope_shift",
                "contrast_if_source_explicit", "dependency_if_source_explicit",
                "cause_effect_if_source_explicit",
            ],
        }
    else:
        branch = {
            "active_preference_dimension": "S-COHERENCE",
            "organization_mode": "content_led_coherence",
            "positive_requirements": ["preserve a clear, proportionate content sequence"],
            "forbidden_shortcuts": ["do not impose an unsupported style template"],
        }
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "module": "ecl_preference_alignment",
        "cognitive_style": style,
        "reading_goal": goal,
        "reading_goal_input": goal_raw,
        **common,
        **branch,
    }


def compile_ecl_relation_plan(
    ecl_contract: dict[str, Any],
    ecl_strategy_text: str,
) -> dict[str, Any]:
    """Attach the strategy's exact LR realizations without another model call."""
    value = json.loads(json.dumps(ecl_contract, ensure_ascii=False))
    slots = value.get("logical_relation_slots", []) or []
    if not slots:
        return value
    parsed: dict[str, dict[str, str]] = {}
    for raw_line in str(ecl_strategy_text).splitlines():
        match = re.search(r"\b(LR_\d{3})\b", raw_line)
        realization_match = re.search(
            r"\bRealization(?:\s+instruction)?\s*:\s*",
            raw_line,
            flags=re.IGNORECASE,
        )
        if not match or not realization_match:
            continue
        relation_id = match.group(1)
        fields = [part.strip(" `") for part in raw_line.split("|")]
        relation_type = fields[2] if len(fields) >= 3 else ""
        realization = raw_line[realization_match.end():].strip(" `*")
        quoted = re.findall(r'["“]([^"”]+)["”]', realization)
        parsed[relation_id] = {
            "planned_relation_type": relation_type,
            "realization_instruction": realization,
            "planned_transition": quoted[-1].strip() if quoted else "",
        }
    unsafe_predicates = re.compile(
        r"\b(?:cause[sd]?|causing|consequence|lead[sd]? to|result[sd]? in|"
        r"drive[sd]?|create[sd]?|threaten[sd]?|require[sd]?|prevent[sd]?|"
        r"rival|replicate[sd]?)\b",
        flags=re.IGNORECASE,
    )

    def neutral_source_transition(slot: dict[str, Any]) -> str:
        target = str(slot.get("to_source_anchor", "")).strip()
        target = re.sub(r"^(?:but|however|yet)\s*,?\s*", "", target, flags=re.I)
        return (
            "The same source discussion also has a different dimension: " + target
        ).strip()

    compiled_slots: list[dict[str, Any]] = []
    for slot in slots:
        relation_id = str(slot.get("relation_id", ""))
        planned = dict(parsed.get(relation_id, {}))
        raw_transition = str(planned.get("planned_transition", "")).strip()
        relation_type = str(planned.get("planned_relation_type", "")).strip()
        anchors = " ".join((
            str(slot.get("from_source_anchor", "")),
            str(slot.get("to_source_anchor", "")),
        ))
        unsupported_predicates = [
            match.group(0) for match in unsafe_predicates.finditer(raw_transition)
            if not re.search(rf"\b{re.escape(match.group(0))}\b", anchors, re.I)
        ]
        neutral_relation = relation_type in {
            "shared_issue_different_scope", "shared_source_basis", "scope_shift"
        }
        explicit_relation = relation_type in {
            "contrast_if_source_explicit", "dependency_if_source_explicit",
            "cause_effect_if_source_explicit",
        }
        source_has_relation_license = bool(unsafe_predicates.search(anchors))
        target_is_question = str(slot.get("to_source_anchor", "")).strip().endswith("?")
        preserves_question = bool(
            raw_transition.endswith("?")
            or re.search(r"\b(?:question|whether|what happens|may|might|could)\b", raw_transition, re.I)
        )
        unsafe_reasons = []
        if neutral_relation and unsafe_predicates.search(raw_transition):
            unsafe_reasons.append("causal_or_dependency_predicate_in_neutral_relation")
        if explicit_relation and not source_has_relation_license:
            unsafe_reasons.append("explicit_relation_not_licensed_by_adjacent_source_anchors")
        if target_is_question and not preserves_question:
            unsafe_reasons.append("source_question_upgraded_to_assertion")
        if unsupported_predicates:
            unsafe_reasons.append("unsupported_assertive_predicate")
        if raw_transition and unsafe_reasons:
            planned["raw_planned_transition"] = raw_transition
            planned["raw_planned_relation_type"] = relation_type
            planned["planned_relation_type"] = "shared_issue_different_scope"
            planned["planned_transition"] = neutral_source_transition(slot)
            planned["plan_safety_status"] = "downgraded_to_source_anchor"
            planned["plan_safety_reasons"] = list(dict.fromkeys(unsafe_reasons))
        else:
            planned["plan_safety_status"] = "accepted"
            planned["plan_safety_reasons"] = []
        compiled_slots.append({**slot, **planned})
    missing = [
        str(slot.get("relation_id", ""))
        for slot in compiled_slots if not slot.get("planned_transition")
    ]
    value["logical_relation_slots"] = compiled_slots
    value["relation_ledger_complete"] = not missing
    value["relation_ledger_missing_ids"] = missing
    value["ecl_strategy_sha256"] = hashlib.sha256(
        str(ecl_strategy_text).encode("utf-8")
    ).hexdigest()
    return value


def build_gcl_schema_alignment_contract(
    schema_support_contract: dict[str, Any] | None,
) -> dict[str, Any]:
    """Expose bridge and guidance obligations to GCL before the first rewrite."""
    support = schema_support_contract or {}
    guidance = support.get("guidance", {}) or {}
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "module": "gcl_schema_alignment",
        "reader": support.get("reader", {}),
        "bridge_targets": [
            {
                key: item.get(key)
                for key in (
                    "support_id", "term_id", "concept", "knowledge_level",
                    "familiar_contexts", "acceptable_support", "direct_explanation_allowed",
                    "linked_claim_ids", "linked_claim_context", "analogy_fit_rule",
                )
            }
            for item in support.get("bridges", []) or []
        ],
        "guidance_target": {
            key: guidance.get(key)
            for key in (
                "support_id", "reading_goal", "goal_aligned_support", "coverage_rule",
                "position_rule", "anti_padding_rule",
            )
        },
        "reader_grounding": support.get("reader_grounding", {}),
        "analogy_support": support.get("analogy_support", {}),
        "joint_execution_rule": (
            "First satisfy every required term bridge with a direct explanation or accurate "
            "mapping; then add the minimum distinct goal-aligned cognitive guidance. A single "
            "span may serve both only when it independently satisfies both contracts."
        ),
        "source_boundary": (
            "Bridges and guidance may guide comprehension but may not add a factual mechanism, "
            "outcome, application, person, institution, example, assurance, or causal relation"
        ),
        "ecl_boundary": "do not redesign article structure already fixed by ECL",
    }


def compile_gcl_support_plan(
    gcl_contract: dict[str, Any],
    gcl_strategy_text: str,
) -> dict[str, Any]:
    """Attach exact GCL realizations from the module-owned strategy output."""
    value = json.loads(json.dumps(gcl_contract, ensure_ascii=False))
    parsed: dict[str, dict[str, str]] = {}
    for raw_line in str(gcl_strategy_text).splitlines():
        match = re.search(r"\b(GS_[A-Z]_[A-Z0-9_]+)\b", raw_line)
        if not match or "|" not in raw_line:
            continue
        fields = [part.strip(" `") for part in raw_line.split("|")]
        realization_field = fields[2] if len(fields) >= 3 else ""
        quoted = re.findall(r'["“]([^"”]+)["”]', realization_field)
        planned = quoted[-1].strip() if quoted else realization_field.strip()
        parsed[match.group(1)] = {
            "planned_function": fields[1] if len(fields) >= 2 else "",
            "planned_realization": planned,
            "planned_placement": fields[3] if len(fields) >= 4 else "",
        }

    required_ids: list[str] = []
    bridges = []
    for target in value.get("bridge_targets", []) or []:
        support_id = str(target.get("support_id", ""))
        if support_id:
            required_ids.append(support_id)
        bridges.append({**target, **parsed.get(support_id, {})})
    value["bridge_targets"] = bridges
    guidance = value.get("guidance_target", {}) or {}
    guidance_id = str(guidance.get("support_id", ""))
    if guidance_id:
        required_ids.append(guidance_id)
        value["guidance_target"] = {**guidance, **parsed.get(guidance_id, {})}
    missing = [
        support_id for support_id in required_ids
        if not parsed.get(support_id, {}).get("planned_realization")
    ]
    value["support_plan_complete"] = not missing
    value["support_plan_missing_ids"] = missing
    value["gcl_strategy_sha256"] = hashlib.sha256(
        str(gcl_strategy_text).encode("utf-8")
    ).hexdigest()
    return value


def build_upfront_strategy_contract(
    *,
    icl_claim_alignment: dict[str, Any],
    ecl_preference_alignment: dict[str, Any],
    gcl_schema_alignment: dict[str, Any],
    strategy_bundle: dict[str, Any] | None = None,
    source_baseline_score: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Combine the three pre-generation contracts without adding an LLM call."""
    unresolved = list(icl_claim_alignment.get("unresolved_conflicts", []))
    if unresolved:
        raise ValueError(
            "unresolved ICL/claim conflicts before strategy generation: "
            + json.dumps(unresolved, ensure_ascii=False, sort_keys=True)
        )
    value = {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "mode": "upfront_strategy_integration",
        "rewrite_calls": 1,
        "composition": {
            "generation_topology": "parallel_module_owned_deltas",
            "layer_order": ["icl", "ecl", "gcl"],
            "layer_ownership": {
                "icl": "source proposition preservation and lexical/term actions",
                "ecl": "organization, hierarchy, grouping, progression, and presentation only",
                "gcl": "term explanations, schema bridges, and cognitive guidance only",
            },
            "merge_rule": (
                "apply layers in order; each later layer adds only its owned fields and "
                "may not restate, replace, or weaken an earlier layer"
            ),
            "execution_rule": (
                "compose all three frozen deltas deterministically, then perform one rewrite"
            ),
        },
        "repair_role": (
            "repair only evaluator-confirmed omissions, incorrect executions, or local "
            "regressions; do not redesign ICL/ECL/GCL strategy"
        ),
        "source_baseline_score": source_baseline_score or {},
        "icl": icl_claim_alignment,
        "ecl": ecl_preference_alignment,
        "gcl": gcl_schema_alignment,
        "frozen_strategy_bundle": {
            key: value
            for key, value in (strategy_bundle or {}).items()
            if key not in {"strategies"}
        },
    }
    value["contract_sha256"] = hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return value


def _strategy_units(value: str) -> list[dict[str, Any]]:
    units: list[dict[str, Any]] = []
    for line_number, raw in enumerate(str(value).splitlines(), 1):
        text = re.sub(r"^[\s#>*\-\d.)]+", "", raw).strip()
        normalized = " ".join(re.findall(r"[a-z0-9]+", text.lower()))
        tokens = set(normalized.split())
        if len(tokens) < 5:
            continue
        units.append({
            "line": line_number,
            "text": text,
            "normalized": normalized,
            "tokens": tokens,
        })
    return units


def _strategy_owner(text: str, fallback: str) -> str:
    value = text.lower()
    if any(marker in value for marker in (
        "claim", "proposition", "immutable", "term", "jargon", "slot"
    )):
        return "icl"
    if any(marker in value for marker in (
        "paragraph", "structure", "organization", "transition", "coherence",
        "logical", "emotional progression", "proportionality"
    )):
        return "ecl"
    if any(marker in value for marker in (
        "bridge", "schema", "analogy", "guidance", "explanation", "cognitive cue"
    )):
        return "gcl"
    return fallback


def build_strategy_deduplication_report(
    icl_strategy: str,
    ecl_strategy: str,
    gcl_strategy: str,
    near_duplicate_threshold: float = 0.82,
) -> dict[str, Any]:
    """Detect repeated cross-lane instructions without another model call."""
    lanes = {
        "icl": _strategy_units(icl_strategy),
        "ecl": _strategy_units(ecl_strategy),
        "gcl": _strategy_units(gcl_strategy),
    }
    duplicates: list[dict[str, Any]] = []
    lane_pairs = (("icl", "ecl"), ("icl", "gcl"), ("ecl", "gcl"))
    for left_name, right_name in lane_pairs:
        for left in lanes[left_name]:
            for right in lanes[right_name]:
                union = left["tokens"] | right["tokens"]
                similarity = (
                    len(left["tokens"] & right["tokens"]) / len(union)
                    if union else 0.0
                )
                exact = left["normalized"] == right["normalized"]
                if not exact and similarity < near_duplicate_threshold:
                    continue
                owner = _strategy_owner(
                    left["text"] if len(left["text"]) >= len(right["text"]) else right["text"],
                    left_name,
                )
                duplicates.append({
                    "left_lane": left_name,
                    "left_line": left["line"],
                    "left_text": left["text"],
                    "right_lane": right_name,
                    "right_line": right["line"],
                    "right_text": right["text"],
                    "match_type": "exact" if exact else "near_lexical",
                    "similarity": round(similarity, 4),
                    "canonical_owner": owner,
                    "execution_rule": (
                        "realize this obligation once under canonical_owner; the other lane "
                        "treats it as a non-regression constraint"
                    ),
                })
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "method": "deterministic_cross_lane_line_similarity",
        "near_duplicate_threshold": near_duplicate_threshold,
        "duplicate_count": len(duplicates),
        "duplicates": duplicates,
        "lane_ownership": {
            "icl": "term treatment plus proposition/immutable-slot preservation",
            "ecl": "organization, hierarchy, progression, paragraphing, and presentation",
            "gcl": "term bridge, explanation method, analogy mapping, and cognitive guidance",
        },
        "coordination_rules": [
            "A repeated obligation is realized once, not once per strategy text.",
            "ICL decides which term treatment is required; GCL decides how required explanation/bridge is realized.",
            "ECL may place a bridge or cue but may not duplicate its content or redesign it.",
            "Claim preservation is never deduplicated away and remains a hard constraint in every lane.",
        ],
    }


def freeze_strategy_bundle(
    icl_strategy: str,
    ecl_strategy: str,
    gcl_strategy: str,
) -> dict[str, Any]:
    """Freeze the exact three parallel outputs used by rewrite and later Repair."""
    strategies = {
        "icl": str(icl_strategy),
        "ecl": str(ecl_strategy),
        "gcl": str(gcl_strategy),
    }
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "frozen": True,
        "generation_topology": "parallel_after_term_scoring",
        "strategy_generation_calls": 3,
        "additional_deduplication_llm_calls": 0,
        "initial_rewrite_calls": 1,
        "strategy_sha256": {
            key: hashlib.sha256(value.encode("utf-8")).hexdigest()
            for key, value in strategies.items()
        },
        "deduplication": build_strategy_deduplication_report(
            strategies["icl"], strategies["ecl"], strategies["gcl"]
        ),
        "strategies": strategies,
    }


def build_strategy_realization_audit(
    *,
    candidate: str,
    claim_contract: list[dict[str, Any]] | None,
    strategy_execution_contract: dict[str, Any] | None,
    claim_validation: dict[str, Any] | None,
    il_evaluation: dict[str, Any] | None,
    schema_evaluation: dict[str, Any] | None,
    ecl_score: dict[str, Any] | None,
) -> dict[str, Any]:
    """Count observable upfront obligations executed in the unified rewrite."""
    execution = strategy_execution_contract or {}
    validation = claim_validation or {}
    il_value = il_evaluation or {}
    schema_value = schema_evaluation or {}
    ecl_value = ecl_score or {}

    claim_results = {
        str(value.get("claim_id", "")): value
        for value in validation.get("assessments", []) or []
        if isinstance(value, dict)
    }
    preserved_verdicts = {
        "entailed_exact", "entailed_via_approved_simplification"
    }
    claim_targets = []
    for claim in claim_contract or []:
        claim_id = str(claim.get("claim_id", ""))
        found = claim_results.get(claim_id, {})
        executed = str(found.get("verdict", "")) in preserved_verdicts
        claim_targets.append({
            "target_id": claim_id,
            "executed": executed,
            "status": str(found.get("verdict", "missing_assessment")),
            "evidence": str(found.get("candidate_span", "")),
        })

    il_results = {
        str(value.get("term_id", "")): value
        for value in il_value.get("assessments", []) or []
        if isinstance(value, dict)
    }
    il_targets = []
    for requirement in execution.get("icl", {}).get("term_actions", []) or []:
        term_id = str(requirement.get("term_id", ""))
        found = il_results.get(term_id, {})
        semantic = bool(found.get("meaning_preserved", False))
        compliant = bool(found.get("strategy_compliant", False))
        evidence = str(found.get("observed_span", "")).strip()
        candidate_key = " ".join(re.findall(r"[a-z0-9]+", candidate.lower()))
        evidence_key = " ".join(re.findall(r"[a-z0-9]+", evidence.lower()))
        evidence_located = bool(
            evidence_key
            and re.search(rf"(?:^| ){re.escape(evidence_key)}(?: |$)", candidate_key)
        )
        optional_safe_omission = bool(
            not requirement.get("hard_required", False)
            and semantic
            and (
                str(found.get("observed_treatment", "")) == "absent"
                or not evidence_located
            )
            and not requirement.get("linked_claim_ids", [])
            and str(requirement.get("required_action", "")) in {
                "compress_or_merge", "replace_with_familiar_equivalent"
            }
        )
        unsafe_introductions = [
            value
            for value in found.get("introduced_propositions", []) or []
            if isinstance(value, dict)
            and str(value.get("verdict", ""))
            in _IL_RELEASE_UNSAFE_INTRODUCTIONS
        ]
        strategy_realized = bool(
            semantic and (compliant or optional_safe_omission)
        )
        semantic_safety_failure = bool(
            not semantic or unsafe_introductions
        )
        advisory_target = bool(
            not requirement.get("hard_required", False)
            and not semantic_safety_failure
        )
        advisory_miss = bool(advisory_target and not strategy_realized)
        release_blocking_target = bool(
            semantic_safety_failure
            or (
                requirement.get("hard_required", False)
                and not strategy_realized
            )
        )
        il_targets.append({
            "target_id": term_id,
            "required_action": str(requirement.get("required_action", "")),
            "hard_required": bool(requirement.get("hard_required", False)),
            "executed": strategy_realized,
            "strategy_realized": strategy_realized,
            "meaning_preserved": semantic,
            "strategy_compliant": compliant,
            "evidence": evidence if evidence_located else "",
            "status": str(found.get("observed_treatment", "missing_assessment")),
            "optional_safe_omission": optional_safe_omission,
            "release_blocking_target": release_blocking_target,
            "advisory_target": advisory_target,
            "advisory_miss": advisory_miss,
            "semantic_safety_failure": semantic_safety_failure,
            "unsafe_introduced_propositions": unsafe_introductions,
        })

    features = ecl_value.get("features", {}) if isinstance(ecl_value, dict) else {}
    ecl_targets = []
    for dimension, found in features.items():
        if not isinstance(found, dict):
            continue
        score = str(found.get("score", "U"))
        ecl_targets.append({
            "target_id": str(dimension),
            "executed": score == "2",
            "status": score,
            "evidence": list(found.get("candidate_evidence", []) or []),
            "repair_instruction": str(found.get("repair_instruction", "")),
        })

    relation_slots = execution.get("ecl", {}).get("logical_relation_slots", []) or []
    candidate_paragraphs = [
        value.strip()
        for value in re.split(r"\n\s*\n", str(candidate))
        if value.strip()
    ]
    explicit_relation_pattern = re.compile(
        r"^(?:#{1,6}\s*)?(?:\d+[.)]\s*)?(?:\*\*)?\s*(?:"
        r"beyond\b|in turn\b|however\b|yet\b|by contrast\b|"
        r"at the same time\b|taken together\b|with (?:these|those|the)\b|"
        r"against this\b|building on\b|following (?:this|that|these|those)\b|"
        r"given (?:this|that|these|those)\b|"
        r"this (?:shift|issue|question|problem|development|pattern|concern)\b|"
        r"these (?:issues|questions|problems|developments|patterns|concerns)\b|"
        r"the .{1,80}? (?:extends|moves|shifts|turns) (?:beyond|from|to)\b|"
        r"another (?:issue|question|dimension|consequence|concern)\b|"
        r"the (?:next|final) (?:issue|question|dimension|step|concern)\b|finally\b)",
        flags=re.IGNORECASE,
    )
    for index, slot in enumerate(relation_slots, 1):
        paragraph = candidate_paragraphs[index] if index < len(candidate_paragraphs) else ""
        opening = re.split(r"(?<=[.!?])\s+", paragraph, maxsplit=1)[0].strip()
        planned_transition = str(slot.get("planned_transition", "")).strip()
        opening_tokens = set(re.findall(r"[a-z0-9]+", opening.lower()))
        planned_tokens = set(re.findall(r"[a-z0-9]+", planned_transition.lower()))
        transition_similarity = (
            len(opening_tokens & planned_tokens) / len(opening_tokens | planned_tokens)
            if opening_tokens and planned_tokens else 0.0
        )
        normalized_opening = " ".join(re.findall(r"[a-z0-9]+", opening.lower()))
        normalized_planned = " ".join(
            re.findall(r"[a-z0-9]+", planned_transition.lower())
        )
        planned_realized = bool(
            normalized_planned
            and (
                normalized_planned in normalized_opening
                or transition_similarity >= 0.62
            )
        )
        marker_realized = bool(opening and explicit_relation_pattern.search(opening))
        executed = planned_realized if planned_transition else marker_realized
        ecl_targets.append({
            "target_id": str(slot.get("relation_id", f"LR_{index:03d}")),
            "target_type": "logical_relation_boundary",
            "from_unit_id": str(slot.get("from_unit_id", "")),
            "to_unit_id": str(slot.get("to_unit_id", "")),
            "executed": executed,
            "status": (
                "planned_relation_realized"
                if executed else "missing_explicit_content_relation"
            ),
            "evidence": [opening] if opening else [],
            "planned_transition": planned_transition,
            "transition_similarity": round(transition_similarity, 4),
            "repair_instruction": (
                "Integrate one content-specific, source-licensed relation into the opening "
                "topic sentence of this major unit; use a neutral scope/sequence relation "
                "when the source does not license causality."
            ) if not executed else "",
        })

    bridge_results = {
        str(value.get("support_id", "")): value
        for value in schema_value.get("bridges", []) or []
        if isinstance(value, dict)
    }
    gcl_targets = []
    for support_id in execution.get("gcl", {}).get("bridge_support_ids", []) or []:
        found = bridge_results.get(str(support_id), {})
        gcl_targets.append({
            "target_id": str(support_id),
            "target_type": "knowledge_bridge",
            "executed": str(found.get("status", "")) == "adequate",
            "status": str(found.get("status", "missing_assessment")),
            "evidence": str(found.get("candidate_span", "")),
        })
    guidance_id = str(execution.get("gcl", {}).get("guidance_support_id", ""))
    if guidance_id:
        guidance = schema_value.get("guidance", {}) or {}
        gcl_targets.append({
            "target_id": guidance_id,
            "target_type": "cognitive_guidance",
            "executed": str(guidance.get("status", "")) == "adequate",
            "status": str(guidance.get("status", "missing_assessment")),
            "evidence": str(guidance.get("candidate_span", "")),
        })

    def summarize(targets: list[dict[str, Any]], evaluated: bool = True) -> dict[str, Any]:
        planned = len(targets)
        executed = sum(bool(value.get("executed")) for value in targets)
        release_blocking_failures = sum(
            bool(value.get("release_blocking_target")) for value in targets
        )
        advisory_targets = sum(
            bool(value.get("advisory_target")) for value in targets
        )
        advisory_misses = sum(
            bool(value.get("advisory_miss")) for value in targets
        )
        semantic_safety_failures = sum(
            bool(value.get("semantic_safety_failure")) for value in targets
        )
        return {
            "evaluated": evaluated,
            "planned_targets": planned,
            "executed_targets": executed,
            "missing_or_failed_targets": planned - executed,
            "execution_rate": round(executed / planned, 4) if planned else 1.0,
            "release_blocking_failures": release_blocking_failures,
            "advisory_targets": advisory_targets,
            "advisory_misses": advisory_misses,
            "semantic_safety_failures": semantic_safety_failures,
            "targets": targets,
        }

    modules = {
        "claim_preservation": summarize(
            claim_targets, evaluated=bool(validation.get("assessments") is not None)
        ),
        "icl": summarize(
            il_targets, evaluated=bool(il_value.get("evaluated", il_targets == []))
        ),
        "ecl": summarize(ecl_targets, evaluated=bool(ecl_value)),
        "gcl": summarize(
            gcl_targets, evaluated=bool(schema_value.get("evaluated", False))
        ),
    }
    if relation_slots:
        relation_targets = [
            value for value in ecl_targets
            if value.get("target_type") == "logical_relation_boundary"
        ]
        modules["ecl"]["logical_relation_coverage"] = {
            "planned_slots": len(relation_targets),
            "executed_slots": sum(
                bool(value.get("executed")) for value in relation_targets
            ),
            "missing_slots": [
                str(value.get("target_id", ""))
                for value in relation_targets if not value.get("executed")
            ],
        }
    planned_total = sum(value["planned_targets"] for value in modules.values())
    executed_total = sum(value["executed_targets"] for value in modules.values())
    return {
        "schema_version": UPFRONT_STRATEGY_VERSION,
        "audit_stage": "immediately_after_unified_rewrite_before_any_repair",
        "candidate_sha256": hashlib.sha256(candidate.encode("utf-8")).hexdigest(),
        "counting_unit": "observable deterministic contract target, not free-form strategy line",
        "planned_targets": planned_total,
        "executed_targets": executed_total,
        "missing_or_failed_targets": planned_total - executed_total,
        "execution_rate": round(executed_total / planned_total, 4) if planned_total else 1.0,
        "modules": modules,
        "repair_input_rule": (
            "Only missing_or_failed target IDs may enter Repair; executed targets are "
            "non-regression constraints."
        ),
    }


def build_strategy_execution_contract(
    *,
    reader_profile: dict[str, Any],
    icl_strategy: str,
    ecl_strategy: str,
    gcl_strategy: str,
    il_term_contract: list[dict[str, Any]] | None,
    schema_support_contract: dict[str, Any] | None,
    max_words: int,
    upfront_strategy_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Compile the three original strategy texts into a compact repair contract.

    The full strategy texts remain the authoritative generation artifacts.  Repair
    receives their hashes plus only deterministic obligations, which prevents a long
    free-form strategy from competing with the current evaluator instruction.
    """
    schema = reader_profile.get("schema", {}) if isinstance(reader_profile, dict) else {}
    support = schema_support_contract or {}
    guidance = support.get("guidance", {}) or {}
    analogy = support.get("analogy_support", {}) or {}
    grounding = support.get("reader_grounding", {}) or {}
    upfront = upfront_strategy_contract or {}
    strategy_hashes = {
        "icl": hashlib.sha256(icl_strategy.encode("utf-8")).hexdigest(),
        "ecl": hashlib.sha256(ecl_strategy.encode("utf-8")).hexdigest(),
        "gcl": hashlib.sha256(gcl_strategy.encode("utf-8")).hexdigest(),
    }
    frozen_hashes = (
        upfront.get("frozen_strategy_bundle", {}).get("strategy_sha256", {})
        if isinstance(upfront, dict) else {}
    )
    if frozen_hashes and frozen_hashes != strategy_hashes:
        raise ValueError(
            "strategy text differs from the frozen strategy bundle used by rewrite"
        )
    return {
        "schema_version": REPAIR_ALIGNMENT_VERSION,
        "strategy_sha256": strategy_hashes,
        "composition": dict(upfront.get("composition", {})),
        "source_baseline_score": dict(upfront.get("source_baseline_score", {})),
        "icl": {
            "term_actions": [
                {
                    key: value.get(key)
                    for key in (
                        "term_id", "source_term", "required_action", "hard_required",
                        "linked_claim_ids", "immutable_anchor_claim_ids",
                        "protected_slot_values", "approved_familiar_forms",
                    )
                }
                for value in (il_term_contract or [])
            ],
        },
        "ecl": {
            "cognitive_style": str(schema.get("cognitive_style", "")),
            "reading_goal": str(
                (upfront.get("ecl", {}) or {}).get(
                    "reading_goal", schema.get("reading_motivation", "")
                )
            ),
            "active_preference_dimension": str(
                (upfront.get("ecl", {}) or {}).get("active_preference_dimension", "")
            ),
            "organization_mode": str(
                (upfront.get("ecl", {}) or {}).get("organization_mode", "")
            ),
            "goal_alignment": dict(
                (upfront.get("ecl", {}) or {}).get("goal_alignment", {}) or {}
            ),
            "logical_relation_slots": list(
                (upfront.get("ecl", {}) or {}).get("logical_relation_slots", [])
            ),
            "relation_execution_rule": str(
                (upfront.get("ecl", {}) or {}).get("relation_execution_rule", "")
            ),
            "relation_grounding_rule": str(
                (upfront.get("ecl", {}) or {}).get("relation_grounding_rule", "")
            ),
            "relation_quality_rule": str(
                (upfront.get("ecl", {}) or {}).get("relation_quality_rule", "")
            ),
            "relation_modality_rule": str(
                (upfront.get("ecl", {}) or {}).get("relation_modality_rule", "")
            ),
            "nonregression_rule": (
                "preserve the current reader-facing structure unless an ECL evaluator "
                "names a failed dimension and target paragraph"
            ),
        },
        "gcl": {
            "knowledge_level": str((support.get("reader", {}) or {}).get("knowledge_level", "")),
            "bridge_support_ids": [
                str(item.get("support_id", ""))
                for item in support.get("bridges", []) or []
                if str(item.get("support_id", ""))
            ],
            "guidance_support_id": str(guidance.get("support_id", "")),
            "analogy_support_id": str(analogy.get("support_id", "")),
            "reader_grounding_support_id": str(grounding.get("support_id", "")),
            "direct_explanation_allowed": bool(
                analogy.get("direct_explanation_fallback", True)
            ),
            "planned_bridge_targets": list(
                (upfront.get("gcl", {}) or {}).get("bridge_targets", [])
            ),
            "planned_guidance_target": dict(
                (upfront.get("gcl", {}) or {}).get("guidance_target", {})
            ),
        },
        "limits": {
            "max_words": int(max_words),
            "merge_compatible_strategy_instructions": True,
            "max_targets_per_repair_call": 4,
            "additional_rewrite_calls": 0,
        },
        "upfront_integration": {
            "enabled": bool(upfront),
            "contract_sha256": str(upfront.get("contract_sha256", "")),
            "repair_role": str(upfront.get(
                "repair_role",
                "repair evaluator-confirmed failures without redesigning strategy",
            )),
            "rewrite_calls": int(upfront.get("rewrite_calls", 1)),
        },
    }


def _assessment_map(values: Iterable[dict[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    return {
        str(value.get(key, "")): value
        for value in values
        if isinstance(value, dict) and str(value.get(key, ""))
    }


def _contract_map(values: Iterable[dict[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    return _assessment_map(values, key)


def _spans(targets: Any, target_id: str) -> list[str]:
    if not isinstance(targets, dict):
        return []
    value = targets.get(target_id, [])
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    return list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))


def _instruction_spans_overlap(
    left: dict[str, Any], right: dict[str, Any]
) -> bool:
    for left_span in left.get("target_spans", []) or []:
        left_norm = " ".join(str(left_span).lower().split())
        for right_span in right.get("target_spans", []) or []:
            right_norm = " ".join(str(right_span).lower().split())
            if left_norm and right_norm and (
                left_norm in right_norm or right_norm in left_norm
            ):
                return True
    return False


def _claim_instruction(
    sequence: int,
    target_id: str,
    spans: list[str],
    assessment: dict[str, Any],
    contract: dict[str, Any],
) -> dict[str, Any]:
    verdict = str(assessment.get("verdict", "omitted"))
    missing = [str(value) for value in assessment.get("failed_slots", []) if str(value)]
    action = "insert_missing_claim" if verdict == "omitted" or not spans else "restore_claim_slots"
    return {
        "instruction_id": f"RA-C-{sequence:03d}",
        "module": "fidelity",
        "target_id": target_id,
        "priority": 1,
        "required_action": action,
        "executable": bool(spans) or action == "insert_missing_claim",
        "allowed_operations": (
            ["insert_before_sentence", "insert_after_sentence"]
            if action == "insert_missing_claim"
            else ["replace_within_sentence", "delete_within_sentence"]
        ),
        "target_spans": spans,
        "source_anchor": str(contract.get("canonical_proposition", "")),
        "source_evidence": list(contract.get("source_evidence", [])),
        "failure": {"verdict": verdict, "failed_slots": missing},
        "acceptance_conditions": [
            "the named claim is fully entailed",
            "all immutable slots and scope are preserved",
            "no unsupported proposition is introduced",
        ],
        "forbidden_changes": [
            "do not alter an unrelated passing claim",
            "do not increase certainty, scope, causality, or specificity",
        ],
    }


def _il_instruction(
    sequence: int,
    target_id: str,
    spans: list[str],
    assessment: dict[str, Any],
    contract: dict[str, Any],
    claim_contracts: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    required_action = str(
        assessment.get("required_action")
        or contract.get("required_action")
        or "preserve_meaning_and_follow_term_strategy"
    )
    source_term = str(contract.get("source_term") or assessment.get("source_term") or "")
    observed_treatment = str(assessment.get("observed_treatment", ""))
    action_recipe = {
        "retain_exact": "restore the exact source term; add no explanation",
        "retain_and_explain": "retain the exact term and add one local explanation of at most 12 words",
        "retain_and_gloss": "retain the exact term and add one local gloss of at most 12 words",
        "replace_with_approved_familiar_form": "replace only the observed jargon span with an approved familiar form",
        "replace_with_familiar_equivalent": "replace only the observed jargon span with a proposition-equivalent familiar expression",
        "retain_anchor_compress_context": "keep the protected anchor and shorten only redundant surrounding wording",
        "compress_or_merge": "compress redundant wording without removing a linked claim",
    }.get(required_action, "make the smallest local change that satisfies the required term treatment")
    if (
        required_action == "replace_with_familiar_equivalent"
        and observed_treatment in {"retained_exact", "retained_with_explanation"}
    ):
        action_recipe = (
            "replace only the source-term surface span with a familiar equivalent; "
            "preserve the adjacent explanation and every fact byte-for-byte"
        )
    source_evidence_choices = list(dict.fromkeys(
        evidence
        for claim_id in contract.get("linked_claim_ids", [])
        for evidence in claim_contracts.get(str(claim_id), {}).get("source_evidence", [])
        if str(evidence).strip()
    ))
    return {
        "instruction_id": f"RA-I-{sequence:03d}",
        "module": "icl",
        "target_id": target_id,
        "priority": 2,
        "required_action": required_action,
        "executable": bool(spans),
        "blocked_reason": "" if spans else "missing_unique_candidate_locator",
        "action_recipe": action_recipe,
        "allowed_operations": ["replace_within_sentence", "delete_within_sentence"],
        "target_spans": spans,
        "source_anchor": source_term,
        "approved_familiar_forms": list(contract.get("approved_familiar_forms", [])),
        "source_evidence_choices": source_evidence_choices,
        "linked_claim_ids": list(contract.get("linked_claim_ids", [])),
        "protected_slot_values": list(contract.get("protected_slot_values", [])),
        "failure": {
            "semantic_verdict": str(assessment.get("semantic_verdict", "")),
            "observed_treatment": observed_treatment,
            "meaning_preserved": bool(assessment.get("meaning_preserved", False)),
            "strategy_compliant": bool(assessment.get("strategy_compliant", False)),
            "reason": str(assessment.get("reason", "")),
        },
        "acceptance_conditions": [
            "meaning_preserved=true",
            "strategy_compliant=true for hard-required actions",
            "linked claims and protected slot values remain intact",
        ],
        "forbidden_changes": [
            "do not treat a term decision as permission to delete a proposition",
            "do not add a mechanism, outcome, application, example, or causal link",
        ],
    }


def _find_schema_failure(schema_evaluation: dict[str, Any], target_id: str) -> dict[str, Any]:
    for key in ("bridges", "analogies", "analogy_complexity", "protected_support"):
        for item in schema_evaluation.get(key, []) or []:
            if not isinstance(item, dict):
                continue
            observed_ids = {
                str(item.get(name, ""))
                for name in ("support_id", "schema_support_id", "bridge_id", "id")
            }
            if target_id in observed_ids:
                return item
    for key in ("guidance", "reader_grounding", "narrative_mapping"):
        item = schema_evaluation.get(key, {}) or {}
        if isinstance(item, dict):
            observed_ids = {
                str(item.get(name, ""))
                for name in ("support_id", "schema_support_id", "id")
            }
            if target_id in observed_ids:
                return item
    return {}


def _schema_instruction(
    sequence: int,
    target_id: str,
    spans: list[str],
    evaluation: dict[str, Any],
    strategy_requirement: dict[str, Any] | None = None,
) -> dict[str, Any]:
    strategy_requirement = strategy_requirement or {}
    status = str(evaluation.get("status", "failed"))
    planned = str(strategy_requirement.get("planned_realization", "")).strip()
    return {
        "instruction_id": f"RA-G-{sequence:03d}",
        "module": "gcl_schema_support",
        "target_id": target_id,
        "priority": 3,
        "required_action": "repair_schema_support_locally",
        "executable": bool(spans),
        "blocked_reason": "" if spans else "missing_unique_candidate_locator",
        "action_recipe": (
            "preserve the target sentence and integrate this frozen planned realization "
            f"locally: {planned}"
            if planned else
            "repair or add one short, nonfactual knowledge bridge, cognitive cue, "
            "direct explanation, or accurate analogy at the failed local target"
        ),
        "allowed_operations": (
            ["replace_within_sentence", "insert_after_sentence"]
            if planned else
            ["replace_within_sentence", "delete_within_sentence"]
        ),
        "target_spans": spans,
        "planned_realization": planned,
        "planned_placement": str(
            strategy_requirement.get("planned_placement", "")
        ),
        "failure": {
            "status": status,
            "reason": str(evaluation.get("reason", "")),
            "forced_binding": bool(evaluation.get("forced_binding", False)),
        },
        "acceptance_conditions": [
            "the named schema-support target becomes adequate",
            "A_B, A_Q, and P_gcl do not decrease",
            "the support remains reader-comprehensible and source-grounded",
        ],
        "forbidden_changes": [
            "do not invent a factual example, mechanism, outcome, or application",
            "do not modify a passing support target",
            "do not use a reader role as a global frame or infer reader beliefs",
        ],
    }


def build_repair_alignment_packet(
    *,
    repair_kind: str,
    triggered_by: list[str] | None,
    active_targets: dict[str, Any] | None,
    claim_contract: list[dict[str, Any]] | None = None,
    validation: dict[str, Any] | None = None,
    il_term_contract: list[dict[str, Any]] | None = None,
    il_evaluation: dict[str, Any] | None = None,
    schema_evaluation: dict[str, Any] | None = None,
    strategy_execution_contract: dict[str, Any] | None = None,
    max_instructions: int = 4,
) -> dict[str, Any]:
    """Build one auditable repair-alignment packet for a bounded repair call.

    The packet contains all current failures for auditability, but only the first
    ``max_instructions`` are selected for the current call.  No selected instruction
    can grant permission in another module namespace.
    """
    if not isinstance(max_instructions, int) or isinstance(max_instructions, bool) or max_instructions < 1:
        raise ValueError("max_instructions must be a positive integer")
    active_targets = active_targets or {}
    validation = validation or {}
    il_evaluation = il_evaluation or {}
    schema_evaluation = schema_evaluation or {}
    claim_assessments = _assessment_map(validation.get("assessments", []), "claim_id")
    claims = _contract_map(claim_contract or [], "claim_id")
    il_assessments = _assessment_map(il_evaluation.get("assessments", []), "term_id")
    terms = _contract_map(il_term_contract or [], "term_id")

    instructions: list[dict[str, Any]] = []
    for index, target_id in enumerate(sorted((active_targets.get("claim") or {}).keys()), 1):
        instructions.append(_claim_instruction(
            index, str(target_id), _spans(active_targets.get("claim"), str(target_id)),
            claim_assessments.get(str(target_id), {}), claims.get(str(target_id), {}),
        ))
    for index, target_id in enumerate(sorted((active_targets.get("il") or {}).keys()), 1):
        instructions.append(_il_instruction(
            index, str(target_id), _spans(active_targets.get("il"), str(target_id)),
            il_assessments.get(str(target_id), {}), terms.get(str(target_id), {}), claims,
        ))
    schema_targets = active_targets.get("schema") or {}
    gcl_requirements = (strategy_execution_contract or {}).get("gcl", {})
    planned_schema_targets = {
        str(value.get("support_id", "")): value
        for value in gcl_requirements.get("planned_bridge_targets", []) or []
        if isinstance(value, dict) and str(value.get("support_id", ""))
    }
    planned_guidance = gcl_requirements.get("planned_guidance_target", {}) or {}
    if isinstance(planned_guidance, dict) and str(
        planned_guidance.get("support_id", "")
    ):
        planned_schema_targets[str(planned_guidance["support_id"])] = planned_guidance
    for index, target_id in enumerate(sorted(schema_targets.keys()), 1):
        instructions.append(_schema_instruction(
            index, str(target_id), _spans(schema_targets, str(target_id)),
            _find_schema_failure(schema_evaluation, str(target_id)),
            planned_schema_targets.get(str(target_id), {}),
        ))

    for index, span in enumerate(active_targets.get("unsupported_spans", []) or [], 1):
        span = str(span).strip()
        if not span:
            continue
        unsupported_assessment = next(
            (
                item for item in validation.get("unsupported_claims", []) or []
                if isinstance(item, dict)
                and str(item.get("candidate_span", "")).strip() == span
            ),
            {},
        )
        closest_source_span = str(
            unsupported_assessment.get("closest_source_span", "")
        ).strip()
        instructions.append({
            "instruction_id": f"RA-U-{index:03d}",
            "module": "fidelity",
            "target_id": f"unsupported:{index}",
            "priority": 1,
            "required_action": "delete_or_source_ground_material_assertion",
            "executable": True,
            "allowed_operations": ["replace_within_sentence", "delete_within_sentence"],
            "target_spans": [span],
            "source_anchor": "",
            "source_evidence_choices": (
                [closest_source_span] if closest_source_span else []
            ),
            "failure": {
                "severity": str(unsupported_assessment.get("severity", "material")),
                "reason": str(unsupported_assessment.get("reason", "")),
            },
            "action_recipe": (
                "delete the unsupported local assertion, or replace it with the "
                "smallest proposition licensed by source_evidence_choices"
            ),
            "acceptance_conditions": ["the material unsupported assertion is absent or exactly source-grounded"],
            "forbidden_changes": ["do not paraphrase the unsupported assertion into another unsupported form"],
        })

    if not instructions and repair_kind == "length":
        instructions.append({
            "instruction_id": "RA-L-001",
            "module": "length",
            "target_id": "word_count",
            "priority": 4,
            "required_action": "shorten_without_strategy_or_claim_regression",
            "executable": True,
            "allowed_operations": ["replace_within_sentence", "delete_within_sentence"],
            "target_spans": [],
            "acceptance_conditions": [
                "word count decreases to the declared maximum",
                "all claims and ICL/ECL/GCL behavior remain non-regressed",
            ],
            "forbidden_changes": [
                "do not delete a protected claim, required term, explanation, bridge, or guidance cue",
            ],
        })

    instructions.sort(key=lambda item: (int(item["priority"]), str(item["instruction_id"])))
    executable = [item for item in instructions if item.get("executable", True)]
    for item in instructions:
        if item["module"] == "icl":
            instruction_scope = f"icl/{item['required_action']}"
        elif item["module"] == "gcl_schema_support":
            instruction_scope = "gcl_schema_support"
        elif item["module"] == "length":
            instruction_scope = "length"
        else:
            instruction_scope = "fidelity"
        item["instruction_scope_id"] = instruction_scope

    # Merge compatible module instructions into one planner call. Select one highest
    # priority instruction from each active module first, then fill the remaining
    # patch capacity by global priority. This reduces sequential rewrite calls while
    # keeping every patch bound to its own namespace and postconditions.
    selected: list[dict[str, Any]] = []
    selected_ids: set[str] = set()
    for module in ("fidelity", "icl", "gcl_schema_support", "length"):
        candidates = [value for value in executable if value["module"] == module]
        item = next(
            (
                value for value in candidates
                if any(_instruction_spans_overlap(value, chosen) for chosen in selected)
            ),
            candidates[0] if candidates else None,
        )
        if item is not None and len(selected) < max_instructions:
            selected.append(item)
            selected_ids.add(str(item["instruction_id"]))
    for item in executable:
        if len(selected) >= max_instructions:
            break
        if str(item["instruction_id"]) in selected_ids:
            continue
        selected.append(item)
        selected_ids.add(str(item["instruction_id"]))
    selected.sort(key=lambda item: (int(item["priority"]), str(item["instruction_id"])))
    selected_scopes = list(dict.fromkeys(
        str(item["instruction_scope_id"]) for item in selected
    ))
    strategy_scope_id = (
        selected_scopes[0] if len(selected_scopes) == 1
        else "merged_repair" if selected_scopes
        else "none"
    )
    deferred = [
        item for item in instructions if item["instruction_id"] not in selected_ids
    ]
    strategy_execution_contract = strategy_execution_contract or {}
    selected_target_ids = {
        str(item.get("target_id", ""))
        for item in selected if item.get("module") == "icl"
    }
    icl_requirements = strategy_execution_contract.get("icl", {})
    strategy_requirements = {
        "icl": {
            **icl_requirements,
            "term_actions": [
                item for item in icl_requirements.get("term_actions", [])
                if str(item.get("term_id", "")) in selected_target_ids
            ],
        } if selected_target_ids else {},
        "ecl_continuity": strategy_execution_contract.get("ecl", {}),
        "gcl": (
            strategy_execution_contract.get("gcl", {})
            if any(item.get("module") == "gcl_schema_support" for item in selected)
            else {}
        ),
    }
    packet = {
        "schema_version": REPAIR_ALIGNMENT_VERSION,
        "mode": REPAIR_ALIGNMENT_MODE,
        "repair_kind": str(repair_kind),
        "triggered_by": list(triggered_by or []),
        "strategy_scope_id": strategy_scope_id,
        "selected_instruction_ids": [item["instruction_id"] for item in selected],
        "deferred_instruction_ids": [item["instruction_id"] for item in deferred],
        "deferred_instructions": deferred,
        "blocked_instruction_ids": [
            item["instruction_id"]
            for item in instructions if not item.get("executable", True)
        ],
        "instructions": selected,
        "all_active_target_ids": {
            "claim": sorted((active_targets.get("claim") or {}).keys()),
            "il": sorted((active_targets.get("il") or {}).keys()),
            "schema": sorted((active_targets.get("schema") or {}).keys()),
        },
        "active_target_ids": {
            "claim": sorted(
                str(item.get("target_id", ""))
                for item in selected
                if item.get("module") == "fidelity"
                and not str(item.get("target_id", "")).startswith("unsupported:")
            ),
            "unsupported": sorted(
                str(item.get("target_id", ""))
                for item in selected
                if str(item.get("target_id", "")).startswith("unsupported:")
            ),
            "il": sorted(
                str(item.get("target_id", ""))
                for item in selected if item.get("module") == "icl"
            ),
            "schema": sorted(
                str(item.get("target_id", ""))
                for item in selected
                if item.get("module") == "gcl_schema_support"
            ),
        },
        "strategy_requirements": strategy_requirements,
        "strategy_sha256": strategy_execution_contract.get("strategy_sha256", {}),
        "limits": strategy_execution_contract.get("limits", {}),
        "all_failed_target_count": len(instructions),
        "selected_target_count": len(selected),
        "alignment_protocol": {
            "scope": "modify only selected instruction targets",
            "one_patch_per_instruction_unless_compatible_overlap": True,
            "overlapping_instructions_may_share_one_patch": True,
            "require_instruction_id_on_patch": True,
            "merge_compatible_instructions": True,
            "instruction_scope_isolation": True,
            "preserve_unselected_modules": True,
            "accept_only_after_rescore": True,
        },
    }
    packet["packet_id"] = "RAP_" + hashlib.sha256(
        json.dumps(
            {
                "repair_kind": packet["repair_kind"],
                "strategy_scope_id": packet["strategy_scope_id"],
                "selected_instruction_ids": packet["selected_instruction_ids"],
                "instructions": packet["instructions"],
            },
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()[:16]
    return packet


def render_repair_alignment_packet(packet: dict[str, Any] | None) -> str:
    """Render the packet near the top of a model prompt."""
    packet = packet or {}
    if packet.get("mode") != REPAIR_ALIGNMENT_MODE:
        return ""
    prompt_packet = {
        key: value for key, value in packet.items()
        if key not in {"deferred_instructions"}
    }
    return (
        "REPAIR INSTRUCTION ALIGNMENT MODE (authoritative for this call)\n"
        "Execute every selected instruction exactly once. Use the instruction's own "
        "module namespace; do not compensate for one failed strategy by changing another. "
        "For every patch, echo its instruction_id and make the smallest local edit that "
        "meets all acceptance_conditions. Preserve every forbidden_changes item and every "
        "unselected ICL/ECL/GCL strategy behavior. Deferred instructions are audit-only and "
        "must not be edited in this call.\n"
        + json.dumps(prompt_packet, ensure_ascii=False, indent=2)
    )


__all__ = [
    "REPAIR_ALIGNMENT_MODE",
    "REPAIR_ALIGNMENT_VERSION",
    "UPFRONT_STRATEGY_VERSION",
    "STANDARD_GENERATION_MODE",
    "build_repair_alignment_packet",
    "build_strategy_deduplication_report",
    "build_strategy_realization_audit",
    "build_ecl_preference_alignment_contract",
    "compile_ecl_relation_plan",
    "build_gcl_schema_alignment_contract",
    "compile_gcl_support_plan",
    "build_icl_claim_alignment_contract",
    "build_strategy_execution_contract",
    "build_upfront_strategy_contract",
    "freeze_strategy_bundle",
    "render_repair_alignment_packet",
    "validate_generation_mode",
]
