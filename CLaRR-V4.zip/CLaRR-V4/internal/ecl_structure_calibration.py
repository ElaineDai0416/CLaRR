#!/usr/bin/env python3
"""Expert-calibrated ECL Structure v3.2 scoring contract.

The deterministic length rule is inherited unchanged from v3.1. Only the five
independent candidate-only rubrics and their response schema are versioned here.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable, Mapping

from ecl_structure import active_feature_names, candidate_structure_facts
from ecl_structure_policy import (
    ECLV31Error,
    ExpansionPolicy,
    build_score_record as build_v31_score_record,
)


ROOT = Path(__file__).resolve().parent
PROMPT_DIR = ROOT / "ecl_prompts/calibration"
COMMON_PROMPT_PATH = PROMPT_DIR / "common_calibration.md"
FEATURE_SCHEMA_VERSION = "ecl-structure-feature-v1.2"
OUTPUT_SCHEMA_VERSION = "ecl-structure-auto-v1.2"
DIMENSION_TO_PROMPT = {
    "S-COHERENCE": "coherence.md",
    "S-PROPORTIONALITY-INTERNAL": "proportionality_internal.md",
    "S-NONMECHANICAL": "nonmechanical.md",
    "S-LOGICAL-ORGANIZATION": "logical_organization.md",
    "S-EMOTIONAL-PROGRESSION": "emotional_progression.md",
}


class ECLV32Error(ECLV31Error):
    pass


def dimensions_for(preference: str) -> tuple[str, ...]:
    active = active_feature_names(preference)
    return (
        "S-COHERENCE",
        "S-PROPORTIONALITY-INTERNAL",
        "S-NONMECHANICAL",
        active[-1],
    )


def feature_prompt(dimension: str, item_id: str, preference: str, candidate: str) -> str:
    if dimension not in DIMENSION_TO_PROMPT:
        raise ECLV32Error(f"unknown v3.2 dimension: {dimension}")
    common = COMMON_PROMPT_PATH.read_text(encoding="utf-8")
    rubric = (PROMPT_DIR / DIMENSION_TO_PROMPT[dimension]).read_text(encoding="utf-8")
    payload = {
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "dimension": dimension,
        "candidate_markdown": candidate,
        "deterministic_structure_facts": candidate_structure_facts(candidate),
    }
    return common + "\n\n" + rubric + "\n\n## Item\n\n" + json.dumps(payload, ensure_ascii=False, indent=2)


def _json_object(raw: str) -> dict[str, Any]:
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise ECLV32Error("feature response did not contain JSON")
        value = json.loads(match.group())
    if not isinstance(value, dict):
        raise ECLV32Error("feature response must be an object")
    return value


def parse_feature_response(
    raw: str,
    *,
    dimension: str,
    item_id: str,
    candidate: str,
) -> dict[str, Any]:
    value = _json_object(raw)
    if value.get("schema_version") != FEATURE_SCHEMA_VERSION:
        raise ECLV32Error("feature schema_version mismatch")
    if str(value.get("item_id", "")) != str(item_id):
        raise ECLV32Error("feature item_id mismatch")
    if value.get("dimension") != dimension:
        raise ECLV32Error("feature dimension mismatch")
    score = str(value.get("score", "")).upper()
    if score not in {"0", "1", "2", "U"}:
        raise ECLV32Error(f"invalid feature score: {score!r}")
    rationale = str(value.get("rationale", "")).strip()
    repair = str(value.get("repair_instruction", "")).strip()
    confidence = str(value.get("confidence", "")).strip().lower()
    if not rationale:
        raise ECLV32Error("feature rationale is required")
    if score in {"0", "1"} and not repair:
        raise ECLV32Error("failed feature requires repair_instruction")
    if score == "2" and repair:
        raise ECLV32Error("feature score 2 requires empty repair_instruction")
    if score == "U" and confidence != "low":
        raise ECLV32Error("feature U requires low confidence")
    if score != "U" and confidence not in {"high", "medium", "low"}:
        raise ECLV32Error("invalid feature confidence")
    evidence = value.get("candidate_evidence", [])
    if not isinstance(evidence, list):
        evidence = []
    exact = [quote for quote in evidence if isinstance(quote, str) and quote in candidate][:2]
    tags = value.get("failure_tags", [])
    if not isinstance(tags, list):
        tags = []
    return {
        "score": score,
        "candidate_evidence": exact,
        "rationale": rationale,
        "failure_tags": [str(tag).strip() for tag in tags if str(tag).strip()],
        "repair_instruction": repair,
        "confidence": confidence,
        "evidence_sanitized": exact != evidence,
    }


def build_score_record(
    *,
    item_id: str,
    preference: str,
    source_text: str,
    candidate: str,
    feature_results: Mapping[str, Mapping[str, Any]],
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    record = build_v31_score_record(
        item_id=item_id,
        preference=preference,
        source_text=source_text,
        candidate=candidate,
        feature_results=feature_results,
        policy=policy,
    )
    record["schema_version"] = OUTPUT_SCHEMA_VERSION
    record["rubric_version"] = "v3.2"
    return record


def score_candidate(
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call: Callable[..., str],
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    """Run four independent judges and aggregate with the frozen length cap.

    ``feature_llm_call`` must accept ``prompt`` plus keyword arguments
    ``dimension``, ``max_tokens``, ``temperature`` and ``response_format``.
    """
    results: dict[str, dict[str, Any]] = {}
    for dimension in dimensions_for(preference):
        prompt = feature_prompt(dimension, item_id, preference, candidate)
        raw = feature_llm_call(
            prompt,
            dimension=dimension,
            max_tokens=1400,
            temperature=0,
            response_format={"type": "json_object"},
        )
        results[dimension] = parse_feature_response(
            raw,
            dimension=dimension,
            item_id=item_id,
            candidate=candidate,
        )
    return build_score_record(
        item_id=item_id,
        preference=preference,
        source_text=source_text,
        candidate=candidate,
        feature_results=results,
        policy=policy,
    )
