"""
llm_client.py
-------------
The single LLM access point shared by core.py and every ablation
entry script. API settings are NOT configured in code: everything resolves
from the system environment at import time.

Environment variables:
    LLM_API_KEY always wins. Otherwise the key is selected from LLM_BASE_URL:
      api.deepseek.com  -> DEEPSEEK_API_KEY
      open.bigmodel.cn  -> ZHIPU_API_KEY -> GLM_API_KEY
    LLM_MODEL always wins. Otherwise the model is selected from LLM_BASE_URL:
      api.deepseek.com  -> DEEPSEEK_MODEL -> deepseek-v4-flash
      open.bigmodel.cn  -> GLM_MODEL      -> glm-5.3-flash
    Unknown/custom URLs retain the legacy fallback order.
    LLM_BASE_URL  -> GLM_BASE_URL   -> DEEPSEEK_BASE_URL

Only the neutral endpoint/model defaults below live in this file; override them
with the environment variables above. No credential is ever read from, stored
in, or printed by this module (the key is passed to the SDK untouched).

Thinking mode (reasoning models):
    LLM_THINKING = "disabled" | "enabled" | "auto" (default: auto)
  Hybrid models such as deepseek-v4-flash think by default and count reasoning
  tokens toward max_tokens: on long JSON judgments the reasoning alone can
  exhaust the budget, returning an empty `content` with finish_reason "length"
  after 100-200 s (and a truncated, unparseable body on the retry). Setting
  LLM_THINKING=disabled sends `thinking: {"type": "disabled"}`, which DeepSeek
  accepts. GLM-5.3-flash REJECTS that parameter (HTTP 400 code 1210) and always
  thinks — leave LLM_THINKING unset ("auto" sends nothing) for that provider.
"""

import hashlib
import json
import math
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar, copy_context
from pathlib import Path
from threading import Lock, current_thread
from typing import Any

import httpx
from openai import OpenAI

BASE_URL = (
    os.environ.get("LLM_BASE_URL")
    or os.environ.get("GLM_BASE_URL")
    or os.environ.get("DEEPSEEK_BASE_URL")
    or "https://open.bigmodel.cn/api/paas/v4"
)


def _resolve_api_key(base_url: str, environment=None) -> str | None:
    """Select a credential for the configured provider without exposing its value."""
    env = environment if environment is not None else os.environ
    if env.get("LLM_API_KEY"):
        return env.get("LLM_API_KEY")
    host = str(base_url).casefold()
    if "api.deepseek.com" in host:
        return env.get("DEEPSEEK_API_KEY")
    if "open.bigmodel.cn" in host:
        return env.get("ZHIPU_API_KEY") or env.get("GLM_API_KEY")
    if "dashscope" in host:
        return env.get("DASHSCOPE_API_KEY")
    return (
        env.get("ZHIPU_API_KEY")
        or env.get("GLM_API_KEY")
        or env.get("DEEPSEEK_API_KEY")
    )


API_KEY = _resolve_api_key(BASE_URL)


def _resolve_model(base_url: str, environment=None) -> str:
    """Select a provider-compatible model while honoring an explicit override."""
    env = environment if environment is not None else os.environ
    if env.get("LLM_MODEL"):
        return env["LLM_MODEL"]
    host = str(base_url).casefold()
    if "api.deepseek.com" in host:
        return env.get("DEEPSEEK_MODEL") or "deepseek-v4-flash"
    if "open.bigmodel.cn" in host:
        return env.get("GLM_MODEL") or "glm-5.3-flash"
    if "dashscope" in host:
        return env.get("DASHSCOPE_MODEL") or "qwen3.7-flash"
    return env.get("GLM_MODEL") or env.get("DEEPSEEK_MODEL") or "glm-5.3-flash"


MODEL = _resolve_model(BASE_URL)

DEFAULT_MAX_TOKENS = 8192
MAX_TOKENS_CEILING = 32768
MIN_OUTPUT_TOKENS = max(0, int(os.environ.get("CLARR_MIN_OUTPUT_TOKENS", "8000")))
EMPTY_CONTENT_RETRIES = 2
RETRY_BACKOFF_SECONDS = 2.0
# "disabled"/"enabled" sends an explicit thinking override; anything else
# (including unset) sends none. See the module docstring for why this must be
# pinned per provider rather than hardcoded.
THINKING_OVERRIDE = os.environ.get("LLM_THINKING", "auto").strip().lower()
# Bound every request phase so a stalled server connection cannot freeze a
# batch run for the full default read window. Observed stalls: the server
# accepts the TLS connection but never answers; 240s comfortably exceeds any
# legitimate completion time on the current provider (~2 min worst case).
REQUEST_TIMEOUT = httpx.Timeout(
    connect=15.0,
    read=float(os.environ.get("LLM_REQUEST_READ_TIMEOUT", "240")),
    write=60.0,
    pool=30.0,
)
# Always connect DIRECTLY to the API endpoint. The local system proxy
# (macOS HTTP/HTTPS/SOCKS on 127.0.0.1) accepts small requests but stalls
# large POST bodies, which froze batch runs mid-evaluation. Both configured
# endpoints (api.deepseek.com, open.bigmodel.cn) are directly reachable.
TRUST_ENV = False

# Per-call telemetry (duration seconds, max_tokens used, finish reason) for
# latency reporting; nothing here contains prompt or key material.
CALL_LOG: list[dict] = []

# Any call slower than this is appended to llm_slow_calls.jsonl next to this
# file (with a timestamp and thread name). Under concurrent batch runs this is
# the only place every slow call — including calls on inner strategy-lane
# threads — is visible, so a latency regression can be dated and attributed.
SLOW_CALL_SECONDS = 20.0
_SLOW_CALL_LOG = Path(__file__).resolve().parent / "llm_slow_calls.jsonl"
_slow_call_lock = Lock()

# Per-call token usage (billing) log: one line per call that returned a
# usage payload, so cost is audited exactly instead of extrapolated from
# samples. Same rules as the slow-call log — counts and timestamps only,
# never prompt bodies or key material.
_USAGE_LOG = Path(__file__).resolve().parent / "llm_usage.jsonl"
_usage_lock = Lock()

# Pair/stage context is propagated into nested executors by
# ContextPropagatingThreadPoolExecutor.  The former thread-local recorder lost
# every source-baseline, strategy, and post-rewrite-audit call because those
# calls run on inner pools.  Explicit recording IDs make the usage record total
# even when many pairs are processed concurrently.
_recording_id: ContextVar[str | None] = ContextVar(
    "clarr_llm_recording_id", default=None
)
_recording_pair_id: ContextVar[str | None] = ContextVar(
    "clarr_llm_pair_id", default=None
)
_recordings: dict[str, list[dict]] = {}
_recordings_lock = Lock()


class ContextPropagatingThreadPoolExecutor(ThreadPoolExecutor):
    """Thread pool that carries pair/stage context into every submitted task."""

    def submit(self, fn, /, *args, **kwargs):
        context = copy_context()
        return super().submit(context.run, fn, *args, **kwargs)


def start_call_recording(pair_id: str | None = None) -> str:
    """Start one pair-scoped recording and return its opaque recording ID."""
    display_pair = str(pair_id or current_thread().name)
    recording_id = f"{display_pair}:{time.time_ns()}"
    with _recordings_lock:
        _recordings[recording_id] = []
    _recording_id.set(recording_id)
    _recording_pair_id.set(display_pair)
    return recording_id


def collect_call_recording() -> list[dict]:
    recording_id = _recording_id.get()
    if recording_id is None:
        return []
    with _recordings_lock:
        entries = list(_recordings.pop(recording_id, []))
    _recording_id.set(None)
    _recording_pair_id.set(None)
    return entries


def infer_call_stage(prompt: str) -> str:
    """Classify a prompt for cost telemetry without changing its contents."""
    value = str(prompt or "")
    if re.search(r"You are the ECL Structure .* repairer", value):
        return "repair.ecl"
    dimension = re.search(
        r'"dimension"\s*:\s*"(S-[A-Z-]+)"', value
    )
    if dimension:
        return "audit.ecl." + dimension.group(1).lower()
    checks = (
        ("term_extraction", "You are a computational linguist"),
        ("term_vtech", "V_tech (1-7): how specialised / unfamiliar"),
        ("strategy.icl", "## ICL STRATEGY"),
        ("strategy.ecl", "## ECL STRATEGY"),
        ("strategy.gcl", "## GCL STRATEGY"),
        ("rewrite", "## UNIFIED CLARR REWRITE"),
        # v4 compact agents: without these markers their calls billed as
        # "unclassified" and bypassed stage_token_cap telemetry (part_2:
        # 6366 post-rewrite + 3504 plain unclassified calls, ~18% of spend).
        # Version-less prefixes so a schema bump does not silently unclassify.
        ("rewrite", "## CLARR ICL/ECL PRIMARY REWRITE AGENT"),
        ("repair.local_patch", "## CLARR LOCAL REPAIR AGENT"),
        ("condense", "The adapted article below is"),
        ("audit.fidelity_adversarial", "performing an adversarial"),
        ("audit.fidelity_primary", "conservative fidelity verifier"),
        ("audit.icl", "You audit whether a reader-adapted rewrite obeys its IL"),
        ("audit.gcl", "You audit observable schema-support features"),
        ("repair.local_patch", "bounded repair packet"),
    )
    for stage, marker in checks:
        if marker in value:
            return stage
    return "unclassified"


def record_local_cache_hit(
    *, stage: str, cache_key: str, content_chars: int = 0
) -> None:
    """Add a zero-token local artifact-cache event to the active pair record."""
    _note_call({
        "attempt": 0,
        "seconds": 0.0,
        "max_tokens": 0,
        "finish": "local_cache_hit",
        "content_chars": int(content_chars),
        "prompt_tokens": 0,
        "cache_hit_tokens": 0,
        "completion_tokens": 0,
        "local_cache_hit": True,
        "cache_key": str(cache_key),
        "stage": str(stage),
    })


def _note_call(entry: dict) -> None:
    resolved_stage = str(entry.get("stage") or "unclassified")
    thread_name = current_thread().name
    if thread_name.startswith("clarr-source-baseline") and not resolved_stage.startswith(
        "source_baseline."
    ):
        resolved_stage = "source_baseline." + resolved_stage
    elif thread_name.startswith("clarr-post-rewrite-audit") and not resolved_stage.startswith(
        "post_rewrite."
    ):
        resolved_stage = "post_rewrite." + resolved_stage
    entry = {
        **entry,
        "pair_id": _recording_pair_id.get(),
        "stage": resolved_stage,
    }
    CALL_LOG.append(entry)
    recording_id = _recording_id.get()
    if recording_id is not None:
        with _recordings_lock:
            if recording_id in _recordings:
                _recordings[recording_id].append(entry)
    if entry.get("seconds", 0.0) >= SLOW_CALL_SECONDS:
        line = json.dumps({
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "thread": current_thread().name,
            "model": MODEL,
            **entry,
        }, ensure_ascii=False)
        with _slow_call_lock:
            with open(_SLOW_CALL_LOG, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    # The usage jsonl is a provider-billing ledger. Local artifact hits belong
    # in pair telemetry/CALL_LOG but must not look like zero-token API calls.
    if entry.get("prompt_tokens") is not None and not entry.get("local_cache_hit"):
        line = json.dumps({
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "thread": current_thread().name,
            "model": MODEL,
            # Optional free-text run tag (e.g. LLM_RUN_TAG=v2) so mixed-version
            # accounting stays separable in one shared jsonl.
            "tag": os.environ.get("LLM_RUN_TAG"),
            "pair_id": entry.get("pair_id"),
            "stage": entry.get("stage"),
            "local_cache_hit": bool(entry.get("local_cache_hit", False)),
            "cache_key": entry.get("cache_key"),
            "prompt_tokens": entry["prompt_tokens"],
            "cache_hit_tokens": entry.get("cache_hit_tokens"),
            "completion_tokens": entry.get("completion_tokens"),
            "seconds": entry.get("seconds"),
        }, ensure_ascii=False)
        with _usage_lock:
            with open(_USAGE_LOG, "a", encoding="utf-8") as f:
                f.write(line + "\n")


_client = None
_client_init_lock = Lock()


# Qwen changes price tiers at 32K input tokens.  Count the complete one-message
# chat request locally, add a conservative cushion for hosted-template drift,
# warn near the boundary, and fail before network transmission at the boundary.
_QWEN_TOKENIZER_ID = os.environ.get("QWEN_TOKENIZER_ID", "Qwen/Qwen3-0.6B")
_INPUT_WARN_TOKENS = int(os.environ.get("LLM_INPUT_WARN_TOKENS", "30000"))
_INPUT_HARD_TOKENS = int(os.environ.get("LLM_INPUT_HARD_TOKENS", "32000"))
_INPUT_SAFETY_RATIO = float(
    os.environ.get("LLM_INPUT_TOKEN_SAFETY_RATIO", "1.03")
)
_INPUT_SAFETY_FIXED = int(
    os.environ.get("LLM_INPUT_TOKEN_SAFETY_FIXED", "64")
)
_qwen_tokenizer: Any | None = None
_qwen_tokenizer_lock = Lock()
_warned_prompt_hashes: set[str] = set()
_warning_lock = Lock()


class InputTokenLimitError(RuntimeError):
    """Raised before transmission when a Qwen request reaches 32K input."""


def _is_qwen_request() -> bool:
    return MODEL.lower().startswith("qwen") or "dashscope" in BASE_URL.lower()


def _get_qwen_tokenizer() -> Any:
    global _qwen_tokenizer
    if _qwen_tokenizer is None:
        with _qwen_tokenizer_lock:
            if _qwen_tokenizer is None:
                try:
                    from transformers import AutoTokenizer
                    _qwen_tokenizer = AutoTokenizer.from_pretrained(
                        _QWEN_TOKENIZER_ID,
                        local_files_only=True,
                    )
                except Exception as exc:
                    raise InputTokenLimitError(
                        "Qwen input-token guard cannot load local tokenizer "
                        f"{_QWEN_TOKENIZER_ID}; refusing to send uncounted input"
                    ) from exc
    return _qwen_tokenizer


def estimate_qwen_input_tokens(prompt: str) -> tuple[int, int]:
    tokenizer = _get_qwen_tokenizer()
    encoded = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        tokenize=True,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    if isinstance(encoded, dict) or hasattr(encoded, "keys"):
        input_ids = encoded["input_ids"]
    else:
        input_ids = encoded
    if input_ids and isinstance(input_ids[0], list):
        input_ids = input_ids[0]
    raw = len(input_ids)
    guarded = math.ceil(raw * _INPUT_SAFETY_RATIO) + _INPUT_SAFETY_FIXED
    return raw, guarded


def enforce_qwen_input_price_guard(prompt: str) -> tuple[int, int] | None:
    if not _is_qwen_request():
        return None
    if not 0 < _INPUT_WARN_TOKENS < _INPUT_HARD_TOKENS:
        raise InputTokenLimitError(
            "invalid Qwen token guard: require 0 < warning < hard limit"
        )
    raw, guarded = estimate_qwen_input_tokens(prompt)
    if guarded >= _INPUT_HARD_TOKENS:
        raise InputTokenLimitError(
            "Qwen request blocked before transmission: "
            f"tokenizer_count={raw}, guarded_count={guarded}, "
            f"hard_limit={_INPUT_HARD_TOKENS}"
        )
    if guarded >= _INPUT_WARN_TOKENS:
        digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:12]
        with _warning_lock:
            first_warning = digest not in _warned_prompt_hashes
            _warned_prompt_hashes.add(digest)
        if first_warning:
            print(
                "[qwen-token-guard] WARNING "
                f"prompt={digest} tokenizer_count={raw} "
                f"guarded_count={guarded} warn={_INPUT_WARN_TOKENS} "
                f"hard={_INPUT_HARD_TOKENS}",
                file=sys.stderr,
                flush=True,
            )
    return raw, guarded


def get_client() -> OpenAI:
    """Create the API client lazily so local validation/tests need no credential."""
    global _client
    if _client is None:
        with _client_init_lock:
            if _client is None:
                if not API_KEY:
                    raise RuntimeError(
                        "No API key found in the environment. Set LLM_API_KEY "
                        "(or ZHIPU_API_KEY / GLM_API_KEY / DEEPSEEK_API_KEY)."
                    )
                _client = OpenAI(
                    api_key=API_KEY,
                    base_url=BASE_URL,
                    http_client=httpx.Client(
                        trust_env=TRUST_ENV, timeout=REQUEST_TIMEOUT,
                    ),
                )
    return _client


def call_llm(
    prompt: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: float = 0.2,
    response_format: dict | None = None,
    stage: str | None = None,
) -> str:
    """Call the configured model and return the response text.

    Reasoning-type models count thinking tokens toward `max_tokens`; when
    reasoning exhausts the budget the response comes back with an empty
    `content` and `finish_reason == "length"`. Such calls are retried with an
    escalated token cap (x2, then the ceiling) instead of identical requests.
    Transient transport errors are retried with the same cap and a backoff.
    """
    enforce_qwen_input_price_guard(prompt)
    request = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "stream": False,
    }
    if response_format is not None:
        request["response_format"] = response_format
    if THINKING_OVERRIDE in ("enabled", "disabled"):
        if "dashscope" in BASE_URL.casefold():
            request["extra_body"] = {
                "enable_thinking": THINKING_OVERRIDE == "enabled"
            }
        else:
            request["extra_body"] = {"thinking": {"type": THINKING_OVERRIDE}}

    cap = max_tokens
    resolved_stage = str(stage or infer_call_stage(prompt))
    # Mirror 04Ablation raise_output_cap: evaluator JSON calls pass hardcoded
    # 5000-token caps that dataset-scale contracts can exceed; lift the floor
    # (never lower) so a truncated JSON judgment cannot kill the pair.
    if isinstance(cap, int) and cap < MIN_OUTPUT_TOKENS:
        cap = MIN_OUTPUT_TOKENS
    last_error: Exception | str | None = None
    for attempt in range(EMPTY_CONTENT_RETRIES + 1):
        started = time.time()
        try:
            resp = get_client().chat.completions.create(
                **request, max_tokens=cap,
            )
            content = resp.choices[0].message.content
            usage = getattr(resp, "usage", None)
            _note_call({
                "attempt": attempt,
                "seconds": round(time.time() - started, 1),
                "max_tokens": cap,
                "finish": str(resp.choices[0].finish_reason),
                "content_chars": len(content or ""),
                # Provider-reported usage (DeepSeek: incl. prompt_cache_hit_
                # tokens). Flat fields so CALL_LOG / thread recordings and the
                # usage jsonl stay grep-able; None-safe for providers without.
                "prompt_tokens": getattr(usage, "prompt_tokens", None),
                "cache_hit_tokens": getattr(usage, "prompt_cache_hit_tokens", None),
                "completion_tokens": getattr(usage, "completion_tokens", None),
                "stage": resolved_stage,
            })
            if content:
                return content
            last_error = (
                f"{MODEL} returned an empty content field "
                f"(finish={resp.choices[0].finish_reason}, max_tokens={cap})"
            )
            if resp.choices[0].finish_reason == "length":
                cap = min(max(cap * 2, DEFAULT_MAX_TOKENS), MAX_TOKENS_CEILING)
        except Exception as exc:  # transient API/transport errors
            _note_call({
                "attempt": attempt,
                "seconds": round(time.time() - started, 1),
                "max_tokens": cap,
                "error": str(exc)[:120],
                "stage": resolved_stage,
            })
            last_error = exc
            time.sleep(RETRY_BACKOFF_SECONDS * (attempt + 1))
    raise RuntimeError(f"LLM call failed after {EMPTY_CONTENT_RETRIES + 1} attempts: {last_error}")


def call_ecl_feature_llm(prompt: str, **kwargs) -> str:
    """Adapt the production caller to the ECL scorer's audit-only keyword."""
    kwargs.pop("dimension", None)
    return call_llm(prompt, **kwargs)
