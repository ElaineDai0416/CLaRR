"""
cost_foundation.py — v2 成本优化补丁层（2026-08-31，基于 part_1 主基线实测）
--------------------------------------------------------------------
设计约束：v1 生成/评分决策逻辑不改；共享的 llm_client 和主入口仅增加
跨线程计量钩子，不改 prompt 或候选接受规则。成本优化在 apply_v2()
导入期以函数重绑定的方式生效，因此 v1 链（正在跑的 part_1/part_2/
part_3 主基线）的实验行为不受影响。
v2 只能通过 core_v2.py 入口（或显式调用 apply_v2()）启用。

实测依据（单配对 24 次调用、84k prompt tokens、23 调用/配对）：
  - 修复回路占 prompt 的 ~74%，其中最热的是 repair_alignment_patch_prompt
    （6.7–8.7k tokens/次）：v1 把每轮都变的 packet JSON（~390 行）放在 prompt
    最顶部，把静态协议/输出 schema/跨读者共享的原文全部挤到动态内容之后，
    DeepSeek 自动前缀缓存只能命中开头 6 行。
  - 术语抽取（[1/7]）与读者无关，同一篇文章的 18 个读者各重跑一次。

本层实现（v2.1）：
  (1) 完整 pair/stage token 归属：ContextVar 跨内层线程池传播，不再
      漏记 source-baseline / strategy / post-audit 调用；
  (2) 精确 artifact checkpoint：按 prompt+模型+参数哈希落盘，并发相同
      请求只调一次 API；可用 CLARR_V2_CACHE_MODE=off|refresh 禁用/刷新；
  (3) 原文 Fidelity 基线确定化，不再用 LLM 判断 source==candidate；
  (4) 原文 ECL 按 article×Logical/Emotional 复用，18 读者从 72 个
      feature calls 降到 8 个；
  (5) reader payload 按 V_tech/ICL/ECL/GCL 裁剪，验证链仅携带紧凑
      claim verdict；
  (6) 最热 planner prompt 前缀规范化：段落内容与 v1 逐字相同，仅重排顺序
      ——静态协议/schema 与 SOURCE 前置，packet/candidate/anchors 后置，
      让前缀缓存命中「静态协议 + 共享原文 + 读者约束」整段。
      唯一文字改动：协议第 8 条中的具体词数移入尾部 LENGTH STATUS
      （动态数值不能留在静态前缀里）。

未在本层实现（第二阶段候选）：修复轮内按 span 交集选择性重评；
ECL 链 prompt 排序；评估器换档模型（v4-flash 已是 DeepSeek 最低档，无更便宜
可选，且换判分主体需重新校准，不建议）。
"""

import copy
import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path
from threading import Lock

import fidelity_repair
import il_fidelity
import llm_client
import schema_support
from comparative_scoring import build_three_dimension_score
from fidelity_repair import _sentence_spans, render_repair_alignment_packet

V2_CACHE_SCHEMA = "clarr-v2-artifact-cache-v1"
_CACHE_DIR = Path(
    os.environ.get(
        "CLARR_V2_CACHE_DIR",
        Path(__file__).resolve().parent / "v2_cache",
    )
)
_CACHE_MODE = os.environ.get("CLARR_V2_CACHE_MODE", "readwrite").strip().lower()
if _CACHE_MODE not in {"off", "readwrite", "refresh"}:
    raise ValueError("CLARR_V2_CACHE_MODE must be off, readwrite, or refresh")

_cache_locks_guard = Lock()
_cache_locks: dict[str, Lock] = {}


def _cache_lock(key: str) -> Lock:
    with _cache_locks_guard:
        return _cache_locks.setdefault(key, Lock())


def _atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(
        path.suffix + f".{os.getpid()}.{threading.get_ident()}.tmp"
    )
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def _json_response_is_cacheable(value: str, kwargs: dict) -> bool:
    """Do not checkpoint malformed JSON that would poison an outer retry."""
    response_format = kwargs.get("response_format") or {}
    if response_format.get("type") != "json_object":
        return True
    text = str(value).strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    try:
        return isinstance(json.loads(text), dict)
    except (TypeError, ValueError, json.JSONDecodeError):
        return False


def _checkpoint_namespace(prompt: str, kwargs: dict) -> str:
    stage = llm_client.infer_call_stage(prompt)
    if stage != "unclassified":
        return stage.replace("/", "_")
    if float(kwargs.get("temperature", 0.2)) == 0.0:
        return "deterministic_unclassified"
    return "generation_unclassified"


def _checkpoint_key(namespace: str, prompt: str, args: tuple, kwargs: dict) -> str:
    payload = {
        "schema": V2_CACHE_SCHEMA,
        "namespace": namespace,
        "model": llm_client.MODEL,
        "thinking": llm_client.THINKING_OVERRIDE,
        "prompt": prompt,
        "args": list(args),
        "kwargs": kwargs,
    }
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode(
            "utf-8"
        )
    ).hexdigest()

# ---------------------------------------------------------------------------
# (3) 前缀规范化的 repair-alignment planner prompt。
# 静态段（协议 + 输出 schema）与 v1 逐字相同；动态段顺序见下方 _v2_… 组装。
# ---------------------------------------------------------------------------
_PLANNER_STATIC = """You are executing one bounded repair packet. Do not rewrite the article.
The packet may merge compatible Fidelity, ICL and GCL instructions so they can be
executed in this single call. Return JSON only. The caller applies exact local patches and then re-scores fidelity,
ICL, GCL/schema-support, ECL continuity, length, and non-regression.

EXECUTION PROTOCOL
1. Execute every selected instruction in this one response. Normally use one patch per
   instruction. When selected instructions name each other in
   compatible_composite_instruction_ids, combine them into one smallest shared patch
   and list every bound ID in instruction_ids and every scope in instruction_scope_ids.
   Each patch must echo the packet strategy_scope_id. Never combine non-overlapping
   instructions or borrow permission across their scopes.
2. Use only that instruction's allowed_operations, target_spans, target ID namespace,
   and exact source_evidence_choices. If no choices are listed, source_evidence must
   still be an exact non-empty SOURCE ARTICLE quote, except nonfactual GCL support or deletion.
   Put fidelity IDs in claim_ids, ICL IDs in term_ids, and GCL IDs in
   schema_support_ids; never copy an ID into another namespace.
3. anchor_sentence must be one exact unique sentence from CURRENT CANDIDATE SENTENCE ANCHORS.
   It must also appear in that instruction's allowed_anchor_sentences.
   replace/delete must use an exact target_span in that anchor. Insertions use target_span="".
4. Make the smallest change. Text outside the target span is immutable. Do not fix a
   deferred instruction and do not change an unselected ICL/ECL/GCL strategy. Deferred
   instruction bodies are intentionally hidden; if an ID is not in
   selected_instruction_ids, it must not appear in patches or self_check.
5. Preserve every protected paragraph, claim, explanation, bridge, guidance strategy,
   analogy, term, number, condition, scope, modality, comparison, and causal direction.
   Copy every required_protected_term_id and required_protected_support_id from the
   instruction into the matching patch fields. If an edited target contains a
   required_preserved_claim_anchor, retain that exact phrase in replacement_text;
   it is the sole surviving surface evidence of a passing claim.
   When protected_target_action is present, replacement is mandatory: do not delete
   the target and do not keep the rejected text unchanged. Ground the smallest safe
   replacement in one exact source_evidence_choice.
6. For familiar substitution, replace only the technical surface form; preserve any
   adjacent explanation and all linked facts. Never replace it with a broader/narrower term.
7. For GCL support, use only a nonfactual bridge/cue/direct explanation or an accurate
   relation-preserving analogy. Never invent a mechanism, outcome, application, or example.
8. Respect the LENGTH STATUS section at the end of this prompt: the final body must
   stay within the declared maximum word count. Do not add padding.
9. In self_check, echo every selected instruction_id, assert scope only after checking,
   and state the expected local candidate evidence. The deterministic caller does not
   trust this report and will reject any mismatch.

OUTPUT SCHEMA
{"mode":"repair_alignment","packet_id":"exact packet_id","strategy_scope_id":"exact packet strategy_scope_id","patches":[{"patch_id":"P01","instruction_ids":["one or compatible overlapping selected RA-* IDs"],"strategy_scope_id":"exact packet strategy_scope_id","instruction_scope_ids":["exact scopes of all bound instructions"],"operation":"operation allowed by every bound instruction","anchor_sentence":"exact current sentence","target_span":"exact selected shared span or empty for insertion","replacement_text":"small local replacement","source_evidence":"exact packet choice/source quote or allowed empty","claim_ids":[],"term_ids":[],"schema_support_ids":[],"protected_term_ids":[],"protected_support_ids":[],"reader_language_note":"how local reader language and protected strategy are retained"}],"self_check":{"addressed_instruction_ids":["all selected IDs"],"scope_respected":true,"source_evidence_exact":true,"postconditions":[{"instruction_id":"RA-*","expected_satisfied":true,"candidate_evidence":"expected local result"}]}}"""


def _v2_repair_alignment_patch_prompt(
    *,
    source_text: str,
    candidate: str,
    max_words: int,
    current_words: int,
    packet: dict,
    active_repair_targets: dict | None,
    protected_paragraphs: list | None,
    explanation_protection_contract: dict | None,
    reader_constraints: str,
) -> str:
    """v1 repair_alignment_patch_prompt 的前缀规范化版本。

    段落内容与 v1 逐字一致，仅重排：静态协议/schema 与跨读者共享的 SOURCE、
    读者约束、保护合同在前（可命中 DeepSeek 前缀缓存），每轮变化的
    packet/candidate/anchors 与 LENGTH STATUS 在后。缓存收益层级：
    全项目 44k 配对共享 静态头 → 同篇 18 读者共享 原文 → 同配对各轮共享
    读者/保护合同 → 仅重试间共享 packet/candidate。
    """
    parts = [
        _PLANNER_STATIC,
        "SOURCE ARTICLE\n" + source_text,
        "TARGET READER (preserve register; never infer beliefs/preferences)\n"
        + reader_constraints,
        "EXPLANATION/GUIDANCE/ANALOGY PROTECTION\n"
        + json.dumps(explanation_protection_contract or {}, ensure_ascii=False, indent=2),
        "PROTECTED PASSING PARAGRAPHS\n"
        + json.dumps(protected_paragraphs or [], ensure_ascii=False, indent=2),
        "SELECTED TARGET NAMESPACES (the packet instructions are the sole edit authority)\n"
        + json.dumps(packet.get("active_target_ids", {}), ensure_ascii=False, indent=2),
        render_repair_alignment_packet(packet),
        "CURRENT CANDIDATE\n" + candidate,
        "CURRENT CANDIDATE SENTENCE ANCHORS\n"
        + json.dumps(
            [value for _, _, value in _sentence_spans(candidate)],
            ensure_ascii=False, indent=2,
        ),
        "LENGTH STATUS\nCurrent length: {} words. Maximum: {} words.".format(
            current_words, max_words
        ),
    ]
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# 可恢复的精确 LLM artifact checkpoint
# ---------------------------------------------------------------------------
def _cached_llm_wrapper(real_call):
    """Cache an exact successful response and coalesce concurrent identical calls."""

    def call_llm(prompt, *args, **kwargs):
        if _CACHE_MODE == "off" or not isinstance(prompt, str):
            return real_call(prompt, *args, **kwargs)
        namespace = _checkpoint_namespace(prompt, kwargs)
        key = _checkpoint_key(namespace, prompt, args, kwargs)
        path = _CACHE_DIR / "llm" / namespace / f"{key}.json"
        with _cache_lock(key):
            legacy_extraction = (
                _CACHE_DIR
                / "extraction"
                / (hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:24] + ".txt")
            )
            if (
                namespace == "term_extraction"
                and _CACHE_MODE != "refresh"
                and legacy_extraction.exists()
            ):
                response = legacy_extraction.read_text(encoding="utf-8")
                llm_client.record_local_cache_hit(
                    stage=namespace,
                    cache_key=key[:24],
                    content_chars=len(response),
                )
                return response
            if _CACHE_MODE != "refresh" and path.exists():
                try:
                    cached = json.loads(path.read_text(encoding="utf-8"))
                    if (
                        cached.get("schema") == V2_CACHE_SCHEMA
                        and isinstance(cached.get("response"), str)
                    ):
                        response = str(cached["response"])
                        llm_client.record_local_cache_hit(
                            stage=namespace,
                            cache_key=key[:24],
                            content_chars=len(response),
                        )
                        return response
                except (OSError, ValueError, json.JSONDecodeError):
                    pass
            value = real_call(prompt, *args, **kwargs)
            if isinstance(value, str) and _json_response_is_cacheable(value, kwargs):
                _atomic_write_text(
                    path,
                    json.dumps({
                        "schema": V2_CACHE_SCHEMA,
                        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                        "namespace": namespace,
                        "model": llm_client.MODEL,
                        "response": value,
                    }, ensure_ascii=False),
                )
            return value

    return call_llm


def _patch_llm_checkpoints(v1) -> None:
    """Checkpoint generation/judge calls and prevent first-request cache stampedes."""
    v1.call_llm = _cached_llm_wrapper(v1.call_llm)
    v1.call_ecl_feature_llm = _cached_llm_wrapper(v1.call_ecl_feature_llm)


# ---------------------------------------------------------------------------
# 按模块裁剪 reader payload，避免每次都携带身份/兴趣/阅读场景
# ---------------------------------------------------------------------------
_reader_views: dict[str, dict[str, str]] = {}
_reader_views_lock = Lock()


def _normalized_motivation(profile: dict) -> str:
    raw = str(profile.get("schema", {}).get("reading_motivation", "")).strip().lower()
    return {
        "analysis": "learning",
        "analytic": "learning",
        "analytical": "learning",
        "analytical_reading": "learning",
        "practice": "utility/practice",
        "practical": "utility/practice",
        "application": "utility/practice",
        "applied": "utility/practice",
        "utility": "utility/practice",
    }.get(raw, raw)


def _build_reader_views(v1, profile: dict) -> dict[str, str]:
    persona = profile.get("persona", {}) or {}
    schema = profile.get("schema", {}) or {}
    k_reader = schema.get("k_reader", "")
    k_label = v1.K_LABELS.get(k_reader, f"k={k_reader}")
    motivation = _normalized_motivation(profile)
    style = str(schema.get("cognitive_style", ""))
    background = "; ".join(
        value for value in (
            str(persona.get("field_of_study", "")).strip(),
            str(persona.get("profession", "")).strip(),
        ) if value
    ) or "general background"
    expertise = json.dumps(
        persona.get("domain_expertise", {}), ensure_ascii=False, separators=(",", ":")
    )
    reader_id = str(profile.get("id", ""))
    schema_block = (
        f"Reader ID: {reader_id}\n"
        f"Prior Knowledge (K): {k_label}\n"
        f"Reading Motivation (P): {motivation}\n"
        f"Cognitive Style (S): {style}"
    )
    return {
        "vtech": (
            f"Reader ID: {reader_id}\nPrior Knowledge: {k_label}\n"
            f"Background: {background}\nDomain Expertise: {expertise}"
        ),
        "icl": schema_block + f"\nRelevant Background: {background}",
        "ecl": (
            f"Reader ID: {reader_id}\nReading Motivation (P): {motivation}\n"
            f"Cognitive Style (S): {style}"
        ),
        "gcl": schema_block + (
            f"\nRelevant Background: {background}\nDomain Expertise: {expertise}"
        ),
        "repair": schema_block + f"\nRelevant Background: {background}",
    }


def _reader_view(reader: str, lane: str) -> str:
    with _reader_views_lock:
        return _reader_views.get(reader, {}).get(lane, reader)


def _patch_reader_views(v1) -> None:
    original_score = v1.score_terms_for_reader
    original_il = v1.prompt_IL_strategy
    original_el = v1.prompt_EL_strategy
    original_gl = v1.prompt_GL_strategy

    def format_reader(profile: dict) -> str:
        views = _build_reader_views(v1, profile)
        repair_view = views["repair"]
        with _reader_views_lock:
            _reader_views[repair_view] = views
        return repair_view

    def score_terms_for_reader(
        terms_raw, article_text, reader_str, article_title="", llm_call_fn=None
    ):
        return original_score(
            terms_raw,
            article_text,
            _reader_view(reader_str, "vtech"),
            article_title=article_title,
            llm_call_fn=llm_call_fn,
        )

    def prompt_il(
        text, scored_terms_block, reader, orig_words, max_words,
        icl_claim_alignment_contract=None,
    ):
        return original_il(
            text, scored_terms_block, _reader_view(reader, "icl"), orig_words,
            max_words, icl_claim_alignment_contract,
        )

    def prompt_el(text, reader, IL_strategy, ecl_preference_alignment_contract=None):
        return original_el(
            text, _reader_view(reader, "ecl"), IL_strategy,
            ecl_preference_alignment_contract,
        )

    def prompt_gl(text, reader, EL_strategy, gcl_schema_alignment_contract=None):
        return original_gl(
            text, _reader_view(reader, "gcl"), EL_strategy,
            gcl_schema_alignment_contract,
        )

    v1.format_reader = format_reader
    v1.score_terms_for_reader = score_terms_for_reader
    v1.prompt_IL_strategy = prompt_il
    v1.prompt_EL_strategy = prompt_el
    v1.prompt_GL_strategy = prompt_gl


# ---------------------------------------------------------------------------
# 验证 payload 精简：删掉审计器用不到的 canonical/rationale/metrics 副本
# ---------------------------------------------------------------------------
def compact_claim_validation(value: dict) -> dict:
    assessments = []
    for item in value.get("assessments", []) or []:
        if not isinstance(item, dict):
            continue
        assessments.append({
            key: item.get(key)
            for key in ("claim_id", "verdict", "failed_slots", "candidate_span")
            if item.get(key) not in (None, "", [], {})
        })
    unsupported = []
    for item in value.get("unsupported_claims", []) or []:
        if not isinstance(item, dict):
            continue
        unsupported.append({
            key: item.get(key)
            for key in (
                "candidate_span", "severity", "closest_source_span", "reason",
            )
            if item.get(key) not in (None, "", [], {})
        })
    return {
        "assessments": assessments,
        "unsupported_claims": unsupported,
        "hard_fidelity_pass": bool(
            (value.get("metrics") or {}).get("hard_fidelity_pass", False)
        ),
    }


def _patch_compact_validation_prompts() -> None:
    original_il = il_fidelity.il_compliance_prompt
    original_schema = schema_support.schema_support_prompt

    def il_prompt(source_text, candidate, term_contract, claim_validation):
        return original_il(
            source_text,
            candidate,
            term_contract,
            compact_claim_validation(claim_validation),
        )

    def schema_prompt(
        source_text, candidate, schema_support_contract, claim_validation,
        explanation_protection_contract=None,
    ):
        return original_schema(
            source_text,
            candidate,
            schema_support_contract,
            compact_claim_validation(claim_validation),
            explanation_protection_contract,
        )

    il_fidelity.il_compliance_prompt = il_prompt
    schema_support.schema_support_prompt = schema_prompt


# ---------------------------------------------------------------------------
# 原文基线：Fidelity 身份结果确定化 + ECL 按文章×风格复用
# ---------------------------------------------------------------------------
def deterministic_source_claim_validation(
    source_text: str, claim_contract: list[dict], policy
) -> dict:
    assessments = []
    for claim in claim_contract:
        evidence = next(
            (
                str(span) for span in claim.get("source_evidence", [])
                if str(span) and str(span) in source_text
            ),
            "",
        )
        assessments.append({
            "claim_id": str(claim.get("claim_id", "")),
            "tier": str(claim.get("tier", "core")),
            "canonical_proposition": str(
                claim.get("canonical_proposition", "")
            ),
            "verdict": "entailed_exact",
            "failed_slots": [],
            "candidate_span": evidence,
            "reason": "identity baseline: candidate is the unchanged source",
        })
    result = {
        "assessments": assessments,
        "unsupported_claims": [],
        "double_checked": False,
        "validation_method": "deterministic_source_identity",
    }
    result = fidelity_repair.apply_lexical_anchor_checks(
        result, source_text, claim_contract
    )
    result["metrics"] = fidelity_repair.score_validation(result, policy)
    return result


def _source_ecl_key(source_text: str, preference: str) -> str:
    payload = {
        "schema": V2_CACHE_SCHEMA,
        "kind": "source_ecl_baseline",
        "source_sha256": hashlib.sha256(source_text.encode("utf-8")).hexdigest(),
        "preference": str(preference).strip().title(),
        "model": llm_client.MODEL,
        "thinking": llm_client.THINKING_OVERRIDE,
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True).encode("utf-8")
    ).hexdigest()


def cached_source_ecl_score(v1, source_text: str, preference: str, item_id: str) -> dict:
    key = _source_ecl_key(source_text, preference)
    path = _CACHE_DIR / "source_ecl" / f"{key}.json"
    with _cache_lock("source_ecl:" + key):
        if _CACHE_MODE != "refresh" and path.exists():
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                if value.get("cache_schema") == V2_CACHE_SCHEMA:
                    llm_client.record_local_cache_hit(
                        stage="source_baseline.ecl_record",
                        cache_key=key[:24],
                    )
                    result = copy.deepcopy(value["score"])
                    result["requested_item_id"] = item_id
                    return result
            except (KeyError, OSError, ValueError, json.JSONDecodeError):
                pass
        stable_id = "source_" + key[:16]
        result = v1.score_ecl_candidate(
            source_text,
            source_text,
            preference,
            stable_id,
            v1.call_ecl_feature_llm,
        )
        if _CACHE_MODE != "off":
            _atomic_write_text(
                path,
                json.dumps({
                    "cache_schema": V2_CACHE_SCHEMA,
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "score": result,
                }, ensure_ascii=False),
            )
        result = copy.deepcopy(result)
        result["requested_item_id"] = item_id
        return result


def _patch_source_baseline(v1) -> None:
    def evaluate_source_three_dimension_baseline(
        *, source_text, claim_contract, il_term_contract,
        schema_support_contract, preference, item_id, policy,
    ):
        source_claim_validation = deterministic_source_claim_validation(
            source_text, claim_contract, policy
        )
        with v1.ThreadPoolExecutor(
            max_workers=3, thread_name_prefix="clarr-source-baseline"
        ) as pool:
            il_future = pool.submit(
                v1.validate_il_compliance,
                source_text,
                source_text,
                il_term_contract,
                source_claim_validation,
                v1.call_llm,
            )
            gcl_future = pool.submit(
                v1.evaluate_schema_support,
                source_text,
                source_text,
                schema_support_contract,
                source_claim_validation,
                v1.call_llm,
                {},
            )
            ecl_future = pool.submit(
                cached_source_ecl_score,
                v1,
                source_text,
                preference,
                item_id + "_source_baseline",
            )
            il_evaluation = il_future.result()
            schema_evaluation = gcl_future.result()
            ecl_evaluation = ecl_future.result()
        value = build_three_dimension_score(
            candidate=source_text,
            il_evaluation=il_evaluation,
            ecl_evaluation=ecl_evaluation,
            schema_evaluation=schema_evaluation,
            stage="source_before_strategy",
        )
        value["claim_validation"] = source_claim_validation
        value["cost_optimization"] = {
            "source_fidelity": "deterministic_identity",
            "source_ecl_cache_key": _source_ecl_key(source_text, preference)[:24],
        }
        return value

    v1.evaluate_source_three_dimension_baseline = (
        evaluate_source_three_dimension_baseline
    )


def _patch_result_provenance(v1) -> None:
    original_process = v1.process_article_for_reader

    def process_article_for_reader(*args, **kwargs):
        result = original_process(*args, **kwargs)
        result["cost_optimization_v2"] = {
            "schema_version": V2_CACHE_SCHEMA,
            "cache_mode": _CACHE_MODE,
            "cache_dir": str(_CACHE_DIR),
            "source_fidelity": "deterministic_identity",
            "source_ecl_cache_scope": "article_sha256+cognitive_style",
            "reader_payload": "lane_specific_compact",
            "claim_validation_prompt": "compact_verdict_packet",
            "exact_llm_artifact_checkpoint": _CACHE_MODE != "off",
        }
        return result

    v1.process_article_for_reader = process_article_for_reader


# ---------------------------------------------------------------------------
# 应用入口
# ---------------------------------------------------------------------------
_APPLIED = False


def apply_v2(verbose: bool = True):
    """在当前进程内启用全部 v2 优化；返回已打补丁的 v1 模块。"""
    global _APPLIED
    os.environ.setdefault("LLM_RUN_TAG", "v2")
    import core as v1

    if _APPLIED:
        return v1

    _patch_llm_checkpoints(v1)
    _patch_reader_views(v1)
    _patch_compact_validation_prompts()
    _patch_source_baseline(v1)
    _patch_result_provenance(v1)
    fidelity_repair.repair_alignment_patch_prompt = _v2_repair_alignment_patch_prompt
    _APPLIED = True

    if verbose:
        print(
            "[v2] patched: exact artifact checkpoints + deterministic source "
            "fidelity + article/style source-ECL cache + staged reader views + "
            "compact validation payloads + prefix-canonical repair planner; "
            f"cache_mode={_CACHE_MODE}; "
            "LLM_RUN_TAG=" + os.environ["LLM_RUN_TAG"],
            flush=True,
        )
    return v1
