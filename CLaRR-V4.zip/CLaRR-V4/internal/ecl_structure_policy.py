#!/usr/bin/env python3
"""Deterministic components and contracts for ECL Structure v3.1."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

import spacy
from markdown_it import MarkdownIt

from ecl_structure import active_feature_names, candidate_structure_facts


ROOT = Path(__file__).resolve().parent
PROMPT_DIR = ROOT / "ecl_prompts/policy"
FEATURE_SCHEMA_VERSION = "ecl-structure-feature-v1.1"
OUTPUT_SCHEMA_VERSION = "ecl-structure-auto-v1.1"
DIMENSION_TO_PROMPT = {
    "S-COHERENCE": "coherence.md",
    "S-PROPORTIONALITY-INTERNAL": "proportionality_internal.md",
    "S-NONMECHANICAL": "nonmechanical.md",
    "S-LOGICAL-ORGANIZATION": "logical_organization.md",
    "S-EMOTIONAL-PROGRESSION": "emotional_progression.md",
}

_PARSER = MarkdownIt("commonmark")
_NLP = spacy.blank("en")


class ECLV31Error(ValueError):
    pass


@dataclass(frozen=True)
class ExpansionPolicy:
    max_unpenalized_ratio: float = 1.30


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def visible_markdown_text(markdown: str) -> str:
    """Extract all visible inline text once, including headings and list items."""
    chunks: list[str] = []
    for token in _PARSER.parse(markdown):
        if token.type != "inline":
            continue
        for child in token.children or []:
            if child.type in {"text", "code_inline", "math_inline", "image"}:
                chunks.append(child.content)
            elif child.type in {"softbreak", "hardbreak"}:
                chunks.append(" ")
        chunks.append(" ")
    return "".join(chunks).strip()


def frozen_word_number_count(text: str, *, markdown: bool) -> int:
    visible = visible_markdown_text(text) if markdown else text
    return sum(
        1 for token in _NLP.make_doc(visible)
        if token.is_alpha or token.like_num
    )


def length_expansion_component(
    source_text: str,
    candidate_markdown: str,
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    """Return the frozen asymmetric expansion cap; length alone never scores 0."""
    policy = policy or ExpansionPolicy()
    source_tokens = frozen_word_number_count(source_text, markdown=False)
    candidate_tokens = frozen_word_number_count(candidate_markdown, markdown=True)
    base = {
        "tokenizer": "spacy.blank('en')",
        "count_rule": "token.is_alpha or token.like_num",
        "candidate_visible_text_rule": "all CommonMark inline visible text",
        "source_token_count": source_tokens,
        "candidate_token_count": candidate_tokens,
        "max_unpenalized_ratio": policy.max_unpenalized_ratio,
        "lower_ratio_penalty": False,
        "length_alone_can_score_zero": False,
    }
    if source_tokens == 0:
        return {
            **base,
            "status": "U_ZERO_SOURCE_DENOMINATOR",
            "candidate_source_ratio": None,
            "expansion_cap": "U",
        }
    if candidate_tokens == 0:
        return {
            **base,
            "status": "U_ZERO_CANDIDATE",
            "candidate_source_ratio": 0.0,
            "expansion_cap": "U",
        }
    ratio = candidate_tokens / source_tokens
    cap = "2" if ratio <= policy.max_unpenalized_ratio else "1"
    return {
        **base,
        "status": "OK",
        "candidate_source_ratio": ratio,
        "expansion_cap": cap,
    }


def combine_proportionality(internal_score: str, expansion: Mapping[str, Any]) -> dict[str, Any]:
    internal = str(internal_score).upper()
    cap = str(expansion.get("expansion_cap", "U")).upper()
    if internal not in {"0", "1", "2", "U"}:
        raise ECLV31Error(f"invalid internal proportionality score: {internal!r}")
    if cap not in {"1", "2", "U"}:
        raise ECLV31Error(f"invalid expansion cap: {cap!r}")
    final = "U" if "U" in {internal, cap} else str(min(int(internal), int(cap)))
    return {
        "internal_score": internal,
        "expansion_cap": cap,
        "final_score": final,
        "formula": "min(internal_score, expansion_cap)",
        "cap_applied": final != internal and final != "U",
    }


def feature_prompt(dimension: str, item_id: str, preference: str, candidate: str) -> str:
    if dimension not in DIMENSION_TO_PROMPT:
        raise ECLV31Error(f"unknown v3.1 dimension: {dimension}")
    rubric = (PROMPT_DIR / DIMENSION_TO_PROMPT[dimension]).read_text(encoding="utf-8")
    payload = {
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "dimension": dimension,
        "candidate_markdown": candidate,
        "deterministic_structure_facts": candidate_structure_facts(candidate),
    }
    return rubric + "\n\n## Item\n\n" + json.dumps(payload, ensure_ascii=False, indent=2)


def _json_object(raw: str) -> dict[str, Any]:
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise ECLV31Error("feature response did not contain JSON")
        value = json.loads(match.group())
    if not isinstance(value, dict):
        raise ECLV31Error("feature response must be an object")
    return value


def parse_feature_response(
    raw: str,
    *,
    dimension: str,
    item_id: str,
    candidate: str,
) -> dict[str, Any]:
    value = _json_object(raw)
    if value.get("schema_version") != FEATURE_SCHEMA_VERSION:
        raise ECLV31Error("feature schema_version mismatch")
    if str(value.get("item_id", "")) != str(item_id):
        raise ECLV31Error("feature item_id mismatch")
    if value.get("dimension") != dimension:
        raise ECLV31Error("feature dimension mismatch")
    score = str(value.get("score", "")).upper()
    if score not in {"0", "1", "2", "U"}:
        raise ECLV31Error(f"invalid feature score: {score!r}")
    rationale = str(value.get("rationale", "")).strip()
    repair = str(value.get("repair_instruction", "")).strip()
    confidence = str(value.get("confidence", "")).strip().lower()
    if not rationale:
        raise ECLV31Error("feature rationale is required")
    if score in {"0", "1"} and not repair:
        raise ECLV31Error("failed feature requires repair_instruction")
    if score == "2" and repair:
        raise ECLV31Error("feature score 2 requires empty repair_instruction")
    if score == "U" and confidence != "low":
        raise ECLV31Error("feature U requires low confidence")
    if score != "U" and confidence not in {"high", "medium", "low"}:
        raise ECLV31Error("invalid feature confidence")
    evidence = value.get("candidate_evidence", [])
    if not isinstance(evidence, list):
        evidence = []
    exact = [quote for quote in evidence if isinstance(quote, str) and quote in candidate][:2]
    tags = value.get("failure_tags", [])
    if not isinstance(tags, list):
        tags = []
    return {
        "score": score,
        "candidate_evidence": exact,
        "rationale": rationale,
        "failure_tags": [str(tag).strip() for tag in tags if str(tag).strip()],
        "repair_instruction": repair,
        "confidence": confidence,
        "evidence_sanitized": exact != evidence,
    }


def build_score_record(
    *,
    item_id: str,
    preference: str,
    source_text: str,
    candidate: str,
    feature_results: Mapping[str, Mapping[str, Any]],
    policy: ExpansionPolicy | None = None,
) -> dict[str, Any]:
    active = active_feature_names(preference)
    expected = {
        "S-COHERENCE",
        "S-PROPORTIONALITY-INTERNAL",
        "S-NONMECHANICAL",
        active[-1],
    }
    if set(feature_results) != expected:
        raise ECLV31Error(f"feature result set mismatch: expected {sorted(expected)}")
    expansion = length_expansion_component(source_text, candidate, policy)
    proportionality = combine_proportionality(
        feature_results["S-PROPORTIONALITY-INTERNAL"]["score"], expansion
    )
    features: dict[str, Any] = {}
    for name in active:
        if name == "S-PROPORTIONALITY":
            internal = dict(feature_results["S-PROPORTIONALITY-INTERNAL"])
            features[name] = {
                **internal,
                "score": proportionality["final_score"],
                "internal_score": proportionality["internal_score"],
                "expansion_cap": proportionality["expansion_cap"],
                "cap_applied": proportionality["cap_applied"],
            }
        else:
            features[name] = dict(feature_results[name])
    scores = [features[name]["score"] for name in active]
    aggregate = "U" if "U" in scores else str(min(int(score) for score in scores))
    passed = None if aggregate == "U" else int(aggregate == "2")
    repair_targets = [name for name in active if features[name]["score"] in {"0", "1"}]
    return {
        "schema_version": OUTPUT_SCHEMA_VERSION,
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "source_sha256": sha256_text(source_text),
        "candidate_sha256": sha256_text(candidate),
        "expansion": expansion,
        "proportionality_components": proportionality,
        "features": features,
        "derived": {
            "active_features": list(active),
            "p_structure_score": aggregate,
            "p_structure_pass": passed,
            "repair_targets": repair_targets,
        },
        "policy": asdict(policy or ExpansionPolicy()),
    }

