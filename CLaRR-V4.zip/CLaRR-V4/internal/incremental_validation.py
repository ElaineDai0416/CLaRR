"""Target-scoped post-patch validation for the isolated CLaRR v3 entry.

The patch applicator has already proved that text outside its exact sentence
anchors is unchanged.  This module therefore re-judges only claim/term/bridge
rows connected to those anchors, while retaining a whole-candidate audit for
new unsupported claims, guidance, grounding, and analogies.  Merged metrics are
always recomputed over the complete contract before the existing non-regression
gate sees the result.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import fidelity_repair
import il_fidelity
import schema_support


# V3 keeps the original whole-candidate schema audit.  A later isolated entry
# may install a conservative decider that proves a local patch cannot affect
# any currently detected schema-support span.
SCHEMA_RECHECK_DECIDER = None
LOCAL_REVIEW_PACKET_BUILDER = None


def _ids(values: Any) -> set[str]:
    if isinstance(values, dict):
        values = values.keys()
    return {str(value) for value in (values or []) if str(value)}


def _patch_values(application: dict[str, Any], key: str) -> set[str]:
    return {
        str(value)
        for patch in application.get("patches", [])
        for value in patch.get(key, [])
        if str(value)
    }


def _touched_text(application: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for patch in application.get("patches", []):
        for key in ("anchor_sentence", "target_span"):
            value = str(patch.get(key, "")).strip()
            if value:
                values.append(value)
        values.extend(
            str(value).strip()
            for value in patch.get("touched_unsupported_spans", [])
            if str(value).strip()
        )
    return list(dict.fromkeys(values))


def _overlaps_touched(span: str, touched: list[str]) -> bool:
    value = str(span).strip()
    return bool(value and any(value in item or item in value for item in touched))


def _merge_by_id(previous: list[dict], updated: list[dict], key: str,
                 order: list[str]) -> list[dict]:
    merged = {str(item.get(key, "")): deepcopy(item) for item in previous}
    merged.update({str(item.get(key, "")): deepcopy(item) for item in updated})
    return [merged[value] for value in order if value in merged]


def evaluate_repair_proposal(
    *,
    source_text: str,
    previous_content: str,
    proposed_content: str,
    claim_contract: list[dict],
    previous_validation: dict,
    il_term_contract: list[dict],
    previous_il_evaluation: dict,
    schema_support_contract: dict | None,
    previous_schema_evaluation: dict | None,
    explanation_protection_contract: dict | None,
    active_targets: dict,
    candidate_application: dict,
    llm_call,
    policy,
) -> tuple[dict, dict, dict | None]:
    """Return full-shaped evaluations after target-scoped LLM re-judgment."""
    touched = _touched_text(candidate_application)

    claim_ids = _ids(active_targets.get("claim")) | _patch_values(
        candidate_application, "claim_ids"
    )
    term_ids = _ids(active_targets.get("il")) | _patch_values(
        candidate_application, "term_ids"
    )
    support_ids = _ids(active_targets.get("schema")) | _patch_values(
        candidate_application, "schema_support_ids"
    )

    for term in il_term_contract:
        term_id = str(term.get("term_id", ""))
        prior = next((item for item in previous_il_evaluation.get("assessments", [])
                      if str(item.get("term_id", "")) == term_id), {})
        if term_id in term_ids or _overlaps_touched(prior.get("observed_span", ""), touched):
            term_ids.add(term_id)
            claim_ids.update(_ids(term.get("linked_claim_ids")))

    bridge_requirements = (schema_support_contract or {}).get("bridges", [])
    for bridge in bridge_requirements:
        support_id = str(bridge.get("support_id", ""))
        if support_id in support_ids or str(bridge.get("term_id", "")) in term_ids:
            support_ids.add(support_id)
            claim_ids.update(_ids(bridge.get("linked_claim_ids")))

    claim_subset = [
        item for item in claim_contract if str(item.get("claim_id", "")) in claim_ids
    ]
    review_source = source_text
    review_candidate = proposed_content
    review_packet_meta: dict[str, Any] = {"scope": "whole_candidate"}
    if callable(LOCAL_REVIEW_PACKET_BUILDER):
        packet = LOCAL_REVIEW_PACKET_BUILDER(
            source_text=source_text,
            previous_content=previous_content,
            proposed_content=proposed_content,
            claim_subset=claim_subset,
            term_contract=il_term_contract,
            term_ids=term_ids,
            previous_validation=previous_validation,
            previous_il_evaluation=previous_il_evaluation,
            candidate_application=candidate_application,
        )
        if isinstance(packet, dict):
            review_source = str(packet.get("source_text") or source_text)
            review_candidate = str(packet.get("candidate_text") or proposed_content)
            review_packet_meta = dict(packet.get("metadata") or review_packet_meta)
    local_validation = fidelity_repair.validate_candidate(
        review_source, review_candidate, claim_subset, llm_call, policy
    )
    assessments = _merge_by_id(
        previous_validation.get("assessments", []),
        local_validation.get("assessments", []),
        "claim_id",
        [str(item.get("claim_id", "")) for item in claim_contract],
    )
    unsupported = [
        deepcopy(item) for item in previous_validation.get("unsupported_claims", [])
        if not _overlaps_touched(item.get("candidate_span", ""), touched)
    ]
    seen = {
        " ".join(str(item.get("candidate_span", "")).lower().split())
        for item in unsupported
    }
    for item in local_validation.get("unsupported_claims", []):
        key = " ".join(str(item.get("candidate_span", "")).lower().split())
        if key and key not in seen:
            unsupported.append(deepcopy(item))
            seen.add(key)
    validation = {
        "assessments": assessments,
        "unsupported_claims": unsupported,
        "double_checked": bool(local_validation.get("double_checked", False)),
        "incremental_validation": {
            "claim_ids": sorted(claim_ids),
            "claim_rows_rejudged": len(claim_subset),
            "unsupported_addition_scope": (
                "whole_candidate"
                if str(review_packet_meta.get("scope", "")).startswith("whole_")
                else "exact_changed_sentence_packet"
            ),
            "review_packet": review_packet_meta,
        },
    }
    validation = fidelity_repair.apply_lexical_anchor_checks(
        validation, proposed_content, claim_contract
    )
    validation["metrics"] = fidelity_repair.score_validation(validation, policy)

    term_subset = [
        item for item in il_term_contract if str(item.get("term_id", "")) in term_ids
    ]
    local_il = il_fidelity.validate_il_compliance(
        review_source, review_candidate, term_subset, validation, llm_call
    )
    il_assessments = _merge_by_id(
        previous_il_evaluation.get("assessments", []),
        local_il.get("assessments", []),
        "term_id",
        [str(item.get("term_id", "")) for item in il_term_contract],
    )
    il_evaluation = {
        "assessments": il_assessments,
        "metrics": il_fidelity.score_il_compliance(il_assessments),
        "evaluated": bool(il_term_contract),
        "incremental_validation": {
            "term_ids": sorted(term_ids),
            "term_rows_rejudged": len(term_subset),
            "review_packet": review_packet_meta,
        },
    }

    if not schema_support_contract:
        return validation, il_evaluation, None

    if (
        callable(SCHEMA_RECHECK_DECIDER)
        and previous_schema_evaluation is not None
        and not SCHEMA_RECHECK_DECIDER(
            candidate_application=candidate_application,
            active_targets=active_targets,
            support_ids=support_ids,
            previous_schema_evaluation=previous_schema_evaluation,
        )
    ):
        reused_schema = deepcopy(previous_schema_evaluation)
        reused_schema["incremental_validation"] = {
            "support_ids": sorted(support_ids),
            "bridge_rows_rejudged": 0,
            "global_support_audits": [],
            "schema_reused": True,
            "reuse_reason": "v4_conservative_literal_patch_proof",
        }
        return validation, il_evaluation, reused_schema

    subset_contract = deepcopy(schema_support_contract)
    subset_contract["bridges"] = [
        item for item in bridge_requirements
        if str(item.get("support_id", "")) in support_ids
    ]
    protection = deepcopy(explanation_protection_contract or {})
    protection["explanations"] = [
        item for item in protection.get("explanations", [])
        if str(item.get("support_id", "")) in support_ids
    ]
    # Analogy protection is global because any local edit may change its frame.
    local_schema = schema_support.evaluate_schema_support(
        source_text,
        proposed_content,
        subset_contract,
        validation,
        llm_call,
        protection,
    )
    previous_schema_evaluation = previous_schema_evaluation or {}
    bridges = _merge_by_id(
        previous_schema_evaluation.get("bridges", []),
        local_schema.get("bridges", []),
        "support_id",
        [str(item.get("support_id", "")) for item in bridge_requirements],
    )
    merged_schema = {
        key: deepcopy(value)
        for key, value in local_schema.items()
        if key not in {"bridges", "metrics", "evaluated"}
    }
    merged_schema["bridges"] = bridges
    merged_schema["metrics"] = schema_support.score_schema_support(
        merged_schema, schema_support_contract.get("weights")
    )
    merged_schema["evaluated"] = True
    merged_schema["incremental_validation"] = {
        "support_ids": sorted(support_ids),
        "bridge_rows_rejudged": len(subset_contract["bridges"]),
        "global_support_audits": ["guidance", "grounding", "analogies"],
    }
    return validation, il_evaluation, merged_schema
