"""V2 ablation pipeline: V1 behaviour + prompt-identical LLM memoization.

Rationale (2026-08-31 token anatomy): per (article x reader) pair the V1
pipeline re-sends byte-identical prompts that do not depend on the reader —

  * prompt_term_extraction(article_text)          — the code itself marks it
    "reader-agnostic"; V1 re-extracts the same article 18 readers x 2
    ICL-bearing variants = 36 times per part;
  * the two source-baseline fidelity verifications validate_candidate(
    source, source, claim_contract) — no reader component, identical for
    every pair of the article across all variants.

V2 wraps every LLM call in a persistent sha256(prompt+kwargs)-keyed cache.
Prompts are never rewritten, reordered, or trimmed — a cache hit means the
exact same request string was already answered, so the model sees exactly
what it would have seen under V1.  Stochastic calls (temperature 0.2) are
memoized: an identical request returns the recorded sample instead of a new
one.  Per-part effect (part_1 anatomy): ~3 calls and ~5.4k prompt + ~1.8k
completion tokens per pair served from cache, ~13% cheaper and ~2 calls
faster per pair.

The cache is shared across variants and across driver restarts (resume/
catchup passes reload it), stored under cache_v2/.  Single-flight: when 16
workers hit the same article's shared prompts concurrently, one caller
performs the call and the rest reuse the result.
"""

from __future__ import annotations

import atexit
import hashlib
import json
import os
import threading
from pathlib import Path
from typing import Any, Callable

import ablation_core as ap
from ablation_core import ABLATION_SPECS, AblationSpec, resolve_spec  # noqa: F401

HERE = Path(__file__).resolve().parent
CACHE_DIR = HERE / "cache_v2"
CACHE_PATH = CACHE_DIR / "llm_cache.json"
STATS_PATH = CACHE_DIR / "stats.json"

ABLATION_SCHEMA_VERSION_V2 = "clarr-module-ablation-v2.0.0"

_FLUSH_EVERY = 8  # dirty entries between atomic flushes; cheap for a few MB


class PersistentPromptCache:
    """Thread-safe, single-flight, disk-persisted memoization of LLM calls."""

    def __init__(self, path: Path = CACHE_PATH) -> None:
        self.path = path
        self.stats_path = path.parent / "stats.json"
        self._lock = threading.Lock()
        self._store: dict[str, str] | None = None
        self._inflight: dict[str, threading.Event] = {}
        self._dirty = 0
        self.stats = {"hits": 0, "misses": 0,
                      "saved_prompt_chars": 0, "saved_completion_chars": 0}

    # ── internals ────────────────────────────────────────────────────────────
    def _load(self) -> dict[str, str]:
        with self._lock:
            if self._store is None:
                try:
                    self._store = json.loads(self.path.read_text("utf-8"))
                    if not isinstance(self._store, dict):
                        self._store = {}
                except FileNotFoundError:
                    self._store = {}
                except Exception as exc:  # corrupt cache must not kill a batch
                    print(f"[v2-cache] WARNING unreadable {self.path.name} "
                          f"({exc}); starting empty")
                    self._store = {}
            return self._store

    @staticmethod
    def _key(fn_id: str, prompt: str, kwargs: dict[str, Any]) -> str:
        payload = json.dumps(
            [fn_id, prompt, sorted(kwargs.items())], ensure_ascii=False
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _flush(self) -> None:
        with self._lock:
            if self._store is None or self._dirty == 0:
                return
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".json.tmp")
            temporary.write_text(
                json.dumps(self._store, ensure_ascii=False), encoding="utf-8"
            )
            os.replace(temporary, self.path)
            self.stats_path.write_text(
                json.dumps(self.stats, ensure_ascii=False, indent=1),
                encoding="utf-8",
            )
            self._dirty = 0

    # ── public ───────────────────────────────────────────────────────────────
    def call(
        self,
        fn_id: str,
        underlying: Callable[..., str],
        prompt: str,
        **kwargs: Any,
    ) -> str:
        key = self._key(fn_id, prompt, kwargs)
        store = self._load()
        while True:
            with self._lock:
                cached = store.get(key)
                if cached is not None:
                    self.stats["hits"] += 1
                    self.stats["saved_prompt_chars"] += len(prompt)
                    self.stats["saved_completion_chars"] += len(cached)
                    return cached
                event = self._inflight.get(key)
                owner = event is None
                if owner:
                    event = threading.Event()
                    self._inflight[key] = event
            if not owner:
                event.wait()
                with self._lock:
                    cached = store.get(key)
                if cached is not None:
                    self.stats["hits"] += 1
                    self.stats["saved_prompt_chars"] += len(prompt)
                    self.stats["saved_completion_chars"] += len(cached)
                    return cached
                continue  # owner failed; take over (or follow the next owner)
            try:
                value = underlying(prompt, **kwargs)
                with self._lock:
                    store[key] = value
                    self.stats["misses"] += 1
                    self._dirty += 1
                    should_flush = self._dirty >= _FLUSH_EVERY
                if should_flush:
                    self._flush()
                return value
            finally:
                with self._lock:
                    self._inflight.pop(key, None)
                event.set()

    def evict(
        self,
        fn_id: str,
        prompt: str,
        call_kwargs: dict[str, Any],
        *,
        expected_value: str | None = None,
    ) -> bool:
        """Remove exactly one cached call, optionally with compare-and-delete.

        ``expected_value`` prevents a late reader of a poisoned value from
        deleting a corrected value that another worker has already installed.
        The deletion is flushed immediately so a process restart cannot replay
        the rejected response.
        """
        key = self._key(fn_id, prompt, call_kwargs)
        store = self._load()
        with self._lock:
            current = store.get(key)
            if current is None:
                return False
            if expected_value is not None and current != expected_value:
                return False
            del store[key]
            self._dirty += 1
        self._flush()
        return True

    def summary(self) -> dict[str, Any]:
        with self._lock:
            return {
                **self.stats,
                "entries": len(self._store) if self._store else 0,
            }


CACHE = PersistentPromptCache()


def _report() -> None:
    CACHE._flush()
    s = CACHE.summary()
    if s["hits"] or s["misses"]:
        approx_tokens = (s["saved_prompt_chars"] + s["saved_completion_chars"]) // 2
        print(f"[v2-cache] calls served from cache={s['hits']} "
              f"live={s['misses']} entries={s['entries']} "
              f"saved≈{approx_tokens:,} tokens (chars p={s['saved_prompt_chars']:,} "
              f"c={s['saved_completion_chars']:,})")


atexit.register(_report)


def _cached(fn_id: str, underlying: Callable[..., str]) -> Callable[..., str]:
    def wrapped(prompt: str, **kwargs: Any) -> str:
        return CACHE.call(fn_id, underlying, prompt, **kwargs)
    return wrapped


_main_llm = _cached("main", ap.raise_output_cap(ap.core.call_llm))
_feature_llm = _cached("feature", ap.raise_output_cap(ap.core.call_ecl_feature_llm))


def process_article_for_reader_ablation_v2(
    article_id: str,
    article_text: str,
    reader_profile: dict[str, Any],
    article_claim_record: dict[str, Any],
    simplification_ledger: dict[str, Any] | None = None,
    *,
    variant: str | AblationSpec,
    article_title: str = "",
    fidelity_policy: Any = None,
    enable_repair: bool = True,
    ecl_repair_rounds: int = 1,
    max_total_repair_attempts: int = 3,
    ecl_calibration_mode: bool = False,
    llm_call: Callable[..., str] | None = None,
    feature_llm_call: Callable[..., str] | None = None,
) -> dict[str, Any]:
    """V1 pipeline with memoized LLM calls; identical prompts, identical flow."""
    result = ap.process_article_for_reader_ablation(
        article_id,
        article_text,
        reader_profile,
        article_claim_record,
        simplification_ledger,
        variant=variant,
        article_title=article_title,
        fidelity_policy=fidelity_policy,
        enable_repair=enable_repair,
        ecl_repair_rounds=ecl_repair_rounds,
        max_total_repair_attempts=max_total_repair_attempts,
        ecl_calibration_mode=ecl_calibration_mode,
        llm_call=llm_call or _main_llm,
        feature_llm_call=feature_llm_call or _feature_llm,
    )
    ablation = dict(result.get("ablation") or {})
    ablation["schema_version"] = ABLATION_SCHEMA_VERSION_V2
    ablation["pipeline_variant"] = "v2-prompt-identical-memoization"
    ablation["token_optimization"] = {
        "mode": "sha256(prompt+kwargs) persistent cache, single-flight",
        "prompts_modified": False,
        "cache_shared_across": ["readers", "variants", "resume_passes"],
        "stochastic_note": (
            "temperature-0.2 calls are memoized: identical requests return the "
            "recorded sample instead of resampling"
        ),
        "parent_schema_version": ap.ABLATION_SCHEMA_VERSION,
    }
    result["ablation"] = ablation
    return result


__all__ = [
    "ABLATION_SCHEMA_VERSION_V2",
    "ABLATION_SPECS",
    "CACHE",
    "PersistentPromptCache",
    "process_article_for_reader_ablation_v2",
    "resolve_spec",
]
