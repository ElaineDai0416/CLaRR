#!/usr/bin/env python3
"""Evaluate-first, dimension-targeted ECL Structure repair.

The repair engine is deliberately separate from the scorer and from the
pipeline's existing fidelity/IL/minimal-edit/style gates. A proposal is accepted
only when the unchanged external gate passes, every active ECL feature is
non-regressing, and the aggregate ECL rank strictly improves.
"""

from __future__ import annotations

import copy
import json
import math
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any, Callable, Mapping

from ecl_structure import candidate_structure_facts
from ecl_structure_policy import ExpansionPolicy, frozen_word_number_count, sha256_text
from ecl_structure_calibration import score_candidate as score_candidate_v32


class ECLRepairV32Error(ValueError):
    pass


@dataclass(frozen=True)
class ECLRepairV32Policy:
    max_rounds: int = 2
    require_existing_gate: bool = True
    require_no_active_regression: bool = True
    require_preservation_self_check: bool = True
    max_unpenalized_ratio: float = 1.30
    # Calibration is diagnostic-only. Two independent scores are required to
    # distinguish stable ECL improvement from repeated-Judge instability.
    calibration_repetitions: int = 0


def global_token_budget(
    score: Mapping[str, Any],
    *,
    maximum_final_words: int | None = None,
    current_candidate_words: int | None = None,
) -> dict[str, Any]:
    """Return both the frozen ECL cap and the pipeline's absolute word cap."""
    expansion = score.get("expansion", {})
    try:
        source_tokens = int(expansion["source_token_count"])
        current_tokens = int(expansion["candidate_token_count"])
        threshold = float(expansion["max_unpenalized_ratio"])
    except (KeyError, TypeError, ValueError):
        return {"status": "U_MISSING_EXPANSION_BUDGET"}
    if source_tokens <= 0:
        return {"status": "U_ZERO_SOURCE_DENOMINATOR"}
    maximum = math.floor(source_tokens * threshold + 1e-9)
    result = {
        "status": "OK",
        "source_token_count": source_tokens,
        "current_candidate_tokens": current_tokens,
        "max_unpenalized_ratio": threshold,
        "maximum_final_tokens": maximum,
        "remaining_headroom": maximum - current_tokens,
        "required_reduction": max(0, current_tokens - maximum),
    }
    if maximum_final_words is not None:
        result.update({
            "main_pipeline_maximum_final_words": int(maximum_final_words),
            "current_candidate_words": current_candidate_words,
            "main_pipeline_remaining_word_headroom": (
                int(maximum_final_words) - int(current_candidate_words)
                if current_candidate_words is not None else None
            ),
        })
    return result


def _markdown_blocks(markdown: str) -> list[str]:
    return [block.strip() for block in re.split(r"\n\s*\n", markdown.strip()) if block.strip()]


def _prose_paragraph_block_indices(candidate: str) -> list[int]:
    """Map scorer paragraph IDs P01/P02/... to 1-based Markdown block indices."""
    blocks = _markdown_blocks(candidate)
    paragraphs = [
        str(item["paragraph_text"])
        for item in candidate_structure_facts(candidate)["prose_paragraphs"]
    ]
    indices: list[int] = []
    search_from = 0
    for paragraph in paragraphs:
        for block_index in range(search_from, len(blocks)):
            if blocks[block_index] == paragraph:
                indices.append(block_index + 1)
                search_from = block_index + 1
                break
    return indices


def _explicit_prose_paragraphs(text: str, paragraph_count: int) -> list[int]:
    """Extract explicit `Paragraph 2` / `P02` references, including simple ranges."""
    if not text or paragraph_count <= 0:
        return []
    found: set[int] = set()
    for match in re.finditer(
        r"\b(?:paragraphs?|paras?)\s*(\d{1,2})(?:\s*[-–—]\s*(\d{1,2}))?\b",
        text,
        flags=re.IGNORECASE,
    ):
        start = int(match.group(1))
        end = int(match.group(2) or start)
        if start > end:
            start, end = end, start
        found.update(range(start, end + 1))
    for match in re.finditer(
        r"\bP0*(\d{1,2})(?:\s*[-–—]\s*P?0*(\d{1,2}))?\b",
        text,
        flags=re.IGNORECASE,
    ):
        start = int(match.group(1))
        end = int(match.group(2) or start)
        if start > end:
            start, end = end, start
        found.update(range(start, end + 1))
    return sorted(index for index in found if 1 <= index <= paragraph_count)


def _named_prose_region(text: str, paragraph_count: int) -> list[int]:
    """Resolve opening/middle/final language used by judge repair instructions."""
    if not text or paragraph_count <= 0:
        return []
    normalized = text.lower()
    # Judge rationales usually state the successful context first and the failure
    # after however/but/yet.  Inspect the contrast tail before treating a positive
    # mention (for example, "sustains through the middle") as the edit target.
    segments = [
        segment.strip(" ,;:")
        for segment in re.split(r"\b(?:however|but|yet)\b", normalized)
        if segment.strip(" ,;:")
    ]
    ordered_segments = list(reversed(segments[1:])) + [segments[0]] if len(segments) > 1 else segments
    for segment in ordered_segments:
        if re.search(r"\b(?:final|last|closing)\s+(?:paragraph|section|block)\b", segment):
            return [paragraph_count]
        if re.search(r"\b(?:middle|central|interior)\s+(?:paragraph|section|region|block|explanation)s?\b", segment):
            if paragraph_count >= 3:
                return list(range(2, paragraph_count))
            return list(range(1, paragraph_count + 1))
        if re.search(r"\b(?:opening|first|introductory)\s+(?:paragraph|section|block)\b", segment):
            return [1]
        if re.search(r"\b(?:conclusion|closing)\b", segment):
            return [paragraph_count]
    return []


def _instruction_prose_targets(target: Mapping[str, Any], paragraph_count: int) -> tuple[list[int], str]:
    """Prefer where-to-edit instructions over endpoint evidence quoted by a judge."""
    sources = (
        ("repair_instruction_explicit", str(target.get("repair_instruction", "")), True),
        ("rationale_explicit", str(target.get("rationale", "")), True),
        ("rationale_region", str(target.get("rationale", "")), False),
        ("repair_instruction_region", str(target.get("repair_instruction", "")), False),
    )
    for label, text, explicit in sources:
        indices = (
            _explicit_prose_paragraphs(text, paragraph_count)
            if explicit
            else _named_prose_region(text, paragraph_count)
        )
        if indices:
            return indices, label
    return [], "candidate_evidence"


def target_paragraph_locators(
    candidate: str,
    targets: list[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Locate the paragraph that must actually be changed for each repair target."""
    blocks = _markdown_blocks(candidate)
    prose_block_indices = _prose_paragraph_block_indices(candidate)
    locators: list[dict[str, Any]] = []
    for target in targets:
        dimension = str(target.get("dimension", ""))
        if dimension == "S-PROPORTIONALITY-EXPANSION":
            continue
        evidence = [
            value for value in target.get("candidate_evidence", [])
            if isinstance(value, str) and value.strip()
        ]
        evidence_indices = sorted({
            index + 1
            for index, block in enumerate(blocks)
            for quote in evidence
            if quote in block
        })
        prose_targets, locator_source = _instruction_prose_targets(
            target, len(prose_block_indices)
        )
        instruction_indices = [
            prose_block_indices[index - 1]
            for index in prose_targets
            if 1 <= index <= len(prose_block_indices)
        ]
        indices = instruction_indices or evidence_indices
        target_block_texts = [
            {"block_index": index, "block_text": blocks[index - 1]}
            for index in indices
            if 1 <= index <= len(blocks)
        ]
        locators.append({
            "dimension": dimension,
            "candidate_evidence": evidence,
            "locator_source": locator_source if instruction_indices else "candidate_evidence",
            "target_prose_paragraph_ids": [f"P{index:02d}" for index in prose_targets]
            if instruction_indices else [],
            "instruction_block_indices": instruction_indices,
            "evidence_block_indices": evidence_indices,
            "target_block_indices": indices,
            "target_block_texts": target_block_texts,
            "coverage_checkable": bool(indices),
        })
    return locators


def _changed_before_block_indices(before: str, after: str) -> list[int]:
    """Return 1-based original block indices touched by the actual proposal diff."""
    before_blocks = _markdown_blocks(before)
    after_blocks = _markdown_blocks(after)
    changed: set[int] = set()
    matcher = SequenceMatcher(a=before_blocks, b=after_blocks, autojunk=False)
    for tag, i1, i2, _j1, _j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        if tag in {"replace", "delete"}:
            changed.update(range(i1 + 1, i2 + 1))
        elif tag == "insert":
            # An inserted block affects its adjacent original boundary.  End-only
            # additions therefore map only to the final original block, not to a
            # target in a distant middle block.
            if before_blocks:
                if i1 > 0:
                    changed.add(i1)
                if i1 < len(before_blocks):
                    changed.add(i1 + 1)
    return sorted(changed)


def _sentence_units(text: str) -> list[str]:
    return [
        unit.strip()
        for unit in re.split(r"(?<=[.!?])\s+", text.strip())
        if unit.strip()
    ]


def _changed_sentence_unit_count(before: str, after: str) -> int:
    """Count actual sentence-level insertions, deletions, or replacements."""
    matcher = SequenceMatcher(
        a=_sentence_units(before),
        b=_sentence_units(after),
        autojunk=False,
    )
    count = 0
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "equal":
            count += max(i2 - i1, j2 - j1)
    return count


def _requires_distributed_emotional_edit(targets: list[Mapping[str, Any]]) -> bool:
    for target in targets:
        if str(target.get("dimension")) != "S-EMOTIONAL-PROGRESSION":
            continue
        audit_text = " ".join([
            str(target.get("rationale", "")),
            str(target.get("repair_instruction", "")),
            " ".join(str(value) for value in target.get("failure_tags", [])),
        ]).lower()
        if any(token in audit_text for token in (
            "middle", "static", "intermittent", "technical_renaming", "translation layer",
        )):
            return True
    return False


def target_paragraph_coverage(
    before: str,
    after: str,
    targets: list[Mapping[str, Any]],
) -> dict[str, Any]:
    locators = target_paragraph_locators(before, targets)
    changed = _changed_before_block_indices(before, after)
    checks = []
    for locator in locators:
        target_indices = locator["target_block_indices"]
        checkable = bool(locator["coverage_checkable"])
        touched = bool(set(target_indices) & set(changed)) if checkable else None
        checks.append({**locator, "target_touched": touched})
    failed = [
        check["dimension"] for check in checks
        if check["coverage_checkable"] and check["target_touched"] is False
    ]
    return {
        "changed_before_block_indices": changed,
        "targets": checks,
        "failed_dimensions": failed,
        "overall_pass": not failed,
    }


def proposal_action_compliance(
    before: str,
    proposed: str,
    score: Mapping[str, Any],
    targets: list[Mapping[str, Any]],
    *,
    maximum_final_words: int | None = None,
    count_words: Callable[[str], int] | None = None,
) -> dict[str, Any]:
    """Deterministically verify that the proposal performed its requested action."""
    before_words = count_words(before) if count_words is not None else None
    proposed_words = (
        count_words(proposed) if count_words is not None and proposed else 0
    )
    budget = global_token_budget(
        score,
        maximum_final_words=maximum_final_words,
        current_candidate_words=before_words,
    )
    before_tokens = frozen_word_number_count(before, markdown=True)
    proposed_tokens = frozen_word_number_count(proposed, markdown=True) if proposed else 0
    maximum = budget.get("maximum_final_tokens")
    ecl_token_budget_pass = (
        proposed_tokens <= int(maximum)
        if budget.get("status") == "OK" and maximum is not None
        else True
    )
    main_word_budget_pass = (
        int(proposed_words) <= int(maximum_final_words)
        if maximum_final_words is not None and proposed_words is not None
        else True
    )
    headroom_pass = ecl_token_budget_pass and main_word_budget_pass
    coverage = target_paragraph_coverage(before, proposed, targets) if proposed else {
        "changed_before_block_indices": [],
        "targets": [],
        "failed_dimensions": [],
        "overall_pass": False,
    }
    expansion_target = any(
        target.get("dimension") == "S-PROPORTIONALITY-EXPANSION" for target in targets
    )
    emotional_distributed_required = _requires_distributed_emotional_edit(targets)
    changed_sentence_units = _changed_sentence_unit_count(before, proposed) if proposed else 0
    emotional_distributed_pass = (
        changed_sentence_units >= 2 if emotional_distributed_required else True
    )
    changed = bool(proposed and proposed != before)
    return {
        "changed": changed,
        "before_candidate_tokens": before_tokens,
        "proposed_candidate_tokens": proposed_tokens,
        "token_delta": proposed_tokens - before_tokens,
        "maximum_final_tokens": maximum,
        "ecl_token_budget_pass": ecl_token_budget_pass,
        "before_candidate_words": before_words,
        "proposed_candidate_words": proposed_words,
        "maximum_final_words": maximum_final_words,
        "main_word_budget_pass": main_word_budget_pass,
        "budget_violations": [
            name for name, passed in (
                ("ecl_visible_token_cap", ecl_token_budget_pass),
                ("main_pipeline_max_words", main_word_budget_pass),
            ) if not passed
        ],
        "remaining_headroom_after": (
            int(maximum) - proposed_tokens if maximum is not None else None
        ),
        "global_token_budget_pass": headroom_pass,
        "expansion_target_present": expansion_target,
        "expansion_progress": expansion_target and proposed_tokens < before_tokens,
        "target_paragraph_coverage": coverage,
        "target_paragraph_coverage_pass": bool(coverage["overall_pass"]),
        "changed_sentence_units": changed_sentence_units,
        "emotional_distributed_edit_required": emotional_distributed_required,
        "emotional_distributed_edit_pass": emotional_distributed_pass,
        "overall_pass": (
            changed and headroom_pass and bool(coverage["overall_pass"])
            and emotional_distributed_pass
        ),
    }


def _json_object(raw: str) -> dict[str, Any]:
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise ECLRepairV32Error("repair response did not contain JSON")
        value = json.loads(match.group())
    if not isinstance(value, dict):
        raise ECLRepairV32Error("repair response must be a JSON object")
    return value


def _gate_pass(result: Mapping[str, Any]) -> bool:
    if "overall_pass" in result:
        return bool(result["overall_pass"])
    selected = result.get("selected_control_gate")
    if isinstance(selected, Mapping) and "overall_pass" in selected:
        return bool(selected["overall_pass"])
    if "release_ready" in result:
        return bool(result["release_ready"])
    raise ECLRepairV32Error(
        "existing gate must expose overall_pass, selected_control_gate.overall_pass, or release_ready"
    )


def protected_dimensions(score: Mapping[str, Any]) -> list[dict[str, Any]]:
    protected = []
    for name in score["derived"]["active_features"]:
        feature = score["features"][name]
        if feature["score"] == "2":
            protected.append({
                "dimension": name,
                "score": "2",
                "candidate_evidence": feature.get("candidate_evidence", []),
                "protection": "do not intentionally edit; post-repair score must remain 2",
            })
    prop = score["features"].get("S-PROPORTIONALITY")
    if prop and prop.get("score") != "2" and prop.get("internal_score") == "2":
        protected.append({
            "dimension": "S-PROPORTIONALITY-INTERNAL",
            "score": "2",
            "candidate_evidence": prop.get("candidate_evidence", []),
            "protection": "shortening must not create internal imbalance",
        })
    return protected


def _target_is_allowed(
    dimension: str,
    allowed_target_dimensions: set[str] | None,
) -> bool:
    if allowed_target_dimensions is None:
        return True
    if dimension in allowed_target_dimensions:
        return True
    return bool(
        dimension.startswith("S-PROPORTIONALITY-")
        and "S-PROPORTIONALITY" in allowed_target_dimensions
    )


def select_repair_targets(
    score: Mapping[str, Any],
    allowed_target_dimensions: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Return failed targets, optionally scoped to source-identified dimensions."""
    targets: list[dict[str, Any]] = []
    for name in score["derived"]["active_features"]:
        feature = score["features"][name]
        if name != "S-PROPORTIONALITY":
            if feature["score"] in {"0", "1"} and _target_is_allowed(
                name, allowed_target_dimensions
            ):
                targets.append({"dimension": name, **dict(feature)})
            continue
        internal = str(feature.get("internal_score", feature.get("score", "U")))
        if internal in {"0", "1"} and _target_is_allowed(
            "S-PROPORTIONALITY-INTERNAL", allowed_target_dimensions
        ):
            targets.append({
                "dimension": "S-PROPORTIONALITY-INTERNAL",
                "score": internal,
                "candidate_evidence": feature.get("candidate_evidence", []),
                "rationale": feature.get("rationale", ""),
                "failure_tags": feature.get("failure_tags", []),
                "repair_instruction": feature.get("repair_instruction", ""),
            })
        if str(feature.get("expansion_cap")) == "1" and _target_is_allowed(
            "S-PROPORTIONALITY-EXPANSION", allowed_target_dimensions
        ):
            expansion = score["expansion"]
            source_tokens = int(expansion["source_token_count"])
            current_tokens = int(expansion["candidate_token_count"])
            threshold = float(expansion["max_unpenalized_ratio"])
            max_tokens = math.floor(source_tokens * threshold + 1e-9)
            targets.append({
                "dimension": "S-PROPORTIONALITY-EXPANSION",
                "score": "1",
                "source_token_count": source_tokens,
                "candidate_token_count": current_tokens,
                "current_ratio": expansion["candidate_source_ratio"],
                "max_unpenalized_ratio": threshold,
                "maximum_candidate_tokens": max_tokens,
                "minimum_tokens_to_remove": max(0, current_tokens - max_tokens),
                "rationale": "candidate/source visible-token ratio exceeds the frozen 1.30 threshold",
                "repair_instruction": (
                    "Remove only redundant framing, repeated explanation, decorative analogies, or "
                    "duplicated summaries until the candidate is within the deterministic token cap."
                ),
            })
    budget = global_token_budget(score)
    return [{**target, "global_token_budget": dict(budget)} for target in targets]


def repair_prompt(
    candidate: str,
    preference: str,
    score: Mapping[str, Any],
    rubric_version: str = "v3.2",
    prior_attempt_feedback: str = "",
    allowed_target_dimensions: set[str] | None = None,
    maximum_final_words: int | None = None,
    count_words: Callable[[str], int] | None = None,
) -> str:
    targets = select_repair_targets(score, allowed_target_dimensions)
    protected = protected_dimensions(score)
    token_budget = global_token_budget(
        score,
        maximum_final_words=maximum_final_words,
        current_candidate_words=(count_words(candidate) if count_words else None),
    )
    paragraph_locators = target_paragraph_locators(candidate, targets)
    action_contracts: list[str] = [
        "- The returned complete candidate MUST differ from the input. Do not merely describe an edit in `changes`; apply it to `repaired_candidate_markdown`."
    ]
    if token_budget.get("status") == "OK":
        maximum_final = int(token_budget["maximum_final_tokens"])
        current_tokens = int(token_budget["current_candidate_tokens"])
        remaining = int(token_budget["remaining_headroom"])
        action_contracts.append(
            f"- GLOBAL TOKEN BUDGET APPLIES TO THIS REPAIR: the complete proposal must contain at "
            f"most {maximum_final} visible tokens. The current candidate has {current_tokens}; "
            f"remaining headroom is {remaining}."
        )
        if remaining < 0:
            action_contracts.append(
                f"- The proposal must remove at least {-remaining} visible tokens before it can be rescored."
            )
        elif remaining <= 10:
            action_contracts.append(
                "- Headroom is very small: use replacement/condensation, not appended wording; prefer net token growth <= 0."
            )
    if maximum_final_words is not None:
        current_words = token_budget.get("current_candidate_words")
        action_contracts.append(
            f"- MAIN PIPELINE LENGTH CAP IS ALSO HARD: the complete proposal must contain at most "
            f"{int(maximum_final_words)} words under the production count_words function"
            + (
                f"; the current candidate has {int(current_words)} words."
                if current_words is not None else "."
            )
        )
    for locator in paragraph_locators:
        if locator["coverage_checkable"]:
            action_contracts.append(
                f"- TARGET BLOCK COVERAGE: {locator['dimension']} must actually modify at least one "
                f"of candidate blocks {locator['target_block_indices']} identified by its exact evidence."
            )
    for target in targets:
        dimension = target["dimension"]
        if dimension == "S-PROPORTIONALITY-EXPANSION":
            maximum = int(target["maximum_candidate_tokens"])
            minimum_remove = int(target["minimum_tokens_to_remove"])
            # A small buffer makes the instruction robust to the model's rough
            # token estimate while the deterministic scorer remains authoritative.
            buffered_maximum = max(1, maximum - max(5, math.ceil(maximum * 0.02)))
            buffered_remove = max(1, int(target["candidate_token_count"]) - buffered_maximum)
            action_contracts.extend([
                f"- EXPANSION IS A HARD NUMERIC TARGET: reduce the complete candidate from "
                f"{target['candidate_token_count']} visible tokens to at most {buffered_maximum} "
                f"visible tokens (the frozen pass boundary is {maximum}).",
                f"- Remove or compress approximately {buffered_remove} tokens, never fewer than "
                f"the measured minimum {minimum_remove}. One cosmetic deletion is insufficient.",
                "- Preserve each unique claim and recommendation by merging repeated formulations, "
                "compressing verbose framing/transitions, and retaining one concise version of repeated explanations.",
            ])
        elif dimension == "S-EMOTIONAL-PROGRESSION":
            action_contracts.extend([
                "- EMOTIONAL PROGRESSION REQUIRES A BLOCK-LEVEL REPAIR: revise the substantial middle "
                "region named by the failure evidence/instruction, not just one noun phrase or one analogy label.",
                "- Treat quoted opening/closing evidence as continuity ANCHORS, not automatic edit locations. "
                "Apply the actual edit inside TARGET PARAGRAPH LOCATORS unless the judge explicitly identifies an endpoint failure.",
                "- CLOSED EVIDENCE LEDGER: the candidate itself is the only evidence available to this repair. Use only a reader "
                "position, felt stake, agency frame, consequence, relation, or analogy that is already explicitly stated in the candidate.",
                "- Shared entities do not license a new relation. Never infer that an existing condition harms, worsens, threatens, "
                "disadvantages, silences, replaces, costs, or puts a livelihood at stake unless that same relation is already explicit.",
                "- Preserve modality exactly: a question stays a question or is restated as its explicit answer; a risk, possibility, "
                "attributed argument, or future concern must not become a present fact, certain effect, or causal mechanism.",
                "- For a static or intermittent middle, revise at least two existing clauses inside the failed middle region: "
                "one clause must reconnect an existing technical fact to the existing reader stake without adding a predicate, and "
                "another must carry that same already-stated stake into the next existing fact or transition. A one-label substitution is insufficient.",
                "- Rewrite two existing explanatory sentences tied to two distinct factual units. Do not satisfy this contract by "
                "inserting a detached slogan such as 'that is a failure you cannot afford'; integrate the existing stake into each explanation.",
                "- Choose the continuity operation from the candidate itself: (A) AGENCY CONTINUITY—if the opening defines a reader role "
                "such as you/designer/architect/user, keep that same role active as the decision-maker or affected person in two target "
                "explanations; or (B) CONSEQUENCE CONTINUITY—if the candidate explicitly states a felt consequence such as silent "
                "damage, wear and tear, failure, cost, or loss, reuse that exact consequence without strengthening or extending it.",
                "- Merely repeating frame words such as crash, system, threat, or pressure after an otherwise unchanged technical analogy "
                "does not create progression. The reader role or existing consequence must change the relational wording of the factual sentence.",
                "- If the failure identifies an analogy stack, revise or remove at least two disjoint rhetorical comparisons and map those "
                "same underlying propositions back to one analogy family already established in the candidate. Do not retain the stack and add a slogan.",
                "- For an endpoint-only failure, rewrite the identified final paragraph in place so it returns to the existing "
                "reader stake. Do not append a second conclusion.",
                "- You MAY revise, replace, or consolidate a purely rhetorical analogy when the listed failure identifies it as "
                "static or disjointed. Preserve the underlying factual proposition and use the candidate's already-established frame; "
                "do not add a new factual example or a new analogy family.",
                "- Prefer substitutions and merged clauses over additions. When headroom is small, make the Emotional repair "
                "token-neutral or shorter. Do not strengthen causality (for example with 'guarantees') or add a new imperative/advice.",
                "- SAFE OPERATIONS are limited to reordering existing clauses, replacing a rhetorical question with a declarative "
                "restatement already answered by the candidate, reusing an existing entity with its existing modality, and adding "
                "neutral anaphora such as 'this concern' or 'the same issue'. If two source-licensed edits cannot be made, do not invent them.",
            ])
            if (
                token_budget.get("status") == "OK"
                and int(token_budget.get("remaining_headroom", 0)) <= 10
            ):
                action_contracts.extend([
                    "- SMALL-HEADROOM EMOTIONAL REPAIR: the returned candidate must be no longer than the current candidate, "
                    f"which has {int(token_budget['current_candidate_tokens'])} visible tokens. The global maximum "
                    f"is {int(token_budget['maximum_final_tokens'])}, but do not consume its remaining headroom.",
                    "- Rewrite or compress the identified target paragraph in place. Delete generic lead-in or redundant "
                    "resource wording to pay for continuity language; an em-dash append or added final clause is noncompliant.",
                ])
        elif dimension in {"S-COHERENCE", "S-LOGICAL-ORGANIZATION"}:
            action_contracts.append(
                f"- {dimension} requires repairing the failed relation or block named in its repair_instruction; "
                "a synonym-only edit is insufficient."
            )
        elif dimension == "S-NONMECHANICAL":
            action_contracts.append(
                "- Remove or integrate the identified template-like scaffolding itself; a synonym-only edit is insufficient."
            )
    action_contract = "\n".join(action_contracts)
    emotional_target_present = any(
        target.get("dimension") == "S-EMOTIONAL-PROGRESSION" for target in targets
    )
    emotional_final_checks = "None; no Emotional target is active."
    if emotional_target_present:
        emotional_final_checks = """- Treat any `e.g.` wording in a judge repair_instruction as an illustrative semantic goal, not text to copy. Never paste it after the original sentence.
- Reject the draft if it introduces any new affected group, livelihood effect, harm, disadvantage, loss of voice, causal link, mechanism, or certainty not already explicit in the candidate.
- Reject the draft if a modal claim (`may`, `could`, `risk`, question, attributed view) becomes an asserted present fact or definite consequence.
- If the draft leaves the identified static explanatory sentence(s) unchanged and only inserts a new slogan/consequence sentence, discard that draft and rewrite the original explanatory sentence(s) instead.
- If a small-headroom contract is active and the draft is longer than the current candidate, discard it before returning; shorten the target paragraph and try again.
- Confirm that the same existing reader role or felt consequence now changes the relational wording of at least two distinct factual explanations for a middle failure, or rewrites the original endpoint in place for an endpoint-only failure."""
    feedback_block = prior_attempt_feedback.strip() or "None; this is the first attempt."
    return f"""You are the ECL Structure {rubric_version} repairer in a controlled rewrite pipeline.

Make the smallest possible edit to the candidate Markdown. Repair only the listed
failed dimensions. Dimensions already scored 2 are protected and must not be
intentionally rewritten. The source article is unavailable; this is not a factual
rewrite.

Hard preservation constraints:
- Preserve every factual proposition, entity, quantity, date, condition, example,
  technical term, and reader-directed recommendation already present.
- Add no new fact, example, analogy, causal explanation, or advice.
- Do not remove a unique factual proposition to meet the length cap. Shorten only
  redundant framing, repeated explanation, decorative analogy, duplicated summary,
  or unnecessarily verbose transition wording.
- Keep unaffected sentences/paragraphs byte-for-byte where feasible. Moving an
  intact block is allowed only when a targeted coherence/organization failure
  requires it.
- "Example" above means an evidence-bearing case, scenario, entity, or quantity.
  A purely rhetorical comparison is a presentation device: its wording may be
  shortened or retargeted only when a listed ECL failure requires it, while its
  underlying factual proposition must remain unchanged.
- For an expansion target, semantic propositions—not sentence wording—are protected.
  You are explicitly allowed to paraphrase, merge, and shorten sentences across the
  whole candidate as needed to meet the numeric budget. The byte-for-byte preference
  does not override the hard expansion target.
- Preserve Markdown validity and the declared presentation preference.
- Return JSON only.

Target-specific completion contract:
{action_contract}

PRIOR ATTEMPT FEEDBACK
{feedback_block}
If feedback is present, correct that exact failure; do not repeat the rejected edit.

PRESENTATION PREFERENCE
{preference.strip().title()}

FAILED TARGETS
{json.dumps(targets, ensure_ascii=False, indent=2)}

GLOBAL TOKEN BUDGET
{json.dumps(token_budget, ensure_ascii=False, indent=2)}

TARGET PARAGRAPH LOCATORS
{json.dumps(paragraph_locators, ensure_ascii=False, indent=2)}

PROTECTED PASSING DIMENSIONS/COMPONENTS
{json.dumps(protected, ensure_ascii=False, indent=2)}

CANDIDATE MARKDOWN
{candidate}

MANDATORY EMOTIONAL FINAL REJECTION TESTS
{emotional_final_checks}

Return exactly:
{{
  "repaired_candidate_markdown": "complete candidate",
  "changes": [
    {{"dimension": "one exact failed target", "before": "exact old candidate span", "after": "exact byte-different replacement span present verbatim in repaired_candidate_markdown"}}
  ],
  "preservation_check": {{
    "claims_added": false,
    "claims_deleted": false,
    "quantities_changed": false,
    "terms_changed": false,
    "passed_dimensions_intentionally_edited": false
  }}
}}

Before returning, verify internally that every target-specific completion condition
is satisfied in the actual `repaired_candidate_markdown`. If the first draft does
not satisfy it, revise the draft rather than returning the unchanged input.
For an expansion target, first make an internal inventory of unique claims,
quantities, terms, evidence-bearing examples, and recommendations; then express that
same inventory more concisely. Do not output the inventory.
"""


def _preservation_self_check_pass(value: Any) -> bool:
    if not isinstance(value, Mapping):
        return False
    fields = (
        "claims_added",
        "claims_deleted",
        "quantities_changed",
        "terms_changed",
        "passed_dimensions_intentionally_edited",
    )
    return all(value.get(field) is False for field in fields)


def _score_rank(score: Mapping[str, Any]) -> tuple[int, int, int]:
    values: list[int] = []
    for name in score["derived"]["active_features"]:
        raw = str(score["features"][name]["score"])
        if raw not in {"0", "1", "2"}:
            return (-1, -1, -1)
        values.append(int(raw))
    return min(values), sum(value == 2 for value in values), sum(values)


def _active_regressions(before: Mapping[str, Any], after: Mapping[str, Any]) -> list[str]:
    regressions = []
    for name in before["derived"]["active_features"]:
        old = str(before["features"][name]["score"])
        new = str(after["features"][name]["score"])
        if old in {"0", "1", "2"} and (new not in {"0", "1", "2"} or int(new) < int(old)):
            regressions.append(name)
    return regressions


def _safe_continuous_progress(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
    targets: list[Mapping[str, Any]],
) -> bool:
    """Allow a gated expansion-only draft to become the next working draft.

    The discrete proportionality score stays at 1 until the 1.30 boundary is
    crossed.  Without this working-state rule, several safe reductions can never
    accumulate.  This is not a final acceptance rule: the caller commits only a
    later proposal whose frozen ECL rank strictly improves.
    """
    dimensions = {str(target.get("dimension")) for target in targets}
    if dimensions != {"S-PROPORTIONALITY-EXPANSION"}:
        return False
    try:
        before_ratio = float(before["expansion"]["candidate_source_ratio"])
        after_ratio = float(after["expansion"]["candidate_source_ratio"])
        before_tokens = int(before["expansion"]["candidate_token_count"])
        after_tokens = int(after["expansion"]["candidate_token_count"])
    except (KeyError, TypeError, ValueError):
        return False
    return after_ratio < before_ratio and after_tokens < before_tokens


def _safe_emotional_region_progress(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
    before_candidate: str,
    after_candidate: str,
    targets: list[Mapping[str, Any]],
) -> dict[str, Any] | None:
    """Recognize a gated score-1 draft whose remaining failure moved regions.

    This is working-state progress only.  It never commits a score-1 draft; it
    merely allows the next round to repair the newly isolated region.
    """
    dimensions = {str(target.get("dimension")) for target in targets}
    if dimensions != {"S-EMOTIONAL-PROGRESSION"}:
        return None
    try:
        before_feature = before["features"]["S-EMOTIONAL-PROGRESSION"]
        after_feature = after["features"]["S-EMOTIONAL-PROGRESSION"]
    except KeyError:
        return None
    if str(before_feature.get("score")) != "1" or str(after_feature.get("score")) != "1":
        return None
    after_targets = [
        target for target in select_repair_targets(after)
        if target.get("dimension") == "S-EMOTIONAL-PROGRESSION"
    ]
    if not after_targets:
        return None
    old_locators = target_paragraph_locators(before_candidate, targets)
    new_locators = target_paragraph_locators(after_candidate, after_targets)
    old_ids = {
        paragraph_id
        for locator in old_locators
        for paragraph_id in locator.get("target_prose_paragraph_ids", [])
    }
    new_ids = {
        paragraph_id
        for locator in new_locators
        for paragraph_id in locator.get("target_prose_paragraph_ids", [])
    }
    if not old_ids or not new_ids or not old_ids.isdisjoint(new_ids):
        return None
    return {
        "old_target_prose_paragraph_ids": sorted(old_ids),
        "new_target_prose_paragraph_ids": sorted(new_ids),
        "new_targets": after_targets,
    }


def _with_local_expansion_count(
    score: Mapping[str, Any],
    candidate_tokens: int,
) -> dict[str, Any]:
    """Update only deterministic expansion metadata for a pre-gate working draft."""
    updated = copy.deepcopy(dict(score))
    expansion = updated["expansion"]
    source_tokens = int(expansion["source_token_count"])
    threshold = float(expansion["max_unpenalized_ratio"])
    ratio = candidate_tokens / source_tokens
    expansion["candidate_token_count"] = candidate_tokens
    expansion["candidate_source_ratio"] = ratio
    expansion["expansion_cap"] = "2" if ratio <= threshold else "1"
    if "severe_expansion_audit_ratio" in expansion:
        expansion["severe_expansion_flag"] = (
            ratio >= float(expansion["severe_expansion_audit_ratio"])
        )
    return updated


def validate_and_repair(
    *,
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    score_candidate_call: Callable[[str, str, str, str], Mapping[str, Any]],
    repair_llm_call: Callable[..., str],
    existing_gate: Callable[[str], Mapping[str, Any]] | None,
    policy: ECLRepairV32Policy | None = None,
    existing_gate_policy_id: str = "unchanged-existing-gate",
    repair_rubric_version: str = "v3.2",
    allowed_target_dimensions: set[str] | None = None,
    maximum_final_words: int | None = None,
    count_words: Callable[[str], int] | None = None,
) -> dict[str, Any]:
    """Evaluate first; repair only failures; accept only protected improvement."""
    policy = policy or ECLRepairV32Policy()
    if policy.calibration_repetitions not in {0, 2}:
        raise ECLRepairV32Error("calibration_repetitions must be 0 or 2")
    if maximum_final_words is not None:
        if maximum_final_words <= 0:
            raise ECLRepairV32Error("maximum_final_words must be positive")
        if count_words is None:
            raise ECLRepairV32Error(
                "count_words is required when maximum_final_words is set"
            )
    if policy.require_existing_gate and existing_gate is None:
        raise ECLRepairV32Error("ECL repair requires the existing full validation gate")
    initial_score = dict(score_candidate_call(source_text, candidate, preference, item_id))
    initial_gate = dict(existing_gate(candidate)) if existing_gate else {"overall_pass": True}
    base = {
        "schema_version": "ecl-structure-repair-v1.2",
        "item_id": str(item_id),
        "presentation_preference": preference.strip().title(),
        "existing_gate_policy_id": existing_gate_policy_id,
        "repair_rubric_version": repair_rubric_version,
        "initial_candidate": candidate,
        "initial_candidate_sha256": sha256_text(candidate),
        "initial_ecl_score": initial_score,
        "initial_existing_gate": initial_gate,
        "initial_protected_dimensions": protected_dimensions(initial_score),
        "allowed_target_dimensions": (
            sorted(allowed_target_dimensions)
            if allowed_target_dimensions is not None else None
        ),
        "history": [],
    }
    if not _gate_pass(initial_gate):
        return {
            **base,
            "status": "blocked_by_existing_gate",
            "final_candidate": candidate,
            "final_candidate_sha256": sha256_text(candidate),
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
        }
    initial_scoped_targets = select_repair_targets(
        initial_score, allowed_target_dimensions
    )
    if allowed_target_dimensions is not None and not initial_scoped_targets:
        return {
            **base,
            "status": "source_targets_satisfied_without_repair",
            "final_candidate": candidate,
            "final_candidate_sha256": sha256_text(candidate),
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
        }
    if initial_score["derived"]["p_structure_pass"] == 1:
        return {
            **base,
            "status": "passed_without_repair",
            "final_candidate": candidate,
            "final_candidate_sha256": sha256_text(candidate),
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
        }
    if initial_score["derived"]["p_structure_score"] == "U":
        return {
            **base,
            "status": "unresolved_ecl_score",
            "final_candidate": candidate,
            "final_candidate_sha256": sha256_text(candidate),
            "final_ecl_score": initial_score,
            "final_existing_gate": initial_gate,
            "repair_rounds_attempted": 0,
            "repair_rounds_accepted": 0,
        }

    current_candidate = candidate
    current_score = initial_score
    current_gate = initial_gate
    committed_candidate = candidate
    committed_score = initial_score
    committed_gate = initial_gate
    history: list[dict[str, Any]] = []
    accepted = 0
    prior_attempt_feedback = ""
    for round_index in range(1, policy.max_rounds + 1):
        targets = select_repair_targets(
            current_score, allowed_target_dimensions
        )
        if not targets:
            break
        repair_temperature = 0.0 if round_index == 1 else min(0.3, 0.1 * round_index)
        raw = repair_llm_call(
            repair_prompt(
                current_candidate,
                preference,
                current_score,
                rubric_version=repair_rubric_version,
                prior_attempt_feedback=prior_attempt_feedback,
                allowed_target_dimensions=allowed_target_dimensions,
                maximum_final_words=maximum_final_words,
                count_words=count_words,
            ),
            max_tokens=5000,
            temperature=repair_temperature,
            response_format={"type": "json_object"},
        )
        value = _json_object(raw)
        proposed = str(value.get("repaired_candidate_markdown", "")).strip()
        action_compliance = proposal_action_compliance(
            current_candidate,
            proposed,
            current_score,
            targets,
            maximum_final_words=maximum_final_words,
            count_words=count_words,
        )
        record: dict[str, Any] = {
            "round": round_index,
            "repair_temperature": repair_temperature,
            "targets": [target["dimension"] for target in targets],
            "protected_before": protected_dimensions(current_score),
            "before_sha256": sha256_text(current_candidate),
            "proposal_sha256": sha256_text(proposed) if proposed else "",
            "proposal_candidate": proposed,
            "changes": value.get("changes", []),
            "preservation_check": value.get("preservation_check"),
            "action_compliance": action_compliance,
            "accepted": False,
        }
        if not proposed or proposed == current_candidate:
            record["rejection_reason"] = "action_noncompliance_unchanged"
            history.append(record)
            prior_attempt_feedback = (
                "ACTION NONCOMPLIANCE: the previous repaired_candidate_markdown was empty or "
                "byte-identical to the input even though `changes` claimed an edit. Apply the edit "
                "to the actual candidate. Model-reported token counts are ignored."
            )
            continue
        if policy.require_preservation_self_check and not _preservation_self_check_pass(
            value.get("preservation_check")
        ):
            record["rejection_reason"] = "preservation_self_check_failed"
            history.append(record)
            prior_attempt_feedback = (
                "REJECTED: the previous preservation self-check admitted a prohibited change. "
                "Undo that change and use only allowed structural/relational editing."
            )
            continue
        if not action_compliance["global_token_budget_pass"]:
            proposed_tokens = int(action_compliance["proposed_candidate_tokens"])
            maximum_tokens = int(action_compliance["maximum_final_tokens"])
            overage = proposed_tokens - maximum_tokens
            if (
                action_compliance["expansion_progress"]
                and action_compliance["main_word_budget_pass"]
            ):
                record["advanced_pre_gate_for_retry"] = True
                record["rejection_reason"] = "expansion_target_not_met"
                history.append(record)
                current_candidate = proposed
                current_score = _with_local_expansion_count(current_score, proposed_tokens)
                prior_attempt_feedback = (
                    "DETERMINISTIC TOKEN CHECK FAILED, BUT THE SHORTER DRAFT IS NOW THE WORKING "
                    f"INPUT: actual={proposed_tokens}, maximum={maximum_tokens}, still_remove={overage}. "
                    "Continue from this exact draft. Do not return it unchanged and do not trust or "
                    "repeat a model-estimated token count. This draft has not passed the preservation "
                    "gate or ECL rescoring yet."
                )
                continue
            record["rejection_reason"] = "global_token_headroom_exceeded"
            history.append(record)
            prior_attempt_feedback = (
                "DETERMINISTIC GLOBAL LENGTH BUDGET FAILED: "
                f"visible_tokens={proposed_tokens}/{maximum_tokens}; "
                f"production_words={action_compliance.get('proposed_candidate_words')}/"
                f"{action_compliance.get('maximum_final_words')}; violations="
                f"{json.dumps(action_compliance.get('budget_violations', []))}. "
                "Replace or condense existing wording; do not append text."
            )
            continue
        if not action_compliance["target_paragraph_coverage_pass"]:
            failed_dimensions = action_compliance["target_paragraph_coverage"]["failed_dimensions"]
            record["rejection_reason"] = "target_paragraph_not_touched"
            history.append(record)
            prior_attempt_feedback = (
                "ACTION NONCOMPLIANCE: the actual diff did not touch the required candidate "
                f"block for: {', '.join(failed_dimensions)}. Modify the indicated target block, not "
                "only the introduction or conclusion."
            )
            continue
        if not action_compliance["emotional_distributed_edit_pass"]:
            changed_units = action_compliance["changed_sentence_units"]
            record["rejection_reason"] = "emotional_action_too_local"
            history.append(record)
            prior_attempt_feedback = (
                "EMOTIONAL ACTION NONCOMPLIANCE: the actual diff changed only "
                f"{changed_units} sentence-level unit(s), but this static/intermittent-middle target "
                "requires at least two distributed sentence edits tied to two distinct existing factual "
                "units. Rewrite those existing explanations in place; do not append a detached slogan."
            )
            continue
        proposed_gate = dict(existing_gate(proposed)) if existing_gate else {"overall_pass": True}
        record["existing_gate"] = proposed_gate
        if not _gate_pass(proposed_gate):
            if policy.calibration_repetitions:
                calibration_scores: list[dict[str, Any]] = []
                calibration_errors: list[str] = []
                for repetition in range(1, policy.calibration_repetitions + 1):
                    try:
                        calibration_scores.append(dict(score_candidate_call(
                            source_text,
                            proposed,
                            preference,
                            f"{item_id}__rejected_r{round_index}_cal{repetition}",
                        )))
                    except Exception as exc:  # diagnostic failure must not alter safety
                        calibration_errors.append(
                            f"{type(exc).__name__}: {str(exc).strip()}"
                        )
                signatures = [
                    {
                        name: str((score.get("features", {}).get(name) or {}).get("score", "U"))
                        for name in score.get("derived", {}).get("active_features", [])
                    }
                    for score in calibration_scores
                ]
                ranks = [_score_rank(score) for score in calibration_scores]
                stable = bool(
                    len(calibration_scores) == policy.calibration_repetitions
                    and len({json.dumps(value, sort_keys=True) for value in signatures}) == 1
                )
                stable_improvement = bool(
                    stable
                    and ranks
                    and ranks[0] > _score_rank(current_score)
                    and not _active_regressions(current_score, calibration_scores[0])
                )
                classification = (
                    "calibration_incomplete"
                    if calibration_errors
                    else "judge_repeat_instability"
                    if not stable
                    else "ecl_improved_but_unsafe"
                    if stable_improvement
                    else "ecl_not_improved"
                )
                record["rejected_proposal_ecl_calibration"] = {
                    "mode": "read_only_rejected_proposal",
                    "excluded_from_acceptance": True,
                    "repetitions": policy.calibration_repetitions,
                    "baseline_rank": list(_score_rank(current_score)),
                    "proposal_ranks": [list(value) for value in ranks],
                    "feature_score_signatures": signatures,
                    "judge_repeat_stable": stable,
                    "classification": classification,
                    "errors": calibration_errors,
                    "scores": calibration_scores,
                }
            record["rejection_reason"] = "existing_gate_failed"
            history.append(record)
            prior_attempt_feedback = (
                "REJECTED BY BASELINE-PRESERVATION GATE. Violations: "
                f"{json.dumps(proposed_gate.get('violations', []), ensure_ascii=False)}. "
                f"Rationale: {str(proposed_gate.get('rationale', '')).strip()} "
                "Undo the prohibited content change while still repairing the target."
            )
            continue
        proposed_score = dict(score_candidate_call(source_text, proposed, preference, item_id))
        regressions = _active_regressions(current_score, proposed_score)
        record["ecl_score"] = proposed_score
        record["active_regressions"] = regressions
        if policy.require_no_active_regression and regressions:
            record["rejection_reason"] = "active_ecl_feature_regressed"
            history.append(record)
            prior_attempt_feedback = (
                "REJECTED: the previous proposal regressed protected active features: "
                f"{', '.join(regressions)}. Restore those features while retaining the target repair."
            )
            continue
        if _score_rank(proposed_score) <= _score_rank(current_score):
            if _safe_continuous_progress(current_score, proposed_score, targets):
                record["advanced_for_retry"] = True
                record["rejection_reason"] = "safe_partial_progress_only"
                history.append(record)
                current_candidate = proposed
                current_score = proposed_score
                current_gate = proposed_gate
                prior_attempt_feedback = (
                    "SAFE PARTIAL PROGRESS ONLY: the expansion ratio improved but the frozen score "
                    "has not crossed the pass boundary. Continue compressing this working draft to "
                    f"at most {proposed_score['expansion'].get('max_unpenalized_ratio', 1.3)} times "
                    "the source token count while preserving all protected content."
                )
                continue
            emotional_progress = _safe_emotional_region_progress(
                current_score,
                proposed_score,
                current_candidate,
                proposed,
                targets,
            )
            if emotional_progress:
                record["advanced_for_retry"] = True
                record["emotional_region_progress"] = emotional_progress
                record["rejection_reason"] = "safe_emotional_region_progress_only"
                history.append(record)
                current_candidate = proposed
                current_score = proposed_score
                current_gate = proposed_gate
                prior_attempt_feedback = (
                    "SAFE EMOTIONAL PARTIAL PROGRESS ONLY: the independent judge moved the remaining "
                    "failure from candidate paragraph(s) "
                    f"{', '.join(emotional_progress['old_target_prose_paragraph_ids'])} to "
                    f"{', '.join(emotional_progress['new_target_prose_paragraph_ids'])}. Preserve the "
                    "already-repaired region byte-for-byte where possible and repair only the newly "
                    "isolated target. This score-1 working draft is not a final accepted output."
                )
                continue
            record["rejection_reason"] = "ecl_score_did_not_improve"
            history.append(record)
            unresolved = select_repair_targets(
                proposed_score, allowed_target_dimensions
            )
            prior_attempt_feedback = (
                "REJECTED: the v3.4-r4 score did not improve. Remaining target audit: "
                f"{json.dumps(unresolved, ensure_ascii=False)}. Make a substantive target-specific "
                "repair, not a cosmetic substitution."
            )
            continue
        record["accepted"] = True
        history.append(record)
        current_candidate = proposed
        current_score = proposed_score
        current_gate = proposed_gate
        committed_candidate = proposed
        committed_score = proposed_score
        committed_gate = proposed_gate
        accepted += 1
        if not select_repair_targets(current_score, allowed_target_dimensions):
            break

    scoped_targets_remaining = select_repair_targets(
        committed_score, allowed_target_dimensions
    )
    if allowed_target_dimensions is not None and not scoped_targets_remaining:
        status = "source_targets_satisfied_after_repair"
    elif committed_score["derived"]["p_structure_pass"] == 1:
        status = "passed_after_repair"
    elif accepted:
        status = "improved_but_below_pass"
    else:
        status = "no_acceptable_repair"
    return {
        **base,
        "history": history,
        "status": status,
        "final_candidate": committed_candidate,
        "final_candidate_sha256": sha256_text(committed_candidate),
        "final_ecl_score": committed_score,
        "final_existing_gate": committed_gate,
        "repair_rounds_attempted": len(history),
        "repair_rounds_accepted": accepted,
    }


def validate_and_repair_ecl_v32(
    *,
    source_text: str,
    candidate: str,
    preference: str,
    item_id: str,
    feature_llm_call: Callable[..., str],
    repair_llm_call: Callable[..., str],
    existing_gate: Callable[[str], Mapping[str, Any]] | None,
    policy: ECLRepairV32Policy | None = None,
    existing_gate_policy_id: str = "unchanged-existing-gate",
) -> dict[str, Any]:
    """Convenience entrypoint using the expert-calibrated v3.2 scorer."""
    effective_policy = policy or ECLRepairV32Policy()
    expansion_policy = ExpansionPolicy(effective_policy.max_unpenalized_ratio)

    def scorer(source: str, text: str, pref: str, identifier: str) -> Mapping[str, Any]:
        return score_candidate_v32(
            source,
            text,
            pref,
            identifier,
            feature_llm_call,
            expansion_policy,
        )

    return validate_and_repair(
        source_text=source_text,
        candidate=candidate,
        preference=preference,
        item_id=item_id,
        score_candidate_call=scorer,
        repair_llm_call=repair_llm_call,
        existing_gate=existing_gate,
        policy=effective_policy,
        existing_gate_policy_id=existing_gate_policy_id,
    )
