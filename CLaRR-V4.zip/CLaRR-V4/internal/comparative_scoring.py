"""Comparable ICL/ECL/GCL scoring built from the frozen Repair evaluators.

This module deliberately does not implement another judge.  It only normalizes
the existing IL, ECL v3.4-r4, and schema-support outputs to a common [0, 1]
scale, preserves their executable failure records, and compares the source with
later candidates using the same definitions.
"""

from __future__ import annotations

import hashlib
from typing import Any, Mapping


THREE_DIMENSION_SCORE_VERSION = "clarr-three-dimension-comparison-v1.0.0"
_TOLERANCE = 1e-4


def _bounded(value: Any, default: float = 0.0) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _icl_packet(evaluation: Mapping[str, Any]) -> dict[str, Any]:
    metrics = dict(evaluation.get("metrics") or {})
    semantic = _bounded(metrics.get("term_semantic_preservation_rate"), 1.0)
    strategy = _bounded(metrics.get("required_strategy_compliance_rate"), 1.0)
    explanation = float(bool(metrics.get("explanation_budget_pass", True)))
    failures = []
    for item in evaluation.get("assessments", []) or []:
        if not isinstance(item, Mapping):
            continue
        semantic_failed = not bool(item.get("meaning_preserved", False))
        strategy_failed = bool(item.get("hard_required", True)) and not bool(
            item.get("strategy_compliant", False)
        )
        bad_introductions = [
            value for value in item.get("introduced_propositions", []) or []
            if isinstance(value, Mapping) and str(value.get("verdict", "")) in {
                "unsupported_material", "inappropriate_inference",
                "redundant_restatement", "excessive_supported_detail",
            }
        ]
        if semantic_failed or strategy_failed or bad_introductions:
            failures.append({
                "target_id": str(item.get("term_id", "")),
                "source_term": str(item.get("source_term", "")),
                "meaning_preserved": not semantic_failed,
                "strategy_compliant": bool(item.get("strategy_compliant", False)),
                "observed_span": str(item.get("observed_span", "")),
                "reason": str(item.get("reason", "")),
                "introduced_propositions": bad_introductions,
            })
    return {
        "score": round((semantic + strategy + explanation) / 3.0, 4),
        "components": {
            "semantic_preservation": semantic,
            "required_strategy_compliance": strategy,
            "explanation_budget": explanation,
        },
        "hard_pass": bool(metrics.get("hard_il_pass", False)),
        "failed_target_ids": [value["target_id"] for value in failures],
        "repair_signals": failures,
    }


def _ecl_packet(evaluation: Mapping[str, Any]) -> dict[str, Any]:
    features = dict(evaluation.get("features") or {})
    active = list((evaluation.get("derived") or {}).get("active_features") or [])
    normalized: dict[str, float | None] = {}
    failures = []
    for name in active:
        value = dict(features.get(name) or {})
        raw_score = value.get("score", "U")
        score = None if str(raw_score) == "U" else _bounded(float(raw_score) / 2.0)
        normalized[str(name)] = score
        if score is None or score < 1.0 - _TOLERANCE:
            failures.append({
                "target_id": str(name),
                "score": raw_score,
                "failure_tags": list(value.get("failure_tags") or []),
                "candidate_evidence": list(value.get("candidate_evidence") or []),
                "reason": str(value.get("rationale", "")),
                "repair_instruction": str(value.get("repair_instruction", "")),
            })
    known = [value for value in normalized.values() if value is not None]
    score = sum(known) / len(known) if known and len(known) == len(normalized) else 0.0
    return {
        "score": round(score, 4),
        "components": normalized,
        "hard_pass": (evaluation.get("derived") or {}).get("p_structure_pass") == 1,
        "failed_target_ids": [value["target_id"] for value in failures],
        "repair_signals": failures,
    }


def _gcl_packet(evaluation: Mapping[str, Any]) -> dict[str, Any]:
    metrics = dict(evaluation.get("metrics") or {})
    failures = []
    for item in evaluation.get("bridges", []) or []:
        if isinstance(item, Mapping) and str(item.get("status", "")) != "adequate":
            failures.append({
                "target_id": str(item.get("support_id", "")),
                "target_type": "knowledge_bridge",
                "status": str(item.get("status", "")),
                "candidate_span": str(item.get("candidate_span", "")),
                "reason": str(item.get("reason", "")),
            })
    guidance = evaluation.get("guidance") or {}
    if isinstance(guidance, Mapping) and str(guidance.get("status", "")) != "adequate":
        failures.append({
            "target_id": str(guidance.get("support_id", "")),
            "target_type": "cognitive_guidance",
            "status": str(guidance.get("status", "")),
            "candidate_span": str(guidance.get("candidate_span", "")),
            "reason": str(guidance.get("reason", "")),
        })
    hard_keys = (
        "guidance_coverage_pass", "bridge_fit_pass", "grounding_boundary_pass",
        "analogy_semantic_pass", "narrative_mapping_pass",
        "analogy_complexity_pass", "necessary_explanations_pass",
        "analogy_fallback_pass",
    )
    return {
        "score": round(_bounded(metrics.get("P_gcl"), 0.0), 4),
        "components": {
            "A_B": round(_bounded(metrics.get("A_B"), 0.0), 4),
            "A_Q": round(_bounded(metrics.get("A_Q"), 0.0), 4),
            "P_gcl": round(_bounded(metrics.get("P_gcl"), 0.0), 4),
        },
        "hard_pass": all(bool(metrics.get(key, True)) for key in hard_keys),
        "failed_target_ids": [value["target_id"] for value in failures if value["target_id"]],
        "repair_signals": failures,
    }


def build_three_dimension_score(
    *,
    candidate: str,
    il_evaluation: Mapping[str, Any] | None,
    ecl_evaluation: Mapping[str, Any] | None,
    schema_evaluation: Mapping[str, Any] | None,
    stage: str,
) -> dict[str, Any]:
    """Normalize the three existing evaluator outputs without changing them."""
    modules = {
        "icl": _icl_packet(il_evaluation or {}),
        "ecl": _ecl_packet(ecl_evaluation or {}),
        "gcl": _gcl_packet(schema_evaluation or {}),
    }
    return {
        "schema_version": THREE_DIMENSION_SCORE_VERSION,
        "stage": str(stage),
        "candidate_sha256": hashlib.sha256(candidate.encode("utf-8")).hexdigest(),
        "scale": "normalized_0_to_1",
        "modules": modules,
        "macro_score": round(
            sum(float(value["score"]) for value in modules.values()) / 3.0, 4
        ),
        "raw_evaluations": {
            "icl": dict(il_evaluation or {}),
            "ecl": dict(ecl_evaluation or {}),
            "gcl": dict(schema_evaluation or {}),
        },
    }


def compare_three_dimension_scores(
    baseline: Mapping[str, Any],
    candidate: Mapping[str, Any],
    *,
    tolerance: float = _TOLERANCE,
) -> dict[str, Any]:
    """Apply the source-vs-candidate success rule independently per module."""
    comparisons: dict[str, Any] = {}
    for module in ("icl", "ecl", "gcl"):
        before = float((baseline.get("modules") or {}).get(module, {}).get("score", 0.0))
        after = float((candidate.get("modules") or {}).get(module, {}).get("score", 0.0))
        if before >= 1.0 - tolerance and after >= before - tolerance:
            status = "already_ceiling"
            success = True
        elif after > before + tolerance:
            status = "improved"
            success = True
        elif after < before - tolerance:
            status = "regressed"
            success = False
        else:
            status = "unchanged"
            success = False
        comparisons[module] = {
            "source_score": round(before, 4),
            "candidate_score": round(after, 4),
            "delta": round(after - before, 4),
            "status": status,
            "success": success,
            "remaining_repair_target_ids": list(
                (candidate.get("modules") or {}).get(module, {}).get(
                    "failed_target_ids", []
                )
            ),
        }
    failed = [name for name, value in comparisons.items() if not value["success"]]
    regressed = [
        name for name, value in comparisons.items() if value["status"] == "regressed"
    ]
    return {
        "schema_version": THREE_DIMENSION_SCORE_VERSION,
        "rule": "candidate_score > source_score per dimension; equality is allowed only at source ceiling",
        "modules": comparisons,
        "overall_success": not failed,
        "failed_dimensions": failed,
        "regressed_dimensions": regressed,
    }
