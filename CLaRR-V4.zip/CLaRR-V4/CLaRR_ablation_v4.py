#!/usr/bin/env python3
"""Public entry point for the three controlled CLaRR V4 ablations."""

from __future__ import annotations

import os
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INTERNAL = ROOT / "internal"
EXAMPLES = ROOT / "examples"


def configure_paths() -> None:
    os.environ.setdefault("CLARR_ARTICLES_FILE", str(EXAMPLES / "articles.json"))
    os.environ.setdefault("CLARR_READERS_FILE", str(EXAMPLES / "readers.json"))
    os.environ.setdefault("CLARR_CLAIMS_FILE", str(EXAMPLES / "claims.json"))
    os.environ.setdefault(
        "CLARR_SIMPLIFICATIONS_FILE", str(EXAMPLES / "simplifications.json")
    )
    os.environ.setdefault("CLARR_V2_CACHE_DIR", str(ROOT / ".cache" / "ablation"))
    os.environ.setdefault("LLM_RUN_TAG", "clarr-v4-ablation")


if __name__ == "__main__":
    configure_paths()
    sys.path.insert(0, str(INTERNAL))

    import ablation_v4
    import ablation_runner as runner

    runner.process_article_for_reader_ablation = (
        ablation_v4.process_article_for_reader_ablation_v4
    )
    runner.HERE = ROOT
    runner.main()
